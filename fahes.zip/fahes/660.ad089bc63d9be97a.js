"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[660],{

/***/ 9771:
/*!*************************************************!*\
  !*** ./src/app/core/models/vin-stamoing.dto.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UpdateVinStampingPayload": () => (/* binding */ UpdateVinStampingPayload)
/* harmony export */ });
class UpdateVinStampingPayload {
  constructor(updatedBy, vinSeqId, incrementCount) {
    this.vinSeqId = 0;
    this.categoryId = 0;
    this.seqPrefix = '';
    this.seq = 0;
    this.availableSeqCount = 0;
    this.status = 0;
    this.createdBy = 0;
    this.updatedBy = 0;
    this.incrementCount = 0;
    this.vinSeqId = vinSeqId;
    this.updatedBy = updatedBy;
    this.incrementCount = incrementCount;
  }
}

/***/ }),

/***/ 2067:
/*!**********************************************************************!*\
  !*** ./src/app/core/resolvers/vin-stamping/vin-stamping.resolver.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VinStampingResolver": () => (/* binding */ VinStampingResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 3158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 591);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_vin_stamping_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../services/vin-stamping.service */ 4060);




class VinStampingResolver {
  constructor(_router, _service) {
    this._router = _router;
    this._service = _service;
  }
  resolve(route, state) {
    return this._service.get().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.catchError)(_ => {
      this._router.navigate(['/error']);
      return rxjs__WEBPACK_IMPORTED_MODULE_2__.EMPTY;
    }));
  }
  static #_ = this.ɵfac = function VinStampingResolver_Factory(t) {
    return new (t || VinStampingResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_services_vin_stamping_service__WEBPACK_IMPORTED_MODULE_0__.VinStampingService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: VinStampingResolver,
    factory: VinStampingResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 4060:
/*!*******************************************************!*\
  !*** ./src/app/core/services/vin-stamping.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VinStampingService": () => (/* binding */ VinStampingService)
/* harmony export */ });
/* harmony import */ var _utilities_apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utilities/apis */ 1603);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 5159);



class VinStampingService {
  constructor(_baseService) {
    this._baseService = _baseService;
  }
  get() {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.VinStamping.get, {});
  }
  update(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.VinStamping.update, payload);
  }
  static #_ = this.ɵfac = function VinStampingService_Factory(t) {
    return new (t || VinStampingService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: VinStampingService,
    factory: VinStampingService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 9362:
/*!****************************************************************************************!*\
  !*** ./src/app/features/vin-stamping/vin-stamping-list/vin-stamping-list.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VinStampingListComponent": () => (/* binding */ VinStampingListComponent)
/* harmony export */ });
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/api */ 4356);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/table.enum */ 6592);
/* harmony import */ var src_app_core_models_vin_stamoing_dto__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/vin-stamoing.dto */ 9771);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_app_core_services_vin_stamping_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/vin-stamping.service */ 4060);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/toastr.service */ 8996);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../shared/components/f-table/f-table.component */ 2812);











class VinStampingListComponent {
  constructor(_vinStamping, _route, confirmationService, messageService, _toastr, _translate) {
    this._vinStamping = _vinStamping;
    this._route = _route;
    this.confirmationService = confirmationService;
    this.messageService = messageService;
    this._toastr = _toastr;
    this._translate = _translate;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subscription();
    this.cols = [{
      title: '#',
      col: 'vinSeqId'
    }, {
      title: 'category',
      col: 'category',
      isLocalized: true
    }, {
      title: 'lastIssuedVin',
      col: 'lastIssuedVin'
    }, {
      title: 'RecentIssuedVINNo',
      col: 'seq',
      isNumber: true
    }, {
      title: 'availableSeqCount',
      col: 'availableSeqCount',
      isNumber: true
    }, {
      title: 'Add to VIN Numbers',
      col: 'actions'
    }];
    this.actions = [{
      name: '',
      type: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_0__.TABLE_ACTIONS_TYPES.ADD_TO_VIN
    }];
    this.items = [];
  }
  ngOnInit() {
    this.getResolved();
  }
  get() {
    this._vinStamping.get().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(el => this.mapRes(el))).subscribe(res => {
      this.items = res;
    });
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(el => el['data']), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.map)(el => this.mapRes(el))).subscribe(res => {
      this.items = res;
    });
    this.subscription.add(sub);
  }
  mapRes(res) {
    return res.map(x => {
      return {
        ...x,
        category: {
          NameEn: x.categoryDescEn,
          NameAr: x.categoryDescAr
        }
      };
    });
  }
  addToVin(event) {
    if (event.value > 0) {
      this.confirmationService.confirm({
        message: `${this._translate.instant('AreYouSureThatYouWantToAddValueToVIN', {
          v1: event.value
        })}`,
        header: `${this._translate.instant('Confirmation')}`,
        icon: 'pi pi-exclamation-triangle',
        acceptLabel: `${this._translate.instant('Confirm')}`,
        rejectLabel: `${this._translate.instant('Cancel')}`,
        accept: () => {
          this.update(new src_app_core_models_vin_stamoing_dto__WEBPACK_IMPORTED_MODULE_1__.UpdateVinStampingPayload(4, event.item.vinSeqId, event.value));
        },
        reject: type => {
          switch (type) {
            case primeng_api__WEBPACK_IMPORTED_MODULE_7__.ConfirmEventType.REJECT:
              this.messageService.add({
                severity: 'error',
                summary: this._translate.instant('Rejected'),
                detail: this._translate.instant('You have rejected')
              });
              break;
            case primeng_api__WEBPACK_IMPORTED_MODULE_7__.ConfirmEventType.CANCEL:
              this.messageService.add({
                severity: 'warn',
                summary: this._translate.instant('Cancelled'),
                detail: this._translate.instant('You have cancelled')
              });
              break;
          }
        }
      });
    }
  }
  update(payload) {
    this._vinStamping.update(payload).subscribe(res => {
      this._toastr.showSuccess(this._translate.instant('Amount Added Successfully!'));
      this.get();
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function VinStampingListComponent_Factory(t) {
    return new (t || VinStampingListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_vin_stamping_service__WEBPACK_IMPORTED_MODULE_2__.VinStampingService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_7__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_7__.MessageService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_3__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_10__.TranslateService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: VinStampingListComponent,
    selectors: [["app-vin-stamping-list"]],
    decls: 2,
    vars: 4,
    consts: [[1, "white-block"], [3, "cols", "items", "actions", "trackBy", "onAction"]],
    template: function VinStampingListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0)(1, "app-f-table", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("onAction", function VinStampingListComponent_Template_app_f_table_onAction_1_listener($event) {
          return ctx.addToVin($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("cols", ctx.cols)("items", ctx.items)("actions", ctx.actions)("trackBy", "vinSeqId");
      }
    },
    dependencies: [_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_4__.FTableComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 7104:
/*!**********************************************************************!*\
  !*** ./src/app/features/vin-stamping/vin-stamping-routing.module.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VinStampingRoutingModule": () => (/* binding */ VinStampingRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _vin_stamping_list_vin_stamping_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vin-stamping-list/vin-stamping-list.component */ 9362);
/* harmony import */ var src_app_core_resolvers_vin_stamping_vin_stamping_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/resolvers/vin-stamping/vin-stamping.resolver */ 2067);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);





const routes = [{
  path: '',
  component: _vin_stamping_list_vin_stamping_list_component__WEBPACK_IMPORTED_MODULE_0__.VinStampingListComponent,
  data: {
    title: "VIN Stamping"
  },
  resolve: {
    data: src_app_core_resolvers_vin_stamping_vin_stamping_resolver__WEBPACK_IMPORTED_MODULE_1__.VinStampingResolver
  }
}];
class VinStampingRoutingModule {
  static #_ = this.ɵfac = function VinStampingRoutingModule_Factory(t) {
    return new (t || VinStampingRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: VinStampingRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](VinStampingRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
})();

/***/ }),

/***/ 8660:
/*!**************************************************************!*\
  !*** ./src/app/features/vin-stamping/vin-stamping.module.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VinStampingModule": () => (/* binding */ VinStampingModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _vin_stamping_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vin-stamping-routing.module */ 7104);
/* harmony import */ var _vin_stamping_list_vin_stamping_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vin-stamping-list/vin-stamping-list.component */ 9362);
/* harmony import */ var src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/f-table/f-table.component */ 2812);
/* harmony import */ var primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/confirmdialog */ 97);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);






class VinStampingModule {
  static #_ = this.ɵfac = function VinStampingModule_Factory(t) {
    return new (t || VinStampingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: VinStampingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _vin_stamping_routing_module__WEBPACK_IMPORTED_MODULE_0__.VinStampingRoutingModule, src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_2__.FTableComponent, primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_5__.ConfirmDialogModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](VinStampingModule, {
    declarations: [_vin_stamping_list_vin_stamping_list_component__WEBPACK_IMPORTED_MODULE_1__.VinStampingListComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _vin_stamping_routing_module__WEBPACK_IMPORTED_MODULE_0__.VinStampingRoutingModule, src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_2__.FTableComponent, primeng_confirmdialog__WEBPACK_IMPORTED_MODULE_5__.ConfirmDialogModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=660.ad089bc63d9be97a.js.map