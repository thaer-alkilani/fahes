"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[54],{

/***/ 57599:
/*!***************************************************************!*\
  !*** ./src/app/core/models/adminstration/StationOperation.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationOperation": () => (/* binding */ StationOperation)
/* harmony export */ });
class StationOperation {}

/***/ }),

/***/ 5058:
/*!******************************************!*\
  !*** ./src/app/core/models/tableData.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tableData": () => (/* binding */ tableData),
/* harmony export */   "tableHeader": () => (/* binding */ tableHeader)
/* harmony export */ });
class tableData {}
class tableHeader {
  constructor() {
    this.ShowInCheckBox = false;
  }
}

/***/ }),

/***/ 67074:
/*!************************************************************!*\
  !*** ./src/app/core/services/application-admin.service.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplicationAdminService": () => (/* binding */ ApplicationAdminService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class ApplicationAdminService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    //this.baseUrl = 'https://localhost:7089/api';
    this.apiUrl = 'ApplicationAdmin/v1';
  }
  getLanes(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetLaneApplicationAdmin`, body);
  }
  getSections(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSectionApplicationAdmin`, body);
  }
  getBooths(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetBoothApplicationAdmin`, body);
  }
  getStationCategoryDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getStationCategoryDetails`, body);
  }
  stationCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/stationCategoryOperation`, body);
  }
  setBoothCamera(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/setBoothCamera`, body);
  }
  laneOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/LaneOperation`, body);
  }
  sectionOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/SectionOperation`, body);
  }
  boothOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/BoothOperation`, body);
  }
  getUserAssignPosition(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetUserAssignPosition`, body);
  }
  userAssignPositionOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/UserAssignPositionOperation`, body);
  }
  getLaneServiceType(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetLaneServiceType`, body);
  }
  getLaneCategoryType(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetLaneCategoryType`, body);
  }
  getInspectionSectionInstructions(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionSectionInstruction`, body);
  }
  instructionOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/InstructionOperation`, body);
  }
  getStationInpsectionServiceTypes(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetStationInpsectionServiceTypes`, body);
  }
  stationInspectionServiceTypeOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/StationInspectionServiceTypeOperation`, body);
  }
  getFeesCategoryDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetFeesCategoryDetails`, body);
  }
  feesCategoryDetailsOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/FeesCategoryDetailsOperation`, body);
  }
  getFeesFormula(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetFeesFormula`, body);
  }
  feesFormulaOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/FeesFormulaOperation`, body);
  }
  getFeesFormulaDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetFeesFormulaDetails`, body);
  }
  feesFormulaDetailsOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/FeesFormulaDetailsOperation`, body);
  }
  cloneFees(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/CloneFees`, body);
  }
  getStationByServiceId(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetStationByServiceId`, body);
  }
  getCategoryByServiceId(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetCategoryByServiceId`, body);
  }
  getPlateTypesByServiceId(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetPlateTypesByServiceId`, body);
  }
  plateTypesServiceOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/PlateTypesServiceOperation`, body);
  }
  getDefectComments(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetDefectComments`, body);
  }
  defectCommentsOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DefectCommentsOperation`, body);
  }
  defectMainCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DefectMainCategoryOperation`, body);
  }
  defectSubCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DefectSubCategoryOperation`, body);
  }
  GetVehicleDetailLst(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetVehicleDetails`, request);
  }
  VehicleDetailOperation(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/VehicleDetailsOperation`, request);
  }
  GetWaqodInstance(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetWaqodInstance`, request);
  }
  GetRegisteredVehicle(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/ViewRegisterVehicles`, request);
  }
  GetTermsAndConditin(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetActiveTermsAndConditin`, request);
  }
  GetDelegationLst(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetDelegationLst`, request);
  }
  POSTDelegation(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/DelegationDML`, request);
  }
  GetcarAccessories(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetarAccessories`, request);
  }
  CarAccessoriesDML(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/CarAccessoriesDML`, request);
  }
  POSTTermsCondition(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/TermsConditionDML`, request);
  }
  GetsectionDevicesLst(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetSectionDevices`, request);
  }
  sectionDevicesDml(request) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/sectionDevicesDml`, request);
  }
  inspectionServiceCategoryOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/inspectionServiceCategoryOperation`, body);
  }
  stationServicesOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/StationServicesOperation`, body);
  }
  static #_ = this.ɵfac = function ApplicationAdminService_Factory(t) {
    return new (t || ApplicationAdminService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: ApplicationAdminService,
    factory: ApplicationAdminService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 990:
/*!*******************************************************!*\
  !*** ./src/app/core/services/system-admin.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemAdminService": () => (/* binding */ SystemAdminService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class SystemAdminService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    // this.baseUrl = ' http://localhost:5125/api';
    this.apiUrl = 'SystemAdmin/v1';
    this.apiUrlSupervisor = 'Supervisor/v1';
  }
  getSystemLookups(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSystemLookups`, body);
  }
  systemLookupsOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/systemLookupsOperations`, body);
  }
  getLookupValues(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSystemLookupValues`, body);
  }
  systemLookupValuesOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/systemLookupValuesOperations`, body);
  }
  getSystemRoles(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSystemRoles`, body);
  }
  getRoleUsers(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getRoleUsers`, body);
  }
  getRoleEntities(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getRoleEntities`, body);
  }
  systemRolesOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/roleDefOperations`, body);
  }
  systemUserRolesOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/userRoleOperations`, body);
  }
  systemEntityRolesOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/entityRoleOperations`, body);
  }
  getEntitiesNotInRole(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getEntitiesNotInRole`, body);
  }
  getUsersNotInRole(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getUsersNotInRole`, body);
  }
  getUsers(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getUsers`, body);
  }
  getUserRoles(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getRolesByUser`, body);
  }
  userOpration(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/userOperations`, body);
  }
  getrolesNotWithUser(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getRolesNotAssignedToUser`, body);
  }
  getManufacturers(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getManufacturers`, body);
  }
  getVehicleModels(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getVehicleModels`, body);
  }
  manufacturerOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/manufacturerOperations`, body);
  }
  vehicleModelOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/vehicleModelOperations`, body);
  }
  getAreas(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getAreas`, body);
  }
  areaOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/areaOperations`, body);
  }
  locationOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/locationOperations`, body);
  }
  getAreaLocations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getAreaLocations`, body);
  }
  moduleOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/ModuleOperations`, body);
  }
  entityOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/systemEntityDefOperations`, body);
  }
  getModules(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getModules`, body);
  }
  getSystemEntityDef(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSystemEntityDef`, body);
  }
  getSystemMessages(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSystemMessages`, body);
  }
  systemMessagesOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/systemMessagesOperations`, body);
  }
  getGlobalConfigurations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getGlobalConfigurations`, body);
  }
  globalConfigurationOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/globalConfigurationOperations`, body);
  }
  getStations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getStations`, body ? body : {});
  }
  getClientAssets(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getClientAssets`, body);
  }
  clientAssetsOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/clientAssetsOperations`, body);
  }
  stationOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/stationOperation`, body);
  }
  getPositions(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrlSupervisor}/GetStationPosition`, body);
  }
  getBooths(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getBooths`, body);
  }
  getLanes(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getLanes`, body);
  }
  getSections(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSections`, body);
  }
  getCreditCards(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getCreditCardTypes`, body);
  }
  creditCardOperation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/creditCardOperations`, body);
  }
  getSystemBlacklist(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSystemBlacklist`, body);
  }
  systemBlacklistOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/systemBlacklistOperations`, body);
  }
  categoryShapesOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/categoryShapesOperations`, body);
  }
  vehicleCategoryOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/vehicleCategoryOperations`, body);
  }
  getVehicleCategories(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getVehicleCategories`, body);
  }
  getCategoryShapes(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getCategoryShapes`, body);
  }
  geShapesNotAssignedToCategory(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/geShapesNotAssignedToCategory`, body);
  }
  getPosTerminalDef(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getPOSTerminalDef`, body);
  }
  posTerminalDefOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/POSTerminalDefOperations`, body);
  }
  getInspectionDeviceVendors(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDeviceVendors`, body);
  }
  inspectionDeviceVendorsOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/inspectionDeviceVendorsOperations`, body);
  }
  getDevicesInputCode(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDevicesInputCode`, body);
  }
  devicesInputCodeOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/devicesInputCodeOperations`, body);
  }
  getDevicesDefectEvaluation(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDevicesDefectEvaluation`, body);
  }
  devicesDefectEvaluationOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/devicesDefectEvaluationOperations`, body);
  }
  getDevicesOutputDefect(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDevicesOutputDefect`, body);
  }
  devicesOutputDefectOperations(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/devicesOutputDefectOperations`, body);
  }
  getDeviceOperationCodes() {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDeviceOperationCodes`, {});
  }
  static #_ = this.ɵfac = function SystemAdminService_Factory(t) {
    return new (t || SystemAdminService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: SystemAdminService,
    factory: SystemAdminService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 25190:
/*!*************************************************************!*\
  !*** ./src/app/core/utilities/enums/operation-type.enum.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "operationType": () => (/* binding */ operationType)
/* harmony export */ });
var operationType;
(function (operationType) {
  operationType["insert"] = "INSERT";
  operationType["update"] = "UPDATE";
  operationType["view"] = "VIEW";
  operationType["delete"] = "DELETE";
})(operationType || (operationType = {}));

/***/ })

}]);
//# sourceMappingURL=54.4f373ac34ede684b.js.map