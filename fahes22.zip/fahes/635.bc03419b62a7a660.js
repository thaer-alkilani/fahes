"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[635],{

/***/ 73874:
/*!****************************************************!*\
  !*** ./src/app/core/models/add-vehicle-details.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddVehicleDetails": () => (/* binding */ AddVehicleDetails)
/* harmony export */ });
class AddVehicleDetails {
  constructor(vehicledetails, phone, area, location, vcategory, cost) {
    this.vdetails = vehicledetails;
    this.phone = phone;
    this.area = area;
    this.location = location;
    this.vCategoryText = vcategory;
    this.cost = cost;
  }
}

/***/ }),

/***/ 69537:
/*!*********************************************************!*\
  !*** ./src/app/core/models/insert-vehicle-equipment.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InsertExternalEquipment": () => (/* binding */ InsertExternalEquipment)
/* harmony export */ });
class InsertExternalEquipment {
  constructor(details) {
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 83439:
/*!*****************************************!*\
  !*** ./src/app/core/models/location.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Locations": () => (/* binding */ Locations)
/* harmony export */ });
class Locations {
  constructor(locId, locName, areaId) {
    this.locationId = locId;
    this.locationName = locName;
    this.areaId = areaId;
  }
}

/***/ }),

/***/ 43347:
/*!************************************************!*\
  !*** ./src/app/core/models/vehicle-details.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleDetails": () => (/* binding */ VehicleDetails)
/* harmony export */ });
class VehicleDetails {
  constructor(PlateNo, PlateType, VINNo, ColorId, SubColorId, CategoryId, VehicleModelId, ManufacturerId, ManufacturerYear, MOIRegistrationDate, Cylinders, Weight, PayloadWeight, ShapeCode, NoOfSeat, OwnerPID, OwnerName, LicenseExpiryDate, CreatedBy, CreatedDate, UpdatedBy, UpdatedDate, ModelEname, ManufacturersEname, IsValidStation, IsStaffVehicle, IsWaqodVehicle, IsReinspection, noOfReinspections) {
    this.plateNo = PlateNo;
    this.plateType = PlateType;
    this.vinNo = VINNo;
    this.colorId = ColorId;
    this.subColorId = SubColorId;
    this.categoryId = CategoryId;
    this.vehicleModelId = VehicleModelId;
    this.manufacturerId = ManufacturerId;
    this.manufacturerYear = ManufacturerYear;
    this.moiRegistrationDate = MOIRegistrationDate;
    this.cylinders = Cylinders;
    this.weight = Weight;
    this.payloadWeight = PayloadWeight;
    this.shapeCode = ShapeCode;
    this.noOfSeat = NoOfSeat;
    this.ownerPID = OwnerPID;
    this.ownerName = OwnerName;
    this.licenseExpiryDate = LicenseExpiryDate;
    this.createdBy = CreatedBy;
    this.createdDate = CreatedDate;
    this.updatedBy = UpdatedBy;
    this.updatedDate = UpdatedDate;
    this.modelEname = ModelEname;
    this.manufacturersEname = ManufacturersEname;
    this.isValidStation = IsValidStation;
    this.isStaffVehicle = IsStaffVehicle;
    this.isWaqodVehicle = IsWaqodVehicle;
    this.isReinspection = IsReinspection;
    this.noOfReinspections = noOfReinspections;
  }
}

/***/ }),

/***/ 59212:
/*!*******************************************************!*\
  !*** ./src/app/core/services/registration.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistrationService": () => (/* binding */ RegistrationService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 58987);



class RegistrationService {
  constructor(http) {
    this.http = http;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Registration/v1';
  }
  createServiceRequest(serviceRequest) {
    return this.http.post(`${this.baseUrl}/${this.apiUrl}/insertServiceRequest`, serviceRequest);
  }
  submitMobileBooking(mobileBookingRequest) {
    return this.http.post(`${this.baseUrl}/${this.apiUrl}/submitMobileBooking`, mobileBookingRequest);
  }
  getInspectionServiceTypes(classificationId) {
    return this.http.post(`${this.baseUrl}/${this.apiUrl}/getInspectionServiceTypes`, {
      classificationId: classificationId
    });
  }
  static #_ = this.ɵfac = function RegistrationService_Factory(t) {
    return new (t || RegistrationService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: RegistrationService,
    factory: RegistrationService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 46949:
/*!*************************************************************************************!*\
  !*** ./src/app/core/utilities/enums/inspection-service-type-classification.rnum.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceTypeClassifications": () => (/* binding */ ServiceTypeClassifications)
/* harmony export */ });
var ServiceTypeClassifications;
(function (ServiceTypeClassifications) {
  ServiceTypeClassifications[ServiceTypeClassifications["Internal"] = 1] = "Internal";
  ServiceTypeClassifications[ServiceTypeClassifications["External"] = 2] = "External";
})(ServiceTypeClassifications || (ServiceTypeClassifications = {}));

/***/ }),

/***/ 32169:
/*!************************************************************!*\
  !*** ./src/app/modules/backoffice/backoffice.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackofficeComponent": () => (/* binding */ BackofficeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 60124);



class BackofficeComponent {
  constructor(sideNav) {
    this.sideNav = sideNav;
  }
  ngOnInit() {
    this.sideNav.setHeaderValue(false, true);
  }
  static #_ = this.ɵfac = function BackofficeComponent_Factory(t) {
    return new (t || BackofficeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_0__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: BackofficeComponent,
    selectors: [["app-backoffice"]],
    decls: 1,
    vars: 0,
    template: function BackofficeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterOutlet],
    styles: [".custom-select[_ngcontent-%COMP%] {\r\n    background-color: #448b23;\r\n    border: 1px solid rgb(54, 52, 52);\r\n}\r\n\r\n[_nghost-%COMP%]     ng-select.ng-select.custom-dp .ng-dropdown-panel .ng-dropdown-panel-items {\r\n    border: 0.2px solid rgb(54, 52, 52);\r\n    background-color: white;\r\n    padding-left: 15px;\r\n}\r\n\r\n.custom-option[_ngcontent-%COMP%] {\r\n    color: #333;\r\n    cursor: pointer;\r\n    background-color: white;\r\n    padding-top: 5px;\r\n}\r\n\r\n.custom-option[_ngcontent-%COMP%]:hover {\r\n    background-color: rgb(195, 203, 210);\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2JhY2tvZmZpY2UuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHlCQUF5QjtJQUN6QixpQ0FBaUM7QUFDckM7O0FBRUE7SUFDSSxtQ0FBbUM7SUFDbkMsdUJBQXVCO0lBQ3ZCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLFdBQVc7SUFDWCxlQUFlO0lBQ2YsdUJBQXVCO0lBQ3ZCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLG9DQUFvQztBQUN4QyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tc2VsZWN0IHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM0NDhiMjM7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoNTQsIDUyLCA1Mik7XHJcbn1cclxuXHJcbjpob3N0IDo6bmctZGVlcCBuZy1zZWxlY3Qubmctc2VsZWN0LmN1c3RvbS1kcCAubmctZHJvcGRvd24tcGFuZWwgLm5nLWRyb3Bkb3duLXBhbmVsLWl0ZW1zIHtcclxuICAgIGJvcmRlcjogMC4ycHggc29saWQgcmdiKDU0LCA1MiwgNTIpO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE1cHg7XHJcbn1cclxuXHJcbi5jdXN0b20tb3B0aW9uIHtcclxuICAgIGNvbG9yOiAjMzMzO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG59XHJcblxyXG4uY3VzdG9tLW9wdGlvbjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTk1LCAyMDMsIDIxMCk7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 28635:
/*!*********************************************************!*\
  !*** ./src/app/modules/backoffice/backoffice.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BackofficeModule": () => (/* binding */ BackofficeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _components_exempted_exempted_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/exempted/exempted.component */ 83452);
/* harmony import */ var _backoffice_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./backoffice.component */ 32169);
/* harmony import */ var _components_external_registration_external_registration_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/external-registration/external-registration.component */ 97186);
/* harmony import */ var _components_landing_landing_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/landing/landing.component */ 67961);
/* harmony import */ var _components_mobile_booking_mobile_booking_mobile_booking_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/mobile-booking/mobile-booking/mobile-booking.component */ 25414);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);
/* harmony import */ var _components_inspection_results_reports_inspection_results_reports_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/inspection-results-reports/inspection-results-reports.component */ 50587);
/* harmony import */ var _components_receipt_backoffice_receipt_backoffice_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/receipt-backoffice/receipt-backoffice.component */ 25753);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);














const routes = [{
  path: '',
  redirectTo: 'external-registration',
  pathMatch: 'full'
}, {
  path: '',
  component: _backoffice_component__WEBPACK_IMPORTED_MODULE_2__.BackofficeComponent,
  children: [{
    path: 'external-registration',
    component: _components_external_registration_external_registration_component__WEBPACK_IMPORTED_MODULE_3__.ExternalRegistrationComponent
  }, {
    path: 'landing',
    component: _components_landing_landing_component__WEBPACK_IMPORTED_MODULE_4__.LandingComponent
  }, {
    path: 'exempted',
    component: _components_exempted_exempted_component__WEBPACK_IMPORTED_MODULE_1__.ExemptedComponent
  }, {
    path: 'mobile-booking',
    component: _components_mobile_booking_mobile_booking_mobile_booking_component__WEBPACK_IMPORTED_MODULE_5__.MobileBookingComponent
  }]
}, {
  path: 'Inspection-result-reports',
  component: _components_inspection_results_reports_inspection_results_reports_component__WEBPACK_IMPORTED_MODULE_6__.InspectionResultsReportsComponent
}, {
  path: 'receipt-backoffice',
  component: _components_receipt_backoffice_receipt_backoffice_component__WEBPACK_IMPORTED_MODULE_7__.ReceiptBackofficeComponent
}];
class BackofficeModule {
  static #_ = this.ɵfac = function BackofficeModule_Factory(t) {
    return new (t || BackofficeModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
    type: BackofficeModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule.forChild(routes), _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__.NgSelectModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](BackofficeModule, {
    declarations: [_components_external_registration_external_registration_component__WEBPACK_IMPORTED_MODULE_3__.ExternalRegistrationComponent, _components_landing_landing_component__WEBPACK_IMPORTED_MODULE_4__.LandingComponent, _backoffice_component__WEBPACK_IMPORTED_MODULE_2__.BackofficeComponent, _components_exempted_exempted_component__WEBPACK_IMPORTED_MODULE_1__.ExemptedComponent, _components_mobile_booking_mobile_booking_mobile_booking_component__WEBPACK_IMPORTED_MODULE_5__.MobileBookingComponent, _components_inspection_results_reports_inspection_results_reports_component__WEBPACK_IMPORTED_MODULE_6__.InspectionResultsReportsComponent, _components_receipt_backoffice_receipt_backoffice_component__WEBPACK_IMPORTED_MODULE_7__.ReceiptBackofficeComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouterModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_12__.NgSelectModule]
  });
})();

/***/ }),

/***/ 83452:
/*!******************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/exempted/exempted.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptedComponent": () => (/* binding */ ExemptedComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/register-vehicle */ 54611);
/* harmony import */ var src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/service-request */ 84908);
/* harmony import */ var src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/vehicle-details */ 43347);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/purchase.service */ 87010);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);





























function ExemptedComponent_div_15_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * This Vehicle is Not Registered in MOI ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ctx_r12.errorMessage, " ");
  }
}
function ExemptedComponent_div_15_option_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r61 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", pt_r61.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", pt_r61.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_select_19_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r63 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", vc_r63.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", vc_r63.descriptionEn, " ");
  }
}
function ExemptedComponent_div_15_select_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r65 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("ngModelChange", function ExemptedComponent_div_15_select_19_Template_select_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r65);
      const ctx_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r64.checkVehicleServices());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_19_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r15.exmpReg.get("vehicleCategories").value);
  }
}
function ExemptedComponent_div_15_input_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 80);
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx_r16.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_select_24_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ot_r67 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ot_r67.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ot_r67.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_select_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_24_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r17.exmpReg.get("ownerTypes").value);
  }
}
function ExemptedComponent_div_15_input_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 82);
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx_r18.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 83);
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r19.exmpReg.get("vdetails").value.ownerPID ? ctx_r19.exmpReg.get("vdetails").value.ownerPID : "")("readonly", ctx_r19.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 84);
  }
}
function ExemptedComponent_div_15_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r22.exmpReg.get("vdetails").value.ownerName ? ctx_r22.exmpReg.get("vdetails").value.ownerName : "");
  }
}
function ExemptedComponent_div_15_input_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 86);
  }
}
function ExemptedComponent_div_15_input_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 87);
  }
}
function ExemptedComponent_div_15_input_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 83);
  }
  if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r25.exmpReg.get("vdetails").value.licenseExpiryDate ? ctx_r25.exmpReg.get("formatExpDate").value : "")("readonly", ctx_r25.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_div_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Invalid date format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Istimara Date must be valid at least 30 days from now ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r28.exmpReg.get("vdetails").value.vinNo ? ctx_r28.exmpReg.get("vdetails").value.vinNo : "");
  }
}
function ExemptedComponent_div_15_input_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 88);
  }
}
function ExemptedComponent_div_15_div_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_select_55_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r69 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", m_r69.manufacturersId);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", m_r69.manufacturersEname, " ");
  }
}
function ExemptedComponent_div_15_select_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("change", function ExemptedComponent_div_15_select_55_Template_select_change_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r71);
      const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r70.getModelTypes($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_55_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r31.exmpReg.get("manufacturerTypes").value);
  }
}
function ExemptedComponent_div_15_input_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 83);
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r32.exmpReg.get("vdetails").value.manufacturersEname ? ctx_r32.exmpReg.get("vdetails").value.manufacturersEname : "")("readonly", ctx_r32.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_select_60_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r73 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", m_r73.modelId);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", m_r73.modelEname, " ");
  }
}
function ExemptedComponent_div_15_select_60_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_60_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r33.exmpReg.get("modelTypes").value);
  }
}
function ExemptedComponent_div_15_input_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 83);
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r34.exmpReg.get("vdetails").value.modelEname ? ctx_r34.exmpReg.get("vdetails").value.modelEname : "")("readonly", ctx_r34.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r35.exmpReg.get("vdetails").value.manufacturerYear ? ctx_r35.exmpReg.get("vdetails").value.manufacturerYear : "");
  }
}
function ExemptedComponent_div_15_select_66_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const year_r75 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", year_r75);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate"](year_r75);
  }
}
function ExemptedComponent_div_15_select_66_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_66_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r36.getYearRange());
  }
}
function ExemptedComponent_div_15_div_67_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Enter a valid year");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r38.exmpReg.get("vdetails").value.cylinders ? ctx_r38.exmpReg.get("vdetails").value.cylinders : "");
  }
}
function ExemptedComponent_div_15_input_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 92);
  }
}
function ExemptedComponent_div_15_div_73_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Enter a valid vehicle cylinders ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r41.exmpReg.get("vdetails").value.weight ? ctx_r41.exmpReg.get("vdetails").value.weight : "");
  }
}
function ExemptedComponent_div_15_input_78_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 93);
  }
  if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx_r42.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_div_79_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Enter a valid weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_input_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r44.exmpReg.get("vdetails").value.payloadWeight ? ctx_r44.exmpReg.get("vdetails").value.payloadWeight : "");
  }
}
function ExemptedComponent_div_15_input_84_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 94);
  }
  if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx_r45.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_div_85_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Enter a valid payload weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_select_89_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r77 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", color_r77.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", color_r77.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_select_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_89_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r47.exmpReg.get("colorList").value);
  }
}
function ExemptedComponent_div_15_input_90_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 96);
  }
  if (rf & 2) {
    const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("readonly", ctx_r48.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_select_94_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r79 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", color_r79.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", color_r79.lkValueEname, " ");
  }
}
function ExemptedComponent_div_15_select_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "select", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](1, ExemptedComponent_div_15_select_94_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r49.exmpReg.get("colorList").value);
  }
}
function ExemptedComponent_div_15_input_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 83);
  }
  if (rf & 2) {
    const ctx_r50 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r50.exmpReg.get("subclr").value)("readonly", ctx_r50.exmpReg.get("nonEditable").value);
  }
}
function ExemptedComponent_div_15_input_99_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 85);
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r51.exmpReg.get("vdetails").value.noOfSeat ? ctx_r51.exmpReg.get("vdetails").value.noOfSeat : "");
  }
}
function ExemptedComponent_div_15_input_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "input", 98);
  }
}
function ExemptedComponent_div_15_div_101_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Enter a valid No of seats");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_15_div_102_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 19)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2, " Exempted Reason ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](3, "input", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r54.exmpReg.get("exmpReason").value);
  }
}
function ExemptedComponent_div_15_div_103_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 19)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2, " Exempted Remarks ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](3, "input", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", ctx_r55.exmpReg.get("vdetails").value.remarks);
  }
}
function ExemptedComponent_div_15_div_104_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "div", 19);
  }
}
function ExemptedComponent_div_15_div_105_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "div", 19);
  }
}
function ExemptedComponent_div_15_div_107_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](1, "div", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, " Woqod Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
}
function ExemptedComponent_div_15_div_108_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 101)(1, "label", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](2, "input", 103)(3, "span", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](4, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](5, "Apply Staff Rate");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("checked", ctx_r59.exmpReg.get("isStaffRate").value);
  }
}
function ExemptedComponent_div_15_span_112_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "span", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ctx_r60.fileName, " ");
  }
}
function ExemptedComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 44)(1, "div", 17)(2, "div", 18)(3, "div", 19)(4, "label", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](5, " License Plate No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](6, "input", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](7, ExemptedComponent_div_15_div_7_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](8, ExemptedComponent_div_15_div_8_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](9, ExemptedComponent_div_15_div_9_Template, 2, 1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](10, "div", 19)(11, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](12, " License Plate Type * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](13, "select", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](14, ExemptedComponent_div_15_option_14_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](15, ExemptedComponent_div_15_div_15_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](16, "div", 19)(17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](18, "Vehicle Category");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](19, ExemptedComponent_div_15_select_19_Template, 2, 1, "select", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](20, ExemptedComponent_div_15_input_20_Template, 1, 1, "input", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](21, "div", 19)(22, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](23, "Owner PID Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](24, ExemptedComponent_div_15_select_24_Template, 2, 1, "select", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](25, ExemptedComponent_div_15_input_25_Template, 1, 1, "input", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](26, "div", 19)(27, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](28, "Owner PID");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](29, ExemptedComponent_div_15_input_29_Template, 1, 2, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](30, ExemptedComponent_div_15_input_30_Template, 1, 0, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](31, ExemptedComponent_div_15_div_31_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](32, "div", 19)(33, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](34, "Owner Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](35, ExemptedComponent_div_15_input_35_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](36, ExemptedComponent_div_15_input_36_Template, 1, 0, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](37, "div", 19)(38, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](39, "Istimara Expiry Date");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](40, ExemptedComponent_div_15_input_40_Template, 1, 0, "input", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](41, ExemptedComponent_div_15_input_41_Template, 1, 2, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](42, ExemptedComponent_div_15_div_42_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](43, ExemptedComponent_div_15_div_43_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](44, "div", 58)(45, "div", 18)(46, "div", 19)(47, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](48, "VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](49, ExemptedComponent_div_15_input_49_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](50, ExemptedComponent_div_15_input_50_Template, 1, 0, "input", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](51, ExemptedComponent_div_15_div_51_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](52, "div", 19)(53, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](54, "Manufacturer");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](55, ExemptedComponent_div_15_select_55_Template, 2, 1, "select", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](56, ExemptedComponent_div_15_input_56_Template, 1, 2, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](57, "div", 19)(58, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](59, "Model");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](60, ExemptedComponent_div_15_select_60_Template, 2, 1, "select", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](61, ExemptedComponent_div_15_input_61_Template, 1, 2, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](62, "div", 19)(63, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](64, "Manufacturing Year");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](65, ExemptedComponent_div_15_input_65_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](66, ExemptedComponent_div_15_select_66_Template, 2, 1, "select", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](67, ExemptedComponent_div_15_div_67_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](68, "div", 19)(69, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](70, "Cylinders");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](71, ExemptedComponent_div_15_input_71_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](72, ExemptedComponent_div_15_input_72_Template, 1, 0, "input", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](73, ExemptedComponent_div_15_div_73_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](74, "div", 19)(75, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](76, "Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](77, ExemptedComponent_div_15_input_77_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](78, ExemptedComponent_div_15_input_78_Template, 1, 1, "input", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](79, ExemptedComponent_div_15_div_79_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](80, "div", 19)(81, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](82, "Payload Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](83, ExemptedComponent_div_15_input_83_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](84, ExemptedComponent_div_15_input_84_Template, 1, 1, "input", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](85, ExemptedComponent_div_15_div_85_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](86, "div", 19)(87, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](88, "Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](89, ExemptedComponent_div_15_select_89_Template, 2, 1, "select", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](90, ExemptedComponent_div_15_input_90_Template, 1, 1, "input", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](91, "div", 19)(92, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](93, "Sub Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](94, ExemptedComponent_div_15_select_94_Template, 2, 1, "select", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](95, ExemptedComponent_div_15_input_95_Template, 1, 2, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](96, "div", 19)(97, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](98, "Seats");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](99, ExemptedComponent_div_15_input_99_Template, 1, 1, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](100, ExemptedComponent_div_15_input_100_Template, 1, 0, "input", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](101, ExemptedComponent_div_15_div_101_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](102, ExemptedComponent_div_15_div_102_Template, 4, 1, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](103, ExemptedComponent_div_15_div_103_Template, 4, 1, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](104, ExemptedComponent_div_15_div_104_Template, 1, 0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](105, ExemptedComponent_div_15_div_105_Template, 1, 0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](106, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](107, ExemptedComponent_div_15_div_107_Template, 4, 0, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](108, ExemptedComponent_div_15_div_108_Template, 6, 1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](109, "button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](110, "span", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](111, " Attachement ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](112, ExemptedComponent_div_15_span_112_Template, 2, 1, "span", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputPlateNo").invalid && ctx_r0.exmpReg.get("inputPlateNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("showMoiError").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.errorMessage);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r0.exmpReg.get("plateTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputPlateType").invalid && ctx_r0.exmpReg.get("inputPlateType").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value || ctx_r0.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value && !ctx_r0.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value && ctx_r0.exmpReg.get("inputPid").invalid && ctx_r0.exmpReg.get("inputPid").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("expDate").hasError("invalidDate") && ctx_r0.exmpReg.get("expDate").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("expDate").hasError("futureDate"));
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value && ctx_r0.exmpReg.get("inputVinNo").invalid && ctx_r0.exmpReg.get("inputVinNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputManfYear").touched && (ctx_r0.exmpReg.get("inputManfYear").hasError("pattern") || ctx_r0.exmpReg.get("inputManfYear").hasError("invalidYear")));
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputCylinders").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputWeight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputPayloadweight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r0.exmpReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("inputNbSeats").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.isExem);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.isWoqodVehicle);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.exmpReg.get("isStaffRateValue").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r0.fileName);
  }
}
function ExemptedComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Please enter a valid phone number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " * Enter a valid PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Enter a valid email");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_46_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" Inspection Services Fees: ", ctx_r80.inspectionFees, " ");
  }
}
function ExemptedComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 12)(3, "div", 6)(4, "div", 106)(5, "div", 8)(6, "h2", 107)(7, "button", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](8, " Service Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](9, "div", 109)(10, "div", 17)(11, "div", 18)(12, "div", 19)(13, "div", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](14, "input", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](15, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](16, "img", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](17, " Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](18, "div", 2)(19, "div", 4)(20, "label", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](21, "Inspection Service Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](22, "div", 4)(23, "div", 115)(24, "input", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("ngModelChange", function ExemptedComponent_div_46_Template_input_ngModelChange_24_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r82);
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r81.onSelectServiceSubType(1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](25, "label", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](26, " Normal Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](27, ExemptedComponent_div_46_div_27_Template, 2, 1, "div", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r6.inspectionFees);
  }
}
function ExemptedComponent_button_51_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function ExemptedComponent_button_51_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r83.submitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, "Payment");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", !ctx_r7.exmpReg.get("isFormValid").value || !ctx_r7.exmpReg.valid);
  }
}
function ExemptedComponent_button_52_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "button", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function ExemptedComponent_button_52_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r86);
      const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r85.continueReceipt());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](1, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
  }
}
function ExemptedComponent_div_54_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 115)(1, "input", 134);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("ngModelChange", function ExemptedComponent_div_54_div_6_div_2_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r92);
      const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r91.onSelectPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](2, "label", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const pt_r90 = ctx.$implicit;
    const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("id", "pt" + pt_r90.lkCodeValue)("value", pt_r90.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵattribute"]("disabled", !ctx_r89.enableCashMethodSetting && pt_r90.lkCodeValue == 1 ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("for", "pt" + pt_r90.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", pt_r90.lkValueEname, " ");
  }
}
function ExemptedComponent_div_54_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 131)(1, "div", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](2, ExemptedComponent_div_54_div_6_div_2_Template, 4, 5, "div", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r87.exmpReg.get("paymentTypes").value);
  }
}
function ExemptedComponent_div_54_div_8_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "ng-option", 142)(1, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", c_r94.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", c_r94.customerName, " ");
  }
}
function ExemptedComponent_div_54_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r96 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 136)(1, "div", 137)(2, "label", 138);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](4, "ng-select", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("change", function ExemptedComponent_div_54_div_8_Template_ng_select_change_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r96);
      const ctx_r95 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r95.isPaymentValid = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementContainerStart"](5, 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](6, "ng-option", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](7, ExemptedComponent_div_54_div_8_ng_option_7_Template, 3, 2, "ng-option", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r88 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngForOf", ctx_r88.creditCustomerList);
  }
}
function ExemptedComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](0, "div", 33)(1, "div", 34)(2, "div", 35)(3, "h1", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](4, "Payment Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](5, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](6, ExemptedComponent_div_54_div_6_Template, 3, 1, "div", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](7, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](8, ExemptedComponent_div_54_div_8_Template, 8, 4, "div", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](10, "div", 125)(11, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](12, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](13, "div", 2)(14, "div", 126)(15, "table", 127)(16, "thead")(17, "tr")(18, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](19, "Service");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](20, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](21, "Fees");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](22, "tbody")(23, "tr")(24, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](25, " Normal Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](26, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](27);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](28, "tfoot")(29, "tr")(30, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](31, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](32, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](34, "div", 128)(35, "button", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function ExemptedComponent_div_54_Template_button_click_35_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r98);
      const ctx_r97 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r97.cancelPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](36, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](37, "button", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function ExemptedComponent_div_54_Template_button_click_37_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵrestoreView"](_r98);
      const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵresetView"](ctx_r99.submitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](38, "Submit");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx_r9.noPaymentRequired);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx_r9.exmpReg.get("showCredit").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ctx_r9.exmpReg.get("feesIns").value, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtextInterpolate1"](" ", ctx_r9.exmpReg.get("amount").value, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("disabled", !ctx_r9.isPaymentValid);
  }
}
class ExemptedComponent {
  constructor(lookupServ, vehicleService, fileService, render, fb, location, purchase, sharedDataService, sharedLookup, sideNav, paymentService, ssrsPrintServ, globalServ, thousandSeparator) {
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.fileService = fileService;
    this.render = render;
    this.fb = fb;
    this.location = location;
    this.purchase = purchase;
    this.sharedDataService = sharedDataService;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.paymentService = paymentService;
    this.ssrsPrintServ = ssrsPrintServ;
    this.globalServ = globalServ;
    this.thousandSeparator = thousandSeparator;
    this.selectedFiles = [];
    this.serviceFlags = {};
    this.creditCustomerList = [];
    this.isExem = false;
    this.paymentName = 'Card';
    this.displayPaymentDetails = 'none';
    this.selectedMainService = [];
    this.printReceiptDirectly = false;
    this.feesDetails = [];
    this.enableCashMethodSetting = true;
    this.isPaymentValid = true;
    this.feesInsChecked = false;
    this.isPaymentStarted = false;
    this.vehicleServices = {
      inspectionServices: [],
      vinStampingServices: [],
      tankerCertServices: []
    };
    this.exmpReg = this.fb.group({
      inputPlateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      inputPlateNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      selectedPayment: [],
      selectedOwnerType: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      selectedServType: [''],
      selectedCust: [''],
      selectedServName: [''],
      selectedManufacturer: [],
      selectedModel: [],
      selectedVehicleCategory: null,
      selectedColor: [''],
      selectedSubColor: [''],
      selectedArea: [''],
      selectedLocation: [''],
      selectedServIns: false,
      selectedServVin: false,
      selectedServTanker: false,
      selectedInsSubType: [],
      selectedServiceType: [],
      checkAllContact: [false],
      checkAllLocation: [false],
      nonEditable: [true],
      isStaffRate: [false],
      isStaffRateValue: [false],
      showCredit: [false],
      showErrorPopup: [true],
      showScreen: [true],
      vdetails: [{}],
      colorList: [[]],
      ownerTypes: [[]],
      plateTypes: [[]],
      manufacturerTypes: [[]],
      modelTypes: [[]],
      vehicleCategories: [[]],
      lookupValues: [{}],
      serviceTypeList: [[]],
      exemptedReason: [[]],
      exmpReason: [''],
      expDate: [''],
      pidValue: [''],
      colorValue: [''],
      subclr: [' '],
      vcategory: [''],
      feesIns: [0],
      amount: [0],
      feesDiscount: [],
      inputOwnerType: [''],
      inputPid: [' ', [_angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required]],
      inputOwnerName: [''],
      inputVinNo: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required],
      inputManfYear: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern('^[0-9]*$')]],
      inputCylinders: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern('^[0-9]*$')],
      inputWeight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern('^[0-9]*$')],
      inputPayloadweight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern('^[0-9]*$')],
      inputNbSeats: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern('^[0-9]*$')],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern(/^[34567]\d{7}$/)]],
      pid: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern(/^.{1,20}$/)]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.pattern(/^.{1,60}$/)]],
      displayServiceType: [false],
      vehicleCategoryValue: null,
      selectedVinStamping: [],
      selectedTanker: [],
      isFormValid: [false],
      vcategoryType: [],
      showNotExm: [false],
      paymentTypes: [[]],
      formatExpDate: [],
      showMoiError: [false]
    });
  }
  dateValidator(control) {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    const minDate = new Date(currentDate);
    minDate.setDate(currentDate.getDate() + 30);
    if (isNaN(selectedDate.getTime())) {
      return {
        invalidDate: true
      };
    }
    if (selectedDate < minDate) {
      return {
        futureDate: true
      };
    }
    return null;
  }
  validManfYear(control) {
    const year = control.value;
    const currentYear = new Date().getFullYear();
    const minYear = 1900; // min allowed vehicle year
    const maxYear = currentYear;
    if (year < minYear || year > maxYear) {
      return {
        'invalidYear': true
      };
    }
    return null;
  }
  getYearRange() {
    const startYear = 1900;
    const currentYear = new Date().getFullYear();
    const yearRange = [];
    for (let year = currentYear + 1; year >= startYear; year--) {
      yearRange.push(year);
    }
    return yearRange;
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(2, 6);
    //  this.sharedDataService.userId$.subscribe((userId) => {
    //    this.userId = userId;
    // });
    this.userId = parseInt(localStorage.getItem('userId'));
    /* this.sharedDataService.stationId$.subscribe((res) => {
      this.stationId = res;
    }); */
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.sharedLookup.colorList$.subscribe(data => {
      this.exmpReg.get('colorList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.exmpReg.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.exmpReg.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.manufacturerTypes$.subscribe(data => {
      this.exmpReg.get('manufacturerTypes').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.exmpReg.get('plateTypes').setValue(data);
    });
    this.sharedLookup.serviceTypeList$.subscribe(data => {
      this.exmpReg.get('serviceTypeList').setValue(data);
    });
    this.sharedLookup.exemptedReasons$.subscribe(data => {
      this.exmpReg.get('exemptedReason').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupCodes.paymentMethods).subscribe(data => {
      this.exmpReg.get('paymentTypes').setValue(data.items);
      const firstPaymentType = data.items.find(item => item.lkValueAname === 'Card').lkCodeValue;
      this.exmpReg.get('selectedPayment').setValue(firstPaymentType);
    });
    this.subscription = this.barCodeSubscription = this.sharedDataService.textEx$.subscribe(text => {
      const plateType = parseInt(text.substring(0, 2));
      const plateNo = parseInt(text.substring(2));
      if (plateNo) {
        this.exmpReg.patchValue({
          inputPlateNo: plateNo,
          inputPlateType: plateType
        });
        this.getExemptedVehicleDetails();
      }
    });
    this.exmpReg.get('inputPlateNo').valueChanges.subscribe(value => {
      if (this.exmpReg.get('inputPlateNo').valueChanges) {
        this.exmpReg.get('inputPlateType').setValue('');
        this.resetInfo();
      }
    });
    this.exmpReg.get('inputPlateType').valueChanges.subscribe(value => {
      this.getExemptedVehicleDetails();
    });
    // check if cash is enabled
    this.sharedDataService.stationSetting$.subscribe(res => {
      const checkCashMethod = res.find(item => item.key === "EnableCashMethod" && item.value === "True");
      if (checkCashMethod != undefined) {
        this.enableCashMethodSetting = checkCashMethod;
      }
    });
  }
  onFileUploaded(fname) {
    this.fileName = fname;
  }
  checkValidRequiredFields() {
    if (this.exmpReg.get('phone').hasError('required') && this.exmpReg.get('inputPlateNo') && this.exmpReg.get('inputPlateNo')) {
      this.exmpReg.get('isFormValid').setValue(false);
    } else {
      this.exmpReg.get('isFormValid').setValue(true);
    }
  }
  getModelTypes(event) {
    this.vehicleService.getModelsByManufacturerId(this.exmpReg.get('selectedManufacturer').value).subscribe(data => {
      this.exmpReg.get('modelTypes').setValue(data.items);
    });
  }
  // call the API GetExemptedVehicle to return the fields if exempted
  getExemptedVehicleDetails() {
    this.exmpReg.get("showMoiError").setValue(false);
    this.errorMessage = '';
    if (this.exmpReg.get('inputPlateType').value) {
      const licenseDetails = {
        plateNo: this.exmpReg.get('inputPlateNo').value,
        plateType: this.exmpReg.get('inputPlateType').value
      };
      this.vehicleService.getExemptedVehicle(licenseDetails).subscribe(data => {
        this.exmpReg.get('vdetails').setValue(data.items);
        if (this.exmpReg.get('vdetails').value) {
          this.exmpReg.get('inputVinNo').setValidators(null);
          this.exmpReg.get('inputManfYear').setValidators(null);
          this.exmpReg.get('inputCylinders').setValidators(null);
          this.exmpReg.get('inputNbSeats').setValidators(null);
          this.exmpReg.updateValueAndValidity();
          this.isExem = true;
          const vehicleSer = {
            categoryId: this.exmpReg.get('vdetails').value.categoryId,
            stationId: this.stationId
          };
          this.vehicleService.getVehicleServices(vehicleSer).subscribe(response => {
            this.vehicleServices = response.items;
            this.getServiceTypes();
          });
          const color = this.exmpReg.get('colorList').value.find(color => color.lkCodeValue == this.exmpReg.get('vdetails').value.colorId);
          this.exmpReg.get('colorValue').setValue(color.lkValueEname);
          if (this.exmpReg.get('vdetails').value.categoryId) {
            this.exmpReg.get('vcategory').setValue(this.exmpReg.get('vehicleCategories').value.find(category => category.categoryId == this.exmpReg.get('vdetails').value.categoryId).descriptionEn);
            this.enableCategorySelection = false;
          } else {
            this.enableCategorySelection = true;
            // if the clerk will manually select the vehicle category it should be required field
            this.exmpReg.get('selectedVehicleCategory').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_23__.Validators.required);
            // Trigger re-validation
            this.exmpReg.get('selectedVehicleCategory').updateValueAndValidity();
          }
          this.exmpReg.get('isStaffRate').setValue(this.exmpReg.get('vdetails').value.isStaffVehicle);
          this.exmpReg.get('isStaffRateValue').setValue(this.exmpReg.get('vdetails').value.isStaffVehicle);
          this.isWoqodVehicle = this.exmpReg.get('vdetails').value.isWaqodVehicle;
          this.exmpReg.get('nonEditable').setValue(true);
          this.exmpReg.get('displayServiceType').setValue(true);
          const isoDate = new Date(this.exmpReg.get('vdetails').value.licenseExpiryDate);
          const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_24__.DatePipe('en-US').transform(isoDate, 'dd-MM-yyyy');
          this.exmpReg.get('formatExpDate').setValue(dateFormat);
          this.exmpReg.get('showMoiError').setValue(false);
          this.exmpReg.get('phone').setValue(this.exmpReg.get('vdetails').value.contactPersonPhone);
          this.exmpReg.get('email').setValue(this.exmpReg.get('vdetails').value.contactPersonEmail);
          this.exmpReg.get('pid').setValue(this.exmpReg.get('vdetails').value.contactPersonPID);
          this.exmpReg.get('pidValue').setValue(this.exmpReg.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.exmpReg.get('vdetails').value.ownerPidType).lkValueEname);
          this.exmpReg.get('exmpReason').setValue(this.exmpReg.get('exemptedReason').value.find(exm => exm.lkCodeValue == this.exmpReg.get('vdetails').value.exemptedReason).lkValueEname);
          let subColor = this.exmpReg.get('colorList').value.find(color => color.lkCodeValue == this.exmpReg.get('vdetails').value.subColorId);
          this.exmpReg.get('subclr').setValue(subColor ?? null);
          this.onSelectServiceSubType(1);
        }
      }, error => {
        this.exmpReg.get('displayServiceType').setValue(false);
        if (error.error.ErrorMessage.includes("Time")) {
          this.errorMessage = "* Timeout error, please try again later";
        }
        if (error.error.ErrorMessage.includes("traffic")) {
          this.errorMessage = "* " + error.error.ErrorMessage;
        }
        if (error.error.ErrorMessage.includes("License")) {
          this.errorMessage = "* " + error.error.ErrorMessage;
        }
        if (error.error.ErrorMessage.includes("not found")) {
          this.exmpReg.get("showMoiError").setValue(true);
        }
      });
    }
    this.exmpReg.get('vdetails').setValue({});
    this.exmpReg.get('vcategory').setValue('');
    this.exmpReg.get('selectedVehicleCategory').setValue('');
    this.exmpReg.get('pidValue').setValue('');
    this.exmpReg.get('colorValue').setValue('');
    this.exmpReg.get('subclr').setValue('');
    this.exmpReg.get('isStaffRate').setValue(false);
    this.isExem = false;
  }
  checkVehicleServices() {
    const vehicleSer = {
      categoryId: this.exmpReg.get('selectedVehicleCategory').value,
      stationId: this.stationId
    };
    this.vehicleService.getVehicleServices(vehicleSer).subscribe(response => {
      this.vehicleServices = response.items;
      this.getServiceTypes();
    });
    this.exmpReg.get('displayServiceType').setValue(true);
  }
  getServiceTypes() {
    let counter = 1;
    for (const [index, key] of Object.keys(this.vehicleServices).entries()) {
      if (this.vehicleServices.hasOwnProperty(key)) {
        this.serviceFlags[index] = {
          value: this.vehicleServices[key].length > 0,
          id: counter++
        };
      }
    }
    //return this.vehicleServices ? Object.keys(this.vehicleServices) : [];
  }

  updateSelectedService(controlName) {
    this.exmpReg.get(controlName).setValue(true);
    const formControls = ['selectedServIns', 'selectedServVin', 'selectedServTanker'];
    formControls.forEach(control => {
      if (control !== controlName) {
        this.exmpReg.get(control).setValue(false);
      }
    });
  }
  onSelectServiceSubType(value) {
    if (value == 1) {
      this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('vehicleCategories').value.find(category => category.categoryId == this.exmpReg.get('vdetails').value.categoryId).categoryId);
      this.feesDetails.push({
        vinNo: this.exmpReg.get('vdetails').value.vinNo,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection,
        serviceId: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceTypes.NormalInspection,
        vehicleCategoryId: this.exmpReg.get('vcategoryType').value,
        isStaffRate: this.exmpReg.get('isStaffRate').value ? true : false
      });
      this.exmpReg.get('selectedServIns').setValue(true);
      this.exmpReg.get('isFormValid').setValue(true);
      if (this.exmpReg.get('isStaffRate').value && value == src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceTypes.NormalInspection) {
        this.feesInsChecked = true;
        this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(data => data.items)).subscribe(items => {
          for (let fee of items) {
            if (fee.serviceTypeId == 1) {
              this.exmpReg.get("feesIns").setValue(fee.feesAmount);
              this.exmpReg.get("feesDiscount").setValue(fee.feesDiscount);
              if (fee.feesAmount != 0) {
                this.subInsId = false;
              } else {
                this.subInsId = true;
                this.exmpReg.get('selectedPayment').setValue(src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.Cash);
              }
            }
          }
          const totalAmount = this.exmpReg.get('feesIns').value || 0;
          this.amountTh = this.thousandSeparator.addThousandSeparator(totalAmount.toString());
          this.exmpReg.get("amount").setValue(totalAmount);
        });
      } else {
        this.vehicleService.getServiceFeesAmount(this.feesDetails).subscribe(response => {
          this.inspectionFees = response.items[0].feesAmount;
        });
      }
    }
  }
  clearServices(serviceType, serviceId) {
    this.exmpReg.get('isFormValid').setValue(false);
    this.exmpReg.get('selectedInsSubType').setValue(null);
    this.exmpReg.get('selectedServIns').setValue(false);
  }
  onSelectPayment() {
    if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.CreditCustomer) {
      this.exmpReg.get('showCredit').setValue(true);
      this.vehicleService.getCreditCustomer(this.exmpReg.get('selectedCust').value).subscribe(data => {
        this.creditCustomerList = data.items;
      });
      this.isPaymentValid = this.exmpReg.get('selectedCust').value ? true : false;
    } else {
      this.exmpReg.get('showCredit').setValue(false);
      this.isPaymentValid = true;
    }
    this.paymentName = this.exmpReg.get('paymentTypes').value.find(payId => payId.lkCodeValue == this.exmpReg.get('selectedPayment').value).lkValueEname;
  }
  continueReceipt() {
    this.submitForm();
    this.submitPayment();
    const modalElement = document.getElementById('PrintReceipt');
    setTimeout(() => {
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
      this.cancel();
    }, 3000);
  }
  cancel() {
    this.sharedDataService.setTextEx('');
    this.location.back();
    this.displayPaymentDetails = 'none';
    this.isPaymentStarted = false;
  }
  submitForm() {
    const date = new Date();
    this.currentDateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_24__.DatePipe('en-US').transform(date, 'dd MMM yyyy');
    this.currentTimeFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_24__.DatePipe('en-US').transform(date, 'h:mm a');
    this.globalServ.getStationPaymentMethods(1).subscribe(response => {
      this.exmpReg.get('paymentTypes').setValue(response.items);
    });
    if (this.exmpReg.get('isFormValid').value) {
      if (this.exmpReg.get('isStaffRate').value || this.exmpReg.get('vdetails').value.isWaqodVehicle) {
        //this.printReceiptDirectly = true;
      }
      const currentDate = new Date();
      if (!this.exmpReg.get('nonEditable').value) {
        // for manual entry to be updated or removed
        this.vehicleDetailsModel = new src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_2__.VehicleDetails(this.exmpReg.get('inputPlateNo').value, this.exmpReg.get('inputPlateType').value, this.exmpReg.get('inputVinNo').value, this.exmpReg.get('selectedColor').value, this.exmpReg.get('selectedSubColor').value, this.exmpReg.get('selectedVehicleCategory').value, this.exmpReg.get('selectedModel').value, this.exmpReg.get('selectedManufacturer').value, this.exmpReg.get('inputManfYear').value, currentDate, this.exmpReg.get('inputCylinders').value, this.exmpReg.get('inputWeight').value, this.exmpReg.get('inputPayloadWeight').value, '', this.exmpReg.get('inputNbSeats').value, this.exmpReg.get('inputPid').value, this.exmpReg.get('inputOwnerName').value, this.exmpReg.get('expDate').value, 0, currentDate, 0, currentDate, '', '', null, null, null, null);
        this.vehicleService.registerVehicle(this.vehicleDetailsModel).subscribe(response => {});
        this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('vehicleCategories').value.find(category => category.categoryId == this.exmpReg.get('selectedVehicleCategory')).categoryId);
      } else {
        if (this.enableCategorySelection) {
          this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('selectedVehicleCategory').value);
        } else {
          this.exmpReg.get('vcategoryType').setValue(this.exmpReg.get('vdetails').value.categoryId);
        }
      }
      this.selectedServTypeValue = this.exmpReg.get('selectedServIns').value ? 1 : this.exmpReg.get('selectedServVin').value ? 2 : 3;
      if (!this.feesInsChecked) {
        this.feesDetails.push({
          vinNo: this.exmpReg.get('vdetails').value.vinNo,
          serviceTypeId: 1,
          serviceId: 1,
          vehicleCategoryId: this.exmpReg.get('vcategoryType').value,
          isStaffRate: this.exmpReg.get('isStaffRate').value ? true : false
        });
        this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(data => data.items)).subscribe(items => {
          for (let fee of items) {
            if (fee.serviceTypeId == 1) {
              this.exmpReg.get("feesIns").setValue(fee.feesAmount);
              this.exmpReg.get("feesDiscount").setValue(fee.feesDiscount);
            }
          }
          const totalAmount = this.exmpReg.get('feesIns').value || 0;
          this.exmpReg.get("amount").setValue(totalAmount);
        });
      } else {}
    } else {
      this.markFormGroupTouched(this.exmpReg);
    }
  }
  markFormGroupTouched(formGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
  cancelPayment() {
    this.feesDetails = [];
    this.exmpReg.get("selectedCust").setValue('');
    this.exmpReg.get("amount").setValue(null);
  }
  submitPayment() {
    const currentDate = new Date();
    const exmpRegServiceRequestData = {
      stationId: this.stationId,
      serviceType: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection,
      serviceID: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_3__.InspectionServiceTypes.NormalInspection,
      contactType: this.exmpReg.get('vdetails').value.ownerPidType,
      contactPersonName: '',
      contactPersonEmail: this.exmpReg.get('email').value,
      contactPersonPhone: this.exmpReg.get('phone').value.toString(),
      status: 1,
      registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.BackOffice,
      boothId: 1,
      posId: 1,
      remarks: '',
      requestRefId: 0,
      createdBy: this.userId,
      vinNo: this.exmpReg.get('vdetails').value.vinNo,
      plateType: parseInt(this.exmpReg.get('inputPlateType').value),
      plateNo: this.exmpReg.get('inputPlateNo').value
    };
    this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__.ServiceRequest(exmpRegServiceRequestData);
    this.vehicleService.insertServiceRequest(this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_25__.map)(data => data.items)).subscribe(items => {
      this.requestId = items;
      // upload attachments
      const fileInfoArray = this.fileService.getFileData();
      for (const fileInfo of fileInfoArray) {
        if (fileInfo) {
          const formData = new FormData();
          formData.append('requestId', this.requestId.toString());
          formData.append('sectionId', '');
          formData.append('defectId', '');
          formData.append('serviceTypeId', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Inspection.toString());
          formData.append('serviceId', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.Exempted.toString());
          formData.append('mimeType', fileInfo.mimeType);
          formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_8__.SystemLookupValueCodes.SupportDocuments.toString());
          formData.append('createdBy', this.userId.toString());
          formData.append('fileData', fileInfo.fileData, fileInfo.filename);
          this.globalServ.uploadAttachement(formData).subscribe(response => {}, error => {});
        }
      }
      // declare object values for RegisterVehicle
      const vehicleDetails = {
        requestId: this.requestId,
        plateNo: this.exmpReg.get('inputPlateNo').value,
        plateType: parseInt(this.exmpReg.get('inputPlateType').value),
        vinNo: this.exmpReg.get('vdetails').value.vinNo,
        colorId: this.exmpReg.get('vdetails').value.colorId,
        subColorId: this.exmpReg.get('vdetails').value.subColorId,
        categoryId: this.exmpReg.get('vcategoryType').value,
        vehicleModelId: this.exmpReg.get('vdetails').value.vehicleModelId,
        manufacturerId: this.exmpReg.get('vdetails').value.manufacturerId,
        manufacturerYear: this.exmpReg.get('vdetails').value.manufacturerYear,
        moiRegistrationDate: this.exmpReg.get('vdetails').value.moiRegistrationDate,
        cylinders: this.exmpReg.get('vdetails').value.cylinders,
        weight: this.exmpReg.get('vdetails').value.weight,
        payloadWeight: this.exmpReg.get('vdetails').value.payloadWeight,
        shapeCode: this.exmpReg.get('vdetails').value.shapeCode,
        descriptionEn: '',
        descriptionAr: '',
        noOfSeat: this.exmpReg.get('vdetails').value.noOfSeat,
        licenseExpiryDate: this.exmpReg.get('vdetails').value.licenseExpiryDate,
        ownerType: parseInt(this.exmpReg.get('vdetails').value.ownerPidType),
        contactPersonPid: this.exmpReg.get('pid').value,
        contactPersonEmail: this.exmpReg.get('email').value,
        contactPersonPhone: this.exmpReg.get('phone').value.toString(),
        ownerId: '0',
        ownerPid: this.exmpReg.get('vdetails').value.ownerPID,
        ownerPidType: parseInt(this.exmpReg.get('vdetails').value.ownerPidType),
        ownerName: this.exmpReg.get('vdetails').value.ownerName,
        departmentId: 0,
        createdBy: this.userId
      };
      // Create an instance of RegisterVehicle using vehicleDetails
      this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
      this.vehicleService.registerVehicle(this.registerVehicle).subscribe(response => {});
      let payment = {
        paymentMethodId: this.exmpReg.get('selectedPayment').value,
        serviceRequestFeesDto: [{
          feesAmount: this.exmpReg.get('amount').value,
          requestId: this.requestId,
          serviceTypeId: this.selectedServTypeValue,
          customerId: this.exmpReg.get('selectedCust').value == undefined ? null : parseInt(this.exmpReg.get('selectedCust').value),
          subDiscount: this.exmpReg.get('feesDiscount').value
        }]
      };
      this.isPaymentStarted = true;
      if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.Card) {
        this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_26__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_27__.catchError)(error => {
          if (error.name === 'TimeoutError') {
            this.isNotReachable = true;
            this.displayPaymentDetails = 'block';
          }
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_28__.throwError)(error);
        })).subscribe(data => {
          const paymentResult = data;
          const isCaptured = paymentResult.items.isCaptured;
          const isCanceled = paymentResult.items.isCanceled;
          const isDeviceNotReachable = paymentResult.items.isDeviceNotReachable;
          const messageCode = paymentResult.messageCode;
          const errorMessage = paymentResult.errorMessage;
          if (data.items) {
            if (!paymentResult.items.isCaptured && !paymentResult.items.isDeviceNotReachable) {
              this.isSuccess = true;
              setTimeout(() => {
                this.isPaymentStarted = false;
                this.cancel();
              }, 3000);
            } else {
              if (paymentResult.items.isCaptured) {
                this.isSuccess = true;
              }
              if (paymentResult.items.isCanceled) {
                this.isPayCanceled = true;
              }
              if (paymentResult.items.isDeviceNotReachable) {
                this.isNotReachable = true;
              }
            }
          } else {
            if (paymentResult.items.isCaptured) {
              this.isSuccess = true;
            }
            if (paymentResult.items.isCanceled) {
              this.isPayCanceled = true;
            }
            if (paymentResult.items.isDeviceNotReachable) {
              this.isNotReachable = true;
            }
          }
          this.displayPaymentDetails = 'block';
        }, error => {
          console.error(error);
          this.isPaymentStarted = false;
        });
      }
      if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.Cash) {
        this.paymentService.submitPayment(payment).subscribe(data => {
          if (data.items) {
            this.isSuccess = true;
            this.isNotReachable = false;
            this.isPayCanceled = false;
            setTimeout(() => {
              this.isPaymentStarted = false;
              this.cancel();
            }, 3000);
          } else {
            this.isNotReachable = true;
            this.isPayCanceled = false;
            this.isSuccess = false;
          }
        }, error => {
          this.isSuccess = false;
          this.displayPaymentDetails = 'block';
        });
      }
      if (this.exmpReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_5__.PaymentMethods.CreditCustomer) {
        this.paymentService.submitPayment(payment).subscribe(data => {
          if (data.items) {
            this.isSuccess = true;
            this.isPayCanceled = false;
            this.isNotReachable = false;
            setTimeout(() => {
              this.isPaymentStarted = false;
              this.cancel();
            }, 3000);
          } else {
            this.isNotReachable = true;
            this.isSuccess = false;
            this.isPayCanceled = false;
          }
          this.displayPaymentDetails = 'block';
        }, error => {
          this.isSuccess = false;
          this.displayPaymentDetails = 'block';
        });
      }
    });
  }
  sendPayment() {}
  downloadPayment() {
    this.ssrsPrintServ.downloadCustomerReport(this.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_4__.ModuleSourceEnum.exempted);
  }
  resetInfo() {
    this.exmpReg.get('displayServiceType').setValue(false);
    this.exmpReg.get('phone').setValue('');
    this.exmpReg.get('pid').setValue('');
    this.exmpReg.get('email').setValue('');
    this.enableCategorySelection = false;
  }
  ngOnDestroy() {
    this.sharedDataService.setTextEx('');
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function ExemptedComponent_Factory(t) {
    return new (t || ExemptedComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_9__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_10__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_11__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_22__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_24__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_12__.PurchaseService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_13__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_14__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_15__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_16__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_17__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_19__.ThousandSeparatorService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵdefineComponent"]({
    type: ExemptedComponent,
    selectors: [["app-exempted"]],
    hostBindings: function ExemptedComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("keydown", function ExemptedComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 80,
    vars: 21,
    consts: [[3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 4, "ngIf"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "formControlName", "phone", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "pid", 1, "form-control"], ["type", "text", "formControlName", "email", 1, "form-control"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 3, "disabled", "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 3, "click", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["class", "modal-dialog modal-dialog-centered", 4, "ngIf"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"], ["id", "errorPopup", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], [1, "modal-body"], [1, "pt-lab"], ["data-bs-backdrop", "static", "id", "PrintReceipt", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close", 3, "click"], ["data-bs-backdrop", "static", "id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "fileUploadModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [3, "fileUploaded"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], ["for", "myInput"], ["type", "number", "id", "myInput", "name", "plateNo", "formControlName", "inputPlateNo", 1, "form-control"], ["formControlName", "inputPlateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "form-control", "formControlName", "selectedVehicleCategory", 3, "ngModelChange", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "vcategory", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedOwnerType", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "pidValue", 3, "readonly", 4, "ngIf"], ["type", "text", "class", "form-control", 3, "value", "readonly", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPid", 4, "ngIf"], ["type", "text", "class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputOwnerName", 4, "ngIf"], ["type", "date", "class", "form-control", "formControlName", "expDate", 4, "ngIf"], [1, "accordion-body", "border-top"], ["type", "text", "class", "form-control", "formControlName", "inputVinNo", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedManufacturer", 3, "change", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedModel", 4, "ngIf"], ["class", "form-control", "formControlName", "inputManfYear", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputCylinders", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputWeight", 3, "readonly", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPayloadweight", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedColor", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "colorValue", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedSubColor", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputNbSeats", 4, "ngIf"], ["class", "col-md-6 col-lg-3", 4, "ngIf"], [1, "col-lg-6", "sr-vc"], ["class", "woqod", 4, "ngIf"], ["class", "staff-rate", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", "id", "attachExm", 1, "btn", "btn-vci"], [1, "bi", "bi-paperclip"], ["id", "fn", 4, "ngIf"], [1, "error-message"], [3, "value"], ["formControlName", "selectedVehicleCategory", 1, "form-control", 3, "ngModelChange"], ["type", "text", "formControlName", "vcategory", 1, "form-control", 3, "readonly"], ["formControlName", "selectedOwnerType", 1, "form-control"], ["type", "text", "formControlName", "pidValue", 1, "form-control", 3, "readonly"], ["type", "text", 1, "form-control", 3, "value", "readonly"], ["type", "number", "formControlName", "inputPid", 1, "form-control"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], ["type", "text", "formControlName", "inputOwnerName", 1, "form-control"], ["type", "date", "formControlName", "expDate", 1, "form-control"], ["type", "text", "formControlName", "inputVinNo", 1, "form-control"], ["formControlName", "selectedManufacturer", 1, "form-control", 3, "change"], ["formControlName", "selectedModel", 1, "form-control"], ["formControlName", "inputManfYear", 1, "form-control"], ["type", "number", "formControlName", "inputCylinders", 1, "form-control"], ["type", "number", "formControlName", "inputWeight", 1, "form-control", 3, "readonly"], ["type", "number", "formControlName", "inputPayloadweight", 1, "form-control", 3, "readonly"], ["formControlName", "selectedColor", 1, "form-control"], ["type", "text", "formControlName", "colorValue", 1, "form-control", 3, "readonly"], ["formControlName", "selectedSubColor", 1, "form-control"], ["type", "number", "formControlName", "inputNbSeats", 1, "form-control"], [1, "woqod"], [1, "warn", "warning-green"], [1, "staff-rate"], [1, "switch"], ["type", "checkbox", "formControlName", "isStaffRate", 3, "checked"], [1, "slider", "round"], ["id", "fn"], ["id", "accordionExample3", 1, "accordion", "section-accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [1, "outline-radio"], ["type", "radio", "id", "ins1", "checked", ""], ["for", "ins1"], ["src", "./assets/img/st-img-1.svg"], [1, "st-label"], [1, "btn-radio"], ["type", "radio", "id", "ns1", "name", "selectedInsSubType", "value", "1", "formControlName", "selectedInsSubType", 3, "ngModelChange"], ["for", "ns1"], ["class", "service-fees", 4, "ngIf"], [1, "service-fees"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "disabled", "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 1, "btn", "btn-orange", 3, "click"], ["id", "exampleModalLabel", 1, "modal-title"], ["class", "payment-info", 4, "ngIf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop2", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "payment-info"], [1, "payment-type"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["type", "radio", "formControlName", "selectedPayment", 3, "id", "value", "ngModelChange"], [3, "for"], [1, "col-md-6", "col-lg-6"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "formControlName", "selectedCust", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "clearSearchOnAdd", "minTermLength", "change"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"]],
    template: function ExemptedComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](0, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](1, "body")(2, "form", 0)(3, "section", 1)(4, "div", 2)(5, "div", 3)(6, "div", 2)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "div", 8)(12, "h2", 9)(13, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](14, " Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](15, ExemptedComponent_div_15_Template, 113, 51, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](16, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](17, "div", 2)(18, "div", 4)(19, "div", 12)(20, "div", 6)(21, "div", 13)(22, "div", 8)(23, "h2", 14)(24, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](25, " Contact Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](26, "div", 16)(27, "div", 17)(28, "div", 18)(29, "div", 19)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](31, "Phone No * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](32, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](33, ExemptedComponent_div_33_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](34, ExemptedComponent_div_34_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](35, "div", 19)(36, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](37, "PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](38, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](39, ExemptedComponent_div_39_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](40, ExemptedComponent_div_40_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](41, "div", 19)(42, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](43, "Email ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](44, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](45, ExemptedComponent_div_45_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](46, ExemptedComponent_div_46_Template, 28, 1, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](47, "div", 2)(48, "div", 25)(49, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function ExemptedComponent_Template_button_click_49_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](50, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](51, ExemptedComponent_button_51_Template, 2, 1, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](52, ExemptedComponent_button_52_Template, 2, 0, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](53, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtemplate"](54, ExemptedComponent_div_54_Template, 39, 5, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](55, "payment-transaction-status-modal", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("onCancelEvent", function ExemptedComponent_Template_payment_transaction_status_modal_onCancelEvent_55_listener() {
          return ctx.cancel();
        })("onCancelFailedEvent", function ExemptedComponent_Template_payment_transaction_status_modal_onCancelFailedEvent_55_listener() {
          return ctx.cancel();
        })("onDownloadPaymentEvent", function ExemptedComponent_Template_payment_transaction_status_modal_onDownloadPaymentEvent_55_listener() {
          return ctx.downloadPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](56, "div", 32)(57, "div", 33)(58, "div", 34)(59, "div", 35)(60, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](61, "Error");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](62, "div", 37)(63, "label", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](64, " Kindly, fill all the required fields ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](65, "div", 39)(66, "div", 33)(67, "div", 34)(68, "div", 35)(69, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelement"](70, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](71, " Receipt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](72, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("click", function ExemptedComponent_Template_button_click_72_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](73, "div", 37)(74, "label", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵtext"](75, " Printing Receipt... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementStart"](76, "div", 42)(77, "div", 33)(78, "div", 34)(79, "app-file-uploads", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵlistener"]("fileUploaded", function ExemptedComponent_Template_app_file_uploads_fileUploaded_79_listener($event) {
          return ctx.onFileUploaded($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("formGroup", ctx.exmpReg);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("phone").hasError("required") && ctx.exmpReg.get("phone").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("phone").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("pid").hasError("required") && ctx.exmpReg.get("pid").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("pid").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.exmpReg.get("email").hasError("email") || ctx.exmpReg.get("email").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !(ctx.isWoqodVehicle || ctx.exmpReg.get("isStaffRate").value && ctx.subInsId));
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", ctx.isWoqodVehicle || ctx.exmpReg.get("isStaffRate").value && ctx.subInsId);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("ngIf", !ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_22__["ɵɵproperty"]("isPaymentStarted", ctx.isPaymentStarted)("email", ctx.exmpReg.get("email").value)("isSuccess", ctx.isSuccess)("isPayCanceled", ctx.isPayCanceled)("isNotReachable", ctx.isNotReachable)("requestRefId", ctx.requestId)("currentDateFormat", ctx.currentDateFormat)("currentTimeFormat", ctx.currentTimeFormat)("totalAmountTh", ctx.amountTh)("paymentName", ctx.paymentName);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_24__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_24__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_23__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_23__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_23__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_23__.FormControlName, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_20__.FileUploadsComponent, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_21__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_29__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_29__.NgOptionComponent],
    styles: [".row[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    margin-left: 0px;\r\n    flex-grow: 1;\r\n}\r\n\r\n.section[_ngcontent-%COMP%] {\r\n    flex-grow: 1;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    color: red;\r\n    font-style: italic;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n.mr-2[_ngcontent-%COMP%] {\r\n    white-space: nowrap;\r\n    padding: 10px;\r\n}\r\n\r\n.remove-service[_ngcontent-%COMP%] {\r\n    position: absolute;\r\n    right: 0;\r\n    top: 0;\r\n    cursor: pointer;\r\n    font-weight: bold;\r\n    color: white;\r\n    font-size: 20px;\r\n    text-align: center;\r\n    width: 100%;\r\n    height: 100%;\r\n    display: inline-block;\r\n}\r\n\r\n.btn-radio[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n    vertical-align: middle;\r\n    position: relative;\r\n}\r\n\r\n#fn[_ngcontent-%COMP%] {\r\n    font-size: 13px;\r\n    font-style: italic;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%] {\r\n    font-size: 20px;\r\n    color: transparent;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n\r\n    top: 0.225em;\r\n\r\n    width: 1.15em;\r\n    height: 1.15em;\r\n\r\n    overflow: hidden;\r\n    border: none;\r\n    background-color: transparent;\r\n    border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::before {\r\n    content: \"\";\r\n    display: block;\r\n    top: -0.08em;\r\n    left: 0.0em;\r\n    position: absolute;\r\n    border: transparent 0.6em solid;\r\n    border-bottom-color: #448b23;\r\n    border-bottom-width: 1em;\r\n    border-top-width: 0;\r\n    box-shadow: #448b23 0 1px 1px;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::after {\r\n    display: block;\r\n    position: absolute;\r\n    top: 0.3em;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 0 1px;\r\n    text-align: center;\r\n    font-family: \"Garamond\";\r\n    content: \"!\";\r\n    font-size: 0.65em;\r\n    font-weight: bold;\r\n    color: white;\r\n}\r\n\r\n.woqod[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    box-shadow: #448b23 0 0.5px 0.5px;\r\n}\r\n\r\n.service-fees[_ngcontent-%COMP%] {\r\n    float: right;\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvZXhlbXB0ZWQvZXhlbXB0ZWQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1Ysa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7O0lBR0ksZ0JBQWdCO0lBQ2hCLFNBQVM7QUFDYjs7QUFFQTtJQUNJLG1CQUFtQjtJQUNuQixhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFFBQVE7SUFDUixNQUFNO0lBQ04sZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixZQUFZO0lBQ1osZUFBZTtJQUNmLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsWUFBWTtJQUNaLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLHFCQUFxQjtJQUNyQixzQkFBc0I7SUFDdEIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGVBQWU7SUFDZixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxxQkFBcUI7O0lBRXJCLFlBQVk7O0lBRVosYUFBYTtJQUNiLGNBQWM7O0lBRWQsZ0JBQWdCO0lBQ2hCLFlBQVk7SUFDWiw2QkFBNkI7SUFDN0Isc0JBQXNCO0FBQzFCOztBQUVBO0lBQ0ksV0FBVztJQUNYLGNBQWM7SUFDZCxZQUFZO0lBQ1osV0FBVztJQUNYLGtCQUFrQjtJQUNsQiwrQkFBK0I7SUFDL0IsNEJBQTRCO0lBQzVCLHdCQUF3QjtJQUN4QixtQkFBbUI7SUFDbkIsNkJBQTZCO0FBQ2pDOztBQUVBO0lBQ0ksY0FBYztJQUNkLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVc7SUFDWCxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLHVCQUF1QjtJQUN2QixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLGlDQUFpQztBQUNyQzs7QUFFQTtJQUNJLFlBQVk7SUFDWixnQkFBZ0I7QUFDcEIiLCJzb3VyY2VzQ29udGVudCI6WyIucm93IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICAgIGZsZXgtZ3JvdzogMTtcclxufVxyXG5cclxuLnNlY3Rpb24ge1xyXG4gICAgZmxleC1ncm93OiAxO1xyXG59XHJcblxyXG4uZXJyb3ItbWVzc2FnZSB7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59XHJcblxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uIHtcclxuICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5tci0yIHtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcblxyXG4ucmVtb3ZlLXNlcnZpY2Uge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4uYnRuLXJhZGlvIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbiNmbiB7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbn1cclxuXHJcbi53YXJuIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbiB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblxyXG4gICAgdG9wOiAwLjIyNWVtO1xyXG5cclxuICAgIHdpZHRoOiAxLjE1ZW07XHJcbiAgICBoZWlnaHQ6IDEuMTVlbTtcclxuXHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwLjYyNWVtO1xyXG59XHJcblxyXG4ud2Fybi53YXJuaW5nLWdyZWVuOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgdG9wOiAtMC4wOGVtO1xyXG4gICAgbGVmdDogMC4wZW07XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3JkZXI6IHRyYW5zcGFyZW50IDAuNmVtIHNvbGlkO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzQ0OGIyMztcclxuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IDFlbTtcclxuICAgIGJvcmRlci10b3Atd2lkdGg6IDA7XHJcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMXB4IDFweDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbjo6YWZ0ZXIge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDAuM2VtO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMCAxcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LWZhbWlseTogXCJHYXJhbW9uZFwiO1xyXG4gICAgY29udGVudDogXCIhXCI7XHJcbiAgICBmb250LXNpemU6IDAuNjVlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ud29xb2Qge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMC41cHggMC41cHg7XHJcbn1cclxuXHJcbi5zZXJ2aWNlLWZlZXMge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 97186:
/*!********************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/external-registration/external-registration.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExternalRegistrationComponent": () => (/* binding */ ExternalRegistrationComponent)
/* harmony export */ });
/* harmony import */ var C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! rxjs */ 68917);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! rxjs */ 56074);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! rxjs */ 63853);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! rxjs */ 91640);
/* harmony import */ var src_app_core_models_add_vehicle_details__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/add-vehicle-details */ 73874);
/* harmony import */ var src_app_core_models_insert_vehicle_equipment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/insert-vehicle-equipment */ 69537);
/* harmony import */ var src_app_core_models_location__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/location */ 83439);
/* harmony import */ var src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/models/register-vehicle */ 54611);
/* harmony import */ var src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/models/service-request */ 84908);
/* harmony import */ var src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/models/vehicle-details */ 43347);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/utilities/enums/report-type.enum */ 76622);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/purchase.service */ 87010);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);



































const _c0 = ["fileInput"];
function ExternalRegistrationComponent_h2_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "h2", 44)(1, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](2, " Vehicle Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
}
function ExternalRegistrationComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 46)(1, "span", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](2, " Vehicle Summary ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const v_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]().$implicit;
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r16.mapToArea(v_r14.area), " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r17.externalRegForm.get("selectedAreaName").value, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const i_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]().index;
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r18.saveSelectedLocation[i_r15].locationName, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r19.externalRegForm.get("selectedLocationName").value, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const v_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", v_r14.phone, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_td_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r21.externalRegForm.get("phone").value, " ");
  }
}
function ExternalRegistrationComponent_div_15_tr_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](9, ExternalRegistrationComponent_div_15_tr_24_td_9_Template, 2, 1, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](10, ExternalRegistrationComponent_div_15_tr_24_td_10_Template, 2, 1, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](11, ExternalRegistrationComponent_div_15_tr_24_td_11_Template, 2, 1, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](12, ExternalRegistrationComponent_div_15_tr_24_td_12_Template, 2, 1, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](13, ExternalRegistrationComponent_div_15_tr_24_td_13_Template, 2, 1, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](14, ExternalRegistrationComponent_div_15_tr_24_td_14_Template, 2, 1, "td", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](17, "td")(18, "button", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_div_15_tr_24_Template_button_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r26);
      const i_r15 = restoredCtx.index;
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r25.deleteVehicle(i_r15));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](19, "i", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const v_r14 = ctx.$implicit;
    const i_r15 = ctx.index;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", v_r14.vdetails.vinNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", v_r14.vdetails.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r13.mapToPlateName(v_r14.vdetails.plateType), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", v_r14.vCategoryText, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r13.externalRegForm.get("checkAllLocation").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r13.externalRegForm.get("checkAllContact").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r13.externalRegForm.get("checkAllContact").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r13.feesArray[i_r15], " ");
  }
}
function ExternalRegistrationComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 48)(1, "div", 49)(2, "div", 50)(3, "table", 51)(4, "thead")(5, "tr", 52)(6, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](7, " VIN Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](8, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](9, " Plate Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](10, "th", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](11, " License Plate Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](12, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](13, " Vehicle Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](14, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](15, " Area ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](16, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](17, " Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](18, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](19, " Contact Number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](20, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](21, " Cost ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](22, "th", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](23, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](24, ExternalRegistrationComponent_div_15_tr_24_Template, 20, 11, "tr", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](25, "tr")(26, "td", 56)(27, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](28, " Total Cost ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](29, "td", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r2.vehicles);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r2.amountTh, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * This Vehicle is Not Registered in MOI ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Vehicle Already Added ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r32.errorMessage, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r33.extError, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r34.woqodErrorMsg, " ");
  }
}
function ExternalRegistrationComponent_div_16_option_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r80 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", pt_r80.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", pt_r80.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_select_30_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r82 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", vc_r82.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", vc_r82.descriptionEn, "");
  }
}
function ExternalRegistrationComponent_div_16_select_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("ngModelChange", function ExternalRegistrationComponent_div_16_select_30_Template_select_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r83.onSelectCategory());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_30_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r37.externalRegForm.get("vehicleCategories").value);
  }
}
function ExternalRegistrationComponent_div_16_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Not an External Vehicle Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 108);
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r39.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_select_36_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ot_r86 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ot_r86.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ot_r86.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_36_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r40.externalRegForm.get("ownerTypes").value);
  }
}
function ExternalRegistrationComponent_div_16_input_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 110);
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r41.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_input_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r42.externalRegForm.get("vdetails").value.ownerPID ? ctx_r42.externalRegForm.get("vdetails").value.ownerPID : "");
  }
}
function ExternalRegistrationComponent_div_16_input_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 112);
  }
}
function ExternalRegistrationComponent_div_16_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r45.externalRegForm.get("vdetails").value.ownerName ? ctx_r45.externalRegForm.get("vdetails").value.ownerName : "");
  }
}
function ExternalRegistrationComponent_div_16_input_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 113);
  }
}
function ExternalRegistrationComponent_div_16_input_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 114);
  }
}
function ExternalRegistrationComponent_div_16_input_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 115);
  }
  if (rf & 2) {
    const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r48.externalRegForm.get("vdetails").value.licenseExpiryDate ? ctx_r48.externalRegForm.get("formatExpDate").value : "")("readonly", ctx_r48.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Invalid date format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_55_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Istimara Date must be valid at least 30 days from now ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r51.externalRegForm.get("vdetails").value.vinNo ? ctx_r51.externalRegForm.get("vdetails").value.vinNo : "");
  }
}
function ExternalRegistrationComponent_div_16_input_62_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 116);
  }
}
function ExternalRegistrationComponent_div_16_select_66_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r88 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", m_r88.manufacturersId);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", m_r88.manufacturersEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_16_select_66_Template_select_change_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r90);
      const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r89.getModelTypes($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_66_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r53.externalRegForm.get("manufacturerTypes").value);
  }
}
function ExternalRegistrationComponent_div_16_input_67_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 115);
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r54.externalRegForm.get("vdetails").value.manufacturersEname ? ctx_r54.externalRegForm.get("vdetails").value.manufacturersEname : "")("readonly", ctx_r54.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_select_71_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const m_r92 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", m_r92.modelId);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", m_r92.modelEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_71_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r55.externalRegForm.get("modelTypes").value);
  }
}
function ExternalRegistrationComponent_div_16_input_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 115);
  }
  if (rf & 2) {
    const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r56.externalRegForm.get("vdetails").value.modelEname ? ctx_r56.externalRegForm.get("vdetails").value.modelEname : "")("readonly", ctx_r56.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_input_76_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r57.externalRegForm.get("vdetails").value.manufacturerYear ? ctx_r57.externalRegForm.get("vdetails").value.manufacturerYear : "");
  }
}
function ExternalRegistrationComponent_div_16_select_77_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const year_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", year_r94);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate"](year_r94);
  }
}
function ExternalRegistrationComponent_div_16_select_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_77_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r58 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r58.getYearRange());
  }
}
function ExternalRegistrationComponent_div_16_input_81_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r59.externalRegForm.get("vdetails").value.cylinders ? ctx_r59.externalRegForm.get("vdetails").value.cylinders : "");
  }
}
function ExternalRegistrationComponent_div_16_input_82_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 120);
  }
}
function ExternalRegistrationComponent_div_16_div_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, "Enter a valid vehicle cylinders");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_87_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r62.externalRegForm.get("vdetails").value.weight ? ctx_r62.externalRegForm.get("vdetails").value.weight : "");
  }
}
function ExternalRegistrationComponent_div_16_input_88_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 121);
  }
  if (rf & 2) {
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r63.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_div_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, "Enter a valid weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_input_93_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r65.externalRegForm.get("vdetails").value.payloadWeight ? ctx_r65.externalRegForm.get("vdetails").value.payloadWeight : "");
  }
}
function ExternalRegistrationComponent_div_16_input_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 122);
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r66.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_div_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, "Enter a valid payload weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_select_99_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r96 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", color_r96.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", color_r96.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_99_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_99_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r68.externalRegForm.get("colorList").value);
  }
}
function ExternalRegistrationComponent_div_16_input_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 124);
  }
  if (rf & 2) {
    const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r69.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_select_104_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r98 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", color_r98.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", color_r98.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_16_select_104_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_16_select_104_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r70.externalRegForm.get("colorList").value);
  }
}
function ExternalRegistrationComponent_div_16_input_105_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 115);
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r71.externalRegForm.get("subclr").value)("readonly", ctx_r71.externalRegForm.get("nonEditable").value);
  }
}
function ExternalRegistrationComponent_div_16_input_109_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 111);
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r72.externalRegForm.get("vdetails").value.noOfSeat ? ctx_r72.externalRegForm.get("vdetails").value.noOfSeat : "");
  }
}
function ExternalRegistrationComponent_div_16_input_110_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 126);
  }
}
function ExternalRegistrationComponent_div_16_div_111_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, "Enter a valid No of seats ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_16_div_113_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" Reinspection ", ctx_r99.externalRegForm.get("noOfReinspections").value, "");
  }
}
function ExternalRegistrationComponent_div_16_div_113_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 127);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](1, "div", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](2, ExternalRegistrationComponent_div_16_div_113_span_2_Template, 2, 1, "span", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r75.isReinspectionExt);
  }
}
function ExternalRegistrationComponent_div_16_div_114_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](1, "div", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](3, " Woqod Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
}
function ExternalRegistrationComponent_div_16_div_115_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 131)(1, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](2, "input", 133)(3, "span", 134);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](4, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](5, "Apply Staff Rate");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("checked", ctx_r77.externalRegForm.get("isStaffRate").value);
  }
}
function ExternalRegistrationComponent_div_16_span_122_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "span", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r79.fileName, " ");
  }
}
function ExternalRegistrationComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r101 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 61)(1, "div", 49)(2, "div", 62)(3, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](4, "img", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](5, "div", 65)(6, "input", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("keyup.enter", function ExternalRegistrationComponent_div_16_Template_input_keyup_enter_6_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r101);
      const ctx_r100 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r100.barCodeScanner());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](7, ExternalRegistrationComponent_div_16_div_7_Template, 2, 0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](8, ExternalRegistrationComponent_div_16_div_8_Template, 2, 0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](10, "div", 62)(11, "div", 63)(12, "label", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](13, " License Plate No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](14, "input", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("ngModelChange", function ExternalRegistrationComponent_div_16_Template_input_ngModelChange_14_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r101);
      const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r102.savePlateNo = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](15, ExternalRegistrationComponent_div_16_div_15_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_16_div_16_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](17, ExternalRegistrationComponent_div_16_div_17_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](18, ExternalRegistrationComponent_div_16_div_18_Template, 2, 1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](19, ExternalRegistrationComponent_div_16_div_19_Template, 2, 1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](20, ExternalRegistrationComponent_div_16_div_20_Template, 2, 1, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](21, "div", 63)(22, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](23, " License Plate Type * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](24, "select", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](25, ExternalRegistrationComponent_div_16_option_25_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](26, ExternalRegistrationComponent_div_16_div_26_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](27, "div", 63)(28, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](29, "Vehicle Category");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](30, ExternalRegistrationComponent_div_16_select_30_Template, 2, 1, "select", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](31, ExternalRegistrationComponent_div_16_div_31_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](32, ExternalRegistrationComponent_div_16_input_32_Template, 1, 1, "input", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](33, "div", 63)(34, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](35, "Owner PID Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](36, ExternalRegistrationComponent_div_16_select_36_Template, 2, 1, "select", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](37, ExternalRegistrationComponent_div_16_input_37_Template, 1, 1, "input", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](38, "div", 63)(39, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](40, "Owner PID");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](41, ExternalRegistrationComponent_div_16_input_41_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](42, ExternalRegistrationComponent_div_16_input_42_Template, 1, 0, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](43, ExternalRegistrationComponent_div_16_div_43_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](44, "div", 63)(45, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](46, "Owner Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](47, ExternalRegistrationComponent_div_16_input_47_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](48, ExternalRegistrationComponent_div_16_input_48_Template, 1, 0, "input", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](49, "div", 63)(50, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](51, "Istimara Expiry Date");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](52, ExternalRegistrationComponent_div_16_input_52_Template, 1, 0, "input", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](53, ExternalRegistrationComponent_div_16_input_53_Template, 1, 2, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](54, ExternalRegistrationComponent_div_16_div_54_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](55, ExternalRegistrationComponent_div_16_div_55_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](56, "div", 83)(57, "div", 62)(58, "div", 63)(59, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](60, "VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](61, ExternalRegistrationComponent_div_16_input_61_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](62, ExternalRegistrationComponent_div_16_input_62_Template, 1, 0, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](63, "div", 63)(64, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](65, "Manufacturer");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](66, ExternalRegistrationComponent_div_16_select_66_Template, 2, 1, "select", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](67, ExternalRegistrationComponent_div_16_input_67_Template, 1, 2, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](68, "div", 63)(69, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](70, "Model");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](71, ExternalRegistrationComponent_div_16_select_71_Template, 2, 1, "select", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](72, ExternalRegistrationComponent_div_16_input_72_Template, 1, 2, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](73, "div", 63)(74, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](75, "Manufacturing Year");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](76, ExternalRegistrationComponent_div_16_input_76_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](77, ExternalRegistrationComponent_div_16_select_77_Template, 2, 1, "select", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](78, "div", 63)(79, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](80, "Cylinders");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](81, ExternalRegistrationComponent_div_16_input_81_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](82, ExternalRegistrationComponent_div_16_input_82_Template, 1, 0, "input", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](83, ExternalRegistrationComponent_div_16_div_83_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](84, "div", 63)(85, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](86, "Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](87, ExternalRegistrationComponent_div_16_input_87_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](88, ExternalRegistrationComponent_div_16_input_88_Template, 1, 1, "input", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](89, ExternalRegistrationComponent_div_16_div_89_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](90, "div", 63)(91, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](92, "Payload Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](93, ExternalRegistrationComponent_div_16_input_93_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](94, ExternalRegistrationComponent_div_16_input_94_Template, 1, 1, "input", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](95, ExternalRegistrationComponent_div_16_div_95_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](96, "div", 63)(97, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](98, "Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](99, ExternalRegistrationComponent_div_16_select_99_Template, 2, 1, "select", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](100, ExternalRegistrationComponent_div_16_input_100_Template, 1, 1, "input", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](101, "div", 63)(102, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](103, "Sub Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](104, ExternalRegistrationComponent_div_16_select_104_Template, 2, 1, "select", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](105, ExternalRegistrationComponent_div_16_input_105_Template, 1, 2, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](106, "div", 63)(107, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](108, "Seats");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](109, ExternalRegistrationComponent_div_16_input_109_Template, 1, 1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](110, ExternalRegistrationComponent_div_16_input_110_Template, 1, 0, "input", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](111, ExternalRegistrationComponent_div_16_div_111_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](112, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](113, ExternalRegistrationComponent_div_16_div_113_Template, 3, 1, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](114, ExternalRegistrationComponent_div_16_div_114_Template, 4, 0, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](115, ExternalRegistrationComponent_div_16_div_115_Template, 6, 1, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](116, "div", 95)(117, "input", 99, 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_16_Template_input_change_117_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r101);
      const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r103.handleFile($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](119, "button", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](120, "span", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](121, " Attachement ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](122, ExternalRegistrationComponent_div_16_span_122_Template, 2, 1, "span", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("barCode").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("barCode").value && !ctx_r3.externalRegForm.get("barCode").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngModel", ctx_r3.savePlateNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPlateNo").invalid && ctx_r3.externalRegForm.get("inputPlateNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("showMoiError").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.duplicateError);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.errorMessage);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.isExt);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.isWoqodAdded != ctx_r3.isWoqod);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r3.externalRegForm.get("plateTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPlateType").invalid && ctx_r3.externalRegForm.get("inputPlateType").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value || ctx_r3.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.vehicleCategError);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value && !ctx_r3.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPid").invalid && ctx_r3.externalRegForm.get("inputPid").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("expDate").hasError("invalidDate") && ctx_r3.externalRegForm.get("expDate").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("expDate").hasError("futureDate"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputCylinders").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputWeight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputPayloadweight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r3.externalRegForm.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("inputNbSeats").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.isReinspectionExt);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.isWoqod);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.externalRegForm.get("isStaffRateValue").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r3.fileName);
  }
}
function ExternalRegistrationComponent_div_18_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Please enter a valid phone number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " * Enter a valid PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, "Enter a valid email");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 136)(3, "div", 6)(4, "div", 137)(5, "div", 8)(6, "h2", 46)(7, "button", 138);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](8, " Contact Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](9, "div", 139)(10, "div", 49)(11, "div", 62)(12, "div", 63)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](14, "Phone No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](15, "input", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_18_div_16_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](17, ExternalRegistrationComponent_div_18_div_17_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](18, "div", 63)(19, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](20, "PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](21, "input", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](22, ExternalRegistrationComponent_div_18_div_22_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](23, "div", 63)(24, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](25, " Email ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](26, "input", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](27, ExternalRegistrationComponent_div_18_div_27_Template, 2, 0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r4.externalRegForm.get("checkAllContact").value && ctx_r4.isInputReadOnly.phone);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("phone").hasError("required") && ctx_r4.externalRegForm.get("phone").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("phone").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r4.externalRegForm.get("checkAllContact").value && ctx_r4.isInputReadOnly.pid);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("pid").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("readonly", ctx_r4.externalRegForm.get("checkAllContact").value && ctx_r4.isInputReadOnly.email);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r4.externalRegForm.get("email").hasError("email"));
  }
}
function ExternalRegistrationComponent_div_19_select_15_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const area_r113 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", area_r113.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate"](area_r113.labelEname);
  }
}
function ExternalRegistrationComponent_div_19_select_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r115 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_19_select_15_Template_select_change_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r115);
      const ctx_r114 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r114.getLocationArea());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](1, ExternalRegistrationComponent_div_19_select_15_option_1_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r108.areaList);
  }
}
function ExternalRegistrationComponent_div_19_input_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 155);
  }
  if (rf & 2) {
    const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r109.externalRegForm.get("selectedAreaName").value);
  }
}
function ExternalRegistrationComponent_div_19_select_20_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const location_r117 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", location_r117.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"]("", location_r117.labelEname, " ");
  }
}
function ExternalRegistrationComponent_div_19_select_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r119 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "select", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_19_select_20_Template_select_change_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r119);
      const ctx_r118 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r118.onSelectLocation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](1, "option");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](2, ExternalRegistrationComponent_div_19_select_20_option_2_Template, 2, 2, "option", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵclassProp"]("readonly", ctx_r110.externalRegForm.get("checkAllLocation").value && ctx_r110.externalRegForm.get("selectedLocation").value != "");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r110.locationList);
  }
}
function ExternalRegistrationComponent_div_19_input_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](0, "input", 155);
  }
  if (rf & 2) {
    const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", ctx_r111.externalRegForm.get("selectedLocationName").value);
  }
}
function ExternalRegistrationComponent_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 136)(3, "div", 6)(4, "div", 143)(5, "div", 8)(6, "h2", 46)(7, "button", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](8, " Area - Location ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](9, "div", 145)(10, "div", 49)(11, "div", 62)(12, "div", 63)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](14, " Area * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](15, ExternalRegistrationComponent_div_19_select_15_Template, 2, 1, "select", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_19_input_16_Template, 1, 1, "input", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](17, "div", 63)(18, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](19, " Location * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](20, ExternalRegistrationComponent_div_19_select_20_Template, 3, 3, "select", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](21, ExternalRegistrationComponent_div_19_input_21_Template, 1, 1, "input", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](22, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](23, "div", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](24, "input", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](25, "label", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](26, " Apply this contact to all vehicles ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](27, "div", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](28, "input", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](29, "label", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](30, " Apply this location to all vehicles ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r5.externalRegForm.get("checkAllLocation").value || ctx_r5.externalRegForm.get("selectedArea").value == "" || !ctx_r5.isInputReadOnly.loc);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r5.externalRegForm.get("checkAllLocation").value && ctx_r5.isInputReadOnly.loc);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx_r5.externalRegForm.get("checkAllLocation").value || ctx_r5.externalRegForm.get("selectedLocation").value == "" || !ctx_r5.isInputReadOnly.loc);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r5.externalRegForm.get("checkAllLocation").value && ctx_r5.isInputReadOnly.loc);
  }
}
function ExternalRegistrationComponent_button_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r121 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "button", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_24_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r121);
      const ctx_r120 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r120.backToScreen());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Add New Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_button_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r123 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "button", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_25_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r123);
      const ctx_r122 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r122.addVehicle());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Add Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("disabled", !ctx_r7.externalRegForm.valid || !ctx_r7.isValidInput || ctx_r7.vehicleCategError);
  }
}
function ExternalRegistrationComponent_button_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r125 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "button", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_26_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r125);
      const ctx_r124 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r124.viewAddedVehicles());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " View Added Vehicles ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_button_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "button", 160);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Confirm & Pay ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("disabled", ctx_r9.inserted || ctx_r9.vehicles.length == 0);
  }
}
function ExternalRegistrationComponent_button_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r127 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "button", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_button_44_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r127);
      const ctx_r126 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      ctx_r126.addVehicleDB();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r126.submitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](1, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
  }
}
function ExternalRegistrationComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 35)(1, "div", 22)(2, "div", 36)(3, "h1", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](4, " Payment ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](5, "div", 40)(6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](7, " The vehicle is registered for a Staff or as Woqod vehicle");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()();
  }
}
function ExternalRegistrationComponent_div_47_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r133 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 173)(1, "input", 174);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("ngModelChange", function ExternalRegistrationComponent_div_47_div_8_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r133);
      const ctx_r132 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r132.onSelectPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](2, "label", 175);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const pt_r131 = ctx.$implicit;
    const ctx_r128 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("id", "pt" + pt_r131.lkCodeValue)("value", pt_r131.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵattribute"]("disabled", !ctx_r128.enableCashMethodSetting && pt_r131.lkCodeValue == 1 ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("for", "pt" + pt_r131.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", pt_r131.lkValueEname, " ");
  }
}
function ExternalRegistrationComponent_div_47_div_10_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "ng-option", 182)(1, "div", 183);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r135 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", c_r135.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", c_r135.customerName, " ");
  }
}
function ExternalRegistrationComponent_div_47_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r137 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 176)(1, "div", 177)(2, "label", 178);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](4, "ng-select", 179);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("change", function ExternalRegistrationComponent_div_47_div_10_Template_ng_select_change_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r137);
      const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r136.isPaymentValid = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementContainerStart"](5, 180);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](6, "ng-option", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](7, ExternalRegistrationComponent_div_47_div_10_ng_option_7_Template, 3, 2, "ng-option", 181);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r129 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r129.creditCustomerList);
  }
}
function ExternalRegistrationComponent_div_47_tr_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const e_r138 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", e_r138.vinNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", e_r138.amount, " ");
  }
}
function ExternalRegistrationComponent_div_47_Template(rf, ctx) {
  if (rf & 1) {
    const _r140 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "div", 35)(1, "div", 22)(2, "div", 36)(3, "h1", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](4, "Payment Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](5, "div", 40)(6, "div", 163)(7, "div", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](8, ExternalRegistrationComponent_div_47_div_8_Template, 4, 5, "div", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](10, ExternalRegistrationComponent_div_47_div_10_Template, 8, 4, "div", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](11, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](12, "div", 167)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](14, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](15, "div", 2)(16, "div", 168)(17, "table", 169)(18, "thead")(19, "tr")(20, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](21, "Vehicle VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](22, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](23, "Fees");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](24, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](25, ExternalRegistrationComponent_div_47_tr_25_Template, 5, 2, "tr", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](26, "tfoot")(27, "tr")(28, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](29, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](30, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](32, "div", 170)(33, "button", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_div_47_Template_button_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r140);
      const ctx_r139 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r139.closePayPop());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](34, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](35, "button", 172);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_div_47_Template_button_click_35_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵrestoreView"](_r140);
      const ctx_r141 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵresetView"](ctx_r141.submitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](36, "Submit");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r12.externalRegForm.get("paymentTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx_r12.externalRegForm.get("showCredit").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngForOf", ctx_r12.listVehicle);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtextInterpolate1"](" ", ctx_r12.amountTh, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("disabled", !ctx_r12.isPaymentValid);
  }
}
class ExternalRegistrationComponent {
  constructor(fb, render, fileService, lookupServ, vehicleService, purchase, router, sharedLookup, sideNav, paymentService, ssrsPrintServ, sharedDataService, globalServ, el, thousandSeparator) {
    this.fb = fb;
    this.render = render;
    this.fileService = fileService;
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.purchase = purchase;
    this.router = router;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.paymentService = paymentService;
    this.ssrsPrintServ = ssrsPrintServ;
    this.sharedDataService = sharedDataService;
    this.globalServ = globalServ;
    this.el = el;
    this.thousandSeparator = thousandSeparator;
    this.isPaymentStarted = false;
    this.printReceiptDirectly = false;
    //vehicleDetailsModel: VehicleDetails;
    this.vehicles = [];
    this.equipments = [];
    this.creditCustomerList = [];
    this.inputPlateTypeTouched = false;
    this.inserted = false;
    this.paymentName = 'Card';
    this.listVehicle = [];
    this.saveSelectedLocation = [];
    this.isWoqod = false;
    this.isWoqodAdded = false;
    this.isInputReadOnly = {
      phone: false,
      email: false,
      pid: false,
      loc: false
    };
    this.displayPaymentDetails = 'none';
    this.enableCategorySelection = false;
    this.vehicleCategError = false;
    this.feesDetails = [];
    this.enableCashMethodSetting = true;
    this.isPaymentValid = true;
    this.feesArray = [];
    this.areaList = [];
    this.locationList = [];
    this.externalRegForm = this.fb.group({
      inputPlateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required],
      inputPlateNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required],
      selectedPayment: ['Card'],
      selectedOwnerType: [''],
      selectedServType: [1],
      selectedServName: [''],
      selectedManufacturer: [],
      selectedModel: [],
      selectedVehicleCategory: null,
      selectedColor: [''],
      selectedSubColor: [''],
      selectedArea: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required],
      selectedLocation: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required],
      selectedAreaName: [''],
      selectedLocationName: [''],
      selectedCust: [],
      checkAllContact: [false],
      checkAllLocation: [false],
      nonEditable: [true],
      isStaffRate: [false],
      isStaffRateValue: [false],
      showCredit: [false],
      showErrorPopup: [true],
      showScreen: [true],
      vdetails: [{}],
      colorList: [[]],
      ownerTypes: [[]],
      plateTypes: [[]],
      manufacturerTypes: [[]],
      modelTypes: [[]],
      vehicleCategories: [[]],
      lookupValues: [{}],
      expDate: [''],
      pidValue: [''],
      colorValue: [''],
      subclr: [' '],
      vcategory: [''],
      fees: [],
      feesDiscount: [],
      amount: [],
      inputOwnerType: [''],
      inputPid: [' ', [_angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required]],
      inputOwnerName: [''],
      inputVinNo: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required],
      inputManfYear: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern('^[0-9]*$')],
      inputCylinders: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern('^[0-9]*$')],
      inputWeight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern('^[0-9]*$')],
      inputPayloadweight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern('^[0-9]*$')],
      inputNbSeats: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern('^[0-9]*$')],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern(/^[34567]\d{7}$/)]],
      pid: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern(/^.{1,20}$/)]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern(/^.{1,60}$/)]],
      cost: [],
      totalCost: [0],
      canPay: [false],
      isAddVehicle: [false],
      paymentTypes: [[]],
      formatExpDate: [],
      showMoiError: [],
      barCode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.pattern(/^.{3,8}$/)],
      noOfReinspections: [null]
    });
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  dateValidator(control) {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    const minDate = new Date(currentDate);
    minDate.setDate(currentDate.getDate() + 30);
    if (isNaN(selectedDate.getTime())) {
      return {
        invalidDate: true
      };
    }
    if (selectedDate < minDate) {
      return {
        futureDate: true
      };
    }
    return null;
  }
  getYearRange() {
    const startYear = 1900;
    const currentYear = new Date().getFullYear();
    const yearRange = [];
    for (let year = currentYear + 1; year >= startYear; year--) {
      yearRange.push(year);
    }
    return yearRange;
  }
  qatarPhoneNumberValidator() {
    return control => {
      const phoneNumber = control.value;
      if (!phoneNumber) {
        return null; // If the control is empty, consider it valid.
      }
      // Remove any non-digit characters and spaces
      const cleanedPhoneNumber = phoneNumber.replace(/[^0-9]/g, '');
      // Check if the cleaned phone number matches the Qatar format
      if (/^(974)?[56789]\d{7}$/.test(cleanedPhoneNumber)) {
        // Format the phone number in the desired format
        const formattedPhoneNumber = `+974 ${cleanedPhoneNumber.substring(1, 4)} ${cleanedPhoneNumber.substring(4)}`;
        // Update the control's value with the formatted phone number
        control.setValue(formattedPhoneNumber);
        return null; // Validation passed
      } else {
        return {
          qatarPhoneNumber: true
        }; // Validation failed
      }
    };
  }

  ngOnInit() {
    this.sideNav.setActiveEnt(2, 4);
    /* this.sharedDataService.userId$.subscribe((userId) => {
       this.userId = userId;
     });*/
    /* this.sharedDataService.stationId$.subscribe((res) => {
       this.stationId = res;
     }); */
    this.userId = parseInt(localStorage.getItem('userId'));
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.extData = this.externalRegForm.value;
    this.sharedLookup.colorList$.subscribe(data => {
      this.externalRegForm.get('colorList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.externalRegForm.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.externalRegForm.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.manufacturerTypes$.subscribe(data => {
      this.externalRegForm.get('manufacturerTypes').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.externalRegForm.get('plateTypes').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_12__.SystemLookupCodes.paymentMethods).subscribe(data => {
      this.externalRegForm.get('paymentTypes').setValue(data.items);
      const firstPaymentType = data.items.find(item => item.lkValueAname === 'Card').lkCodeValue;
      this.externalRegForm.get('selectedPayment').setValue(firstPaymentType);
    });
    this.vehicleService.getAreas().subscribe(data => {
      this.areaList = data.items;
    });
    this.externalRegForm.get('inputPlateNo').valueChanges.subscribe(value => {
      if (this.externalRegForm.get('inputPlateNo').valueChanges) {
        this.externalRegForm.get('barCode').value ? null : this.externalRegForm.get('inputPlateType').setValue('');
        this.enableCategorySelection = false;
        this.vehicleCategError = false;
        this.woqodErrorMsg = '';
        this.extError = '';
        this.duplicateError = false;
        this.isWoqod = false;
      }
    });
    this.externalRegForm.get('inputPlateType').valueChanges.subscribe(value => {
      if (!this.externalRegForm.get('barCode').value) {
        this.savePlateNo = parseInt(this.externalRegForm.get('inputPlateNo').value);
        this.savePlateType = parseInt(this.externalRegForm.get('inputPlateType').value);
        this.getVehicleDetails();
        this.isValidInput = true;
      } else {
        this.savePlateType = this.externalRegForm.get('inputPlateType').value;
        this.getVehicleDetails();
      }
    });
    // check if cash is enabled
    this.sharedDataService.stationSetting$.subscribe(res => {
      const checkCashMethod = res.find(item => item.key === "EnableCashMethod" && item.value === "True");
      if (checkCashMethod != undefined) {
        this.enableCashMethodSetting = checkCashMethod;
      }
    });
    // check if email has been already added
    this.externalRegForm.get('email').valueChanges.subscribe(value => {
      if (this.externalRegForm.get('email').valid) {
        this.sendEmail = true;
      }
    });
  }
  onFileUploaded(fname) {
    this.fileName = fname;
  }
  barCodeScanner() {
    const barCodeTxt = this.externalRegForm.get('barCode').value;
    if (barCodeTxt) {
      this.savePlateNo = parseInt(barCodeTxt.substring(2));
      this.savePlateType = parseInt(barCodeTxt.substring(0, 2));
      this.externalRegForm.get('inputPlateType').setValue(this.savePlateType);
      //this.getVehicleDetails();
    }
  }

  getLocationArea() {
    this.vehicleService.getAreaLocations(this.externalRegForm.get('selectedArea').value).subscribe(data => {
      this.locationList = data.items;
    });
    this.externalRegForm.get('selectedAreaName').setValue(this.areaList.find(area => area.value == this.externalRegForm.get('selectedArea').value).labelEname);
  }
  onInputBlur() {
    this.isInputReadOnly['phone'] = true;
    this.isInputReadOnly['email'] = true;
    this.isInputReadOnly['pid'] = true;
  }
  onSelectLocation() {
    this.externalRegForm.get('selectedLocationName').setValue(this.locationList.find(loc => loc.value == this.externalRegForm.get('selectedLocation').value).labelEname);
    const location = new src_app_core_models_location__WEBPACK_IMPORTED_MODULE_3__.Locations(this.externalRegForm.get('selectedLocation').value, this.externalRegForm.get('selectedLocationName').value, this.externalRegForm.get('selectedArea').value);
    this.saveSelectedLocation.push(location);
  }
  mapToPlateName(pltType) {
    return this.externalRegForm.get('plateTypes').value.find(plt => plt.lkCodeValue == pltType).lkValueEname;
  }
  mapToArea(areaId) {
    return this.areaList.find(area => area.value == areaId).labelEname;
  }
  mapToLocation(locId, areaId) {
    const location = this.locationList.find(loc => loc.value == locId);
    return location.labelEname;
  }
  getModelTypes(event) {
    this.vehicleService.getModelsByManufacturerId(this.externalRegForm.get('selectedManufacturer').value).subscribe(data => {
      this.externalRegForm.get('modelTypes').setValue(data.items);
    });
  }
  // Integrate with API GetVehicleDetails to return data from MOI/Vehicles table database
  getVehicleDetails() {
    this.externalRegForm.get("showMoiError").setValue(false);
    this.errorMessage = '';
    if (this.externalRegForm.get('inputPlateType').value && this.externalRegForm.get('inputPlateType').value || this.savePlateNo && this.savePlateType) {
      const vehDetails = {
        plateNo: this.savePlateNo,
        plateType: this.savePlateType,
        stationId: this.stationId
      };
      // check if the vehicle is already added
      const plateNumberExists = this.vehicles.some(vehicle => vehicle.vdetails.plateNo == vehDetails.plateNo);
      if (this.vehicles.length > 0 && plateNumberExists) {
        this.duplicateError = true;
      } else {
        this.duplicateError = false;
        if (vehDetails.plateNo) {
          this.vehicleService.getVehicleDetails(vehDetails).subscribe(response => {
            if (response.items) {
              this.externalRegForm.get('vdetails').setValue(response.items);
              this.externalRegForm.get('barCode').setValue('');
              this.isWoqod = this.externalRegForm.get('vdetails').value.isWaqodVehicle;
              if (this.externalRegForm.get('vdetails').value.isExternal || this.externalRegForm.get('vdetails').value.categoryId == 0) {
                if (this.vehicles.length == 0 || this.vehicles.length > 0 && this.isWoqodAdded === this.isWoqod) {
                  this.isExt = true;
                  this.externalRegForm.get('vdetails').value.isReinspection ? this.isReinspectionExt = true : this.isReinspectionExt = false;
                  this.externalRegForm.get('noOfReinspections').setValue(this.externalRegForm.get('vdetails').value.noOfReinspections);
                  this.externalRegForm.get('inputVinNo').setValidators(null);
                  this.externalRegForm.get('inputManfYear').setValidators(null);
                  this.externalRegForm.get('inputCylinders').setValidators(null);
                  this.externalRegForm.get('inputNbSeats').setValidators(null);
                  this.externalRegForm.updateValueAndValidity();
                  const color = this.externalRegForm.get('colorList').value.find(color => color.lkCodeValue == this.externalRegForm.get('vdetails').value.colorId);
                  this.externalRegForm.get('colorValue').setValue(color.lkValueEname);
                  this.externalRegForm.get('pidValue').setValue(this.externalRegForm.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.externalRegForm.get('vdetails').value.ownerPidType).lkValueEname);
                  this.savePid = this.externalRegForm.get('vdetails').value.ownerPidType;
                  // if category is null enable manual selection for vehicle category
                  if (this.externalRegForm.get('vdetails').value.categoryId) {
                    this.externalRegForm.get('vcategory').setValue(this.externalRegForm.get('vehicleCategories').value.find(category => category.categoryId == this.externalRegForm.get('vdetails').value.categoryId).descriptionEn);
                    this.enableCategorySelection = false;
                  } else {
                    this.enableCategorySelection = true;
                    // if the clerk will manually select the vehicle category it should be required field
                    this.externalRegForm.get('selectedVehicleCategory').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_28__.Validators.required);
                    // Trigger re-validation
                    this.externalRegForm.get('selectedVehicleCategory').updateValueAndValidity();
                  }
                  this.externalRegForm.get('isStaffRate').setValue(this.externalRegForm.get('vdetails').value.isStaffVehicle);
                  this.externalRegForm.get('isStaffRateValue').setValue(this.externalRegForm.get('vdetails').value.isStaffVehicle);
                  this.externalRegForm.get('nonEditable').setValue(true);
                  this.vinNo = this.externalRegForm.get('vdetails').value.vinNo;
                  const isoDate = new Date(this.externalRegForm.get('vdetails').value.licenseExpiryDate);
                  const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(isoDate, 'dd-MM-yyyy');
                  this.externalRegForm.get('formatExpDate').setValue(dateFormat);
                  this.externalRegForm.get('showMoiError').setValue(false);
                  if (!this.externalRegForm.get('checkAllContact').value) {
                    this.externalRegForm.get('phone').setValue(this.externalRegForm.get('vdetails').value.contactPersonPhone);
                    this.externalRegForm.get('email').setValue(this.externalRegForm.get('vdetails').value.contactPersonEmail);
                    this.externalRegForm.get('pid').setValue(this.externalRegForm.get('vdetails').value.contactPersonPID);
                  }
                  this.externalRegForm.get('subclr').setValue(this.externalRegForm.get('colorList').value.find(color => color.lkCodeValue == this.externalRegForm.get('vdetails').value.subColorId).lkValueEname);
                } else {
                  this.woqodErrorMsg = this.isWoqodAdded ? "Kindly, add Woqod Vehicles" : "Cannot add Woqod Vehicle";
                  this.externalRegForm.get('vdetails').setValue({});
                  this.isValidInput = false;
                }
              } else {
                this.extError = "* Not an External Vehicle";
                this.isExt = false;
                this.externalRegForm.get('vdetails').setValue({});
              }
            }
          }, error => {});
        } else {
          this.enableCategorySelection = false;
        }
      }
    }
    this.externalRegForm.get('vdetails').setValue({});
    this.externalRegForm.get('vcategory').setValue('');
    this.externalRegForm.get('selectedVehicleCategory').setValue('');
    this.externalRegForm.get('pidValue').setValue('');
    this.externalRegForm.get('colorValue').setValue('');
    this.externalRegForm.get('subclr').setValue('');
    this.externalRegForm.get('isStaffRate').setValue(false);
    this.externalRegForm.get('inputPid').setValidators(null);
    this.enableCategorySelection = false;
    this.vehicleCategError = false;
  }
  onSelectCategory() {
    const selectedVehicle = this.externalRegForm.get('selectedVehicleCategory').value;
    if (selectedVehicle == 1 || selectedVehicle == 11 || selectedVehicle == 12) {
      this.vehicleCategError = false;
    } else {
      this.vehicleCategError = true;
    }
  }
  get invalidFormControls() {
    return Object.keys(this.externalRegForm.controls).filter(controlName => this.externalRegForm.controls[controlName].invalid);
  }
  selectFile() {
    this.render.selectRootElement(this.fileInput.nativeElement).click();
  }
  handleFile(event) {
    const inputElement = event.target;
    const selectedFile = inputElement.files[0];
    if (selectedFile) {
      const fileData = new FormData();
      fileData.append('file', selectedFile);
      this.fileService.handleFileService(fileData);
    }
  }
  onSelectPayment() {
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.CreditCustomer) {
      this.externalRegForm.get('showCredit').setValue(true);
      this.vehicleService.getCreditCustomer(this.externalRegForm.get('selectedCust').value).subscribe(data => {
        this.creditCustomerList = data.items;
      });
      this.isPaymentValid = this.externalRegForm.get('selectedCust').value ? true : false;
    } else {
      this.externalRegForm.get('showCredit').setValue(false);
      this.isPaymentValid = true;
    }
    this.paymentName = this.externalRegForm.get('paymentTypes').value.find(payId => payId.lkCodeValue == this.externalRegForm.get('selectedPayment').value).lkValueEname;
  }
  submitPayment() {
    const date = new Date();
    this.currentDateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(date, 'dd MMM yyyy');
    this.currentTimeFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(date, 'h:mm a');
    if (this.isWoqodAdded) {
      this.externalRegForm.get('selectedPayment').setValue(4);
    }
    let payment = {
      paymentMethodId: this.externalRegForm.get('selectedPayment').value,
      serviceRequestFeesDto: [{
        feesAmount: this.externalRegForm.get('totalCost').value,
        requestId: this.requestId,
        serviceTypeId: 1,
        customerId: this.externalRegForm.get('selectedCust').value == undefined ? null : parseInt(this.externalRegForm.get('selectedCust').value),
        subDiscount: 0
      }]
    };
    this.isPaymentStarted = true;
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.Card) {
      this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_30__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_31__.catchError)(error => {
        if (error.name === 'TimeoutError') {
          this.isNotReachable = true;
          this.displayPaymentDetails = 'block';
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_32__.throwError)(error);
      })).subscribe(data => {
        const paymentResult = data;
        const isCaptured = paymentResult.items.isCaptured;
        const isCanceled = paymentResult.items.isCanceled;
        const isDeviceNotReachable = paymentResult.items.isDeviceNotReachable;
        const messageCode = paymentResult.messageCode;
        const errorMessage = paymentResult.errorMessage;
        if (data.items) {
          if (!paymentResult.items.isCaptured && !paymentResult.items.isDeviceNotReachable) {
            this.isSuccess = true;
            let customerReportDto = {
              requestId: this.requestId,
              isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
              moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
              reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.CustomerReport
            };
            let inspectorReportDto = {
              requestId: this.requestId,
              isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
              moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
              reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.InspectorReport
            };
            let reports = [customerReportDto, inspectorReportDto];
            this.ssrsPrintServ.printReports(reports);
            setTimeout(() => {
              this.isPaymentStarted = false;
              this.cancelExt();
            }, 3000);
          } else {
            if (paymentResult.items.isCaptured) {
              this.isSuccess = true;
            }
            if (paymentResult.items.isCanceled) {
              this.isPayCanceled = true;
            }
            if (paymentResult.items.isDeviceNotReachable) {
              this.isNotReachable = true;
            }
          }
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        console.error(error);
        this.displayPaymentDetails = 'block';
      });
    }
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.Cash) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          let customerReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.CustomerReport
          };
          let inspectorReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.InspectorReport
          };
          let reports = [customerReportDto, inspectorReportDto];
          this.ssrsPrintServ.printReports(reports);
          this.isSuccess = true;
          this.isNotReachable = false;
          this.isPayCanceled = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.cancelExt();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isPayCanceled = false;
          this.isSuccess = false;
        }
      }, error => {
        this.isSuccess = false;
      });
    }
    if (this.externalRegForm.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_9__.PaymentMethods.CreditCustomer) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          let customerReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.CustomerReport
          };
          let inspectorReportDto = {
            requestId: this.requestId,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_11__.ReportType.InspectorReport
          };
          let reports = [customerReportDto, inspectorReportDto];
          this.ssrsPrintServ.printReports(reports);
          this.isSuccess = true;
          this.isPayCanceled = false;
          this.isNotReachable = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.cancelExt();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isSuccess = false;
          this.isPayCanceled = false;
        }
      }, error => {
        this.isSuccess = false;
      });
    }
    if (!this.externalRegForm.get('showScreen').value && this.isWoqodAdded) {
      const modalElement = document.getElementById('PrintReceipt');
      setTimeout(() => {
        if (modalElement) {
          modalElement.classList.remove('show');
          modalElement.style.display = 'none';
          document.body.classList.remove('modal-open');
          const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
          if (modalBackdrop) {
            modalBackdrop.remove();
          }
          document.body.style.overflow = 'auto';
        }
        this.cancelExt();
      }, 2000);
    }
  }
  sendPayment() {}
  downloadPayment() {
    this.ssrsPrintServ.downloadCustomerReport(this.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_10__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_8__.ModuleSourceEnum.external);
  }
  addVehicle() {
    this.isWoqodAdded = this.isWoqod;
    let saveLocId;
    let saveAreaId;
    this.contactPhone = this.externalRegForm.get("phone").value;
    this.contactEmail = this.externalRegForm.get("email").value;
    this.contactPid = this.externalRegForm.get("pid").value;
    if (this.externalRegForm.get('checkAllContact').value) {
      this.onInputBlur();
    }
    if (this.externalRegForm.get('checkAllLocation').value) {
      this.isInputReadOnly['loc'] = true;
      const location = new src_app_core_models_location__WEBPACK_IMPORTED_MODULE_3__.Locations(this.externalRegForm.get('selectedLocation').value, this.externalRegForm.get('selectedLocationName').value, this.externalRegForm.get('selectedArea').value);
      this.saveSelectedLocation.push(location);
      saveLocId = this.externalRegForm.get('selectedLocation').value;
      saveAreaId = this.externalRegForm.get('selectedArea').value;
    }
    const currentDate = new Date();
    const categoryIdVeh = this.enableCategorySelection ? this.externalRegForm.get('selectedVehicleCategory').value : this.externalRegForm.get('vdetails').value.categoryId;
    if (this.externalRegForm.get('nonEditable')) {
      const selectedVehicleCategoryText = this.externalRegForm.get('vehicleCategories').value.find(category => category.categoryId == categoryIdVeh).descriptionEn;
      const vehCateg = this.enableCategorySelection ? selectedVehicleCategoryText : this.externalRegForm.get('vcategory').value;
      this.feesDetails.push({
        vinNo: this.externalRegForm.get('vdetails').value.vinNo,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.Inspection,
        serviceId: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__.InspectionServiceTypes.ExternalInspection,
        vehicleCategoryId: categoryIdVeh,
        isStaffRate: this.externalRegForm.get('isStaffRate').value ? true : false
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.map)(data => data.items)).subscribe(items => {
        for (let fee of items) {
          if (fee.serviceTypeId == 1) {
            this.externalRegForm.get("fees").setValue(fee.feesAmount);
            this.feesArray.push(fee.feesAmount);
            this.externalRegForm.get("feesDiscount").setValue(fee.feesDiscount);
          }
        }
        this.feesDetails = [];
        const cost = this.externalRegForm.get('fees').value || 0;
        this.externalRegForm.get("amount").setValue(cost);
        const totalAmount = this.externalRegForm.get("totalCost").value + cost;
        this.amountTh = this.thousandSeparator.addThousandSeparator(totalAmount.toString());
        this.externalRegForm.get("totalCost").setValue(totalAmount);
        const area = this.externalRegForm.get('selectedArea').value ? this.externalRegForm.get('selectedArea').value : saveAreaId;
        const loc = this.externalRegForm.get('selectedLocation').value ? this.externalRegForm.get('selectedLocation').value : saveLocId;
        const addVehicle = new src_app_core_models_add_vehicle_details__WEBPACK_IMPORTED_MODULE_1__.AddVehicleDetails(this.externalRegForm.get('vdetails').value, this.externalRegForm.get('phone').value, area, loc, vehCateg, cost);
        this.vehicles.push(addVehicle);
        this.resetInfo();
      });
      this.externalRegForm.get('showScreen').setValue(false);
    }
  }
  addVehicleDB() {
    var _this = this;
    return (0,C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.externalRegForm.get('nonEditable')) {
        _this.inserted = true;
        _this.externalRegForm.get('showScreen').setValue(false);
        const currentDate = new Date();
        let counter = 0;
        const mainServiceRequest = {
          stationId: _this.stationId,
          serviceType: 1,
          serviceID: 5,
          contactType: _this.savePid,
          contactPersonName: '',
          contactPersonEmail: _this.externalRegForm.get('email').value,
          contactPersonPhone: _this.externalRegForm.get('phone').value.toString(),
          status: 1,
          registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.BackOffice,
          boothId: 1,
          posId: 1,
          remarks: '',
          requestRefId: _this.requestId,
          createdBy: _this.userId,
          vinNo: _this.vinNo,
          plateType: _this.vehicles[0].vdetails.plateType,
          plateNo: parseInt(_this.vehicles[0].vdetails.plateNo)
        };
        _this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_5__.ServiceRequest(mainServiceRequest);
        // Insert the service request for main vehicle
        const mainServiceRequestObservable = (0,rxjs__WEBPACK_IMPORTED_MODULE_34__.of)(_this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_35__.switchMap)(mainRequest => {
          // Insert the service request for main vehicle
          if (counter == 0) {
            return _this.vehicleService.insertServiceRequest(mainRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.map)(data => {
              _this.requestId = data.items;
              // upload attachments
              const fileInfoArray = _this.fileService.getFileData();
              for (const fileInfo of fileInfoArray) {
                if (fileInfo) {
                  const formData = new FormData();
                  formData.append('requestId', _this.requestId.toString());
                  formData.append('sectionId', '');
                  formData.append('defectId', '');
                  formData.append('serviceTypeId', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.Inspection.toString());
                  formData.append('serviceId', src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__.InspectionServiceTypes.ExternalInspection.toString());
                  formData.append('mimeType', fileInfo.mimeType);
                  formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.SupportDocuments.toString());
                  formData.append('createdBy', _this.userId.toString());
                  formData.append('fileData', fileInfo.fileData, fileInfo.filename);
                  _this.globalServ.uploadAttachement(formData).subscribe(response => {}, error => {});
                }
              }
              return _this.requestId; // Pass requestId to the next observable
            }));
          } else return (0,rxjs__WEBPACK_IMPORTED_MODULE_34__.of)(null);
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_36__.publishReplay)(1), (0,rxjs__WEBPACK_IMPORTED_MODULE_37__.refCount)());
        const observables = _this.vehicles.map(eq => {
          return mainServiceRequestObservable.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_35__.switchMap)(requestId => {
            counter++;
            let requestIdVehicles = 0;
            if (requestId != null) {
              const externalRegServiceRequestData = {
                stationId: _this.stationId,
                serviceType: 1,
                serviceID: 5,
                contactType: _this.savePid,
                contactPersonName: '',
                contactPersonEmail: _this.externalRegForm.get('email').value,
                contactPersonPhone: _this.externalRegForm.get('phone').value.toString(),
                status: 1,
                registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.BackOffice,
                boothId: 1,
                posId: 1,
                remarks: '',
                requestRefId: _this.requestId,
                createdBy: _this.userId,
                vinNo: eq.vdetails.vinNo,
                plateType: eq.vdetails.plateType,
                plateNo: parseInt(eq.vdetails.plateNo)
              };
              _this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_5__.ServiceRequest(externalRegServiceRequestData);
            }
            // Insert the service request for each vehicle
            const insertServiceRequestObservable = _this.vehicleService.insertServiceRequest(_this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.map)(data => data.items));
            return insertServiceRequestObservable.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_38__.concatMap)(items => {
              requestIdVehicles = items;
              const vehicleDetails = {
                requestId: requestIdVehicles,
                plateNo: parseInt(eq.vdetails.plateNo),
                plateType: eq.vdetails.plateType,
                vinNo: eq.vdetails.vinNo,
                colorId: eq.vdetails.colorId,
                subColorId: eq.vdetails.subColorId,
                categoryId: eq.vdetails.categoryId,
                vehicleModelId: eq.vdetails.vehicleModelId,
                manufacturerId: eq.vdetails.manufacturerId,
                manufacturerYear: eq.vdetails.manufacturerYear,
                moiRegistrationDate: eq.vdetails.moiRegistrationDate,
                cylinders: eq.vdetails.cylinders,
                weight: eq.vdetails.weight,
                payloadWeight: eq.vdetails.payloadWeight,
                shapeCode: eq.vdetails.shapeCode,
                descriptionEn: '',
                descriptionAr: '',
                noOfSeat: eq.vdetails.noOfSeat,
                licenseExpiryDate: eq.vdetails.licenseExpiryDate,
                ownerType: _this.savePid,
                contactPersonPid: _this.contactPid,
                contactPersonEmail: _this.contactEmail,
                contactPersonPhone: _this.contactPhone.toString(),
                ownerId: '0',
                ownerPid: eq.vdetails.ownerPID,
                ownerPidType: _this.savePid,
                ownerName: eq.vdetails.ownerName,
                departmentId: 0,
                createdBy: _this.userId
              };
              _this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_4__.RegisterVehicle(vehicleDetails);
              const registerVehicleObservable = _this.vehicleService.registerVehicle(_this.registerVehicle);
              const externalEquipmentDetails = {
                requestId: requestIdVehicles,
                plateNo: parseInt(eq.vdetails.plateNo),
                plateType: eq.vdetails.plateType,
                vinNo: eq.vdetails.vinNo,
                categoryId: eq.vdetails.categoryId,
                areaId: parseInt(eq.area),
                locationId: parseInt(eq.location),
                amount: eq.cost,
                contactPersonName: 'name',
                contactPersonEmail: _this.contactEmail,
                contactPersonPhone: eq.phone.toString(),
                remarks: '',
                contactPID: _this.contactPid,
                createdBy: _this.userId
              };
              _this.extEquipment = new src_app_core_models_insert_vehicle_equipment__WEBPACK_IMPORTED_MODULE_2__.InsertExternalEquipment(externalEquipmentDetails);
              _this.equipments.push(_this.extEquipment);
              // Combine both observables for the current vehicle
              return registerVehicleObservable;
            }));
          }));
        });
        //observables.unshift(mainServiceRequestObservable);
        // Use forkJoin to execute all observables in parallel
        (0,rxjs__WEBPACK_IMPORTED_MODULE_39__.forkJoin)(observables).subscribe(responses => {
          _this.vehicleService.insertExternalEquipment(_this.equipments).subscribe(data => {
            _this.vehicleService.getExternalEquipmentVehiclesDetails(_this.requestId).subscribe(response => {
              _this.externalRegForm.get('totalCost').setValue(response.items.totalAmount);
              _this.listVehicle.push(...response.items.externalEquipmentVehicles);
              _this.isTotalZero = _this.externalRegForm.get('totalCost').value == 0 ? true : false;
            }, error => {
              _this.isTotalZero = true;
            });
          });
        }, error => {
          // Handle errors
        });
      } else {
        const currentDate = new Date();
        // for manual entry to be updated or removed
        const vehicleDetailsModel = new src_app_core_models_vehicle_details__WEBPACK_IMPORTED_MODULE_6__.VehicleDetails(_this.externalRegForm.get('inputPlateNo').value, _this.externalRegForm.get('inputPlateType').value, _this.externalRegForm.get('inputVinNo').value, _this.externalRegForm.get('selectedColor').value, _this.externalRegForm.get('selectedSubColor').value, _this.externalRegForm.get('selectedVehicleCategory').value, _this.externalRegForm.get('selectedModel').value, _this.externalRegForm.get('selectedManufacturer').value, _this.externalRegForm.get('inputManfYear').value, currentDate, _this.externalRegForm.get('inputCylinders').value, _this.externalRegForm.get('inputWeight').value, _this.externalRegForm.get('inputPayloadWeight').value, '', _this.externalRegForm.get('inputNbSeats').value, _this.externalRegForm.get('inputPid').value, _this.externalRegForm.get('inputOwnerName').value, _this.externalRegForm.get('expDate').value, 0, currentDate, 0, currentDate, '', '', null, null, null, null);
        const addVehicle = new src_app_core_models_add_vehicle_details__WEBPACK_IMPORTED_MODULE_1__.AddVehicleDetails(vehicleDetailsModel, _this.externalRegForm.get('phone').value, _this.externalRegForm.get('selectedArea').value, _this.externalRegForm.get('selectedLocation').value, _this.externalRegForm.get('vcategory').value, 0);
        _this.vehicles.push(addVehicle);
      }
      _this.externalRegForm.get('nonEditable').setValue(false);
      //reset input values
      //this.resetInfo();
      _this.globalServ.getStationPaymentMethods(1).subscribe(response => {
        _this.externalRegForm.get('paymentTypes').setValue(response.items);
      });
    })();
  }
  deleteVehicle(index) {
    this.vehicles.splice(index, 1);
    this.equipments.splice(index, 1);
    this.feesArray.splice(index, 1);
    this.feesDetails.splice(index, 1);
    this.externalRegForm.get('totalCost').setValue(0);
    for (let v of this.vehicles) {
      this.feesDetails.push({
        vinNo: v.vdetails.vinNo,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_13__.SystemLookupValueCodes.Inspection,
        serviceId: src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_7__.InspectionServiceTypes.ExternalInspection,
        vehicleCategoryId: v.vdetails.categoryId,
        isStaffRate: this.externalRegForm.get('isStaffRate').value ? true : false
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_33__.map)(data => data.items)).subscribe(items => {
        for (let fee of items) {
          if (fee.serviceTypeId == 1) {
            this.externalRegForm.get("fees").setValue(fee.feesAmount);
            this.feesArray.push(fee.feesAmount);
            this.externalRegForm.get("feesDiscount").setValue(fee.feesDiscount);
          }
        }
        const cost = this.externalRegForm.get('fees').value || 0;
        this.externalRegForm.get("amount").setValue(cost);
        const totalAmount = this.externalRegForm.get("totalCost").value + cost;
        this.amountTh = this.thousandSeparator.addThousandSeparator(totalAmount.toString());
        this.externalRegForm.get("totalCost").setValue(totalAmount);
      });
    }
    if (this.inserted) {
      this.vehicleService.deleteExternalEquipmentVehicle(this.listVehicle[index].requestId, this.listVehicle[index].vinNo).subscribe(response => {
        this.vehicleService.getExternalEquipmentVehiclesDetails(this.requestId).subscribe(response => {
          this.externalRegForm.get('totalCost').setValue(response.items.totalAmount);
        });
      }, error => {
        this.isTotalZero = true;
      });
      this.listVehicle.splice(index, 1);
    }
    if (this.vehicles.length == 0) {
      this.externalRegForm.get('canPay').setValue(false);
      this.inserted = false;
      this.isTotalZero = true;
      this.viewBtn = false;
      this.externalRegForm.get('showScreen').setValue(true);
      this.focusScanner();
    }
  }
  viewAddedVehicles() {
    this.externalRegForm.get('showScreen').setValue(false);
    this.viewBtn = false;
  }
  focusScanner() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#bcode');
      if (myInput) {
        myInput.focus();
      }
    }, 100);
  }
  backToScreen() {
    this.externalRegForm.get('showScreen').setValue(true);
    if (this.vehicles.length > 0) {
      this.viewBtn = true;
    }
    this.focusScanner();
    this.vehicleCategError = false;
    this.resetInfo();
  }
  cancelExt() {
    window.location.reload();
    this.displayPaymentDetails = 'none';
    this.isPaymentStarted = true;
    this.isPaymentStarted = false;
  }
  cancelExtFaild() {
    this.isPaymentStarted = false;
  }
  closePayPop() {
    this.externalRegForm.get('selectedCust').setValue('');
  }
  resetInfo() {
    this.externalRegForm.get('inputPlateNo').setValue(' ');
    this.externalRegForm.get('inputPlateType').setValue(' ');
    this.externalRegForm.get('vdetails').setValue({});
    this.externalRegForm.get('inputVinNo').setValue('');
    this.externalRegForm.get('selectedColor').setValue('');
    this.externalRegForm.get('selectedSubColor').setValue('');
    this.externalRegForm.get('selectedVehicleCategory').setValue('');
    this.externalRegForm.get('selectedModel').setValue('');
    this.externalRegForm.get('selectedManufacturer').setValue('');
    this.externalRegForm.get('inputManfYear').setValue(null);
    this.externalRegForm.get('inputCylinders').setValue(null);
    this.externalRegForm.get('inputWeight').setValue(null);
    //this.externalRegForm.get('inputPayloadWeight').setValue(null);
    this.externalRegForm.get('inputNbSeats').setValue(null);
    this.externalRegForm.get('inputPid').setValue(null);
    this.isValidInput = false;
    this.displayPaymentDetails = 'none';
    this.isReinspectionExt = false;
    this.externalRegForm.get('noOfReinspections').setValue('');
    if (!this.externalRegForm.get('checkAllContact').value) {
      this.externalRegForm.get('phone').setValue('');
      this.externalRegForm.get('email').setValue('');
      this.externalRegForm.get('pid').setValue('');
    }
    if (!this.externalRegForm.get('checkAllLocation').value) {
      this.externalRegForm.get('selectedArea').setValue('');
      this.externalRegForm.get('selectedLocation').setValue(' ');
    }
  }
  static #_ = this.ɵfac = function ExternalRegistrationComponent_Factory(t) {
    return new (t || ExternalRegistrationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_28__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_27__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_14__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_15__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_16__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_17__.PurchaseService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_40__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_18__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_19__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_20__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_21__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_22__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_23__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_27__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_24__.ThousandSeparatorService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵdefineComponent"]({
    type: ExternalRegistrationComponent,
    selectors: [["app-external-registration"]],
    viewQuery: function ExternalRegistrationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵloadQuery"]()) && (ctx.fileInput = _t.first);
      }
    },
    hostBindings: function ExternalRegistrationComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("keydown", function ExternalRegistrationComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 64,
    vars: 24,
    consts: [[3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["class", "accordion-header", "id", "headingOne", 4, "ngIf"], ["class", "accordion-header", "id", "headingTwo", 4, "ngIf"], ["class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample0", 4, "ngIf"], ["id", "act-search2", "class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 4, "ngIf"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "class", "btn btn-dark-gray", 3, "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", 3, "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 3, "disabled", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "confirmationModal", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered", "modal-sm"], [1, "modal-content"], [1, "modal-header", "ps-info"], ["id", "exampleModalLabel", 1, "modal-title"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "modal-body", "text-center"], [1, "modal-footer", "justify-content-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "click"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 3, "click", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["class", "modal-dialog modal-dialog-centered", 4, "ngIf"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"], ["data-bs-backdrop", "static", "id", "PrintReceipt", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "pt-lab"], ["data-bs-backdrop", "static", "id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [3, "fileUploaded"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "headingTwo", 1, "accordion-header"], ["id", "vehicleSummary"], ["aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample0", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col"], ["scopr", "col"], [4, "ngFor", "ngForOf"], ["colspan", "7"], ["colspan", "2"], [4, "ngIf"], ["id", "btndel", 1, "btn", "btn-link", 3, "click"], [1, "bi", "bi-trash3-fill"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["src", "./assets/img/scan.svg", "width", "30px", "height", "30px"], [1, "col-md-6", "col-md-4"], ["type", "text", "formControlName", "barCode", "id", "bcode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["class", "col-md-6 col-md-4", "class", "error-message", 4, "ngIf"], ["class", "col-md-6 col-md-4", "class", "info-msg", 4, "ngIf"], ["for", "myInput"], ["type", "number", "id", "myInput", "name", "plateNo", "formControlName", "inputPlateNo", "oninput", "(event.key === 'ArrowUp' || event.key === 'ArrowDown')? event.target.defaultValue : event.target.value;", 1, "form-control", 3, "ngModel", "ngModelChange"], ["class", "error-message", 4, "ngIf"], ["formControlName", "inputPlateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "form-control", "formControlName", "selectedVehicleCategory", 3, "ngModelChange", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "vcategory", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedOwnerType", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "pidValue", 3, "readonly", 4, "ngIf"], ["type", "text", "class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPid", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputOwnerName", 4, "ngIf"], ["type", "date", "class", "form-control", "formControlName", "expDate", 4, "ngIf"], ["type", "text", "class", "form-control", 3, "value", "readonly", 4, "ngIf"], [1, "accordion-body", "border-top"], ["type", "text", "class", "form-control", "formControlName", "inputVinNo", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedManufacturer", 3, "change", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedModel", 4, "ngIf"], ["class", "form-control", "formControlName", "inputManfYear", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputCylinders", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputWeight", 3, "readonly", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputPayloadweight", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedColor", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "colorValue", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedSubColor", 4, "ngIf"], ["type", "number", "class", "form-control", "formControlName", "inputNbSeats", 4, "ngIf"], [1, "col-lg-6", "sr-vc"], ["class", "reinspection", 4, "ngIf"], ["class", "woqod", 4, "ngIf"], ["class", "staff-rate", 4, "ngIf"], ["type", "file", 2, "display", "none", 3, "change"], ["fileInput", ""], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", 1, "btn", "btn-vci"], [1, "bi", "bi-paperclip"], ["id", "fn", 4, "ngIf"], [1, "error-message"], [1, "info-msg"], [3, "value"], ["formControlName", "selectedVehicleCategory", 1, "form-control", 3, "ngModelChange"], ["type", "text", "formControlName", "vcategory", 1, "form-control", 3, "readonly"], ["formControlName", "selectedOwnerType", 1, "form-control"], ["type", "text", "formControlName", "pidValue", 1, "form-control", 3, "readonly"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], ["type", "number", "formControlName", "inputPid", 1, "form-control"], ["type", "text", "formControlName", "inputOwnerName", 1, "form-control"], ["type", "date", "formControlName", "expDate", 1, "form-control"], ["type", "text", 1, "form-control", 3, "value", "readonly"], ["type", "text", "formControlName", "inputVinNo", 1, "form-control"], ["formControlName", "selectedManufacturer", 1, "form-control", 3, "change"], ["formControlName", "selectedModel", 1, "form-control"], ["formControlName", "inputManfYear", 1, "form-control"], ["type", "text", "formControlName", "inputCylinders", 1, "form-control"], ["type", "number", "formControlName", "inputWeight", 1, "form-control", 3, "readonly"], ["type", "number", "formControlName", "inputPayloadweight", 1, "form-control", 3, "readonly"], ["formControlName", "selectedColor", 1, "form-control"], ["type", "text", "formControlName", "colorValue", 1, "form-control", 3, "readonly"], ["formControlName", "selectedSubColor", 1, "form-control"], ["type", "number", "formControlName", "inputNbSeats", 1, "form-control"], [1, "reinspection"], [1, "warn", "warning"], [1, "woqod"], [1, "warn", "warning-green"], [1, "staff-rate"], [1, "switch"], ["type", "checkbox", "formControlName", "isStaffRate", 3, "checked"], [1, "slider", "round"], ["id", "fn"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "formControlName", "phone", 1, "form-control", 3, "readonly"], ["type", "text", "formControlName", "pid", 1, "form-control", 3, "readonly"], ["type", "text", "formControlName", "email", 1, "form-control", 3, "readonly"], ["id", "accordion3", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["aria-colspan", "accordion-collapse collapse show", "aria-label", "headingThree", "data-bs-parent", "#accordion3", 1, "act-search4"], ["class", "form-control", "formControlName", "selectedArea", 3, "change", 4, "ngIf"], ["class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedLocation", 3, "readonly", "change", 4, "ngIf"], [1, "form-check"], ["type", "checkbox", "id", "checkVehicles1", "formControlName", "checkAllContact", 1, "form-check-input"], ["for", "checkVehicles1", 1, "form-check-label"], ["type", "checkbox", "id", "checkVehicles2", "formControlName", "checkAllLocation", 1, "form-check-input"], ["for", "checkVehicles2", 1, "form-check-label"], ["formControlName", "selectedArea", 1, "form-control", 3, "change"], ["readonly", "", 1, "form-control", 3, "value"], ["formControlName", "selectedLocation", 1, "form-control", 3, "change"], ["type", "button", 1, "btn", "btn-dark-gray", 3, "click"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-orange", 3, "disabled"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 1, "btn", "btn-orange", 3, "click"], [1, "modal-title"], [1, "payment-info"], [1, "payment-type"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop2", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "btn-radio"], ["type", "radio", "formControlName", "selectedPayment", 3, "id", "value", "ngModelChange"], [3, "for"], [1, "col-md-6", "col-lg-6"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "formControlName", "selectedCust", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "clearSearchOnAdd", "minTermLength", "change"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"]],
    template: function ExternalRegistrationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](0, "body")(1, "form", 0)(2, "section", 1)(3, "div", 2)(4, "div", 3)(5, "div", 2)(6, "div", 3)(7, "div", 2)(8, "div", 4)(9, "div", 5)(10, "div", 6)(11, "div", 7)(12, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](13, ExternalRegistrationComponent_h2_13_Template, 3, 0, "h2", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](14, ExternalRegistrationComponent_div_14_Template, 3, 0, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](15, ExternalRegistrationComponent_div_15_Template, 31, 2, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](16, ExternalRegistrationComponent_div_16_Template, 123, 53, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](17, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](18, ExternalRegistrationComponent_div_18_Template, 28, 7, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](19, ExternalRegistrationComponent_div_19_Template, 31, 4, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](20, "div", 2)(21, "div", 14)(22, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_Template_button_click_22_listener() {
          return ctx.cancelExt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](23, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](24, ExternalRegistrationComponent_button_24_Template, 2, 0, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](25, ExternalRegistrationComponent_button_25_Template, 2, 1, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](26, ExternalRegistrationComponent_button_26_Template, 2, 0, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](27, ExternalRegistrationComponent_button_27_Template, 2, 1, "button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](28, "div", 20)(29, "div", 21)(30, "div", 22)(31, "div", 23)(32, "h5", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](33, "Save Vehicle(s)");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](34, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](35, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](36, " Are you sure no more vehicles to be added ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](37, "br")(38, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](39, "div", 27)(40, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](41, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](42, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_Template_button_click_42_listener() {
          return ctx.addVehicleDB();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](43, " Yes, Proceed ");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](44, ExternalRegistrationComponent_button_44_Template, 2, 0, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](45, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](46, ExternalRegistrationComponent_div_46_Template, 8, 0, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtemplate"](47, ExternalRegistrationComponent_div_47_Template, 37, 5, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](48, "payment-transaction-status-modal", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("onCancelEvent", function ExternalRegistrationComponent_Template_payment_transaction_status_modal_onCancelEvent_48_listener() {
          return ctx.cancelExt();
        })("onCancelFailedEvent", function ExternalRegistrationComponent_Template_payment_transaction_status_modal_onCancelFailedEvent_48_listener() {
          return ctx.cancelExtFaild();
        })("onDownloadPaymentEvent", function ExternalRegistrationComponent_Template_payment_transaction_status_modal_onDownloadPaymentEvent_48_listener() {
          return ctx.downloadPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](49, "div", 34)(50, "div", 35)(51, "div", 22)(52, "div", 36)(53, "h1", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelement"](54, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](55, " Receipt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](56, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("click", function ExternalRegistrationComponent_Template_button_click_56_listener() {
          return ctx.cancelExt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](57, "div", 40)(58, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵtext"](59, " Printing Receipt... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementStart"](60, "div", 42)(61, "div", 35)(62, "div", 22)(63, "app-file-uploads", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵlistener"]("fileUploaded", function ExternalRegistrationComponent_Template_app_file_uploads_fileUploaded_63_listener($event) {
          return ctx.onFileUploaded($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("formGroup", ctx.externalRegForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value && !ctx.inserted);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.viewBtn && ctx.externalRegForm.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value && !ctx.isWoqodAdded && ctx.externalRegForm.get("totalCost").value != 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx.externalRegForm.get("showScreen").value && (ctx.isWoqodAdded || ctx.externalRegForm.get("totalCost").value == 0));
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("ngIf", !ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_27__["ɵɵproperty"]("isPaymentStarted", ctx.isPaymentStarted)("email", ctx.externalRegForm.get("email").value)("isSuccess", ctx.isSuccess)("isPayCanceled", ctx.isPayCanceled)("isNotReachable", ctx.isNotReachable)("requestRefId", ctx.requestId)("currentDateFormat", ctx.currentDateFormat)("currentTimeFormat", ctx.currentTimeFormat)("totalAmountTh", ctx.amountTh)("paymentName", ctx.paymentName);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_29__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_29__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_28__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_28__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_28__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_28__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_28__.FormControlName, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_25__.FileUploadsComponent, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_26__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_41__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_41__.NgOptionComponent],
    styles: [".container[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n    color: white;\r\n    background-color: #F89828;\r\n}\r\n\r\n\r\n.custom-table[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    color: black;\r\n    background-color: #ffdcb3;\r\n    border: 1px solid white;\r\n    border-collapse: collapse;\r\n    margin: 20px 0;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    color: red;\r\n    font-style: italic;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n#btndel[_ngcontent-%COMP%] {\r\n    padding: 5px;\r\n    border-radius: 40%;\r\n    border: none;\r\n    width: 30px;\r\n    height: 31px;\r\n    color: orange;\r\n    float: left;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin: 1px;\r\n    font-weight: 500;\r\n    font-size: 25px;\r\n}\r\n\r\n#btndel.hover[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: orange;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n#confirmationModal[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin: auto;\r\n}\r\n\r\n.modal-footer[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n#vehicleSummary[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    margin-left: 20px;\r\n    margin-top: 5px;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%], .warn[_ngcontent-%COMP%]::before, .warn[_ngcontent-%COMP%]::after {\r\n    position: relative;\r\n    padding: 0;\r\n    margin: 0;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%] {\r\n    font-size: 20px;\r\n    color: transparent;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n\r\n    top: 0.225em;\r\n\r\n    width: 1.15em;\r\n    height: 1.15em;\r\n\r\n    overflow: hidden;\r\n    border: none;\r\n    background-color: transparent;\r\n    border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::before {\r\n    content: \"\";\r\n    display: block;\r\n    top: -0.08em;\r\n    left: 0.0em;\r\n    position: absolute;\r\n    border: transparent 0.6em solid;\r\n    border-bottom-color: #448b23;\r\n    border-bottom-width: 1em;\r\n    border-top-width: 0;\r\n    box-shadow: #448b23 0 1px 1px;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::after {\r\n    display: block;\r\n    position: absolute;\r\n    top: 0.3em;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 0 1px;\r\n    text-align: center;\r\n    font-family: \"Garamond\";\r\n    content: \"!\";\r\n    font-size: 0.65em;\r\n    font-weight: bold;\r\n    color: white;\r\n}\r\n\r\n.woqod[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    box-shadow: #448b23 0 0.5px 0.5px;\r\n}\r\n\r\n#fn[_ngcontent-%COMP%] {\r\n    font-size: 13px;\r\n    font-style: italic;\r\n}\r\n\r\n.warn.warning[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n\r\n    top: 0.225em;\r\n\r\n    width: 1.15em;\r\n    height: 1.15em;\r\n\r\n    overflow: hidden;\r\n    border: none;\r\n    background-color: transparent;\r\n    border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning[_ngcontent-%COMP%]::before {\r\n    content: \"\";\r\n    display: block;\r\n    top: -0.08em;\r\n    left: 0.0em;\r\n    position: absolute;\r\n    border: transparent 0.6em solid;\r\n    border-bottom-color: rgb(249, 41, 41);\r\n    border-bottom-width: 1em;\r\n    border-top-width: 0;\r\n    box-shadow: #943131 0 1px 1px;\r\n}\r\n\r\n.warn.warning[_ngcontent-%COMP%]::after {\r\n    display: block;\r\n    position: absolute;\r\n    top: 0.3em;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 0 1px;\r\n    text-align: center;\r\n    font-family: \"Garamond\";\r\n    content: \"!\";\r\n    font-size: 0.65em;\r\n    font-weight: bold;\r\n    color: white;\r\n}\r\n\r\n.reinspection[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    box-shadow: #943131 0 0.5px 0.5px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvZXh0ZXJuYWwtcmVnaXN0cmF0aW9uL2V4dGVybmFsLXJlZ2lzdHJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksWUFBWTtJQUNaLHlCQUF5QjtBQUM3Qjs7O0FBR0E7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1Ysa0JBQWtCO0FBQ3RCOztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixXQUFXO0lBQ1gsWUFBWTtJQUNaLGFBQWE7SUFDYixXQUFXO0lBQ1gsYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksV0FBVztJQUNYLHdCQUF3QjtBQUM1Qjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkI7O0FBRUE7OztJQUdJLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsU0FBUztBQUNiOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHFCQUFxQjs7SUFFckIsWUFBWTs7SUFFWixhQUFhO0lBQ2IsY0FBYzs7SUFFZCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLFlBQVk7SUFDWixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLCtCQUErQjtJQUMvQiw0QkFBNEI7SUFDNUIsd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQiw2QkFBNkI7QUFDakM7O0FBRUE7SUFDSSxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixPQUFPO0lBQ1AsV0FBVztJQUNYLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsaUNBQWlDO0FBQ3JDOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHFCQUFxQjs7SUFFckIsWUFBWTs7SUFFWixhQUFhO0lBQ2IsY0FBYzs7SUFFZCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLFlBQVk7SUFDWixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLCtCQUErQjtJQUMvQixxQ0FBcUM7SUFDckMsd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQiw2QkFBNkI7QUFDakM7O0FBRUE7SUFDSSxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixPQUFPO0lBQ1AsV0FBVztJQUNYLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsaUNBQWlDO0FBQ3JDIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbnRoIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XHJcbn1cclxuXHJcblxyXG4uY3VzdG9tLXRhYmxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmRjYjM7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcclxuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICBtYXJnaW46IDIwcHggMDtcclxufVxyXG5cclxuLmVycm9yLW1lc3NhZ2Uge1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XHJcbiAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBhcHBlYXJhbmNlOiBub25lO1xyXG4gICAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4jYnRuZGVsIHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDQwJTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMXB4O1xyXG4gICAgY29sb3I6IG9yYW5nZTtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbjogMXB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG5cclxuI2J0bmRlbC5ob3ZlciB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufVxyXG5cclxuI2NvbmZpcm1hdGlvbk1vZGFsIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbjogYXV0bztcclxufVxyXG5cclxuLm1vZGFsLWZvb3RlciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbiN2ZWhpY2xlU3VtbWFyeSB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogNXB4O1xyXG59XHJcblxyXG4ud2FybixcclxuLndhcm46OmJlZm9yZSxcclxuLndhcm46OmFmdGVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi53YXJuIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbiB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblxyXG4gICAgdG9wOiAwLjIyNWVtO1xyXG5cclxuICAgIHdpZHRoOiAxLjE1ZW07XHJcbiAgICBoZWlnaHQ6IDEuMTVlbTtcclxuXHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwLjYyNWVtO1xyXG59XHJcblxyXG4ud2Fybi53YXJuaW5nLWdyZWVuOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgdG9wOiAtMC4wOGVtO1xyXG4gICAgbGVmdDogMC4wZW07XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3JkZXI6IHRyYW5zcGFyZW50IDAuNmVtIHNvbGlkO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzQ0OGIyMztcclxuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IDFlbTtcclxuICAgIGJvcmRlci10b3Atd2lkdGg6IDA7XHJcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMXB4IDFweDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbjo6YWZ0ZXIge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDAuM2VtO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMCAxcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LWZhbWlseTogXCJHYXJhbW9uZFwiO1xyXG4gICAgY29udGVudDogXCIhXCI7XHJcbiAgICBmb250LXNpemU6IDAuNjVlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ud29xb2Qge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMC41cHggMC41cHg7XHJcbn1cclxuXHJcbiNmbiB7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbn1cclxuXHJcbi53YXJuLndhcm5pbmcge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cclxuICAgIHRvcDogMC4yMjVlbTtcclxuXHJcbiAgICB3aWR0aDogMS4xNWVtO1xyXG4gICAgaGVpZ2h0OiAxLjE1ZW07XHJcblxyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMC42MjVlbTtcclxufVxyXG5cclxuLndhcm4ud2FybmluZzo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHRvcDogLTAuMDhlbTtcclxuICAgIGxlZnQ6IDAuMGVtO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm9yZGVyOiB0cmFuc3BhcmVudCAwLjZlbSBzb2xpZDtcclxuICAgIGJvcmRlci1ib3R0b20tY29sb3I6IHJnYigyNDksIDQxLCA0MSk7XHJcbiAgICBib3JkZXItYm90dG9tLXdpZHRoOiAxZW07XHJcbiAgICBib3JkZXItdG9wLXdpZHRoOiAwO1xyXG4gICAgYm94LXNoYWRvdzogIzk0MzEzMSAwIDFweCAxcHg7XHJcbn1cclxuXHJcbi53YXJuLndhcm5pbmc6OmFmdGVyIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwLjNlbTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDAgMXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiR2FyYW1vbmRcIjtcclxuICAgIGNvbnRlbnQ6IFwiIVwiO1xyXG4gICAgZm9udC1zaXplOiAwLjY1ZW07XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLnJlaW5zcGVjdGlvbiB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6ICM5NDMxMzEgMCAwLjVweCAwLjVweDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 50587:
/*!******************************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/inspection-results-reports/inspection-results-reports.component.ts ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionResultsReportsComponent": () => (/* binding */ InspectionResultsReportsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








function InspectionResultsReportsComponent_option_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const service_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", service_r4.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", service_r4.serviceName, " ");
  }
}
function InspectionResultsReportsComponent_option_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", pt_r5.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", pt_r5.lkValueEname, " ");
  }
}
function InspectionResultsReportsComponent_tr_83_button_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_tr_83_button_18_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12);
      const item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r10.submitReportPayment(item_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Print ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function InspectionResultsReportsComponent_tr_83_button_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_tr_83_button_19_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r15);
      const item_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r13.downloadInspectionReport(item_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Print ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function InspectionResultsReportsComponent_tr_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "td", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](18, InspectionResultsReportsComponent_tr_83_button_18_Template, 2, 0, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, InspectionResultsReportsComponent_tr_83_button_19_Template, 2, 0, "button", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.fahesReceiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.plateTypeName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.reportFee, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.ownerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.prevReqsForThisReport, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", item_r6.isPaymentRequired == 1 ? "Paid" : "Free", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", item_r6.isPaymentRequired == 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", item_r6.isPaymentRequired == 0);
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function InspectionResultsReportsComponent_li_89_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "li", 42)(1, "a", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_li_89_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r18);
      const page_r16 = restoredCtx.$implicit;
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r17.changePage(page_r16));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const page_r16 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](2, _c0, ctx_r3.currentPage === page_r16));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r16);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
class InspectionResultsReportsComponent {
  constructor(InspectionService, ssrsPrintService, sharedLookup) {
    this.InspectionService = InspectionService;
    this.ssrsPrintService = ssrsPrintService;
    this.sharedLookup = sharedLookup;
    this.inspectionReports = [];
    this.currentPage = 1;
    this.pageSize = 10;
    this.plateTypes = [];
    this.subServices = [];
  }
  ngOnInit() {
    this.loadReportDetails();
    this.createInspectionReportsSearchForm();
    this.bindSearchFormChange();
    this.loadPlateTypes();
  }
  loadSubServices(serviceType) {
    this.InspectionService.getSubServices({
      serviceType: serviceType
    }).subscribe(data => {
      this.subServices = data.items;
    });
  }
  loadPlateTypes() {
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.plateTypes = data;
    });
  }
  bindSearchFormChange() {
    this.inspectionReportsSearchForm.controls.serviceType.valueChanges.subscribe(res => {
      this.loadSubServices(res);
    });
    this.inspectionReportsSearchForm.valueChanges.subscribe(formValue => {
      let value = this.inspectionReportsSearchForm.value;
      value.serviceType = value.serviceType == -1 ? null : value.serviceType;
      value.plateType = value.plateType == -1 ? null : value.plateType;
      value.serviceId = value.serviceId == -1 ? null : value.serviceId;
      this.InspectionService.getInspectedVehicleReportDetails(value).subscribe(data => {
        this.inspectionReports = data.items;
      });
    });
  }
  createInspectionReportsSearchForm() {
    this.inspectionReportsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      plateNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null),
      plateType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(-1),
      vinNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null),
      receiptNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null),
      serviceType: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(-1),
      serviceId: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(-1)
    });
  }
  submitReportPayment(reportPayment) {
    this.downloadInspectionReport(reportPayment);
    this.loadReportDetails();
    //payment
  }

  logSelectedReport(reportPayment) {
    var body = {
      fahesReceiptNo: reportPayment.fahesReceiptNo,
      requestId: reportPayment.requestId,
      reportFee: reportPayment.reportFee,
      reportFeesType: reportPayment.reportFeesType
    };
    this.InspectionService.insertInspectionResultsReportLog(body).subscribe(data => {
      this.loadReportDetails();
    });
  }
  loadReportDetails() {
    this.InspectionService.getInspectedVehicleReportDetails({}).subscribe(data => {
      this.inspectionReports = data.items;
    });
  }
  totalPages() {
    let total = 0;
    total = Math.ceil(this.inspectionReports?.length / this.pageSize);
    return Array.from({
      length: total
    }, (_, i) => i + 1);
  }
  changePage(page) {
    if (page >= 1 && page <= this.totalPages().length) this.currentPage = page;
  }
  get paginatedData() {
    if (this.pageSize === -1) return this.inspectionReports; // Return all data when pageSize is -1
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = Math.min(startIndex + this.pageSize, this.inspectionReports?.length);
    return this.inspectionReports?.slice(startIndex, endIndex);
  }
  downloadInspectionReport(report) {
    this.logSelectedReport(report);
    let ssrs = {
      moduleName: "Inspection Results",
      reportName: "InspectionByID",
      parameters: {
        RequestId: report.requestId.toString()
      }
    };
    this.ssrsPrintService.downloadReport(ssrs, report.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_0__.PrintEnum.printSave);
    this.loadReportDetails();
  }
  resetSearchForm() {
    this.inspectionReportsSearchForm.reset();
  }
  static #_ = this.ɵfac = function InspectionResultsReportsComponent_Factory(t) {
    return new (t || InspectionResultsReportsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_1__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_2__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_3__.SharedLookupService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: InspectionResultsReportsComponent,
    selectors: [["app-inspection-results-reports"]],
    decls: 93,
    vars: 12,
    consts: [[1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], ["id", "headingTwo", 1, "accordion-header"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-2"], ["for", "plateNo"], ["type", "text", "id", "username", "formControlName", "receiptNo", 1, "form-control", "searchBox"], ["formControlName", "serviceType", 1, "form-control"], ["value", "-1", "selected", "", "disabled", ""], ["value", "1"], ["value", "2"], ["value", "3"], ["formControlName", "serviceId", 1, "form-control", 3, "disabled"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "number", "id", "username", "formControlName", "plateNo", 1, "form-control", "searchBox"], ["formControlName", "plateType", 1, "form-control"], ["type", "text", "id", "username", "formControlName", "vinNo", 1, "form-control", "searchBox"], ["type", "reset", 1, "btn", "btn-orange", 3, "click"], [1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], [3, "value"], ["id", "print"], ["class", "btn btn-outline-orange small-text", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 3, "click", 4, "ngIf"], ["class", "btn btn-outline-orange small-text", 3, "click", 4, "ngIf"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-outline-orange", "small-text", 3, "click"], [1, "btn", "btn-outline-orange", "small-text", 3, "click"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"]],
    template: function InspectionResultsReportsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 0)(3, "div", 2)(4, "div", 3)(5, "div", 4)(6, "div", 5)(7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](8, "br")(9, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Inspection Reports");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div", 7)(13, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "form", 9)(16, "div", 10)(17, "div", 11)(18, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](20, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 11)(22, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, " Service Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "select", 14)(25, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "Select Service Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, " Inspection Service ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, " Vin Stamping ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "option", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](32, " Tanker Certificate ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "div", 11)(34, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](35, "Selected Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "select", 19)(37, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](38, "Select Service");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](39, InspectionResultsReportsComponent_option_39_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "div", 11)(41, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](42, "Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](43, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](44, "div", 11)(45, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](46, " Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](47, "select", 22)(48, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](49, "Select Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](50, InspectionResultsReportsComponent_option_50_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](51, "div", 11)(52, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](53, "Vin No");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](54, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](55, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](56, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](57, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](58, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_button_click_58_listener() {
          return ctx.resetSearchForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](59, " reset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](60, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](61, "table", 25)(62, "thead")(63, "tr", 26)(64, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](65, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](66, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](67, " Service Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](68, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](69, " Plate No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](70, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](71, " Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](72, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](73, " Report Fee ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](74, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](75, " Owner Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](76, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](77, " No. Of Prev Times ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](78, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](79, " Cost");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](80, "th", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](81, " Action ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](82, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](83, InspectionResultsReportsComponent_tr_83_Template, 20, 10, "tr", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](84, "div", 29)(85, "ul", 30)(86, "li", 31)(87, "a", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_a_click_87_listener() {
          return ctx.changePage(ctx.currentPage - 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](88, "i", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](89, InspectionResultsReportsComponent_li_89_Template, 3, 4, "li", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](90, "li", 31)(91, "a", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionResultsReportsComponent_Template_a_click_91_listener() {
          return ctx.changePage(ctx.currentPage + 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](92, "i", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx.inspectionReportsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", (ctx.inspectionReportsSearchForm.controls.serviceType == null ? null : ctx.inspectionReportsSearchForm.controls.serviceType.value) == -1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.subServices);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](33);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.paginatedData);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](8, _c1, ctx.currentPage === 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.totalPages());
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](10, _c1, ctx.currentPage === ctx.totalPages().length));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName],
    styles: ["th[_ngcontent-%COMP%] {\r\n    color: white;\r\n    background-color: #F89828;\r\n}\r\n\r\n\r\n.custom-table[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    color: black;\r\n    background-color: #ffdcb3;\r\n    border: 1px solid white;\r\n    border-collapse: collapse;\r\n    margin: 20px 0;\r\n}\r\n\r\ntable[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\nimg[_ngcontent-%COMP%] {\r\n    width: 20px;\r\n    height: 20px;\r\n}\r\n\r\n#print[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n}\r\n\r\n.small-text[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n}\r\n\r\n\r\n.pagination-container[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin-top: 20px;\r\n}\r\n\r\n.pagination[_ngcontent-%COMP%] {\r\n    list-style-type: none;\r\n    display: flex;\r\n    margin: 0;\r\n    padding: 0;\r\n}\r\n\r\n.page-item[_ngcontent-%COMP%] {\r\n    margin: 0 2px;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n    padding: 5px 5px;\r\n    text-decoration: none;\r\n}\r\n\r\n#pagesId[_ngcontent-%COMP%] {\r\n    background-color: #F89828;\r\n    color: white;\r\n}\r\n\r\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    color: #F89828;\r\n    font-weight: bold;\r\n    border-color: #F89828;\r\n}\r\n\r\n.bi[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n}\r\n\r\n.no-request[_ngcontent-%COMP%] {\r\n    margin-top: 50px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvaW5zcGVjdGlvbi1yZXN1bHRzLXJlcG9ydHMvaW5zcGVjdGlvbi1yZXN1bHRzLXJlcG9ydHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFlBQVk7SUFDWix5QkFBeUI7QUFDN0I7OztBQUdBO0lBQ0ksa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWix5QkFBeUI7SUFDekIsdUJBQXVCO0lBQ3ZCLHlCQUF5QjtJQUN6QixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksV0FBVztJQUNYLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7OztBQUdBO0lBQ0ksYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0kscUJBQXFCO0lBQ3JCLGFBQWE7SUFDYixTQUFTO0lBQ1QsVUFBVTtBQUNkOztBQUVBO0lBQ0ksYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsY0FBYztJQUNkLGlCQUFpQjtJQUNqQixxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSxjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCIiwic291cmNlc0NvbnRlbnQiOlsidGgge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcclxufVxyXG5cclxuXHJcbi5jdXN0b20tdGFibGUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZGNiMztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xyXG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICAgIG1hcmdpbjogMjBweCAwO1xyXG59XHJcblxyXG50YWJsZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbmltZyB7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGhlaWdodDogMjBweDtcclxufVxyXG5cclxuI3ByaW50IHtcclxuICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbn1cclxuXHJcbi5zbWFsbC10ZXh0IHtcclxuICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbn1cclxuXHJcblxyXG4ucGFnaW5hdGlvbi1jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ucGFnZS1pdGVtIHtcclxuICAgIG1hcmdpbjogMCAycHg7XHJcbn1cclxuXHJcbi5wYWdlLWxpbmsge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcGFkZGluZzogNXB4IDVweDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG5cclxuI3BhZ2VzSWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxubGkucGFnZS1pdGVtLmFjdGl2ZSAjcGFnZXNJZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGNvbG9yOiAjRjg5ODI4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBib3JkZXItY29sb3I6ICNGODk4Mjg7XHJcbn1cclxuXHJcbi5iaSB7XHJcbiAgICBjb2xvcjogI0Y4OTgyODtcclxufVxyXG5cclxuLm5vLXJlcXVlc3Qge1xyXG4gICAgbWFyZ2luLXRvcDogNTBweDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 67961:
/*!****************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/landing/landing.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingComponent": () => (/* binding */ LandingComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);







const _c0 = ["barCode"];
function LandingComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
function LandingComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
class LandingComponent {
  constructor(formBuilder, router, sharedDataService, sideNav, el) {
    this.formBuilder = formBuilder;
    this.router = router;
    this.sharedDataService = sharedDataService;
    this.sideNav = sideNav;
    this.el = el;
    this.submitted = false;
    this.isBarCodeScanned = false;
    this.landingForm = formBuilder.group({
      displayBarCode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.pattern(/^.{3,8}$/)]]
    });
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(2, 6);
  }
  getIstimaraCode() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCode');
      if (myInput) {
        myInput.focus();
      }
    }, 200);
  }
  onBarcodeInput(event) {
    const barcodeValue = event.target.value;
    this.landingForm.get('displayBarCode').setValue(barcodeValue);
    this.isBarCodeScanned = true;
    this.readBarCode();
  }
  readBarCode() {
    if (this.landingForm.valid) {
      this.sharedDataService.setTextEx(this.landingForm.get('displayBarCode').value);
      this.router.navigate(['backoffice/exempted']);
      const modalElement = document.getElementById('istimaraCode');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
  }
  ngOnDestroy() {
    this.landingForm.get('displayBarCode').setValue('');
  }
  static #_ = this.ɵfac = function LandingComponent_Factory(t) {
    return new (t || LandingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: LandingComponent,
    selectors: [["app-landing"]],
    viewQuery: function LandingComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.barCode = _t.first);
      }
    },
    decls: 36,
    vars: 3,
    consts: [["lang", "en"], ["charset", "utf-8"], ["content", "width=device-width, initial-scale=1.0", "name", "viewport"], ["href", "./assets/img/favicon.png", "rel", "icon"], [3, "formGroup"], [1, "main-container-wrap"], [1, "rvd"], [1, "rvd-links"], ["href", "#", "data-bs-toggle", "modal", "data-bs-target", "#istimaraCode", 3, "click"], ["src", "./assets/img/scan.svg"], ["routerLink", "../exempted", 1, "btn", "btn-link"], ["src", "./assets/img/keyboard.svg"], ["id", "istimaraCode", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["src", "./assets/img/scan.svg", "width", "50px"], [1, "modal-body"], ["type", "text", "id", "barCode", "formControlName", "displayBarCode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCode", ""], ["class", "error-message", 4, "ngIf"], ["class", "info-msg", 4, "ngIf"], [1, "error-message"], [1, "info-msg"]],
    template: function LandingComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "html", 0)(1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "meta", 1)(3, "meta", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "title");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5, "FAHES ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "link", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "body")(8, "form", 4)(9, "div", 5)(10, "div", 6)(11, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12, " Read Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14, " Choose the preferred option ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "div", 7)(16, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function LandingComponent_Template_a_click_16_listener() {
          return ctx.getIstimaraCode();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](17, "img", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, "Scan Istimara");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "a", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](23, "Manual Entry");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "div", 12)(25, "div", 13)(26, "div", 14)(27, "div", 15)(28, "h1", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](29, "img", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](30, " Istimara Bar Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "div", 18)(32, "input", 19, 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("keyup.enter", function LandingComponent_Template_input_keyup_enter_32_listener($event) {
          return ctx.onBarcodeInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](34, LandingComponent_div_34_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](35, LandingComponent_div_35_Template, 2, 0, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.landingForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](26);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.landingForm.get("displayBarCode").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.landingForm.valid);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterLink, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 25414:
/*!*********************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/mobile-booking/mobile-booking/mobile-booking.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileBookingComponent": () => (/* binding */ MobileBookingComponent)
/* harmony export */ });
/* harmony import */ var C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var _classes_payment_details__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../classes/payment-details */ 48672);
/* harmony import */ var src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/modules/shared/custom-validators/date.validator */ 97633);
/* harmony import */ var src_app_core_utilities_enums_inspection_service_type_classification_rnum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/inspection-service-type-classification.rnum */ 46949);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_registration_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/registration.service */ 59212);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_thousand_separator_directive__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../../../../shared/thousand-separator.directive */ 59903);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);




























function MobileBookingComponent_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "option", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ownerPidType_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", ownerPidType_r24.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ownerPidType_r24.lkValueEname, " ");
  }
}
function MobileBookingComponent_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_25_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
function MobileBookingComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_25_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r2.mobileBookingForm.get("pidNo").value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, " * Enter a valid Owner PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_58_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
const _c0 = function () {
  return ["serviceRequest", "contactPersonPhone"];
};
function MobileBookingComponent_div_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_58_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r6.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](1, _c0)).value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_59_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Please enter a valid phone number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_64_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
const _c1 = function () {
  return ["serviceRequest", "secondaryPhoneNo"];
};
function MobileBookingComponent_div_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_64_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r8.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](1, _c1)).value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Please enter a valid phone number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_70_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
const _c2 = function () {
  return ["serviceRequest", "pid"];
};
function MobileBookingComponent_div_70_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_70_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r10.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](1, _c2)).value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, " *PID shouldn't be more than 20 characters ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_76_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
}
const _c3 = function () {
  return ["serviceRequest", "contactPersonEmail"];
};
function MobileBookingComponent_div_76_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, MobileBookingComponent_div_76_ng_container_1_Template, 2, 0, "ng-container", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r12.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](1, _c3)).value.toString().length <= 0);
  }
}
function MobileBookingComponent_div_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Please enter valid email address ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_82_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_87_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_92_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_93_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " *Preferred date can't be less than today date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Invalid Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function MobileBookingComponent_div_118_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "input", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](2, "label", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const service_r30 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", "service" + service_r30.serviceId)("value", service_r30.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("for", "service" + service_r30.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](service_r30.descriptionEn);
  }
}
function MobileBookingComponent_ng_container_134_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](1, "div", 68)(2, "input", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_ng_container_134_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r33);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r32.onSelectPayment($event));
    })("ngModelChange", function MobileBookingComponent_ng_container_134_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r33);
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r34.paymentType.paymentTypeId = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const paymentMethod_r31 = ctx.$implicit;
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", paymentMethod_r31.lkCodeValue)("ngModel", ctx_r20.paymentType.paymentTypeId)("value", paymentMethod_r31.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵattribute"]("for", paymentMethod_r31.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](paymentMethod_r31.lkValueEname);
  }
}
function MobileBookingComponent_div_136_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "ng-option", 77)(1, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r36 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", c_r36.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", c_r36.customerName, " ");
  }
}
function MobileBookingComponent_div_136_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 34)(1, "div", 72)(2, "label", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](4, "ng-select", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_div_136_Template_ng_select_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r38);
      const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r37.selectedCustomer = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](5, 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](6, "ng-option", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](7, MobileBookingComponent_div_136_ng_option_7_Template, 3, 2, "ng-option", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngModel", ctx_r21.selectedCustomer)("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx_r21.creditCustomerList);
  }
}
function MobileBookingComponent_div_138_tr_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "tr")(1, "td", 83)(2, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" * Fees should be ", ctx_r39.downpaymentConfigTh, " or more ");
  }
}
function MobileBookingComponent_div_138_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 79)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "div", 1)(4, "div", 80)(5, "table", 81)(6, "thead")(7, "tr")(8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](9, "Service");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](11, "Fees");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "tbody")(13, "tr")(14, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](16, "td")(17, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_div_138_Template_input_ngModelChange_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r41);
      const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r40.downpaymentThousand = $event);
    })("ngModelChange", function MobileBookingComponent_div_138_Template_input_ngModelChange_17_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r41);
      const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r42.validateSubmitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](18, MobileBookingComponent_div_138_tr_18_Template, 4, 1, "tr", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](19, "tfoot")(20, "tr")(21, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](22, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](23, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](24);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()();
  }
  if (rf & 2) {
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ctx_r22.getSelectedInpsectionServiceType(), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngModel", ctx_r22.downpaymentThousand);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r22.payError);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ctx_r22.downpaymentThousand, " ");
  }
}
function MobileBookingComponent_ng_container_144_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](1, "payment-transaction-status-modal", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("onCancelEvent", function MobileBookingComponent_ng_container_144_Template_payment_transaction_status_modal_onCancelEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r44);
      const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r43.closePaymentDetailsModal());
    })("onCancelFailedEvent", function MobileBookingComponent_ng_container_144_Template_payment_transaction_status_modal_onCancelFailedEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r44);
      const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r45.closePaymentDetailsModal());
    })("onDownloadPaymentEvent", function MobileBookingComponent_ng_container_144_Template_payment_transaction_status_modal_onDownloadPaymentEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r44);
      const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r46.downloadReport());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](2, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipe"](3, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("isPaymentStarted", ctx_r23.isPaymentStarted)("email", "test")("isSuccess", ctx_r23.isSuccess)("isPayCanceled", ctx_r23.isPayCanceled)("isNotReachable", ctx_r23.isNotReachable)("requestRefId", ctx_r23.requestId)("currentDateFormat", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind2"](2, 10, ctx_r23.getCurrentDate(), "dd MMM yyyy"))("currentTimeFormat", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpipeBind2"](3, 13, ctx_r23.getCurrentDate(), "HH:mm a"))("totalAmountTh", ctx_r23.totalFeesTh)("paymentName", ctx_r23.getPaymentMethodName(ctx_r23.paymentType.paymentTypeId));
  }
}
const _c4 = function () {
  return ["serviceRequest", "contactPersonName"];
};
const _c5 = function () {
  return ["serviceRequest", "location"];
};
const _c6 = function () {
  return ["serviceRequest", "noOfVehicle"];
};
const _c7 = function () {
  return ["serviceRequest", "inspectionDate"];
};
const _c8 = function (a0) {
  return {
    "display": a0
  };
};
class MobileBookingComponent {
  constructor(lookupService, registerService, fb, router, paymentService, vehicleService, sideNav, ssrsPrintServ, globalServ, sharedDataService, thousandService) {
    this.lookupService = lookupService;
    this.registerService = registerService;
    this.fb = fb;
    this.router = router;
    this.paymentService = paymentService;
    this.vehicleService = vehicleService;
    this.sideNav = sideNav;
    this.ssrsPrintServ = ssrsPrintServ;
    this.globalServ = globalServ;
    this.sharedDataService = sharedDataService;
    this.thousandService = thousandService;
    this.display = 'none';
    this.displayPaymentDetails = 'none';
    this.isCollectPayment = false;
    this.downpaymentAmount = 0;
    this.feesDiscount = 0;
    this.requestId = 0;
    this.isCreditSelected = false;
    this.payError = false;
    this.isPaymentStarted = false;
    this.paymentType = new _classes_payment_details__WEBPACK_IMPORTED_MODULE_3__.PaymentDetails();
    this.initForm();
    this.fillLookupControls();
  }
  initForm() {
    this.sideNav.setActiveEnt(2, 3);
    this.mobileBookingForm = this.fb.group({
      ownerName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      pidNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required]],
      ownerType: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required]],
      address: [''],
      serviceRequest: this.fb.group({
        // contactType: ['', Validators.required],
        contactPersonName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
        contactPersonPhone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^[34567]\d{7}$/)]],
        contactPersonEmail: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)]],
        pid: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^.{1,20}$/)]],
        location: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required]],
        noOfVehicle: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.min(0)]],
        inspectionDate: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_4__.DateValidator.NotLessThanToday, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_4__.DateValidator.ValidateFourDigitYear]],
        serviceType: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
        secondaryPhoneNo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^[34567]\d{7}$/)]]
      })
    });
    /*this.sharedDataService.stationId$.subscribe((res) => {
      this.stationId = res;
    });
    */
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.mobileBookingForm.get('pidNo').valueChanges.subscribe(value => {
      // Check validity and log "test" if it's valid
      if (this.mobileBookingForm.get('pidNo').value && this.mobileBookingForm.get('pidNo').valid) {
        this.vehicleService.getOwnerNameByPid(this.mobileBookingForm.get('pidNo').value.toString()).subscribe(response => {
          this.mobileBookingForm.get('ownerName').setValue(response.items);
        });
      }
    });
    this.vehicleService.getDownPaymentAmount().subscribe(response => {
      this.downpaymentConfig = response.items;
      this.downpaymentThousand = this.thousandService.addThousandSeparator(this.downpaymentConfig.toString());
      this.downpaymentConfigTh = this.thousandService.addThousandSeparator(this.downpaymentConfig.toString());
    });
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  //#region Lookups  : 
  getOwnerPidTypes() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.mobileBookingOwnerPidType).subscribe(response => {
      this.ownerPidTypes = response.items;
    });
  }
  getServiceTypes() {
    this.registerService.getInspectionServiceTypes(src_app_core_utilities_enums_inspection_service_type_classification_rnum__WEBPACK_IMPORTED_MODULE_5__.ServiceTypeClassifications.External).subscribe(response => {
      this.serviceTypes = response.items.filter(x => x.serviceId != src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_6__.InspectionServiceTypes.ExternalInspection);
    });
  }
  getPaymentMethods() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.paymentMethods).subscribe(response => {
      this.paymentMethods = response.items;
    });
  }
  getContactTypes() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.contactType).subscribe(response => {
      this.contactTypes = response.items;
    });
  }
  formatPidInput(event) {
    let value = event.target.value;
    // Remove non-digit characters
    value = value.replace(/\D/g, '');
    if (this.mobileBookingForm.get("ownerType").value == 1) {
      let formattedValue = '';
      for (let i = 0; i < value.length; i++) {
        if (i === 2 || i === 6) {
          formattedValue += '-';
        }
        formattedValue += value[i];
      }
      event.target.value = formattedValue;
    }
  }
  validateOwnerPid() {
    // if the owner type is company
    if (this.mobileBookingForm.get("ownerType").value == 1) {
      this.mobileBookingForm.get('pidNo').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^\d{2}-\d{4}-\d{2}$/));
      this.mobileBookingForm.get('pidNo').updateValueAndValidity();
    } else {
      this.mobileBookingForm.get('pidNo').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.pattern(/^.{11}$/));
      this.mobileBookingForm.get('pidNo').updateValueAndValidity();
    }
  }
  fillLookupControls() {
    this.getOwnerPidTypes();
    this.getServiceTypes();
    this.getPaymentMethods();
    this.getContactTypes();
  }
  //#endregion
  getSelectedInpsectionServiceType() {
    if (this.serviceTypes) {
      let serviceType = this.serviceTypes.find(x => x.serviceId == this.mobileBookingForm.get(['serviceRequest', 'serviceType']).value);
      return serviceType == undefined ? "" : serviceType.descriptionEn;
    }
  }
  //Payments :
  collectPayment() {
    this.isCollectPayment = true;
    this.downpaymentAmount = Number(this.downpaymentThousand.replace(/,/g, ''));
    this.display = 'block';
  }
  submitForm() {
    var _this = this;
    return (0,C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.globalServ.getStationPaymentMethods(_this.stationId).subscribe(response => {
        _this.paymentMethods = response.items;
      });
      if (_this.requestId == 0) {
        // Handle form submission for mobile booking
      } else {
        _this.collectPayment();
      }
    })();
  }
  onDownpaymentChange(event) {
    this.downpaymentAmount = event.target.value;
  }
  cancel() {
    this.router.navigate(['/registration/landing']);
  }
  submitPayment() {
    var _this2 = this;
    return (0,C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.mobileBookingForm.valid) {
        let mobileBookingWorkFlowRequest;
        let mobileBookingRequest = _this2.mobileBookingForm.value;
        let serviceRequest = _this2.mobileBookingForm.get('serviceRequest').value;
        delete mobileBookingRequest.serviceRequest;
        //Parse value to int as the reactive form bind it as string 
        mobileBookingRequest.ownerType = parseInt(mobileBookingRequest.ownerType);
        const pidNumber = Number(mobileBookingRequest.pidNo.toString().replace(/-/g, ''));
        mobileBookingRequest.pidNo = pidNumber;
        const downpaymentInt = Number(_this2.downpaymentAmount.toString().replace(/,/g, ''));
        mobileBookingRequest.downpaymentAmount = _this2.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer ? null : downpaymentInt;
        mobileBookingRequest.noOfVehicle = _this2.mobileBookingForm.get(['serviceRequest', 'noOfVehicle']).value;
        mobileBookingRequest.location = _this2.mobileBookingForm.get(['serviceRequest', 'location']).value;
        mobileBookingRequest.inspectionDate = _this2.mobileBookingForm.get(['serviceRequest', 'inspectionDate']).value;
        mobileBookingRequest.secondaryPhoneNo = _this2.mobileBookingForm.get(['serviceRequest', 'secondaryPhoneNo']).value;
        serviceRequest.registrationSource = src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupValueCodes.BackOffice;
        serviceRequest.serviceId = src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupValueCodes.Inspection;
        serviceRequest.stationId = parseInt(localStorage.getItem('stationId'));
        yield _this2.registerService.createServiceRequest(serviceRequest).subscribe(response => {
          mobileBookingRequest.requestId = response.items;
          _this2.requestId = response.items;
          _this2.registerService.submitMobileBooking(mobileBookingRequest).subscribe(response => {
            _this2.isRequestSubmitted = true;
            _this2.collectPayment();
            _this2.submitPaymentMobile();
            _this2.display = 'none';
          });
        });
      }
    })();
  }
  submitPaymentMobile() {
    const downpaymentInt = Number(this.downpaymentAmount.toString().replace(/,/g, ''));
    this.downpaymentAmount = downpaymentInt;
    let payment = {
      paymentMethodId: this.paymentType.paymentTypeId,
      serviceRequestFeesDto: [{
        feesAmount: this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer ? 0 : this.downpaymentAmount,
        requestId: this.requestId,
        serviceTypeId: this.mobileBookingForm.get(['serviceRequest', 'serviceType']).value,
        customerId: this.selectedCustomer == undefined ? null : this.selectedCustomer,
        subDiscount: this.feesDiscount
      }]
    };
    this.totalFeesTh = this.downpaymentThousand;
    this.isPaymentStarted = true;
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.Card) {
      this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_23__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_24__.catchError)(error => {
        if (error.name === 'TimeoutError') {
          this.isNotReachable = true;
          this.displayPaymentDetails = 'block';
        }
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_25__.throwError)(error);
      })).subscribe(data => {
        // Handle the successful response
        const paymentResult = data;
        const messageCode = paymentResult.messageCode;
        const errorMessage = paymentResult.errorMessage;
        if (paymentResult.items.isCaptured) {
          this.isSuccess = true;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.closePaymentDetailsModal();
          }, 3000);
        }
        if (paymentResult.items.isCanceled) {
          this.isPayCanceled = true;
        }
        if (paymentResult.items.isDeviceNotReachable) {
          this.isNotReachable = true;
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        console.error(error);
      });
    }
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.Cash) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          this.isSuccess = true;
          this.isNotReachable = false;
          this.isPayCanceled = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.closePaymentDetailsModal();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isPayCanceled = false;
          this.isSuccess = false;
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        this.isSuccess = false;
        this.displayPaymentDetails = 'block';
      });
    }
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer) {
      this.paymentService.submitPayment(payment).subscribe(data => {
        if (data.items) {
          this.isSuccess = true;
          this.isPayCanceled = false;
          this.isNotReachable = false;
          setTimeout(() => {
            this.isPaymentStarted = false;
            this.closePaymentDetailsModal();
          }, 3000);
        } else {
          this.isNotReachable = true;
          this.isSuccess = false;
          this.isPayCanceled = false;
        }
        this.displayPaymentDetails = 'block';
      }, error => {
        this.isSuccess = false;
        this.displayPaymentDetails = 'block';
      });
    }
    this.cancelPayment();
  }
  onSelectPayment(paymentMethodTypeId) {
    if (paymentMethodTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer) {
      this.isCreditSelected = true;
      this.vehicleService.getCreditCustomer(this.selectedCustomer).subscribe(data => {
        this.creditCustomerList = data.items;
      });
    } else {
      this.isCreditSelected = false;
    }
    // this.paymentName = this.manualReg.get('paymentTypes').value.find((payId => payId.lkCodeValue == this.manualReg.get('selectedPayment').value)).lkValueEname;
  }

  closePaymentDetailsModal() {
    this.isPaymentStarted = false;
    this.displayPaymentDetails = 'none';
    this.mobileBookingForm.reset();
    this.paymentType = new _classes_payment_details__WEBPACK_IMPORTED_MODULE_3__.PaymentDetails();
    this.isRequestSubmitted = false;
    this.isSuccess = false;
    this.isPayCanceled = false;
    this.isNotReachable = false;
    this.requestId = 0;
    this.isCreditSelected = false;
    this.selectedCustomer = undefined;
  }
  downloadReport() {
    this.ssrsPrintServ.downloadCustomerReport(this.requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_8__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_9__.ModuleSourceEnum.mobile);
  }
  getCurrentDate() {
    return new Date();
  }
  getPaymentMethodName(paymentMethodId) {
    return this.paymentMethods.find(x => x.lkCodeValue == paymentMethodId).lkValueEname;
  }
  cancelPayment() {
    this.selectedCustomer = undefined;
    this.downpaymentAmount = this.downpaymentConfig;
    this.downpaymentThousand = this.thousandService.addThousandSeparator(this.downpaymentConfig.toString());
    const modalElement = document.getElementById('paymentDetailsModal');
  }
  validateSubmitPayment() {
    this.downpaymentThousand = this.thousandService.addThousandSeparator(this.downpaymentThousand);
    this.downpaymentAmount = Number(this.downpaymentThousand.replace(/,/g, ''));
    if (this.paymentType.paymentTypeId == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_7__.PaymentMethods.CreditCustomer && this.selectedCustomer == undefined) return false;
    if (this.downpaymentAmount < this.downpaymentConfig) {
      this.payError = true;
      return false;
    } else {
      this.payError = false;
      return true;
    }
  }
  static #_ = this.ɵfac = function MobileBookingComponent_Factory(t) {
    return new (t || MobileBookingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_10__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_registration_service__WEBPACK_IMPORTED_MODULE_11__.RegistrationService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_26__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_12__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_13__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_14__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_15__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_16__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_17__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_18__.ThousandSeparatorService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdefineComponent"]({
    type: MobileBookingComponent,
    selectors: [["app-mobile-booking"]],
    hostBindings: function MobileBookingComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("keydown", function MobileBookingComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 145,
    vars: 63,
    consts: [[3, "formGroup"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "companyPersonDetails", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "companyPersonDetailsHeading", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-companyPersonDetails", 1, "accordion-button"], ["id", "act-companyPersonDetails", "aria-labelledby", "companyPersonDetailsHeading", "data-bs-parent", "#companyPersonDetails", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-4", "col-lg-4"], ["name", "ownerType", "formControlName", "ownerType", 1, "form-control", 3, "ngModelChange"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "validation-filed", 4, "ngIf"], ["type", "text", "name", "pidNo", "formControlName", "pidNo", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9-]/g, '');", "required", "", 1, "form-control", 3, "input"], ["for", "ownerName"], ["type", "text", "id", "ownerName", "name", "ownerName", "formControlName", "ownerName", "required", "", 1, "form-control"], ["type", "text", "formControlName", "address", 1, "form-control"], ["formGroupName", "serviceRequest"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-4", "col-lg-3"], ["type", "text", "name", "contactPersonName", "formControlName", "contactPersonName", "required", "", 1, "form-control"], ["type", "text", "name", "contactPersonPhone", "formControlName", "contactPersonPhone", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "required", "", 1, "form-control"], ["type", "text", "name", "secondaryPhoneNo", "formControlName", "secondaryPhoneNo", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", 1, "form-control"], ["type", "text", "name", "pid", "formControlName", "pid", "required", "", 1, "form-control"], ["type", "text", "name", "contactPersonEmail", "formControlName", "contactPersonEmail", "required", "", 1, "form-control"], ["type", "text", "name", "location", "formControlName", "location", 1, "form-control"], [1, "col-md-6", "col-lg-6"], ["id", "NumberOfVehicles", "name", "NumberOfVehicles", "type", "number", "min", "0", "maxlength", "11", "formControlName", "noOfVehicle", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "required", "", 1, "form-control"], ["type", "date", "name", "inspectionDate", "formControlName", "inspectionDate", 1, "form-control"], ["id", "accordionExample3", 1, "accordion", "section-accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-6", "col-lg-3"], [1, "outline-radio"], ["type", "radio", "id", "rb1", "checked", ""], ["for", "rb1"], ["src", "./assets/img/st-img-1.svg"], [1, "st-label"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "disabled", "click"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "paymentModel", "aria-hidden", "true", 1, "modal", "fade", "locPop", 3, "ngStyle"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "paymentModel", 1, "modal-title"], [1, "modal-body"], [1, "payment-info"], [1, "payment-type"], [4, "ngFor", "ngForOf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], ["class", "summery-details", 4, "ngIf"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#paymentDetailsModal", 1, "btn", "btn-orange", 3, "disabled", "click"], [4, "ngIf"], [3, "value"], [1, "validation-filed"], [1, "btn-radio"], ["type", "radio", "name", "serviceType", "formControlName", "serviceType", 3, "id", "value"], [3, "for"], ["type", "radio", 3, "id", "ngModel", "value", "ngModelChange"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "ngModel", "clearSearchOnAdd", "minTermLength", "ngModelChange"], [1, "dropdown-container"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], ["appThousandSeparator", "", "type", "text", 1, "form-control", 3, "ngModel", "ngModelChange"], ["colspan", "2", 2, "text-align", "center"], [1, "validation-filed", 2, "font-style", "italic"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"]],
    template: function MobileBookingComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "form", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 3)(5, "div", 4)(6, "div", 5)(7, "div", 6)(8, "div", 7)(9, "h2", 8)(10, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](11, " Company/Person Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "div", 10)(13, "div", 11)(14, "div", 12)(15, "div", 13)(16, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](17, "Owner PID Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](18, "select", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("ngModelChange", function MobileBookingComponent_Template_select_ngModelChange_18_listener() {
          return ctx.validateOwnerPid();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](19, MobileBookingComponent_option_19_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](20, MobileBookingComponent_div_20_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](21, "div", 13)(22, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](23, "Owner PID *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](24, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("input", function MobileBookingComponent_Template_input_input_24_listener($event) {
          return ctx.formatPidInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](25, MobileBookingComponent_div_25_Template, 2, 1, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](26, MobileBookingComponent_div_26_Template, 3, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](27, "div", 13)(28, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](29, "Owner Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](30, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](31, MobileBookingComponent_div_31_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](32, "div", 13)(33, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](34, "Address");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](35, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](36, "div", 21)(37, "div", 1)(38, "div", 3)(39, "div", 22)(40, "div", 5)(41, "div", 23)(42, "div", 7)(43, "h2", 24)(44, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](45, " Contact Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](46, "div", 26)(47, "div", 11)(48, "div", 12)(49, "div", 27)(50, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](51, "Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](52, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](53, MobileBookingComponent_div_53_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](54, "div", 27)(55, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](56, "Phone No *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](57, "input", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](58, MobileBookingComponent_div_58_Template, 2, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](59, MobileBookingComponent_div_59_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](60, "div", 27)(61, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](62, "Secondary Phone No *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](63, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](64, MobileBookingComponent_div_64_Template, 2, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](65, MobileBookingComponent_div_65_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](66, "div", 27)(67, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](68, "PID *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](69, "input", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](70, MobileBookingComponent_div_70_Template, 2, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](71, MobileBookingComponent_div_71_Template, 3, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](72, "div", 27)(73, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](74, "Email *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](75, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](76, MobileBookingComponent_div_76_Template, 2, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](77, MobileBookingComponent_div_77_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](78, "div", 27)(79, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](80, "Inspection Location *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](81, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](82, MobileBookingComponent_div_82_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](83, "div", 34)(84, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](85, "Approximate Number of vehicles to be Inspected*");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](86, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](87, MobileBookingComponent_div_87_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](88, "div", 27)(89, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](90, "Preferred Date *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](91, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](92, MobileBookingComponent_div_92_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](93, MobileBookingComponent_div_93_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](94, MobileBookingComponent_div_94_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](95, "div", 1)(96, "div", 3)(97, "div", 22)(98, "div", 5)(99, "div", 37)(100, "div", 7)(101, "h2", 38)(102, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](103, " Service Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](104, "div", 40)(105, "div", 11)(106, "div", 12)(107, "div", 41)(108, "div", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](109, "input", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](110, "label", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](111, "img", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](112, "Inspection");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](113, "div", 1)(114, "div", 3)(115, "label", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](116, "Inspection Service Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](117, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](118, MobileBookingComponent_div_118_Template, 4, 4, "div", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](119, "div", 1)(120, "div", 48)(121, "button", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_121_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](122, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](123, "button", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_123_listener() {
          return ctx.submitForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](124, "Payment");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](125, "div", 51)(126, "div", 52)(127, "div", 53)(128, "div", 54)(129, "h1", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](130, "Payment Details");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](131, "div", 56)(132, "div", 57)(133, "div", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](134, MobileBookingComponent_ng_container_134_Template, 5, 5, "ng-container", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](135, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](136, MobileBookingComponent_div_136_Template, 8, 5, "div", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](137, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](138, MobileBookingComponent_div_138_Template, 25, 4, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](139, "div", 62)(140, "button", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_140_listener() {
          return ctx.cancelPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](141, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](142, "button", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function MobileBookingComponent_Template_button_click_142_listener() {
          return ctx.submitPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](143, "Submit");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](144, MobileBookingComponent_ng_container_144_Template, 4, 16, "ng-container", 65);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("formGroup", ctx.mobileBookingForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.ownerPidTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get("ownerType").dirty || ctx.mobileBookingForm.get("ownerType").touched) && ctx.mobileBookingForm.get("ownerType").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get("pidNo").touched && ctx.mobileBookingForm.get("pidNo").hasError("required"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get("pidNo").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get("ownerName").dirty || ctx.mobileBookingForm.get("ownerName").touched) && ctx.mobileBookingForm.get("ownerName").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](28, _c4)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](29, _c4)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](30, _c4)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](31, _c0)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](32, _c0)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](33, _c0)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](34, _c0)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](35, _c1)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](36, _c1)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](37, _c1)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](38, _c1)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](39, _c2)).touched && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](40, _c2)).hasError("required"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](41, _c2)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](42, _c3)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](43, _c3)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](44, _c3)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](45, _c3)).hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](46, _c5)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](47, _c5)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](48, _c5)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](49, _c6)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](50, _c6)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](51, _c6)).invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](52, _c7)).dirty || ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](53, _c7)).touched) && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](54, _c7)).errors != null && (ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](55, _c7)).errors == null ? null : ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](56, _c7)).errors.required));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](57, _c7)).errors != null && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](58, _c7)).errors.LessThanToday);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](59, _c7)).hasError("InvalidDate") && ctx.mobileBookingForm.get(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](60, _c7)).touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx.mobileBookingForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](61, _c8, ctx.display));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.paymentMethods);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isCreditSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.isCreditSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx.validateSubmitPayment());
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isPaymentStarted);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_27__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_27__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_27__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_22__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_22__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_22__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.MaxLengthValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormControlName, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormGroupName, _shared_thousand_separator_directive__WEBPACK_IMPORTED_MODULE_19__.ThousandSeparatorDirective, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_20__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_28__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_28__.NgOptionComponent, _angular_common__WEBPACK_IMPORTED_MODULE_27__.DatePipe],
    styles: ["input[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvbW9iaWxlLWJvb2tpbmcvbW9iaWxlLWJvb2tpbmcvbW9iaWxlLWJvb2tpbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7SUFHSSxnQkFBZ0I7SUFDaEIsU0FBUztBQUNiOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyJpbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uIHtcclxuICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 25753:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/backoffice/components/receipt-backoffice/receipt-backoffice.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReceiptBackofficeComponent": () => (/* binding */ ReceiptBackofficeComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/modules/shared/custom-validators/date.validator */ 97633);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 94666);












function ReceiptBackofficeComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * Enter a valid date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function ReceiptBackofficeComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * From Date cannot be later than the To Date. Please select valid dates. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function ReceiptBackofficeComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * From Time must be earlier than the To Time. Please select valid time ranges. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
function ReceiptBackofficeComponent_option_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "option", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", pt_r6.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", pt_r6.lkValueEname, " ");
  }
}
function ReceiptBackofficeComponent_tr_77_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "td", 45)(14, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_tr_77_Template_button_click_14_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r10);
      const i_r8 = restoredCtx.index;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r9.printCustomerReport(i_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](15, "img", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](16, " Customer Receipt ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](17, "td", 45)(18, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_tr_77_Template_button_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r10);
      const i_r8 = restoredCtx.index;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r11.printInspectorReport(i_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](19, "img", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](20, " Inspector Receipt ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const r_r7 = ctx.$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r7.receiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r7.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx_r4.mapToPlateName(r_r7.plateType), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r7.vinNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r7.ownerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", r_r7.serviceName, " ");
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function ReceiptBackofficeComponent_li_83_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "li", 48)(1, "a", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_li_83_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r14);
      const i_r12 = restoredCtx.$implicit;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      ctx_r13.currentPage = i_r12 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r13.getPagedReceipts(ctx_r13.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r12 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](2, _c0, ctx_r5.currentPage === i_r12 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](i_r12 + 1);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
class ReceiptBackofficeComponent {
  constructor(fb, vehicleService, sideNav, ssrsService, sharedLookup, sharedData) {
    this.fb = fb;
    this.vehicleService = vehicleService;
    this.sideNav = sideNav;
    this.ssrsService = ssrsService;
    this.sharedLookup = sharedLookup;
    this.sharedData = sharedData;
    this.currentPage = 1;
    this.itemsPerPage = 10;
    this.initializeForm();
    this.setupFormValidators();
  }
  initializeForm() {
    const dateFrom = new Date();
    // set the time from to 6 am
    dateFrom.setHours(6, 0, 0, 0);
    const timeTo = new Date(dateFrom.getTime());
    // set time to to 6 pm
    timeTo.setHours(18, 0, 0, 0);
    this.receiptForm = this.fb.group({
      inputDateFrom: [dateFrom.toISOString().slice(0, 10), [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_2__.DateValidator.CheckMonthDate]],
      inputTimeFrom: [dateFrom.toTimeString().slice(0, 5), _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      inputDateTo: [dateFrom.toISOString().slice(0, 10), [_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, src_app_modules_shared_custom_validators_date_validator__WEBPACK_IMPORTED_MODULE_2__.DateValidator.CheckMonthDate]],
      inputTimeTo: [timeTo.toTimeString().slice(0, 5), _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      plateNo: [''],
      plateType: [''],
      ownerPID: [''],
      vinNo: [''],
      receiptNo: ['']
    });
  }
  ngOnInit() {
    this.moduleId = 2;
    this.sideNav.setActiveEnt(this.moduleId, 77);
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.getAllReceipts();
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.plateTypes = data;
    });
    this.receiptForm.get('inputDateFrom').valueChanges.subscribe(() => {
      this.receiptForm.get('inputDateTo').updateValueAndValidity();
    });
    this.receiptForm.get("inputTimeFrom").valueChanges.subscribe(() => {
      this.receiptForm.get("inputTimeTo").updateValueAndValidity();
    });
  }
  setupFormValidators() {
    this.receiptForm.get('inputDateTo').setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, this.validateDateTo.bind(this)]);
    this.receiptForm.get('inputDateTo').updateValueAndValidity();
    this.receiptForm.get('inputTimeTo').setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required, this.validateTimeTo.bind(this)]);
    this.receiptForm.get('inputTimeTo').updateValueAndValidity();
  }
  validateDateTo(control) {
    const inputDateFrom = new Date(this.receiptForm.get('inputDateFrom').value);
    const inputDateTo = new Date(this.receiptForm.get('inputDateTo').value);
    return inputDateTo >= inputDateFrom ? null : {
      invalidDateRange: true
    };
  }
  validateTimeTo() {
    const timeTo = this.receiptForm.get('inputTimeTo').value;
    const timeFrom = this.receiptForm.get('inputTimeFrom').value;
    if (this.receiptForm.get('inputDateTo').value == this.receiptForm.get('inputDateFrom').value) {
      return timeTo > timeFrom ? null : {
        invalidTimeRange: true
      };
    } else {
      return null;
    }
  }
  mapToPlateName(pltType) {
    return this.plateTypes.find(plt => plt.lkCodeValue == pltType).lkValueEname;
  }
  getAllReceipts() {
    const dateDetails = {
      stationId: this.stationId,
      plateNo: this.receiptForm.get('plateNo').value ? this.receiptForm.get('plateNo').value : null,
      plateType: this.receiptForm.get('plateType').value ? this.receiptForm.get('plateType').value : null,
      vinNo: this.receiptForm.get('vinNo').value ? this.receiptForm.get('vinNo').value : null,
      ownerPID: this.receiptForm.get('ownerPID').value ? this.receiptForm.get('ownerPID').value : null,
      receiptNo: this.receiptForm.get('receiptNo').value ? this.receiptForm.get('receiptNo').value : null,
      fromDate: this.receiptForm.get("inputDateFrom").value + 'T' + this.receiptForm.get('inputTimeFrom').value,
      toDate: this.receiptForm.get("inputDateTo").value + 'T' + this.receiptForm.get('inputTimeTo').value,
      pageIndex: 1,
      pageSize: this.itemsPerPage,
      serviceType: this.moduleId
    };
    this.getReceiptDetails(dateDetails, false);
  }
  getReceiptDetails(details, isNextPage) {
    this.vehicleService.getReceiptDetails(details).subscribe(response => {
      this.receiptDetails = response.items.receipts;
      if (!isNextPage) {
        this.totalReceipts = this.receiptDetails.length;
        if (this.totalReceipts > this.itemsPerPage) {
          this.getPagedReceipts(1);
        }
      }
    });
  }
  clearFilters() {
    this.initializeForm();
    this.getAllReceipts();
  }
  getPagedReceipts(page) {
    const dateDetails = {
      stationId: this.stationId,
      fromDate: this.receiptForm.get("inputDateFrom").value + 'T' + this.receiptForm.get('inputTimeFrom').value,
      toDate: this.receiptForm.get("inputDateTo").value + 'T' + this.receiptForm.get('inputTimeTo').value,
      pageIndex: page,
      pageSize: this.itemsPerPage,
      serviceType: this.moduleId
    };
    this.getReceiptDetails(dateDetails, true);
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.receiptDetails.slice(startIndex, endIndex);
  }
  get totalPages() {
    if (this.totalReceipts > this.itemsPerPage) {
      return Math.ceil(this.totalReceipts / this.itemsPerPage);
    } else {
      return 1;
    }
  }
  pagesArray(totalPages) {
    return Array.from({
      length: totalPages
    }, (_, index) => index);
  }
  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  nextPage() {
    const totalPages = Math.ceil(this.receiptDetails.length / this.itemsPerPage);
    if (this.currentPage < totalPages) {
      this.currentPage++;
    }
  }
  printCustomerReport(index) {
    this.ssrsService.downloadCustomerReport(this.receiptDetails[index].requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_1__.PrintEnum.printSave, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_0__.ModuleSourceEnum.registration);
  }
  printInspectorReport(index) {
    this.ssrsService.downloadInspetorReport(this.receiptDetails[index].requestId, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_1__.PrintEnum.printSave, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_0__.ModuleSourceEnum.registration);
  }
  static #_ = this.ɵfac = function ReceiptBackofficeComponent_Factory(t) {
    return new (t || ReceiptBackofficeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_5__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_6__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: ReceiptBackofficeComponent,
    selectors: [["app-receipt-backoffice"]],
    decls: 87,
    vars: 14,
    consts: [[3, "formGroup"], [1, "row", "form-field"], [1, "col-md-2"], ["type", "date", "id", "fromDate", "formControlName", "inputDateFrom", "required", "", 1, "form-control"], ["type", "time", "id", "fromTime", "formControlName", "inputTimeFrom", 1, "form-control"], ["type", "date", "id", "toDate", "formControlName", "inputDateTo", "required", "", 1, "form-control"], ["type", "time", "id", "toTime", "formControlName", "inputTimeTo", 1, "form-control"], ["class", "row error-message", 4, "ngIf"], ["class", "error-message", 4, "ngIf"], [1, "row", "form-fields"], [1, "col-md-3"], ["type", "text", "formControlName", "plateNo", 1, "form-control"], ["formControlName", "plateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "text", "formControlName", "ownerPID", 1, "form-control"], ["type", "text", "formControlName", "vinNo", 1, "form-control"], ["type", "text", "formControlName", "receiptNo", 1, "form-control"], ["id", "endBt", 1, "col-md-4", "end-btns"], [1, "btn", "btn-orange", 3, "disabled", "click"], [1, "btn", "btn-outline-gray", 3, "click"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], ["id", "headingTwo", 1, "accordion-header"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col"], ["scopr", "col"], ["scope", "col", "colspan", "2"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], [1, "row", "error-message"], [1, "error-message"], [3, "value"], ["id", "print"], [1, "btn", "btn-outline-gray", "small-text", 3, "click"], ["src", "./assets/img/printer.svg"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"]],
    template: function ReceiptBackofficeComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "html")(1, "body")(2, "form", 0)(3, "div", 1)(4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](5, " Date-Time From: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](6, "input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](8, "label")(9, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](10, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](11, " Date-Time To: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](12, "input", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](13, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](14, "label")(15, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](16, ReceiptBackofficeComponent_div_16_Template, 2, 0, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](17, ReceiptBackofficeComponent_div_17_Template, 2, 0, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](18, ReceiptBackofficeComponent_div_18_Template, 2, 0, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](19, "div", 9)(20, "div", 10)(21, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](22, "Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](23, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](24, "div", 10)(25, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](26, " Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](27, "select", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](28, ReceiptBackofficeComponent_option_28_Template, 2, 2, "option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](29, "div", 10)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](31, " Owner PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](32, "input", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](33, "div", 9)(34, "div", 10)(35, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](36, " VIN No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](37, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](38, "div", 10)(39, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](40, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](41, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](42, "div", 17)(43, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_Template_button_click_43_listener() {
          return ctx.getAllReceipts();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](44, " View Receipts ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](45, "button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_Template_button_click_45_listener() {
          return ctx.clearFilters();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](46, " Clear Filters ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](47, "div", 20)(48, "div", 21)(49, "div", 20)(50, "div", 22)(51, "div", 23)(52, "div", 24)(53, "div", 25)(54, "div", 26)(55, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](56, " Receipts ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](57, "div", 27)(58, "div", 28)(59, "table", 29)(60, "thead")(61, "tr", 30)(62, "th", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](63, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](64, "th", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](65, " Plate Number ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](66, "th", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](67, " License Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](68, "th", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](69, " Vin No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](70, "th", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](71, " Owner Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](72, "th", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](73, " Service Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](74, "th", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](75, " Action ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](76, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](77, ReceiptBackofficeComponent_tr_77_Template, 21, 6, "tr", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](78, "div", 35)(79, "ul", 36)(80, "li", 37)(81, "a", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_Template_a_click_81_listener() {
          ctx.currentPage = ctx.currentPage - 1;
          return ctx.getPagedReceipts(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](82, "i", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](83, ReceiptBackofficeComponent_li_83_Template, 3, 4, "li", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](84, "li", 37)(85, "a", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ReceiptBackofficeComponent_Template_a_click_85_listener() {
          ctx.currentPage = ctx.currentPage + 1;
          return ctx.getPagedReceipts(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](86, "i", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.receiptForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.receiptForm.get("inputDateTo").invalid && ctx.receiptForm.get("inputDateTo").hasError("dateMonthError"));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.receiptForm.get("inputDateTo").hasError("invalidDateRange"));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.receiptForm.get("inputTimeTo").hasError("invalidTimeRange"));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("disabled", ctx.receiptForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](34);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.receiptDetails);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](10, _c1, ctx.currentPage == 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.pagesArray(ctx.totalPages));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](12, _c1, ctx.currentPage * ctx.itemsPerPage >= ctx.totalReceipts));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName],
    styles: ["th[_ngcontent-%COMP%] {\r\n    color: white;\r\n    background-color: #F89828;\r\n}\r\n\r\n\r\n.custom-table[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    color: black;\r\n    background-color: #ffdcb3;\r\n    border: 1px solid white;\r\n    border-collapse: collapse;\r\n    margin: 20px 0;\r\n}\r\n\r\ntable[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\nimg[_ngcontent-%COMP%] {\r\n    width: 20px;\r\n    height: 20px;\r\n}\r\n\r\n#print[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n}\r\n\r\n.small-text[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n}\r\n\r\n.pagination-container[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin-left: 400px;\r\n}\r\n\r\n.page-item[_ngcontent-%COMP%] {\r\n    margin: 0 2px;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n    padding: 5px 5px;\r\n    text-decoration: none;\r\n}\r\n\r\n#pagesId[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    color: #F89828;\r\n}\r\n\r\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\r\n    background-color: #F89828;\r\n    color: white;\r\n    font-weight: bold;\r\n    border-color: #F89828;\r\n}\r\n\r\n.bi[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin-right: 100px;\r\n}\r\n\r\n#filterPl[_ngcontent-%COMP%] {\r\n    margin-left: 30px;\r\n}\r\n\r\n#endBt[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9iYWNrb2ZmaWNlL2NvbXBvbmVudHMvcmVjZWlwdC1iYWNrb2ZmaWNlL3JlY2VpcHQtYmFja29mZmljZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksWUFBWTtJQUNaLHlCQUF5QjtBQUM3Qjs7O0FBR0E7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsY0FBYztBQUNsQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksaUJBQWlCO0FBQ3JCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCIiwic291cmNlc0NvbnRlbnQiOlsidGgge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcclxufVxyXG5cclxuXHJcbi5jdXN0b20tdGFibGUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZGNiMztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xyXG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICAgIG1hcmdpbjogMjBweCAwO1xyXG59XHJcblxyXG50YWJsZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbmltZyB7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGhlaWdodDogMjBweDtcclxufVxyXG5cclxuI3ByaW50IHtcclxuICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbn1cclxuXHJcbi5zbWFsbC10ZXh0IHtcclxuICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uLWNvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tbGVmdDogNDAwcHg7XHJcbn1cclxuXHJcbi5wYWdlLWl0ZW0ge1xyXG4gICAgbWFyZ2luOiAwIDJweDtcclxufVxyXG5cclxuLnBhZ2UtbGluayB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nOiA1cHggNXB4O1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcblxyXG4jcGFnZXNJZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGNvbG9yOiAjRjg5ODI4O1xyXG59XHJcblxyXG5saS5wYWdlLWl0ZW0uYWN0aXZlICNwYWdlc0lkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGJvcmRlci1jb2xvcjogI0Y4OTgyODtcclxufVxyXG5cclxuLmJpIHtcclxuICAgIGNvbG9yOiAjRjg5ODI4O1xyXG59XHJcblxyXG4uZXJyb3ItbWVzc2FnZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwMHB4O1xyXG59XHJcblxyXG4jZmlsdGVyUGwge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDMwcHg7XHJcbn1cclxuXHJcbiNlbmRCdCB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 56757:
/*!****************************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/observable/fromSubscribable.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fromSubscribable": () => (/* binding */ fromSubscribable)
/* harmony export */ });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Observable */ 90833);

function fromSubscribable(subscribable) {
  return new _Observable__WEBPACK_IMPORTED_MODULE_0__.Observable(subscriber => subscribable.subscribe(subscriber));
}

/***/ }),

/***/ 62101:
/*!******************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/connect.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "connect": () => (/* binding */ connect)
/* harmony export */ });
/* harmony import */ var _Subject__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Subject */ 80228);
/* harmony import */ var _observable_from__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../observable/from */ 59346);
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/lift */ 41944);
/* harmony import */ var _observable_fromSubscribable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../observable/fromSubscribable */ 56757);




const DEFAULT_CONFIG = {
  connector: () => new _Subject__WEBPACK_IMPORTED_MODULE_0__.Subject()
};
function connect(selector, config = DEFAULT_CONFIG) {
  const {
    connector
  } = config;
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_1__.operate)((source, subscriber) => {
    const subject = connector();
    (0,_observable_from__WEBPACK_IMPORTED_MODULE_2__.from)(selector((0,_observable_fromSubscribable__WEBPACK_IMPORTED_MODULE_3__.fromSubscribable)(subject))).subscribe(subscriber);
    subscriber.add(source.subscribe(subject));
  });
}

/***/ }),

/***/ 98532:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/multicast.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "multicast": () => (/* binding */ multicast)
/* harmony export */ });
/* harmony import */ var _observable_ConnectableObservable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../observable/ConnectableObservable */ 23932);
/* harmony import */ var _util_isFunction__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/isFunction */ 92971);
/* harmony import */ var _connect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./connect */ 62101);



function multicast(subjectOrSubjectFactory, selector) {
  const subjectFactory = (0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(subjectOrSubjectFactory) ? subjectOrSubjectFactory : () => subjectOrSubjectFactory;
  if ((0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(selector)) {
    return (0,_connect__WEBPACK_IMPORTED_MODULE_1__.connect)(selector, {
      connector: subjectFactory
    });
  }
  return source => new _observable_ConnectableObservable__WEBPACK_IMPORTED_MODULE_2__.ConnectableObservable(source, subjectFactory);
}

/***/ }),

/***/ 68917:
/*!************************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/publishReplay.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "publishReplay": () => (/* binding */ publishReplay)
/* harmony export */ });
/* harmony import */ var _ReplaySubject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../ReplaySubject */ 26067);
/* harmony import */ var _multicast__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./multicast */ 98532);
/* harmony import */ var _util_isFunction__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/isFunction */ 92971);



function publishReplay(bufferSize, windowTime, selectorOrScheduler, timestampProvider) {
  if (selectorOrScheduler && !(0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(selectorOrScheduler)) {
    timestampProvider = selectorOrScheduler;
  }
  const selector = (0,_util_isFunction__WEBPACK_IMPORTED_MODULE_0__.isFunction)(selectorOrScheduler) ? selectorOrScheduler : undefined;
  return source => (0,_multicast__WEBPACK_IMPORTED_MODULE_1__.multicast)(new _ReplaySubject__WEBPACK_IMPORTED_MODULE_2__.ReplaySubject(bufferSize, windowTime, timestampProvider), selector)(source);
}

/***/ })

}]);
//# sourceMappingURL=635.bc03419b62a7a660.js.map