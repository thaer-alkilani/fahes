"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[596],{

/***/ 93739:
/*!***************************************************************!*\
  !*** ./src/app/core/resolver/get-mobile-workflow.resolver.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetMobileWorkflowResolver": () => (/* binding */ GetMobileWorkflowResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _services_notification_center_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/notification-center.service */ 77668);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);




class GetMobileWorkflowResolver {
  constructor(_service, _router) {
    this._service = _service;
    this._router = _router;
  }
  resolve(route, state) {
    const requestId = route.queryParams['requestId'];
    const transId = route.queryParams['transId'];
    if (!requestId || !transId) return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    return this._service.getMobileWorkflowNotificationDetails(requestId).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(x => {
      if (!x) this._router.navigate(['/mobile-workflow'], {});
      return x;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(_ => {
      // this._router.navigate(['/error'], {});
      return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    }));
  }
  static #_ = this.ɵfac = function GetMobileWorkflowResolver_Factory(t) {
    return new (t || GetMobileWorkflowResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_services_notification_center_service__WEBPACK_IMPORTED_MODULE_0__.NotificationCenterService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: GetMobileWorkflowResolver,
    factory: GetMobileWorkflowResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 72202:
/*!************************************************************************************************!*\
  !*** ./src/app/modules/mobile-workflow/mobile-workflow-base/mobile-workflow-base.component.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileWorkflowBaseComponent": () => (/* binding */ MobileWorkflowBaseComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 60124);


class MobileWorkflowBaseComponent {
  static #_ = this.ɵfac = function MobileWorkflowBaseComponent_Factory(t) {
    return new (t || MobileWorkflowBaseComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: MobileWorkflowBaseComponent,
    selectors: [["app-mobile-workflow-base"]],
    decls: 1,
    vars: 0,
    template: function MobileWorkflowBaseComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 522:
/*!****************************************************************************************************************!*\
  !*** ./src/app/modules/mobile-workflow/mobile-workflow-notification/mobile-workflow-notification.component.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileWorkflowNotificationComponent": () => (/* binding */ MobileWorkflowNotificationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 26078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var src_app_core_services_notification_center_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/notification-center.service */ 77668);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular2-notifications */ 55609);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);









const _c0 = ["notificationComponent"];
function MobileWorkflowNotificationComponent_div_1_p_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](item_r2.value);
  }
}
function MobileWorkflowNotificationComponent_div_1_p_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](2, 1, item_r2.value, "d/M/yy"));
  }
}
function MobileWorkflowNotificationComponent_div_1_p_5_img_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "img", 13);
  }
}
function MobileWorkflowNotificationComponent_div_1_p_5_img_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "img", 14);
  }
}
function MobileWorkflowNotificationComponent_div_1_p_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, MobileWorkflowNotificationComponent_div_1_p_5_img_1_Template, 1, 0, "img", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, MobileWorkflowNotificationComponent_div_1_p_5_img_2_Template, 1, 0, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !item_r2.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r2.value);
  }
}
function MobileWorkflowNotificationComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 8)(1, "label", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, MobileWorkflowNotificationComponent_div_1_p_3_Template, 2, 1, "p", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, MobileWorkflowNotificationComponent_div_1_p_4_Template, 3, 4, "p", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, MobileWorkflowNotificationComponent_div_1_p_5_Template, 3, 2, "p", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r2.label, " :");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !(item_r2.isDate || item_r2.isBool));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r2.isDate);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r2.isBool);
  }
}
function MobileWorkflowNotificationComponent_button_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function MobileWorkflowNotificationComponent_button_10_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r13);
      const a_r11 = restoredCtx.$implicit;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r12.submit(a_r11.lkCodeValue));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const a_r11 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx_r1.form.invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](a_r11.lkValueEname);
  }
}
class MobileWorkflowNotificationComponent {
  constructor(_route, location, _fb, _service, notificationService, _lookups) {
    this._route = _route;
    this.location = location;
    this._fb = _fb;
    this._service = _service;
    this.notificationService = notificationService;
    this._lookups = _lookups;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_3__.Subscription();
  }
  ngOnInit() {
    this.initForm();
    this.getResolved();
    this.getActions();
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(el => el['data'])).subscribe(res => {
      if (res) {
        this.items = res;
        this.itemsToShow = [{
          label: "Address",
          value: res.address
        }, {
          label: "Contact Person Phone",
          value: res.contactPersonPhone
        }, {
          label: "Downpayment Amount",
          value: res.downpaymentAmount
        }, {
          label: "Fahes Receipt No",
          value: res.fahesReceiptNo
        }, {
          label: "Inspection Date",
          value: res.inspectionDate,
          isDate: true
        }, {
          label: "Inspection Start Date",
          value: res.inspectionStartDate,
          isDate: true
        }, {
          label: "Inspection End Date",
          value: res.inspectionEndDate,
          isDate: true
        }, {
          label: "Gate Pass Flag",
          value: res.gatepassFlag,
          isBool: true
        }, {
          label: "Inspection Duration",
          value: res.inspectionDuration
        }, {
          label: "No. Of Vehicle",
          value: res.noOfVehicle
        }, {
          label: "Owner Name",
          value: res.ownerName
        }, {
          label: "PID No",
          value: res.pidNo
        }, {
          label: "Remaining Balance",
          value: res.remainingBalance
        }, {
          label: "Remarks",
          value: res.remarks
        }, {
          label: "Secondry Phone No",
          value: res.secondryPhoneNo
        }, {
          label: "Traveling Time",
          value: res.travelingTime
        }];
      }
      this.form.controls['requestId'].patchValue(res.requestId);
    });
    this.subscription.add(sub);
    const paramsSub = this._route.queryParamMap.subscribe(x => this.form.controls['transId'].patchValue(+x.get('transId')));
    this.subscription.add(paramsSub);
  }
  getActions() {
    this._lookups.getLookupValuesByCode(58).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(x => x.items)).subscribe(res => this.actions = res);
  }
  initForm() {
    this.form = this._fb.group({
      transId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      requestId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      actionType: [null],
      userRemarks: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }
  submit(action) {
    this.form.controls['actionType'].patchValue(action);
    if (this.form.invalid) return;
    this._service.submitMobileWorkflowNotification(this.form.getRawValue()).subscribe({
      next: res => {
        if (res) {
          this.notificationService.success("Success", "completed successfully", {
            timeOut: 3000,
            position: ['top', 'center']
          });
          this._service.sendClickEvent();
          this.location.back();
        }
      }
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function MobileWorkflowNotificationComponent_Factory(t) {
    return new (t || MobileWorkflowNotificationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_7__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_notification_center_service__WEBPACK_IMPORTED_MODULE_0__.NotificationCenterService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](angular2_notifications__WEBPACK_IMPORTED_MODULE_8__.NotificationsService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_1__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: MobileWorkflowNotificationComponent,
    selectors: [["app-mobile-workflow-notification"]],
    viewQuery: function MobileWorkflowNotificationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.notificationComponent = _t.first);
      }
    },
    decls: 11,
    vars: 3,
    consts: [[1, "row"], ["class", "col-lg-6 col-md-6", 4, "ngFor", "ngForOf"], [3, "formGroup"], [1, "w-100"], [1, "st-label"], ["formControlName", "userRemarks", "placeholder", "Write here...", 1, "txtarea", "w-100"], [1, "w-100", "end-btns"], ["type", "button", "class", "btn btn-outline-gray", 3, "disabled", "click", 4, "ngFor", "ngForOf"], [1, "col-lg-6", "col-md-6"], [1, "fw-bold"], [4, "ngIf"], ["src", "./assets/img/red-x-icon.svg", 4, "ngIf"], ["src", "./assets/img/check-circle.svg", 4, "ngIf"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/check-circle.svg"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "disabled", "click"]],
    template: function MobileWorkflowNotificationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, MobileWorkflowNotificationComponent_div_1_Template, 6, 4, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "form", 2)(3, "div", 3)(4, "label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5, " Remarks ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, " * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "textarea", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](10, MobileWorkflowNotificationComponent_button_10_Template, 2, 2, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.itemsToShow);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.form);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.actions);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 47596:
/*!*******************************************************************!*\
  !*** ./src/app/modules/mobile-workflow/mobile-workflow.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MobileWorkflowModule": () => (/* binding */ MobileWorkflowModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _mobile_workflow_base_mobile_workflow_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mobile-workflow-base/mobile-workflow-base.component */ 72202);
/* harmony import */ var _mobile_workflow_notification_mobile_workflow_notification_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mobile-workflow-notification/mobile-workflow-notification.component */ 522);
/* harmony import */ var src_app_core_resolver_get_mobile_workflow_resolver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/resolver/get-mobile-workflow.resolver */ 93739);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);









const routes = [{
  path: '',
  component: _mobile_workflow_base_mobile_workflow_base_component__WEBPACK_IMPORTED_MODULE_0__.MobileWorkflowBaseComponent,
  children: [{
    path: '',
    component: _mobile_workflow_notification_mobile_workflow_notification_component__WEBPACK_IMPORTED_MODULE_1__.MobileWorkflowNotificationComponent,
    resolve: {
      data: src_app_core_resolver_get_mobile_workflow_resolver__WEBPACK_IMPORTED_MODULE_2__.GetMobileWorkflowResolver
    }
  }]
}];
class MobileWorkflowModule {
  static #_ = this.ɵfac = function MobileWorkflowModule_Factory(t) {
    return new (t || MobileWorkflowModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: MobileWorkflowModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](MobileWorkflowModule, {
    declarations: [_mobile_workflow_base_mobile_workflow_base_component__WEBPACK_IMPORTED_MODULE_0__.MobileWorkflowBaseComponent, _mobile_workflow_notification_mobile_workflow_notification_component__WEBPACK_IMPORTED_MODULE_1__.MobileWorkflowNotificationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_3__.SharedModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=596.62ff67f51dcd696c.js.map