"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[482],{

/***/ 1485:
/*!***********************************************************************!*\
  !*** ./src/app/core/models/adminstration/SystemBlacklistOperation.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BlackListEntryType": () => (/* binding */ BlackListEntryType),
/* harmony export */   "SystemBlacklistOperation": () => (/* binding */ SystemBlacklistOperation)
/* harmony export */ });
class SystemBlacklistOperation {}
var BlackListEntryType;
(function (BlackListEntryType) {
  BlackListEntryType[BlackListEntryType["Customer"] = 1] = "Customer";
  BlackListEntryType[BlackListEntryType["Vehicle"] = 2] = "Vehicle";
  BlackListEntryType[BlackListEntryType["InspectionReport"] = 3] = "InspectionReport";
})(BlackListEntryType || (BlackListEntryType = {}));

/***/ }),

/***/ 5716:
/*!***************************************************************************!*\
  !*** ./src/app/core/models/application-admin/searchRegisterVehicleDto.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "searchRegisterVehicleDto": () => (/* binding */ searchRegisterVehicleDto)
/* harmony export */ });
class searchRegisterVehicleDto {
  constructor() {
    this.pageNumber = 1;
  }
}

/***/ }),

/***/ 50737:
/*!**************************************************************************!*\
  !*** ./src/app/core/models/visual-defects/defect-comment-request-dto.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectCommentRequestDto": () => (/* binding */ DefectCommentRequestDto)
/* harmony export */ });
class DefectCommentRequestDto {
  constructor() {
    this.recent = 10;
  }
}

/***/ }),

/***/ 53805:
/*!*******************************************************************!*\
  !*** ./src/app/core/utilities/enums/system-lookup-value-codes.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemLookupValueCodes": () => (/* binding */ SystemLookupValueCodes)
/* harmony export */ });
var SystemLookupValueCodes;
(function (SystemLookupValueCodes) {
  //Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["Inspection"] = 1] = "Inspection";
  SystemLookupValueCodes[SystemLookupValueCodes["VINStamping"] = 2] = "VINStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["TankerCertificate"] = 3] = "TankerCertificate";
  SystemLookupValueCodes[SystemLookupValueCodes["Exempted"] = 4] = "Exempted";
  SystemLookupValueCodes[SystemLookupValueCodes["MobileInspection"] = 4] = "MobileInspection";
  //Registration Resource :
  SystemLookupValueCodes[SystemLookupValueCodes["MoblieApplication"] = 1] = "MoblieApplication";
  SystemLookupValueCodes[SystemLookupValueCodes["Booth"] = 2] = "Booth";
  SystemLookupValueCodes[SystemLookupValueCodes["BackOffice"] = 3] = "BackOffice";
  SystemLookupValueCodes[SystemLookupValueCodes["SupportDocuments"] = 1] = "SupportDocuments";
  SystemLookupValueCodes[SystemLookupValueCodes["InspectionImages"] = 2] = "InspectionImages";
  // Vin Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["NewStamping"] = 1] = "NewStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["ReStamping"] = 2] = "ReStamping";
})(SystemLookupValueCodes || (SystemLookupValueCodes = {}));

/***/ }),

/***/ 53482:
/*!*******************************************************!*\
  !*** ./src/app/modules/app-admin/app-admin.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppAdminModule": () => (/* binding */ AppAdminModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _app_administrator_app_administrator_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-administrator/app-administrator.component */ 20473);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./component/data-table/data-table.component */ 42797);
/* harmony import */ var _app_admin_app_administrator_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../app-admin/app-administrator/station-operation/station-operation.component */ 75842);
/* harmony import */ var _app_administrator_service_operation_service_operation_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-administrator/service-operation/service-operation.component */ 18259);
/* harmony import */ var _app_administrator_station_services_station_services_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app-administrator/station-services/station-services.component */ 51044);
/* harmony import */ var _app_administrator_feesmanagement_feesmanagement_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-administrator/feesmanagement/feesmanagement.component */ 82668);
/* harmony import */ var _app_administrator_feesoperation_feesoperation_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-administrator/feesoperation/feesoperation.component */ 47246);
/* harmony import */ var _app_administrator_defects_defects_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-administrator/defects/defects.component */ 6102);
/* harmony import */ var _app_administrator_defects_operation_defects_operation_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app-administrator/defects-operation/defects-operation.component */ 57117);
/* harmony import */ var _app_administrator_waqod_vehicle_waqod_vehicle_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./app-administrator/waqod-vehicle/waqod-vehicle.component */ 47587);
/* harmony import */ var _app_administrator_waqod_details_operation_waqod_details_operation_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app-administrator/waqod-details-operation/waqod-details-operation.component */ 93254);
/* harmony import */ var _app_administrator_vehicl_registeration_view_vehicl_registeration_view_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./app-administrator/vehicl-registeration-view/vehicl-registeration-view.component */ 78998);
/* harmony import */ var _app_administrator_terms_condition_terms_condition_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./app-administrator/terms-condition/terms-condition.component */ 92854);
/* harmony import */ var _app_administrator_delegation_delegation_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./app-administrator/delegation/delegation.component */ 75461);
/* harmony import */ var _app_administrator_car_accessories_car_accessories_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./app-administrator/car-accessories/car-accessories.component */ 12153);
/* harmony import */ var _app_administrator_tems_condition_form_tems_condition_form_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./app-administrator/tems-condition-form/tems-condition-form.component */ 83489);
/* harmony import */ var _app_administrator_system_blacklist_system_blacklist_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./app-administrator/system-blacklist/system-blacklist.component */ 12820);
/* harmony import */ var _app_administrator_system_blacklist_system_blacklist_operation_system_blacklist_operation_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./app-administrator/system-blacklist/system-blacklist-operation/system-blacklist-operation.component */ 55286);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/core */ 22560);
























const routes = [{
  path: 'station',
  component: _app_administrator_app_administrator_component__WEBPACK_IMPORTED_MODULE_0__.AppAdministratorComponent
}, {
  path: 'stations/edit/:stationId',
  component: _app_admin_app_administrator_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_3__.StationOperationComponent
}, {
  path: 'stations/new',
  component: _app_admin_app_administrator_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_3__.StationOperationComponent
}, {
  path: 'station-services',
  component: _app_administrator_station_services_station_services_component__WEBPACK_IMPORTED_MODULE_5__.StationServicesComponent
}, {
  path: 'service',
  component: _app_administrator_service_operation_service_operation_component__WEBPACK_IMPORTED_MODULE_4__.ServiceOperationComponent
}, {
  path: 'service/new',
  component: _app_administrator_service_operation_service_operation_component__WEBPACK_IMPORTED_MODULE_4__.ServiceOperationComponent
}, {
  path: 'service/edit/:serviceId',
  component: _app_administrator_service_operation_service_operation_component__WEBPACK_IMPORTED_MODULE_4__.ServiceOperationComponent
}, {
  path: 'fees',
  component: _app_administrator_feesmanagement_feesmanagement_component__WEBPACK_IMPORTED_MODULE_6__.FeesmanagementComponent
}, {
  path: 'fees-operation/:serviceId',
  component: _app_administrator_feesoperation_feesoperation_component__WEBPACK_IMPORTED_MODULE_7__.FeesoperationComponent
}, {
  path: 'fees-operation',
  component: _app_administrator_feesoperation_feesoperation_component__WEBPACK_IMPORTED_MODULE_7__.FeesoperationComponent
}, {
  path: 'defects',
  component: _app_administrator_defects_defects_component__WEBPACK_IMPORTED_MODULE_8__.DefectsComponent
}, {
  path: 'defects-operation/edit/:defCommentId',
  component: _app_administrator_defects_operation_defects_operation_component__WEBPACK_IMPORTED_MODULE_9__.DefectsOperationComponent
}, {
  path: 'defects-operation/new/:mainDef/:subDef',
  component: _app_administrator_defects_operation_defects_operation_component__WEBPACK_IMPORTED_MODULE_9__.DefectsOperationComponent
}, {
  path: 'waqod-vehicle',
  component: _app_administrator_waqod_vehicle_waqod_vehicle_component__WEBPACK_IMPORTED_MODULE_10__.WaqodVehicleComponent
}, {
  path: 'waqod-vehicle/new',
  component: _app_administrator_waqod_details_operation_waqod_details_operation_component__WEBPACK_IMPORTED_MODULE_11__.WaqodDetailsOperationComponent
}, {
  path: 'waqod-vehicle/edit/:vinNo',
  component: _app_administrator_waqod_details_operation_waqod_details_operation_component__WEBPACK_IMPORTED_MODULE_11__.WaqodDetailsOperationComponent
}, {
  path: 'vehicle-registered-view',
  component: _app_administrator_vehicl_registeration_view_vehicl_registeration_view_component__WEBPACK_IMPORTED_MODULE_12__.VehiclRegisterationViewComponent
}, {
  path: 'terms-condition',
  component: _app_administrator_terms_condition_terms_condition_component__WEBPACK_IMPORTED_MODULE_13__.TermsConditionComponent
}, {
  path: 'delegation',
  component: _app_administrator_delegation_delegation_component__WEBPACK_IMPORTED_MODULE_14__.DelegationComponent
}, {
  path: 'terms-condition/new',
  component: _app_administrator_tems_condition_form_tems_condition_form_component__WEBPACK_IMPORTED_MODULE_16__.TermsConditionFormComponent
}, {
  path: 'terms-condition/edit/:termId',
  component: _app_administrator_tems_condition_form_tems_condition_form_component__WEBPACK_IMPORTED_MODULE_16__.TermsConditionFormComponent
}, {
  path: 'car-accessories',
  component: _app_administrator_car_accessories_car_accessories_component__WEBPACK_IMPORTED_MODULE_15__.CarAccessoriesComponent
},
//System-blacklist
{
  path: 'system-blacklist',
  component: _app_administrator_system_blacklist_system_blacklist_component__WEBPACK_IMPORTED_MODULE_17__.SystemBlacklistComponent
}, {
  path: 'system-blacklist/new',
  component: _app_administrator_system_blacklist_system_blacklist_operation_system_blacklist_operation_component__WEBPACK_IMPORTED_MODULE_18__.SystemBlacklistOperationComponent
}, {
  path: 'system-blacklist/:selectionId',
  component: _app_administrator_system_blacklist_system_blacklist_component__WEBPACK_IMPORTED_MODULE_17__.SystemBlacklistComponent
}, {
  path: 'system-blacklist/edit/:entryId',
  component: _app_administrator_system_blacklist_system_blacklist_operation_system_blacklist_operation_component__WEBPACK_IMPORTED_MODULE_18__.SystemBlacklistOperationComponent
}];
class AppAdminModule {
  static #_ = this.ɵfac = function AppAdminModule_Factory(t) {
    return new (t || AppAdminModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineNgModule"]({
    type: AppAdminModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule.forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.ReactiveFormsModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_19__["ɵɵsetNgModuleScope"](AppAdminModule, {
    declarations: [_app_administrator_app_administrator_component__WEBPACK_IMPORTED_MODULE_0__.AppAdministratorComponent, _app_admin_app_administrator_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_3__.StationOperationComponent, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_2__.DataTableComponent, _app_administrator_service_operation_service_operation_component__WEBPACK_IMPORTED_MODULE_4__.ServiceOperationComponent, _app_administrator_station_services_station_services_component__WEBPACK_IMPORTED_MODULE_5__.StationServicesComponent, _app_administrator_station_services_station_services_component__WEBPACK_IMPORTED_MODULE_5__.StationServicesComponent, _app_administrator_feesmanagement_feesmanagement_component__WEBPACK_IMPORTED_MODULE_6__.FeesmanagementComponent, _app_administrator_feesoperation_feesoperation_component__WEBPACK_IMPORTED_MODULE_7__.FeesoperationComponent, _app_administrator_defects_defects_component__WEBPACK_IMPORTED_MODULE_8__.DefectsComponent, _app_administrator_defects_operation_defects_operation_component__WEBPACK_IMPORTED_MODULE_9__.DefectsOperationComponent, _app_administrator_waqod_vehicle_waqod_vehicle_component__WEBPACK_IMPORTED_MODULE_10__.WaqodVehicleComponent, _app_administrator_waqod_details_operation_waqod_details_operation_component__WEBPACK_IMPORTED_MODULE_11__.WaqodDetailsOperationComponent, _app_administrator_vehicl_registeration_view_vehicl_registeration_view_component__WEBPACK_IMPORTED_MODULE_12__.VehiclRegisterationViewComponent, _app_administrator_terms_condition_terms_condition_component__WEBPACK_IMPORTED_MODULE_13__.TermsConditionComponent, _app_administrator_delegation_delegation_component__WEBPACK_IMPORTED_MODULE_14__.DelegationComponent, _app_administrator_car_accessories_car_accessories_component__WEBPACK_IMPORTED_MODULE_15__.CarAccessoriesComponent, _app_administrator_tems_condition_form_tems_condition_form_component__WEBPACK_IMPORTED_MODULE_16__.TermsConditionFormComponent, _app_administrator_system_blacklist_system_blacklist_component__WEBPACK_IMPORTED_MODULE_17__.SystemBlacklistComponent, _app_administrator_system_blacklist_system_blacklist_operation_system_blacklist_operation_component__WEBPACK_IMPORTED_MODULE_18__.SystemBlacklistOperationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_20__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_21__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.ReactiveFormsModule]
  });
})();

/***/ }),

/***/ 20473:
/*!************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/app-administrator.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppAdministratorComponent": () => (/* binding */ AppAdministratorComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../component/data-table/data-table.component */ 42797);









const _c0 = ["saveStationModalButton"];
const _c1 = ["CheckStationActiveDeactiveModalBtn"];
const _c2 = ["CheckModelActiveDeactiveModalBtn"];
class AppAdministratorComponent {
  constructor(systemAdmin, router, sideNav) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.sideNav = sideNav;
    this.stations = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.stationHeaders = [{
      JsonPropName: 'stationNameEn',
      showName: 'Station Name'
    },
    //{ JsonPropName: 'descriptionEn', showName: 'Description' },
    {
      JsonPropName: 'classificationDescriptionEn',
      showName: 'Classification'
    }, {
      JsonPropName: 'reservationTypeEn',
      showName: 'Reservation Type'
    }, {
      JsonPropName: 'addressEn',
      showName: 'Address'
    }, {
      JsonPropName: 'AreaEn',
      showName: 'Area'
    }, {
      JsonPropName: 'LocationEn',
      showName: 'Location'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 93);
    this.stations.data = [];
    this.stationsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
    this.bindChange();
    this.loadStations();
  }
  loadStations() {
    this.systemAdmin.getStations({}).subscribe(result => {
      this.stations.data = result.items;
      this.stations.data.sort();
      if (this.stations.data.length > 0) this.onStationSelection(this.stations.data[this.stations.data.length - 1]);
    });
  }
  bindChange() {
    this.stationsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchStations(change);
    });
  }
  viewSelectedStation(item) {
    this.router.navigate(['app-admin/stations/view', item.lkCode]);
  }
  onModelStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "model");
    this.CheckModelActiveDeactiveModalBtn.nativeElement.click();
  }
  onStationStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "station");
    this.CheckStationActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmStationActiveDeactiveCahnge() {
    let ManufacOperation; //= new StationOperation(); 
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.stationOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveStationModalButton.nativeElement.click();
      }
    });
  }
  onCancelStationActiveDeactiveChange() {
    this.loadStations();
  }
  updateSelectedStation(item) {
    this.router.navigate(['app-admin/stations/edit', item.stationId]);
  }
  searchStations(searchValue) {
    this.systemAdmin.getStations({
      containsText: searchValue
    }).subscribe(result => {
      this.stations.data = result.items;
    });
  }
  AddNewStation() {
    this.router.navigate(['app-admin/stations/new']);
  }
  onStationSelection(item) {
    this.selectedStationId = item.stationsId;
  }
  setActiveTab(tab) {
    this.activeTab = tab;
  }
  static #_ = this.ɵfac = function AppAdministratorComponent_Factory(t) {
    return new (t || AppAdministratorComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: AppAdministratorComponent,
    selectors: [["app-app-administrator"]],
    viewQuery: function AppAdministratorComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveStationModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckStationActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckModelActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 63,
    vars: 7,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "viewItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveStationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#stationConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckStationActiveDeactiveModalBtn", ""], ["id", "stationConfirmationModal", "data-bs-backdrop", "static", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"]],
    template: function AppAdministratorComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13, " Stations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function AppAdministratorComponent_Template_button_click_19_listener() {
          return ctx.AddNewStation();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, " Add Station ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 13)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Station Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](31, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "app-data-table", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function AppAdministratorComponent_Template_app_data_table_updateItemEvent_32_listener($event) {
          return ctx.updateSelectedStation($event);
        })("viewItemEvent", function AppAdministratorComponent_Template_app_data_table_viewItemEvent_32_listener($event) {
          return ctx.viewSelectedStation($event);
        })("selectItemEvent", function AppAdministratorComponent_Template_app_data_table_selectItemEvent_32_listener($event) {
          return ctx.onStationSelection($event);
        })("checkboxEvent", function AppAdministratorComponent_Template_app_data_table_checkboxEvent_32_listener($event) {
          return ctx.onStationStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](33, "button", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](35, "div", 23)(36, "div", 24)(37, "div", 25)(38, "div", 26)(39, "h1", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](40, "img", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](42, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](43, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](45, "div", 32)(46, "div", 33)(47, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](48, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "div", 34)(50, "div", 1)(51, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](52, "img", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](53, "div", 3)(54, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](56);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](57, "br")(58, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function AppAdministratorComponent_Template_button_click_59_listener() {
          return ctx.onCancelStationActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](60, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](61, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function AppAdministratorComponent_Template_button_click_61_listener() {
          return ctx.onConfirmStationActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](62, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.stationsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.stationHeaders)("tblValues", ctx.stations)("isDeleteOperationEnabled", false)("selectedRow", ctx.stations.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__.DataTableComponent],
    styles: [".inspection-tab-menu[_ngcontent-%COMP%] {\r\n    width: 1230px;\r\n    margin-left: 15px;\r\n    margin-top: 1%;\r\n}\r\n\r\n@media (max-width: 768px) {\r\n    .inspection-tab-menu[_ngcontent-%COMP%] {\r\n        margin-left: 0;\r\n        padding: 0 15px;\r\n    }\r\n}\r\n\r\n\r\n\r\n.outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n#stationConfirmationModal[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvYXBwLWFkbWluaXN0cmF0b3IuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGFBQWE7SUFDYixpQkFBaUI7SUFDakIsY0FBYztBQUNsQjs7QUFFQTtJQUNJO1FBQ0ksY0FBYztRQUNkLGVBQWU7SUFDbkI7QUFDSjs7OztBQUlBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0QiIsInNvdXJjZXNDb250ZW50IjpbIi5pbnNwZWN0aW9uLXRhYi1tZW51IHtcclxuICAgIHdpZHRoOiAxMjMwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICAgIG1hcmdpbi10b3A6IDElO1xyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogNzY4cHgpIHtcclxuICAgIC5pbnNwZWN0aW9uLXRhYi1tZW51IHtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgICAgICBwYWRkaW5nOiAwIDE1cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5cclxuLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufVxyXG5cclxuI3N0YXRpb25Db25maXJtYXRpb25Nb2RhbCB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 12153:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/car-accessories/car-accessories.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CarAccessoriesComponent": () => (/* binding */ CarAccessoriesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular2-notifications */ 55609);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);










function CarAccessoriesComponent_div_32_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function CarAccessoriesComponent_div_32_div_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function CarAccessoriesComponent_div_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 8)(7, "div", 9)(8, "div", 10)(9, "form", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](10, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div", 12)(12, "div", 13)(13, "label", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](14, "Item Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](15, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, CarAccessoriesComponent_div_32_div_16_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "div", 13)(18, "label", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](19, "Item Price");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](20, "input", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](21, CarAccessoriesComponent_div_32_div_21_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "div", 13)(23, "div", 29)(24, "button", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function CarAccessoriesComponent_div_32_Template_button_click_24_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      $event.preventDefault();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r3.submitUpdates());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25, "Save");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](26, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r0.updatedPriceForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("hidden", ctx_r0.isHidden);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r0.updatedPriceForm.get("itemName").dirty || ctx_r0.updatedPriceForm.get("itemName").touched) && ctx_r0.updatedPriceForm.get("itemName").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", (ctx_r0.updatedPriceForm.get("itemPrice").dirty || ctx_r0.updatedPriceForm.get("itemPrice").touched) && ctx_r0.updatedPriceForm.get("itemPrice").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r0.updatedPriceForm.valid);
  }
}
class CarAccessoriesComponent {
  constructor(appAdmin, fb, sideNav, notificationService) {
    this.appAdmin = appAdmin;
    this.fb = fb;
    this.sideNav = sideNav;
    this.notificationService = notificationService;
    this.accessoriesTD = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.isHidden = true;
    this.accessoriesTDHeader = [{
      JsonPropName: 'itemId',
      showName: 'Item ID'
    }, {
      JsonPropName: 'itemName',
      showName: 'Item Name'
    }, {
      JsonPropName: 'itemDescription',
      showName: 'Item Description'
    }, {
      JsonPropName: 'itemPrice',
      showName: 'Item Price'
    }, {
      JsonPropName: 'uomName',
      showName: 'UOM Name'
    }, {
      JsonPropName: 'uomDisplayName',
      showName: 'UOM Display Name'
    }
    // { JsonPropName: 'updatedDate', showName: 'Updated Date' },
    //{ JsonPropName: 'updatedBy', showName: 'Updated By' },
    ];
  }

  ngOnInit() {
    this.sideNav.setActiveEnt(10, 109);
    this.userId = parseInt(localStorage.getItem('userId'));
    this.initForm();
    // this.bindChange();
    this.loadItems();
  }
  loadItems() {
    this.appAdmin.GetcarAccessories({}).subscribe(result => {
      this.accessoriesTD.data = result.items;
    });
  }
  bindChange() {
    let request = this.carSearchForm.value;
    request.itemId = parseInt(this.carSearchForm.get("itemId").value) > 0 ? this.carSearchForm.get("itemId").value : null;
    this.appAdmin.GetcarAccessories(request).subscribe(result => {
      this.accessoriesTD.data = result.items;
    });
  }
  initForm() {
    this.carSearchForm = this.fb.group({
      itemId: null,
      itemName: null,
      status: null
    });
    this.updatedPriceForm = this.fb.group({
      itemId: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      itemName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      itemPrice: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
  }
  onRowSelected(item) {
    this.updatedPriceForm.patchValue(item);
    this.selectedItem = item;
  }
  submitUpdates() {
    let request = this.selectedItem;
    request.itemName = this.updatedPriceForm.get("itemName").value;
    request.itemPrice = this.updatedPriceForm.get("itemPrice").value;
    request.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    this.appAdmin.CarAccessoriesDML(request).subscribe(result => {
      if (result.items === true) {
        this.selectedItem = new Object();
        let obj = this.accessoriesTD.data.find(x => x.itemId === request.itemId);
        obj.itemName = request.itemName;
        obj.itemPrice = request.itemPrice;
        this.notificationService.success("Success", "Operation completed successfully", {
          timeOut: 3000,
          position: ['top', 'center']
        });
      }
    });
  }
  static #_ = this.ɵfac = function CarAccessoriesComponent_Factory(t) {
    return new (t || CarAccessoriesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](angular2_notifications__WEBPACK_IMPORTED_MODULE_7__.NotificationsService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: CarAccessoriesComponent,
    selectors: [["app-car-accessories"]],
    decls: 33,
    vars: 8,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-4", "col-lg-4"], ["for", "itemId"], ["type", "number", "id", "itemId", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "itemId", 1, "form-control", 3, "ngModelChange"], ["for", "itemName"], ["type", "text", "id", "itemName", "formControlName", "itemName", 1, "form-control", 3, "ngModelChange"], ["for", "status"], ["type", "date", "id", "status", "formControlName", "status", 1, "form-control", 3, "ngModelChange"], ["value", "1"], ["value", "2"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "backendOrdering", "backendPagination", "updateItemEvent", "paginationEvent"], ["class", "row", 4, "ngIf"], ["type", "text", "formControlName", "itemId", 3, "hidden"], ["type", "text", "id", "itemName", "readonly", "", "formControlName", "itemName", 1, "form-control"], ["class", "validation-filed", 4, "ngIf"], ["for", "itemPrice"], ["type", "text", "id", "itemPrice", "formControlName", "itemPrice", 1, "form-control"], [1, "row", "endBt"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "validation-filed"]],
    template: function CarAccessoriesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, " Car Accessories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "form", 11)(13, "div", 12)(14, "div", 13)(15, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](16, "Item ID");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function CarAccessoriesComponent_Template_input_ngModelChange_17_listener() {
          return ctx.bindChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 13)(19, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, "Item Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function CarAccessoriesComponent_Template_input_ngModelChange_21_listener() {
          return ctx.bindChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](22, "div", 13)(23, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24, "Status");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "select", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function CarAccessoriesComponent_Template_select_ngModelChange_25_listener() {
          return ctx.bindChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](27, " Active");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](29, " InActive");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](30, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "app-data-table", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("updateItemEvent", function CarAccessoriesComponent_Template_app_data_table_updateItemEvent_31_listener($event) {
          return ctx.onRowSelected($event);
        })("paginationEvent", function CarAccessoriesComponent_Template_app_data_table_paginationEvent_31_listener() {
          return false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](32, CarAccessoriesComponent_div_32_Template, 27, 5, "div", 23);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.carSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tblHeaders", ctx.accessoriesTDHeader)("tblValues", ctx.accessoriesTD)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", true)("backendOrdering", false)("backendPagination", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.selectedItem);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__.DataTableComponent],
    styles: [".endBt[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvY2FyLWFjY2Vzc29yaWVzL2Nhci1hY2Nlc3Nvcmllcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0FBQ3BCIiwic291cmNlc0NvbnRlbnQiOlsiLmVuZEJ0IHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 57117:
/*!******************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/defects-operation/defects-operation.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectsOperationComponent": () => (/* binding */ DefectsOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);











function DefectsOperationComponent_span_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"](" [", ctx_r0.mainDefId, " - ", ctx_r0.subDefId, "] ");
  }
}
function DefectsOperationComponent_option_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cm_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", cm_r6.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", cm_r6.lkValueEname, " ");
  }
}
function DefectsOperationComponent_option_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cm_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", cm_r7.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", cm_r7.lkValueEname, " ");
  }
}
function DefectsOperationComponent_option_68_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cm_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", cm_r8.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", cm_r8.lkValueEname, " ");
  }
}
function DefectsOperationComponent_div_198_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Are you sure you want to update this Defect ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function DefectsOperationComponent_div_199_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Are you sure you want to add this Defect ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
class DefectsOperationComponent {
  constructor(route, appAdmin, fb, lookupService, router, defectServ, sideNav) {
    this.route = route;
    this.appAdmin = appAdmin;
    this.fb = fb;
    this.lookupService = lookupService;
    this.router = router;
    this.defectServ = defectServ;
    this.sideNav = sideNav;
    this.commentTypeList = [];
    this.mainDefList = [];
    this.axleNb = 0;
    this.locNb = 0;
    this.locationValueItems = {
      axle1: 1,
      axle2: 2,
      axle3: 4,
      axle4: 8,
      axle5: 16,
      axle6: 32,
      axle7: 64,
      axle8: 128,
      axle9: 256,
      fl: 512,
      fc: 1024,
      fr: 2048,
      cl: 4096,
      cc: 8192,
      cr: 16384,
      rl: 32768,
      rr: 65536,
      rc: 131072
    };
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 104);
    this.userId = parseInt(localStorage.getItem('userId'));
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.evaluationList).subscribe(data => {
      this.commentTypeList = data.items;
    });
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.deviceMode).subscribe(data => {
      this.modeList = data.items;
    });
    this.checkViewInsertUpdateMode();
    this.createDefectForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.view) this.route.params.subscribe(params => {
      this.defCommentId = +params['defCommentId'];
      console.log(this.defCommentId);
      if (this.defCommentId > 0) {
        this.loadDefects();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
      this.updateDef = true;
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert) {
      this.title = "New";
      this.action = "Created";
      this.updateDef = false;
      this.route.params.subscribe(params => {
        this.mainDefId = +params['mainDef'];
        this.subDefId = +params['subDef'];
      });
    }
  }
  loadDefects() {
    this.appAdmin.getDefectComments({
      defCommentId: this.defCommentId
    }).subscribe(response => {
      this.defectId = response.items[0].defectId;
      this.defectForm.patchValue(response.items[0]);
      this.selectedDefectLocation = response.items[0].selectedDefectLocation;
      // this.locNb = response.items[0].location;
      // this.axleNb = response.items[0].axle;
      const selectedLocations = this.selectedDefectLocation.split(",");
      this.locationList = {
        axle1: selectedLocations.includes('Axle1'),
        axle2: selectedLocations.includes('Axle2'),
        axle3: selectedLocations.includes('Axle3'),
        axle4: selectedLocations.includes('Axle4'),
        axle5: selectedLocations.includes('Axle5'),
        axle6: selectedLocations.includes('Axle6'),
        axle7: selectedLocations.includes('Axle7'),
        axle8: selectedLocations.includes('Axle8'),
        axle9: selectedLocations.includes('Axle9'),
        fl: selectedLocations.includes('FL'),
        fc: selectedLocations.includes('FC'),
        fr: selectedLocations.includes('FR'),
        cr: selectedLocations.includes('CR'),
        cl: selectedLocations.includes('CL'),
        cc: selectedLocations.includes('C'),
        rr: selectedLocations.includes('RR'),
        rl: selectedLocations.includes('RL'),
        rc: selectedLocations.includes('RC')
      };
      this.initLocs = true;
      for (let loc in this.locationList) {
        switch (loc) {
          case 'axle1':
            this.locationList.axle1 ? this.onChangeAxle(this.locationValueItems.axle1, '') : null;
            break;
          case 'axle2':
            this.locationList.axle2 ? this.onChangeAxle(this.locationValueItems.axle2, '') : null;
            break;
          case 'axle3':
            this.locationList.axle3 ? this.onChangeAxle(this.locationValueItems.axle3, '') : null;
            break;
          case 'axle4':
            this.locationList.axle4 ? this.onChangeAxle(this.locationValueItems.axle4, '') : null;
            break;
          case 'axle5':
            this.locationList.axle5 ? this.onChangeAxle(this.locationValueItems.axle5, '') : null;
            break;
          case 'axle6':
            this.locationList.axle6 ? this.onChangeAxle(this.locationValueItems.axle6, '') : null;
            break;
          case 'axle7':
            this.locationList.axle7 ? this.onChangeAxle(this.locationValueItems.axle7, '') : null;
            break;
          case 'axle8':
            this.locationList.axle8 ? this.onChangeAxle(this.locationValueItems.axle8, '') : null;
            break;
          case 'axle9':
            this.locationList.axle9 ? this.onChangeAxle(this.locationValueItems.axle9, '') : null;
            break;
          case 'fl':
            this.locationList.fl ? this.onChangeLoc(this.locationValueItems.fl, '') : null;
            break;
          case 'fc':
            this.locationList.fc ? this.onChangeLoc(this.locationValueItems.fc, '') : null;
            break;
          case 'fr':
            this.locationList.fr ? this.onChangeLoc(this.locationValueItems.fr, '') : null;
            break;
          case 'cr':
            this.locationList.cr ? this.onChangeLoc(this.locationValueItems.cr, '') : null;
            break;
          case 'cl':
            this.locationList.cl ? this.onChangeLoc(this.locationValueItems.cl, '') : null;
            break;
          case 'cc':
            this.locationList.c ? this.onChangeLoc(this.locationValueItems.cc, '') : null;
            break;
          case 'rr':
            this.locationList.rr ? this.onChangeLoc(this.locationValueItems.rr, '') : null;
            break;
          case 'rl':
            this.locationList.rl ? this.onChangeLoc(this.locationValueItems.rl, '') : null;
            break;
          case 'rc':
            this.locationList.rc ? this.onChangeLoc(this.locationValueItems.rc, '') : null;
            break;
        }
      }
      this.initLocs = false;
      console.log(this.axleNb);
    });
  }
  createDefectForm() {
    this.defectForm = this.fb.group({
      defCommentCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      defCommentId: [null],
      subDefectId: [null],
      mainDefectsId: [null],
      descriptionEn: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      descriptionAr: [''],
      mode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      commentType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      deviceComment: [null],
      location: [null],
      isRemarkRequired: [null],
      axle: [null],
      status: [null],
      createdBy: [null],
      createdDate: [null],
      updatedBy: [null],
      updatedDate: [null],
      commentTypeAr: [null],
      commentTypeEn: [null],
      selectedDefectLocation: [null]
    });
  }
  saveDefectCmnt() {
    const saveDefCmnt = {
      operationType: this.updateDef ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert,
      defCommentCode: this.defectForm.get('defCommentCode').value,
      defCommentId: this.defectForm.get('defCommentId').value,
      subDefectId: this.updateDef ? this.defectForm.get('subDefectId').value : this.subDefId,
      mainDefectsId: this.updateDef ? this.defectForm.get('mainDefectsId').value : this.mainDefId,
      descriptionEn: this.defectForm.get('descriptionEn').value,
      descriptionAr: this.defectForm.get('descriptionAr').value,
      mode: parseInt(this.defectForm.get('mode').value),
      commentType: parseInt(this.defectForm.get('commentType').value),
      deviceComment: parseInt(this.defectForm.get('deviceComment').value),
      location: this.locNb,
      isRemarkRequired: this.defectForm.get('isRemarkRequired').value ? this.defectForm.get('isRemarkRequired').value : false,
      axle: this.axleNb,
      status: 1,
      createdBy: this.userId,
      createDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdmin.defectCommentsOperation(saveDefCmnt).subscribe(response => {
      if (this.updateDef) {
        this.loadDefects();
      } else {
        this.backToDefects();
      }
    });
  }
  onChangeAxle(value, event) {
    const isChecked = this.initLocs ? true : event.target.checked;
    if (isChecked) {
      this.axleNb += value;
    } else {
      this.axleNb -= value;
    }
    console.log(this.axleNb);
  }
  onChangeLoc(value, event) {
    const isChecked = this.initLocs ? true : event.target.checked;
    console.log(this.initLocs);
    if (isChecked) {
      this.locNb += value;
    } else {
      this.locNb -= value;
    }
    console.log(this.locNb);
  }
  backToDefects() {
    this.router.navigate(['app-admin/defects']);
  }
  static #_ = this.ɵfac = function DefectsOperationComponent_Factory(t) {
    return new (t || DefectsOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_4__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: DefectsOperationComponent,
    selectors: [["app-defects-operation"]],
    decls: 204,
    vars: 27,
    consts: [[1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], [3, "formGroup"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "spt", 4, "ngIf"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-lg-5"], [1, "row"], [1, "col-12"], [1, "st-label"], ["type", "text", "formControlName", "defCommentCode", 1, "form-control"], [1, "row", "justify-content-between"], ["type", "text", "formControlName", "descriptionEn", 1, "form-control"], ["type", "text", "formControlName", "descriptionAr", 1, "form-control"], [1, "col-lg-12"], ["formControlName", "commentType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["formControlName", "deviceComment", 1, "form-control"], ["id", "rem", 1, "col-lg-12"], ["formControlName", "mode", 1, "form-control"], [1, "col-lg-5", 2, "margin-left", "185px"], ["type", "checkbox", "formControlName", "isRemarkRequired", "id", "rmch", 1, "form-check-input", "carchkbx"], ["id", "loca", 1, "col-lg-5"], [1, "card-header"], [1, "card-body"], ["id", "chRow", 1, "row"], [1, "col-4"], [1, "form-check"], ["type", "checkbox", "id", "axle1", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle1", 1, "form-check-label"], ["type", "checkbox", "id", "axle2", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle2", 1, "form-check-label"], ["type", "checkbox", "id", "axle3", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle3", 1, "form-check-label"], ["type", "checkbox", "id", "axle4", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle4", 1, "form-check-label"], ["type", "checkbox", "id", "axle5", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle5", 1, "form-check-label"], ["type", "checkbox", "id", "axle6", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle6", 1, "form-check-label"], ["type", "checkbox", "id", "axle7", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle7", 1, "form-check-label"], ["type", "checkbox", "id", "axle8", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle8", 1, "form-check-label"], ["type", "checkbox", "id", "axle9", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "axle9", 1, "form-check-label"], ["type", "checkbox", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "fl", 1, "form-check-label"], ["type", "checkbox", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "fc", 1, "form-check-label"], ["type", "checkbox", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "fr", 1, "form-check-label"], ["type", "checkbox", "id", "cl", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "cl", 1, "form-check-label"], ["type", "checkbox", "id", "c", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "c", 1, "form-check-label"], ["type", "checkbox", "id", "cr", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "cr", 1, "form-check-label"], ["type", "checkbox", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "rl", 1, "form-check-label"], ["type", "checkbox", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "rc", 1, "form-check-label"], ["type", "checkbox", "id", "rr", 1, "form-check-input", "carchkbx", 3, "checked", "change"], ["for", "rr", 1, "form-check-label"], [1, "end-btns"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmDef", 1, "btn", "btn-orange", 3, "disabled"], ["id", "confirmDef", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], [1, "modal-body"], [4, "ngIf"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"], ["id", "spt"], [3, "value"]],
    template: function DefectsOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "html");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "body")(3, "div", 0)(4, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DefectsOperationComponent_Template_a_click_4_listener() {
          return ctx.backToDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "form", 3)(8, "div", 4)(9, "div", 5)(10, "div", 6)(11, "h2", 7)(12, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](14, DefectsOperationComponent_span_14_Template, 2, 2, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "div", 10)(16, "div", 11)(17, "div", 12)(18, "div", 13)(19, "div", 14)(20, "div", 15)(21, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](22, " Defect Comment Code * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](24, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "div", 18)(26, "div", 13)(27, "div", 14)(28, "div", 15)(29, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](30, " Defect Description En * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](32, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "div", 13)(34, "div", 14)(35, "div", 15)(36, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](37, " Defect Description Ar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](38, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](39, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "div", 18)(41, "div", 13)(42, "div", 14)(43, "div", 21)(44, "div", 15)(45, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](46, " Comment Type * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](47, "div", 15)(48, "select", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](49, DefectsOperationComponent_option_49_Template, 2, 2, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](50, "div", 13)(51, "div", 14)(52, "div", 21)(53, "div", 15)(54, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](55, " Device Comment ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "div", 15)(57, "select", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](58, DefectsOperationComponent_option_58_Template, 2, 2, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "div", 12)(60, "div", 13)(61, "div", 14)(62, "div", 25)(63, "div", 15)(64, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](65, " Mode * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "div", 15)(67, "select", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](68, DefectsOperationComponent_option_68_Template, 2, 2, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](69, "div", 27)(70, "div", 14)(71, "div", 25)(72, "div", 15)(73, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](74, " Is Remark Required ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](75, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](76, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](77, "div", 18)(78, "div", 29)(79, "div", 14)(80, "div", 21)(81, "div", 4)(82, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](83, "Axle(s)");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](84, "div", 31)(85, "div", 32)(86, "div", 33)(87, "div", 34)(88, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_88_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle1, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](89, "label", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](90, " 1 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](91, "div", 33)(92, "div", 34)(93, "input", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_93_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle2, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](94, "label", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](95, " 2 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](96, "div", 33)(97, "div", 34)(98, "input", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_98_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle3, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](99, "label", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](100, " 3 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](101, "div", 32)(102, "div", 33)(103, "div", 34)(104, "input", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_104_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle4, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](105, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](106, " 4 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](107, "div", 33)(108, "div", 34)(109, "input", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_109_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle5, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](110, "label", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](111, " 5 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](112, "div", 33)(113, "div", 34)(114, "input", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_114_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle6, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](115, "label", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](116, " 6 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](117, "div", 32)(118, "div", 33)(119, "div", 34)(120, "input", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_120_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle7, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](121, "label", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](122, " 7 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](123, "div", 33)(124, "div", 34)(125, "input", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_125_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle8, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](126, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](127, " 8 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](128, "div", 33)(129, "div", 34)(130, "input", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_130_listener($event) {
          return ctx.onChangeAxle(ctx.locationValueItems.axle9, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](131, "label", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](132, " 9 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](133, "div", 29)(134, "div", 14)(135, "div", 21)(136, "div", 4)(137, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](138, "Location(s)");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](139, "div", 31)(140, "div", 32)(141, "div", 33)(142, "div", 34)(143, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_143_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.fl, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](144, "label", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](145, " FL ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](146, "div", 33)(147, "div", 34)(148, "input", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_148_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.fc, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](149, "label", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](150, " FC ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](151, "div", 33)(152, "div", 34)(153, "input", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_153_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.fr, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](154, "label", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](155, " FR ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](156, "div", 32)(157, "div", 33)(158, "div", 34)(159, "input", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_159_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.cl, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](160, "label", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](161, " CL ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](162, "div", 33)(163, "div", 34)(164, "input", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_164_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.cc, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](165, "label", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](166, " C ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](167, "div", 33)(168, "div", 34)(169, "input", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_169_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.cr, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](170, "label", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](171, " CR ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](172, "div", 32)(173, "div", 33)(174, "div", 34)(175, "input", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_175_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.rl, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](176, "label", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](177, " RL ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](178, "div", 33)(179, "div", 34)(180, "input", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_180_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.rc, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](181, "label", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](182, " RC ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](183, "div", 33)(184, "div", 34)(185, "input", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function DefectsOperationComponent_Template_input_change_185_listener($event) {
          return ctx.onChangeLoc(ctx.locationValueItems.rr, $event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](186, "label", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](187, " RR ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](188, "div", 71)(189, "button", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](190, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](191, "div", 73)(192, "div", 74)(193, "div", 75)(194, "div", 76)(195, "h1", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](196, " Confirmation ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](197, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](198, DefectsOperationComponent_div_198_Template, 2, 0, "div", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](199, DefectsOperationComponent_div_199_Template, 2, 0, "div", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](200, "button", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](201, "img", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](202, "button", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DefectsOperationComponent_Template_button_click_202_listener() {
          return ctx.saveDefectCmnt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](203, "img", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.defectForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.title, " Defect Comment ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx.updateDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.commentTypeList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.commentTypeList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.modeList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.axle9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.fl);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.fc);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.fr);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.cl);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.cc);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.cr);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.rl);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.rc);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("checked", ctx.locationList == null ? null : ctx.locationList.rr);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.defectForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.updateDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx.updateDef);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: ["#loca[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n    position: relative;\r\n}\r\n\r\n#chRow[_ngcontent-%COMP%] {\r\n    margin-top: 10px;\r\n}\r\n\r\n#rem[_ngcontent-%COMP%] {\r\n    margin-top: 10px;\r\n}\r\n\r\n#rmch[_ngcontent-%COMP%] {\r\n    margin-left: 10px;\r\n    margin-top: 10px;\r\n}\r\n\r\n#spt[_ngcontent-%COMP%] {\r\n    margin-left: 10px;\r\n    font-style: italic;\r\n    color: #F89828;\r\n}\r\n\r\n.carchkbx[_ngcontent-%COMP%] {\r\n    width: 1.5em;\r\n    height: 1.5em;\r\n}\r\n\r\n.carchkbx[_ngcontent-%COMP%]:focus {\r\n    outline: none;\r\n    border: none;\r\n}\r\n\r\n.carchbx[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked {\r\n    background-color: #F89828 !important;\r\n    border: solid 1px #F89828 !important;\r\n}\r\n\r\ninput[type=\"checkbox\"][_ngcontent-%COMP%] {\r\n    margin-right: 10px;\r\n    color: #ef9c3d;\r\n}\r\n\r\n.form-check-label[_ngcontent-%COMP%] {\r\n    margin-top: 5px;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvZGVmZWN0cy1vcGVyYXRpb24vZGVmZWN0cy1vcGVyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtJQUNoQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksWUFBWTtJQUNaLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLG9DQUFvQztJQUNwQyxvQ0FBb0M7QUFDeEM7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsY0FBYztBQUNsQjs7QUFFQTtJQUNJLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0QiIsInNvdXJjZXNDb250ZW50IjpbIiNsb2NhIHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbiNjaFJvdyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4jcmVtIHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbiNybWNoIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuI3NwdCB7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICAgIGNvbG9yOiAjRjg5ODI4O1xyXG59XHJcblxyXG4uY2FyY2hrYngge1xyXG4gICAgd2lkdGg6IDEuNWVtO1xyXG4gICAgaGVpZ2h0OiAxLjVlbTtcclxufVxyXG5cclxuLmNhcmNoa2J4OmZvY3VzIHtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbn1cclxuXHJcbi5jYXJjaGJ4IGlucHV0W3R5cGU9XCJjaGVja2JveFwiXTpjaGVja2VkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4MjggIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICNGODk4MjggIWltcG9ydGFudDtcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdIHtcclxuICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgIGNvbG9yOiAjZWY5YzNkO1xyXG59XHJcblxyXG4uZm9ybS1jaGVjay1sYWJlbCB7XHJcbiAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn1cclxuXHJcbi5tb2RhbC1jb250ZW50IHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 6102:
/*!**********************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/defects/defects.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectsComponent": () => (/* binding */ DefectsComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_models_visual_defects_defect_comment_request_dto__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/visual-defects/defect-comment-request-dto */ 50737);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);








class DefectsComponent {
  constructor(appAdmin, router, defectServ, sideNav) {
    this.appAdmin = appAdmin;
    this.router = router;
    this.defectServ = defectServ;
    this.sideNav = sideNav;
    this.defects = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.defectsHeader = [{
      JsonPropName: 'defCommentCode',
      showName: 'Defect Comment Code'
    }, {
      JsonPropName: 'descriptionEn',
      showName: 'Description En'
    }, {
      JsonPropName: 'descriptionAr',
      showName: 'Description Ar'
    }, {
      JsonPropName: 'commentTypeEn',
      showName: 'Comment Type'
    }];
    this.mainDefects = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.mainDefHeader = [{
      JsonPropName: 'mainDefectId',
      showName: 'Main Defect ID'
    }, {
      JsonPropName: 'defectNameEn',
      showName: 'Main Defect Name En'
    }, {
      JsonPropName: 'defectNameAr',
      showName: 'Main Defect Name Ar'
    }];
    this.subDefects = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.subDefHeader = [{
      JsonPropName: 'subDefectId',
      showName: 'Sub Defect ID'
    }, {
      JsonPropName: 'descriptionEn',
      showName: 'Sub Defect Name En'
    }, {
      JsonPropName: 'descriptionAr',
      showName: 'Sub Defect Name Ar'
    }];
    this.cmntDefects = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.cmntDefHeader = [{
      JsonPropName: 'descriptionEn',
      showName: 'Sub Defect Name En'
    }, {
      JsonPropName: 'descriptionAr',
      showName: 'Sub Defect Name Ar'
    }];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 104);
    this.loadDefects();
  }
  loadDefects() {
    this.defectServ.getMainVisualDefects({}).subscribe(response => {
      this.mainDefects.data = response.items;
      this.onSelectMainDef(this.mainDefects.data[0]);
    });
    this.appAdmin.getDefectComments({}).subscribe(response => {
      this.defects.data = response.items;
    });
  }
  onSelectMainDef(main) {
    this.defectServ.getSubVisualDefects({
      mainDefectId: main.mainDefectId
    }).subscribe(response => {
      this.subDefects.data = response.items;
      this.onSelectSubDef(this.subDefects.data[0]);
    });
    this.selectedMainDefectId = main.mainDefectId;
  }
  onSelectSubDef(sub) {
    let subDefSearch = new src_app_core_models_visual_defects_defect_comment_request_dto__WEBPACK_IMPORTED_MODULE_1__.DefectCommentRequestDto();
    subDefSearch = {
      mainDefectId: this.selectedMainDefectId,
      subDefectId: sub.subDefectId,
      descriptionEn: undefined,
      orderByDescription: undefined,
      orderByCommentId: undefined,
      recent: undefined
    };
    this.selectedSubDefectId = sub.subDefectId;
    this.defectServ.getSubVisualDefectsComments(subDefSearch).subscribe(response => {
      this.cmntDefects.data = response.items;
    });
  }
  addDefect() {
    this.router.navigate(['app-admin/defects-operation/new', this.selectedMainDefectId, this.selectedSubDefectId]);
  }
  updateSelectedDefect(subDefect) {
    this.router.navigate(['app-admin/defects-operation/edit', subDefect.defCommentId]);
  }
  static #_ = this.ɵfac = function DefectsComponent_Factory(t) {
    return new (t || DefectsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_3__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: DefectsComponent,
    selectors: [["app-defects"]],
    decls: 31,
    vars: 14,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "selectedRow", "selectItemEvent"], [1, "col-md-4"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent"]],
    template: function DefectsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "html")(1, "body")(2, "section", 0)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 2)(7, "div", 1)(8, "div", 3)(9, "div", 4)(10, "div", 5)(11, "div", 6)(12, "div", 7)(13, "h2", 8)(14, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, " Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "div", 10)(17, "div", 11)(18, "div", 12)(19, "app-data-table", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("selectItemEvent", function DefectsComponent_Template_app_data_table_selectItemEvent_19_listener($event) {
          return ctx.onSelectMainDef($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "div", 12)(21, "div", 1)(22, "app-data-table", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("selectItemEvent", function DefectsComponent_Template_app_data_table_selectItemEvent_22_listener($event) {
          return ctx.onSelectSubDef($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div", 12)(24, "div", 1)(25, "div", 14)(26, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DefectsComponent_Template_button_click_26_listener() {
          return ctx.addDefect();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](27, " Add Defect Comment ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](28, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "div", 1)(30, "app-data-table", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function DefectsComponent_Template_app_data_table_updateItemEvent_30_listener($event) {
          return ctx.updateSelectedDefect($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.mainDefHeader)("tblValues", ctx.mainDefects)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("selectedRow", ctx.mainDefects.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.subDefHeader)("tblValues", ctx.subDefects)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("selectedRow", ctx.subDefects.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.cmntDefHeader)("tblValues", ctx.cmntDefects)("isDeleteOperationEnabled", false)("selectedRow", ctx.cmntDefects.data[0]);
      }
    },
    dependencies: [_component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_5__.DataTableComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 75461:
/*!****************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/delegation/delegation.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DelegationComponent": () => (/* binding */ DelegationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular2-notifications */ 55609);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);











function DelegationComponent_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const user_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", user_r8.userId);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", user_r8.userFullName, " ");
  }
}
function DelegationComponent_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function DelegationComponent_option_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const user_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", user_r9.userId);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", user_r9.userFullName, " ");
  }
}
function DelegationComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32)(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, "Users must not be matched.");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
}
function DelegationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function DelegationComponent_div_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function DelegationComponent_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " *To Date Must be grater than From Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function DelegationComponent_div_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
class DelegationComponent {
  constructor(appAdmin, fb, systemAdmin, sideNav, notificationService) {
    this.appAdmin = appAdmin;
    this.fb = fb;
    this.systemAdmin = systemAdmin;
    this.sideNav = sideNav;
    this.notificationService = notificationService;
    this.delegationdt = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.operation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    this.users = [];
    this.ishidden = true;
    this.delegationdtHeader = [{
      JsonPropName: 'delegateId',
      showName: 'Delegate ID'
    }, {
      JsonPropName: 'fromUserName',
      showName: 'From User Name'
    }, {
      JsonPropName: 'toUserName',
      showName: 'To User Name'
    }, {
      JsonPropName: 'fromDate',
      showName: 'From Date'
    }, {
      JsonPropName: 'toDate',
      showName: 'To Date'
    }
    //{ JsonPropName: 'createdBy', showName: 'Created By' },
    // { JsonPropName: 'updatedBy', showName: 'Updated By' },
    ];
  }

  ngOnInit() {
    this.sideNav.setActiveEnt(10, 108);
    this.userId = parseInt(localStorage.getItem('userId'));
    this.initForm();
    this.loadUsers();
  }
  loadUsers() {
    this.systemAdmin.getUsers({}).subscribe(result => {
      this.users = result.items.users;
      this.loadDelegation();
    });
  }
  initForm() {
    this.delegateForm = this.fb.group({
      delegateId: null,
      fromUserId: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      toUserId: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      fromDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      toDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
    }, {
      validator: [dateRangeValidator, notMatching]
    });
  }
  onRowSelected(item) {
    this.selectedMainRow = item;
    this.operation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    this.delegateForm.patchValue(this.selectedMainRow);
    this.delegateForm.get("fromDate").setValue(item.fromDate);
    //patch form item
  }

  loadDelegation() {
    this.appAdmin.GetDelegationLst({}).subscribe(result => {
      this.delegationdt.data = this.Modifydelegationdt(result);
    });
  }
  submitForm() {
    let request = this.delegateForm.value;
    if (this.operation === src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) request.createdBy = this.userId;
    request.operationType = this.operation;
    request.updatedBy = this.userId;
    this.appAdmin.POSTDelegation(request).subscribe(result => {
      if (result.items && this.operation === src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
        this.loadDelegation();
        this.notificationService.success("Success", "Operation completed successfully", {
          timeOut: 3000,
          position: ['top', 'center']
        });
      }
    });
  }
  ClearForm() {
    this.delegateForm.reset();
  }
  Modifydelegationdt(result) {
    result.items.forEach(element => {
      const fromUserName = this.users.find(x => x.userId == element.fromUserId);
      const toUserName = this.users.find(x => x.userId == element.toUserId);
      element.fromUserName = fromUserName ? fromUserName.userFullName : element.fromUserId;
      element.toUserName = toUserName ? toUserName.userFullName : element.toUserId;
    });
    return result.items;
  }
  getValidDate(datetime) {
    const defaultDate = new Date(datetime);
    const year = defaultDate.getFullYear();
    const month = ('0' + (defaultDate.getMonth() + 1)).slice(-2);
    const day = ('0' + defaultDate.getDate()).slice(-2);
    const hours = ('0' + defaultDate.getHours()).slice(-2);
    const minutes = ('0' + defaultDate.getMinutes()).slice(-2);
    const defaultDateTime = `${year}-${month}-${day}T${hours}:${minutes}`;
    console.log(year, month, day, hours, minutes, defaultDateTime);
    return defaultDateTime;
  }
  static #_ = this.ɵfac = function DelegationComponent_Factory(t) {
    return new (t || DelegationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_4__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](angular2_notifications__WEBPACK_IMPORTED_MODULE_8__.NotificationsService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: DelegationComponent,
    selectors: [["app-delegation"]],
    decls: 50,
    vars: 17,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "formGroup"], ["type", "text", "formControlName", "delegateId", 3, "hidden"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-3"], ["for", "fromUserId"], ["name", "fromUserId", "formControlName", "fromUserId", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "validation-filed", 4, "ngIf"], ["for", "toUserId"], ["name", "toUserId", "formControlName", "toUserId", 1, "form-control"], ["for", "fromDate"], ["type", "datetime-local", "id", "fromDate", "value", "05/18/2024T07:50", "formControlName", "fromDate", 1, "form-control"], ["for", "toDate"], ["type", "datetime-local", "id", "toDate", "formControlName", "toDate", 1, "form-control"], [1, "col-md-4", "col-lg-4"], [1, "row", "endBt"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "row", "endBt", 2, "margin-left", "2px"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-orange", 3, "click"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "backendOrdering", "backendPagination", "selectItemEvent", "paginationEvent"], [3, "value"], [1, "validation-filed"]],
    template: function DelegationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](8, " Delegation ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "form", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](13, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 13)(15, "div", 14)(16, "label", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](17, "from User*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "select", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](19, DelegationComponent_option_19_Template, 2, 2, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](20, DelegationComponent_div_20_Template, 2, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "div", 14)(22, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](23, "To User*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "select", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](25, DelegationComponent_option_25_Template, 2, 2, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](26, DelegationComponent_div_26_Template, 3, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](27, DelegationComponent_div_27_Template, 2, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 14)(29, "label", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](30, "From Date*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](31, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](32, DelegationComponent_div_32_Template, 2, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "div", 14)(34, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](35, "To Date*");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](36, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](37, DelegationComponent_div_37_Template, 2, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](38, DelegationComponent_div_38_Template, 2, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](39, "div", 0)(40, "div", 25)(41, "div", 26)(42, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DelegationComponent_Template_button_click_42_listener($event) {
          $event.preventDefault();
          return ctx.submitForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](43, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "div", 25)(45, "div", 28)(46, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DelegationComponent_Template_button_click_46_listener($event) {
          $event.preventDefault();
          return ctx.ClearForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](47, "Clear");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](48, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "app-data-table", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("selectItemEvent", function DelegationComponent_Template_app_data_table_selectItemEvent_49_listener($event) {
          return ctx.onRowSelected($event);
        })("paginationEvent", function DelegationComponent_Template_app_data_table_paginationEvent_49_listener() {
          return false;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.delegateForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("hidden", ctx.ishidden);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.users);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.delegateForm.get("fromUserId").dirty || ctx.delegateForm.get("fromUserId").touched) && ctx.delegateForm.get("fromUserId").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.users);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.delegateForm.hasError("matching"));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.delegateForm.get("toUserId").dirty || ctx.delegateForm.get("toUserId").touched) && ctx.delegateForm.get("toUserId").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.delegateForm.get("fromDate").dirty || ctx.delegateForm.get("fromDate").touched) && ctx.delegateForm.get("fromDate").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.delegateForm.hasError("dateRange"));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", (ctx.delegateForm.get("toDate").dirty || ctx.delegateForm.get("toDate").touched) && ctx.delegateForm.get("toDate").invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.delegateForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.delegationdtHeader)("tblValues", ctx.delegationdt)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("backendOrdering", false)("backendPagination", true);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_5__.DataTableComponent],
    styles: ["#loca[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n    position: relative;\r\n}\r\n\r\n#chRow[_ngcontent-%COMP%] {\r\n    margin-top: 10px;\r\n}\r\n\r\n\r\n.carchkbx[_ngcontent-%COMP%] {\r\n    width: 1.5em;\r\n    height: 1.5em;\r\n}\r\n\r\n.carchkbx[_ngcontent-%COMP%]:focus {\r\n    outline: none;\r\n    border: none;\r\n}\r\n\r\n.form-check-input[_ngcontent-%COMP%]   .carchkbx[_ngcontent-%COMP%]:checked {\r\n    background: #F89828 !important;\r\n    border: solid 1px #F89828 !important;\r\n}\r\n.endBt[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvZGVsZWdhdGlvbi9kZWxlZ2F0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnQkFBZ0I7SUFDaEIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCOzs7QUFHQTtJQUNJLFlBQVk7SUFDWixhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksYUFBYTtJQUNiLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSw4QkFBOEI7SUFDOUIsb0NBQW9DO0FBQ3hDO0FBQ0E7SUFDSSxnQkFBZ0I7QUFDcEIiLCJzb3VyY2VzQ29udGVudCI6WyIjbG9jYSB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4jY2hSb3cge1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuXHJcbi5jYXJjaGtieCB7XHJcbiAgICB3aWR0aDogMS41ZW07XHJcbiAgICBoZWlnaHQ6IDEuNWVtO1xyXG59XHJcblxyXG4uY2FyY2hrYng6Zm9jdXMge1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLmZvcm0tY2hlY2staW5wdXQgLmNhcmNoa2J4OmNoZWNrZWQge1xyXG4gICAgYmFja2dyb3VuZDogI0Y4OTgyOCAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggI0Y4OTgyOCAhaW1wb3J0YW50O1xyXG59XHJcbi5lbmRCdCB7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}
function notMatching(control) {
  const firstControlValue = control.get('fromUserId')?.value;
  const secondControlValue = control.get('toUserId')?.value;
  if (firstControlValue && secondControlValue && firstControlValue === secondControlValue) {
    return {
      matching: true
    }; // Validation error if values match
  }

  return null; // No validation error
}

function dateRangeValidator(control) {
  const startDate = control.get('fromDate')?.value;
  const endDate = control.get('toDate')?.value;
  if (startDate && endDate && new Date(startDate) >= new Date(endDate)) {
    return {
      dateRange: true
    }; // Validation error if start date >= end date
  }

  return null; // No validation error
}

/***/ }),

/***/ 82668:
/*!************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/feesmanagement/feesmanagement.component.ts ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeesmanagementComponent": () => (/* binding */ FeesmanagementComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);







function FeesmanagementComponent_tr_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "td", 32)(6, "button", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function FeesmanagementComponent_tr_32_Template_button_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const s_r2 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r4.setUpFees(s_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, " Setup Fees ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "button", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function FeesmanagementComponent_tr_32_Template_button_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5);
      const s_r2 = restoredCtx.$implicit;
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r6.selectedService = s_r2);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9, " Clone From Another Service ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const s_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", s_r2.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", s_r2.descriptionEn, " ");
  }
}
function FeesmanagementComponent_ng_container_52_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "option", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const s_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", s_r7.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", s_r7.serviceName, " ");
  }
}
function FeesmanagementComponent_ng_container_52_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, FeesmanagementComponent_ng_container_52_option_1_Template, 2, 2, "option", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const s_r7 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", s_r7.serviceId != (ctx_r1.selectedService == null ? null : ctx_r1.selectedService.serviceId));
  }
}
class FeesmanagementComponent {
  constructor(sideNav, appAdmin, route, fb) {
    this.sideNav = sideNav;
    this.appAdmin = appAdmin;
    this.route = route;
    this.fb = fb;
    this.services = [];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 96);
    this.loadServices();
    this.createCloneForm();
  }
  createCloneForm() {
    this.cloneForm = this.fb.group({
      selectedTarget: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]
    });
  }
  loadServices() {
    this.appAdmin.getStationInpsectionServiceTypes({}).subscribe(response => {
      console.log(response.items);
      this.services = response.items;
    });
  }
  setUpFees(service) {
    this.route.navigate(['app-admin/fees-operation', service.serviceId]);
  }
  onTargetChange() {
    console.log(this.cloneForm.get('selectedTarget').value);
  }
  cloneFees() {
    const cloneDets = {
      sourceServiceId: parseInt(this.cloneForm.get('selectedTarget').value),
      targetServiceId: this.selectedService.serviceId
    };
    this.appAdmin.cloneFees(cloneDets).subscribe(response => {
      if (response.items) {
        this.route.navigate(['app-admin/fees-operation', this.selectedService.serviceId]);
        const modalElement = document.getElementById('cloneModal');
        if (modalElement) {
          modalElement.classList.remove('show');
          modalElement.style.display = 'none';
          document.body.classList.remove('modal-open');
          const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
          if (modalBackdrop) {
            modalBackdrop.remove();
          }
          document.body.style.overflow = 'auto';
        }
      }
    });
  }
  static #_ = this.ɵfac = function FeesmanagementComponent_Factory(t) {
    return new (t || FeesmanagementComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_0__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_1__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: FeesmanagementComponent,
    selectors: [["app-feesmanagement"]],
    decls: 60,
    vars: 5,
    consts: [[3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "table", "table-bordered", "table-striped"], [4, "ngFor", "ngForOf"], ["id", "cloneModal", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "modal-body"], [1, "col-lg-3"], ["for", "sname", 1, "st-label"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], [1, "col-lg-3", "right"], ["formControlName", "selectedTarget", 1, "form-control", 3, "change"], [1, "modal-footer"], [1, "col-12", "end-btns"], ["data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray"], [1, "btn", "btn-orange", 3, "disabled", "click"], ["id", "tdsm"], [1, "btn", "btn-outline-orange", "small-text", 3, "click"], ["data-bs-toggle", "modal", "data-bs-target", "#cloneModal", 1, "btn", "btn-outline-orange", "small-text", 3, "click"], [3, "value", 4, "ngIf"], [3, "value"]],
    template: function FeesmanagementComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "body")(1, "form", 0)(2, "section", 1)(3, "div", 2)(4, "div", 3)(5, "div", 2)(6, "div", 3)(7, "div", 2)(8, "div", 4)(9, "div", 5)(10, "div", 6)(11, "div", 7)(12, "div", 8)(13, "h2", 9)(14, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15, " Fees ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 11)(17, "div", 12)(18, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](19, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "form")(21, "div", 2)(22, "table", 14)(23, "thead")(24, "tr")(25, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](26, " Service Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](28, " Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](30, " Action ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](32, FeesmanagementComponent_tr_32_Template, 10, 2, "tr", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](33, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "div", 16)(35, "div", 17)(36, "div", 18)(37, "div", 19)(38, "h1", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](39, " Clone From Another Service ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](40, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](41, "div", 22)(42, "div", 2)(43, "div", 23)(44, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](45, " Target Service ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](46, "input", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](47, "div", 26)(48, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](49, " Source Service ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](50, "select", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function FeesmanagementComponent_Template_select_change_50_listener() {
          return ctx.onTargetChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](51, "option");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](52, FeesmanagementComponent_ng_container_52_Template, 2, 1, "ng-container", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](53, "div", 28)(54, "div", 2)(55, "div", 29)(56, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](57, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](58, "button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function FeesmanagementComponent_Template_button_click_58_listener() {
          return ctx.cloneFees();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](59, " Clone ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx.cloneForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.services);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", ctx.selectedService == null ? null : ctx.selectedService.serviceName);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.services);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", !ctx.cloneForm.valid);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName],
    styles: [".btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: #F89828;\r\n    font-weight: bold;\r\n}\r\n\r\n#tdsm[_ngcontent-%COMP%] {\r\n    width: 350px;\r\n}\r\n\r\n.small-text[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n    margin-right: 5px;\r\n}\r\n\r\n.col-lg-3[_ngcontent-%COMP%] {\r\n    margin-left: 50px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvZmVlc21hbmFnZW1lbnQvZmVlc21hbmFnZW1lbnQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksV0FBVztJQUNYLHlCQUF5QjtJQUN6QixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGlCQUFpQjtBQUNyQjs7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn1cclxuXHJcbnRoIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4jdGRzbSB7XHJcbiAgICB3aWR0aDogMzUwcHg7XHJcbn1cclxuXHJcbi5zbWFsbC10ZXh0IHtcclxuICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxufVxyXG5cclxuLmNvbC1sZy0zIHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 47246:
/*!**********************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/feesoperation/feesoperation.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FeesoperationComponent": () => (/* binding */ FeesoperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










function FeesoperationComponent_div_5_tr_32_span_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cf_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", cf_r5.feesAmount, "");
  }
}
function FeesoperationComponent_div_5_tr_32_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cf_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", cf_r5.feesAmount);
  }
}
function FeesoperationComponent_div_5_tr_32_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cf_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", cf_r5.reinspectionFeesAmount, " ");
  }
}
function FeesoperationComponent_div_5_tr_32_span_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "input", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const cf_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", cf_r5.reinspectionFeesAmount);
  }
}
function FeesoperationComponent_div_5_tr_32_i_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "i", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_5_tr_32_i_14_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r22);
      const i_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r20.editCategFees(i_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_5_tr_32_i_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "i", 26);
  }
}
function FeesoperationComponent_div_5_tr_32_i_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "i", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_5_tr_32_i_18_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r25);
      const i_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r23.saveCategFees(i_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_5_tr_32_span_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span")(1, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_5_tr_32_span_19_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r28);
      const i_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r26.formulaAction(i_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Add Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
function FeesoperationComponent_div_5_tr_32_span_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span")(1, "button", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_5_tr_32_span_20_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r31);
      const i_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r29.formulaAction(i_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Add/Edit Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
function FeesoperationComponent_div_5_tr_32_Template(rf, ctx) {
  if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, FeesoperationComponent_div_5_tr_32_span_6_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, FeesoperationComponent_div_5_tr_32_span_7_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, FeesoperationComponent_div_5_tr_32_span_9_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, FeesoperationComponent_div_5_tr_32_span_10_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, FeesoperationComponent_div_5_tr_32_i_14_Template, 1, 0, "i", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "a", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_5_tr_32_Template_a_click_15_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r33);
      const i_r6 = restoredCtx.index;
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r32.cancelCategEdit(i_r6));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, FeesoperationComponent_div_5_tr_32_i_16_Template, 1, 0, "i", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](18, FeesoperationComponent_div_5_tr_32_i_18_Template, 1, 0, "i", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, FeesoperationComponent_div_5_tr_32_span_19_Template, 3, 0, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, FeesoperationComponent_div_5_tr_32_span_20_Template, 3, 0, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const cf_r5 = ctx.$implicit;
    const i_r6 = ctx.index;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", cf_r5.categoryDescEn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", cf_r5.categoryTypeEn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", cf_r5.isFormula, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !cf_r5.isFormula && !ctx_r4.isEditCateg[i_r6]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", cf_r5.isFormula && !ctx_r4.isEditCateg[i_r6]);
  }
}
function FeesoperationComponent_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "form", 5)(2, "section", 6)(3, "div", 7)(4, "div", 8)(5, "div", 9)(6, "div", 10)(7, "div", 11)(8, "div", 12)(9, "h2", 13)(10, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, " Category Fees ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "div", 15)(13, "div", 16)(14, "div", 17)(15, "div", 7)(16, "table", 18)(17, "thead")(18, "tr")(19, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Category Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](22, " Category Type Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24, " Fees ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26, " Reinspection Fees ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, " Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](30, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](32, FeesoperationComponent_div_5_tr_32_Template, 21, 12, "tr", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r0.categFeesForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r0.categFees);
  }
}
function FeesoperationComponent_div_6_tr_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "td")(8, "button", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_6_tr_30_Template_button_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r39);
      const i_r37 = restoredCtx.index;
      const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r38.formulaDetails(i_r37));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, "Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const formula_r36 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", formula_r36.formulaName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", formula_r36.feesAmount, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", formula_r36.reinspectionFeesAmount, " ");
  }
}
function FeesoperationComponent_div_6_tr_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr", 5)(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "input", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](6, "input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "td")(8, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_6_tr_31_Template_button_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r41);
      const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r40.saveNewInitFormula());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9, " Save Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_6_tr_31_Template_button_click_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r41);
      const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r42.addNewFormulaName = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r35.formulaInitForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r35.formulaInitForm.valid);
  }
}
function FeesoperationComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "form")(2, "section", 6)(3, "div", 7)(4, "div", 8)(5, "div", 9)(6, "div", 10)(7, "div", 11)(8, "div", 12)(9, "h2", 13)(10, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, " Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "div", 15)(13, "div", 16)(14, "div", 17)(15, "div", 7)(16, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_6_Template_button_click_16_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r44);
      const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r43.addNewFormulaName = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](17, " + Add New Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 7)(19, "table", 18)(20, "thead")(21, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](22, " Formula Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24, " Fees ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26, " Reinspection Fees ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, FeesoperationComponent_div_6_tr_30_Template, 10, 3, "tr", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](31, FeesoperationComponent_div_6_tr_31_Template, 11, 2, "tr", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r1.formulas);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.addNewFormulaName);
  }
}
function FeesoperationComponent_div_7_div_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_div_17_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r50);
      const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r49.newFormula());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " + Add New Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_7_tr_34_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const fd_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", fd_r51.vehicleAttributeNameDescEn, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_5_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const attr_r67 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", attr_r67.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", attr_r67.lkValueEname, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span")(1, "select", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, FeesoperationComponent_div_7_tr_34_span_5_option_2_Template, 2, 2, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r54.attrNames);
  }
}
function FeesoperationComponent_div_7_tr_34_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const fd_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", fd_r51.valueOperationeDescEn, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_8_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const op_r70 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", op_r70.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", op_r70.lkValueEname, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span")(1, "select", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, FeesoperationComponent_div_7_tr_34_span_8_option_2_Template, 2, 2, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r56.operationVal);
  }
}
function FeesoperationComponent_div_7_tr_34_span_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const fd_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", fd_r51.value, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "input", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_7_tr_34_span_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const fd_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", fd_r51.attributeOperationDescEn, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_14_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const op_r74 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", op_r74.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", op_r74.lkValueEname, " ");
  }
}
function FeesoperationComponent_div_7_tr_34_span_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span")(1, "select", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, FeesoperationComponent_div_7_tr_34_span_14_option_2_Template, 2, 2, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r60.conditionOp);
  }
}
function FeesoperationComponent_div_7_tr_34_i_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r77 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "i", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_tr_34_i_16_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r77);
      const i_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r75.editFormula(i_r52));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_7_tr_34_i_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r80 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "i", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_tr_34_i_17_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r80);
      const i_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r78.deleteFormula(i_r52));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_7_tr_34_i_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "i", 26);
  }
}
function FeesoperationComponent_div_7_tr_34_i_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "i", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_tr_34_i_21_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r83);
      const i_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().index;
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r81.updateFormula(i_r52));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function FeesoperationComponent_div_7_tr_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, FeesoperationComponent_div_7_tr_34_span_4_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, FeesoperationComponent_div_7_tr_34_span_5_Template, 3, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, FeesoperationComponent_div_7_tr_34_span_7_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](8, FeesoperationComponent_div_7_tr_34_span_8_Template, 3, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, FeesoperationComponent_div_7_tr_34_span_10_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](11, FeesoperationComponent_div_7_tr_34_span_11_Template, 2, 0, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](13, FeesoperationComponent_div_7_tr_34_span_13_Template, 2, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, FeesoperationComponent_div_7_tr_34_span_14_Template, 3, 1, "span", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, FeesoperationComponent_div_7_tr_34_i_16_Template, 1, 0, "i", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, FeesoperationComponent_div_7_tr_34_i_17_Template, 1, 0, "i", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "a", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_tr_34_Template_a_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r85);
      const i_r52 = restoredCtx.index;
      const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r84.cancelFormulaEdit(i_r52));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, FeesoperationComponent_div_7_tr_34_i_19_Template, 1, 0, "i", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](21, FeesoperationComponent_div_7_tr_34_i_21_Template, 1, 0, "i", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const fd_r51 = ctx.$implicit;
    const i_r52 = ctx.index;
    const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", fd_r51.seq, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r46.isEditFormula[i_r52]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r46.isEditFormula[i_r52]);
  }
}
function FeesoperationComponent_div_7_tr_35_option_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const attr_r89 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", attr_r89.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", attr_r89.lkValueEname, " ");
  }
}
function FeesoperationComponent_div_7_tr_35_option_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const op_r90 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", op_r90.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", op_r90.lkValueEname, " ");
  }
}
function FeesoperationComponent_div_7_tr_35_option_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const op_r91 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", op_r91.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", op_r91.lkValueEname, " ");
  }
}
function FeesoperationComponent_div_7_tr_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r93 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td")(4, "select", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, FeesoperationComponent_div_7_tr_35_option_5_Template, 2, 2, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "td")(7, "select", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](8, FeesoperationComponent_div_7_tr_35_option_8_Template, 2, 2, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](10, "input", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "td")(12, "select", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](13, FeesoperationComponent_div_7_tr_35_option_13_Template, 2, 2, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "td")(15, "button", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](16, " Save Formula ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_tr_35_Template_button_click_17_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r93);
      const ctx_r92 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r92.addNewFormula = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r47.formulaForm.get("seq").value, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r47.attrNames);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r47.operationVal);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r47.conditionOp);
  }
}
function FeesoperationComponent_div_7_ng_container_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const fd_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate4"](" ", fd_r94.vehicleAttributeNameDescEn, " ", fd_r94.valueOperationeDescEn, " ", fd_r94.value, " ", fd_r94.attributeOperationDescEn !== "Null" ? fd_r94.attributeOperationDescEn : " ", " ");
  }
}
function FeesoperationComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r97 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div")(1, "form", 5)(2, "section", 6)(3, "div", 7)(4, "div", 8)(5, "div", 9)(6, "div", 10)(7, "div", 37)(8, "div", 12)(9, "h2", 13)(10, "button", 14)(11, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, " \u00A0 Formula Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "div", 38)(15, "div", 16)(16, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, FeesoperationComponent_div_7_div_17_Template, 4, 0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 7)(19, "table", 18)(20, "thead")(21, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](22, " Seq. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24, " Attribute ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26, " Operation ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, " Value ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](30, " Condition ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](32, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](34, FeesoperationComponent_div_7_tr_34_Template, 22, 13, "tr", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](35, FeesoperationComponent_div_7_tr_35_Template, 18, 4, "tr", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "tr")(37, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](38, " Formula Equation ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "td", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](40, FeesoperationComponent_div_7_ng_container_40_Template, 2, 4, "ng-container", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](41, "div", 40)(42, "div", 41)(43, "div", 42)(44, "div", 43)(45, "h1", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](46, " Confirmation ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](47, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](48, "div", 46)(49, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](50, " Are you sure you want to save formula details ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](51, "div", 48)(52, "div", 49)(53, "button", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](54, " Cancel ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](55, "button", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_7_Template_button_click_55_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r97);
      const ctx_r96 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r96.saveNewFormula());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](56, " Add Formula Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx_r2.formulaForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r2.displayFn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r2.addNewFormula);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r2.formulaDets);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.addNewFormula);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r2.formulaDets);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r2.formulaForm.valid);
  }
}
function FeesoperationComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r99 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 62)(1, "button", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_div_8_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r99);
      const ctx_r98 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r98.loadCategoryDetails());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Back ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
}
class FeesoperationComponent {
  constructor(route, appAdminService, fb, sideNav, router, lookupService) {
    this.route = route;
    this.appAdminService = appAdminService;
    this.fb = fb;
    this.sideNav = sideNav;
    this.router = router;
    this.lookupService = lookupService;
    this.categFees = [];
    this.isEditCateg = Array().fill(false);
    this.isEditFormula = Array().fill(false);
    this.isFormulaDetails = false;
    this.formulas = [];
    this.formulaDets = [];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 96);
    this.userId = parseInt(localStorage.getItem('userId'));
    this.route.params.subscribe(params => {
      this.serviceId = +params['serviceId'];
      console.log(this.serviceId);
      this.loadCategoryDetails();
    });
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.fvo).subscribe(op => this.operationVal = op.items);
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.van).subscribe(va => this.attrNames = va.items);
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.attributeOperation).subscribe(va => this.conditionOp = va.items);
    this.createCategoryFeesForm();
    this.createFormulaForm();
    this.createFormulaInitForm();
  }
  createCategoryFeesForm() {
    this.categFeesForm = this.fb.group({
      fees: [null],
      reinspectionfees: [null]
    });
  }
  createFormulaForm() {
    this.formulaForm = this.fb.group({
      attributeName: [null],
      operation: [null],
      value: [null],
      condition: [null],
      seq: [null]
    });
  }
  createFormulaInitForm() {
    this.formulaInitForm = this.fb.group({
      formulaName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      fees: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      reinspectionfees: [null]
    });
  }
  loadCategoryDetails() {
    this.appAdminService.getFeesCategoryDetails({
      serviceId: this.serviceId
    }).subscribe(res => {
      this.categFees = res.items;
    });
    this.isFormulaAction = false;
    this.isFormulaDetails = false;
    this.addNewFormula = false;
    this.addNewFormulaName = false;
    this.formulas = [];
    this.formulaDets = [];
    this.formulaForm.reset();
  }
  editCategFees(i) {
    this.isEditCateg = Array(this.categFees?.length).fill(false);
    this.isEditCateg[i] = true;
    this.categFeesForm.get('fees').setValue(this.categFees[i].feesAmount);
    this.categFeesForm.get('reinspectionfees').setValue(this.categFees[i].reinspectionFeesAmount);
  }
  cancelCategEdit(index) {
    this.isEditCateg[index] = false;
  }
  saveCategFees(i) {
    const categData = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update,
      feesDetailId: this.categFees[i].feesDetailId,
      serviceId: this.categFees[i].serviceId,
      categoryId: this.categFees[i].categoryId,
      feesAmount: this.categFeesForm.get('fees').value,
      feesRecurrenceFlag: this.categFees[i].feesRecurrenceFlag,
      recurringNo: this.categFees[i].recurringNo,
      reinspectionFeesAmount: this.categFeesForm.get('reinspectionfees').value,
      isFormula: this.categFees[i].isFormula,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdminService.feesCategoryDetailsOperation(categData).subscribe(res => {
      this.isEditCateg[i] = false;
      this.loadCategoryDetails();
    });
  }
  formulaAction(i) {
    this.isFormulaAction = true;
    this.appAdminService.getFeesFormula({
      feesDetailId: this.categFees[i].feesDetailId
    }).subscribe(response => {
      if (response.items.length > 0) {
        this.formulas = response.items;
        this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.attributeOperation).subscribe(va => this.conditionOp = va.items);
      } else {
        this.addNewFormulaName = true;
        // this.isFormulaDetails = true;
        //   this.addNewFormula = true;
        this.conditionOp = [{
          lkCodeValue: 3,
          lkValueEname: 'NULL'
        }];
        this.formulaForm.get('condition').setValue(3);
        this.formulaForm.get('seq').setValue(1);
      }
      this.currentCategForm = i;
    });
  }
  formulaDetails(i) {
    this.isFormulaDetails = true;
    this.displayFn = this.formulas[i].formulaName;
    this.formulaIdSelected = this.formulas[i].formulaId;
    // this.formulas[i].feesDetailId s
    this.appAdminService.getFeesFormulaDetails({
      feesDetailId: this.formulaIdSelected
    }).subscribe(response => {
      this.formulaDets = response.items;
    });
  }
  editFormula(i) {
    this.isEditFormula = Array(this.formulaDets?.length).fill(false);
    this.isEditFormula[i] = true;
    this.formulaForm.get('attributeName').setValue(this.formulaDets[i].vehicleAttributeName);
    this.formulaForm.get('operation').setValue(this.formulaDets[i].valueOperation);
    this.formulaForm.get('value').setValue(this.formulaDets[i].value);
    this.formulaForm.get('condition').setValue(this.formulaDets[i].attributeOperation);
  }
  cancelFormulaEdit(i) {
    this.isEditFormula[i] = false;
  }
  deleteFormula(i) {
    const formulaInitName = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType["delete"],
      feesDetailId: this.categFees[this.currentCategForm].feesDetailId,
      formulaName: this.displayFn,
      feesAmount: this.categFees[this.currentCategForm].feesAmount,
      reinspectionFeesAmount: this.categFees[this.currentCategForm].reinspectionFeesAmount,
      status: 1,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    const formulaDelete = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType["delete"],
      feesDetailId: this.formulaDets[i].feesDetailId,
      seq: this.formulaDets[i].seq,
      vehicleAttributeName: this.formulaDets[i].vehicleAttributeName,
      valueOperation: this.formulaDets[i].valueOperation,
      value: this.formulaDets[i].value.toString(),
      attributeOperation: this.formulaDets[i].attributeOperation,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdminService.feesFormulaOperation(formulaInitName).subscribe(res => {
      this.appAdminService.feesFormulaDetailsOperation(formulaDelete).subscribe(response => {
        this.appAdminService.getFeesFormula({
          feesDetailsId: this.categFees[this.currentCategForm].feesDetailsId
        }).subscribe(response => {});
        this.formulaDetails(i);
      });
    });
  }
  updateFormula(i) {
    this.isEditFormula[i] = false;
    const formulaUpdate = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update,
      feesDetailId: this.formulaIdSelected,
      seq: this.formulaDets[i].seq,
      vehicleAttributeName: parseInt(this.formulaForm.get('attributeName').value),
      valueOperation: parseInt(this.formulaForm.get('operation').value),
      value: this.formulaForm.get('value').value.toString(),
      attributeOperation: parseInt(this.formulaForm.get('condition').value),
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdminService.feesFormulaDetailsOperation(formulaUpdate).subscribe(response => {
      this.formulaDetails(i);
    });
  }
  saveNewInitFormula() {
    const formulaInitName = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert,
      feesDetailId: this.categFees[this.currentCategForm].feesDetailId,
      formulaName: this.formulaInitForm.get('formulaName').value,
      feesAmount: this.formulaInitForm.get('fees').value,
      reinspectionFeesAmount: this.formulaInitForm.get('reinspectionfees').value,
      status: 1,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdminService.feesFormulaOperation(formulaInitName).subscribe(response => {
      this.addNewFormulaName = false;
      this.formulaAction(this.currentCategForm);
    });
  }
  saveNewFormula() {
    const formula = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert,
      feesDetailId: this.formulaIdSelected,
      seq: this.formulaForm.get('seq').value,
      vehicleAttributeName: parseInt(this.formulaForm.get('attributeName').value),
      valueOperation: parseInt(this.formulaForm.get('operation').value),
      value: this.formulaForm.get('value').value.toString(),
      attributeOperation: parseInt(this.formulaForm.get('condition').value),
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdminService.feesFormulaDetailsOperation(formula).subscribe(response => {
      this.loadCategoryDetails();
      const modalElement = document.getElementById('saveFormula');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    });
  }
  newFormula() {
    this.addNewFormula = true;
    this.formulaForm.reset();
    const seqnb = this.formulaDets[this.formulaDets.length - 1] ? this.formulaDets[this.formulaDets.length - 1].seq + 1 : 1;
    this.formulaForm.get('seq').setValue(seqnb);
  }
  backToFees() {
    this.router.navigate(['app-admin/fees']);
  }
  static #_ = this.ɵfac = function FeesoperationComponent_Factory(t) {
    return new (t || FeesoperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: FeesoperationComponent,
    selectors: [["app-feesoperation"]],
    decls: 9,
    vars: 4,
    consts: [[1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], [4, "ngIf"], ["class", "end-btns", 4, "ngIf"], [3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "table", "table-bordered", "table-striped"], [4, "ngFor", "ngForOf"], ["class", "bi bi-pencil-fill", 3, "click", 4, "ngIf"], ["class", "bi bi-x-circle-fill text-danger", 4, "ngIf"], ["class", "bi bi-check-circle-fill text-success", 3, "click", 4, "ngIf"], ["type", "number", "formControlName", "fees", "oninput", "this.value = this.value.slice(0, 4)", 1, "form-control", 3, "value"], ["type", "number", "formControlName", "reinspectionfees", "oninput", "this.value = this.value.slice(0, 4)", 1, "form-control", 3, "value"], [1, "bi", "bi-pencil-fill", 3, "click"], [1, "bi", "bi-x-circle-fill", "text-danger"], [1, "bi", "bi-check-circle-fill", "text-success", 3, "click"], [1, "btn", "btn-outline-orange", "small-text", 3, "click"], [1, "btn", "btn-orange", "small-text", 3, "click"], [3, "formGroup", 4, "ngIf"], [1, "btn-outline-orange", "small-text", 3, "click"], ["type", "text", "formControlName", "formulaName", 1, "form-control"], ["type", "number", "formControlName", "fees", 1, "form-control"], ["type", "number", "formControlName", "reinspectionfees", 1, "form-control"], [1, "btn", "btn-outline-orange", "small-text", 3, "disabled", "click"], ["type", "button", "aria-label", "Close", 1, "btn-close", 3, "click"], ["id", "accordionExamplefd2", 1, "accordion", "section", "accordian"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExamplefd2", 1, "accordion-collapse", "collapse", "show"], ["colspan", "5"], ["id", "saveFormula", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "modal-body"], [1, "row", "form-fields"], [1, "modal-footer"], [1, "col-12", "end-btns"], ["data-bs-dismiss", "modal", 1, "bnt", "btn-outline-gray"], ["id", "fda", 1, "btn", "btn-orange", 3, "disabled", "click"], ["class", "bi bi-trash-fill", 3, "click", 4, "ngIf"], ["formControlName", "attributeName", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["formControlName", "operation", 1, "form-control"], ["type", "number", "formControlName", "value", 1, "form-control"], ["formControlName", "condition", 1, "form-control"], [1, "bi", "bi-trash-fill", 3, "click"], ["type", "number", "formControlName", "value", "oninput", "this.value = this.value.slice(0, 4)", 1, "form-control"], ["data-bs-toggle", "modal", "data-bs-target", "#saveFormula", 1, "btn", "btn-outline-orange", "small-text"], [1, "end-btns"], [1, "btn", "btn-orange", 3, "click"]],
    template: function FeesoperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "body")(1, "div", 0)(2, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function FeesoperationComponent_Template_a_click_2_listener() {
          return ctx.backToFees();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, FeesoperationComponent_div_5_Template, 33, 2, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, FeesoperationComponent_div_6_Template, 32, 2, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, FeesoperationComponent_div_7_Template, 57, 7, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](8, FeesoperationComponent_div_8_Template, 3, 0, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx.isFormulaAction);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.isFormulaAction && ctx.formulas.length > 0 || ctx.addNewFormulaName);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.isFormulaDetails);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.isFormulaAction || ctx.isFormulaDetails);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: ["th[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: #F89828;\r\n    font-weight: bold;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n.small-text[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n    text-align: center;\r\n    width: 150px;\r\n}\r\n\r\n.btn-close[_ngcontent-%COMP%] {\r\n    font-size: medium;\r\n    text-align: center;\r\n    font-weight: bolder;\r\n}\r\n\r\ntable[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n.bi-pencil-fill[_ngcontent-%COMP%], .bi-trash-fill[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n    cursor: pointer;\r\n    margin-right: 2px;\r\n    padding: 3% 3% 1.8% 3%;\r\n}\r\n\r\n.bi[_ngcontent-%COMP%] {\r\n    margin-right: 5px;\r\n}\r\n\r\n.modal-body[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n#fda[_ngcontent-%COMP%] {\r\n    margin-top: 29px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvZmVlc29wZXJhdGlvbi9mZWVzb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gseUJBQXlCO0lBQ3pCLGlCQUFpQjtBQUNyQjs7QUFFQTs7SUFHSSxnQkFBZ0I7SUFDaEIsU0FBUztBQUNiOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLG1CQUFtQjtBQUN2Qjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTs7SUFFSSxjQUFjO0lBQ2QsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQixzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEIiLCJzb3VyY2VzQ29udGVudCI6WyJ0aCB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XHJcbiAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBhcHBlYXJhbmNlOiBub25lO1xyXG4gICAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59XHJcblxyXG4uc21hbGwtdGV4dCB7XHJcbiAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG59XHJcblxyXG4uYnRuLWNsb3NlIHtcclxuICAgIGZvbnQtc2l6ZTogbWVkaXVtO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxufVxyXG5cclxudGFibGUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uYmktcGVuY2lsLWZpbGwsXHJcbi5iaS10cmFzaC1maWxsIHtcclxuICAgIGNvbG9yOiAjRjg5ODI4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAycHg7XHJcbiAgICBwYWRkaW5nOiAzJSAzJSAxLjglIDMlO1xyXG59XHJcblxyXG4uYmkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi5tb2RhbC1ib2R5IHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuI2ZkYSB7XHJcbiAgICBtYXJnaW4tdG9wOiAyOXB4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 18259:
/*!******************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/service-operation/service-operation.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceOperationComponent": () => (/* binding */ ServiceOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);
















const _c0 = ["saveServiceModalButton"];
const _c1 = ["confirmPop"];
const _c2 = ["CheckServiceActiveDeactiveModalBtn"];
function ServiceOperationComponent_option_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "option", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const c_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", c_r18.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", c_r18.lkValueEname, " ");
  }
}
function ServiceOperationComponent_div_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const st_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "s1" + st_r19.lkCodeValue)("value", st_r19.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "s1" + st_r19.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", st_r19.lkValueEname, " ");
  }
}
function ServiceOperationComponent_div_70_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "est" + yn_r20.id)("value", yn_r20.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "est" + yn_r20.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r20.name, " ");
  }
}
function ServiceOperationComponent_div_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "sms" + yn_r21.id)("value", yn_r21.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "sms" + yn_r21.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r21.name, " ");
  }
}
function ServiceOperationComponent_div_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "sup" + yn_r22.id)("value", yn_r22.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "sup" + yn_r22.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r22.name, " ");
  }
}
function ServiceOperationComponent_div_90_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "em2" + yn_r23.id)("value", yn_r23.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "em2" + yn_r23.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r23.name, " ");
  }
}
function ServiceOperationComponent_div_104_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "mo" + yn_r24.id)("value", yn_r24.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "mo" + yn_r24.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r24.name, " ");
  }
}
function ServiceOperationComponent_div_118_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r25 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "req1" + yn_r25.id)("value", yn_r25.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "req1" + yn_r25.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r25.name, " ");
  }
}
function ServiceOperationComponent_div_124_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const yn_r26 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "st1" + yn_r26.id)("value", yn_r26.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "st1" + yn_r26.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", yn_r26.name, " ");
  }
}
function ServiceOperationComponent_div_131_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 27)(1, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ft_r27 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("id", "ft1" + ft_r27.lkCodeValue)("value", ft_r27.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("for", "ft1" + ft_r27.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ft_r27.lkValueEname, " ");
  }
}
function ServiceOperationComponent_div_140_div_13_option_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "option", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ptl_r30 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ptl_r30.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ptl_r30.lkValueEname, " ");
  }
}
function ServiceOperationComponent_div_140_div_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 24)(1, "div", 89)(2, "label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](3, " Plate Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "select", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](5, ServiceOperationComponent_div_140_div_13_option_5_Template, 2, 2, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](6, "div", 92)(7, "button", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_div_140_div_13_Template_button_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r32);
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r31.addPlateService());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](8, " Add ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx_r28.plateTypeFilter);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("disabled", !ctx_r28.plateForm.valid);
  }
}
function ServiceOperationComponent_div_140_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 85)(1, "div", 19)(2, "h2", 20)(3, "button", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](5, "div", 87)(6, "div", 23)(7, "div", 88)(8, "div", 24)(9, "div", 89)(10, "button", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_div_140_Template_button_click_10_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r34);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r33.showPT = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](11, " + Add Plate Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](12, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](13, ServiceOperationComponent_div_140_div_13_Template, 9, 2, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](14, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "div", 0)(16, "app-data-table", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("deleteItemEvent", function ServiceOperationComponent_div_140_Template_app_data_table_deleteItemEvent_16_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r34);
      const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r35.openDeleteModal($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()()();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate2"](" ", ctx_r10.title, " ", ctx_r10.serviceName, " Plate Types ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r10.showPT);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("tblHeaders", ctx_r10.plateHeaders)("tblValues", ctx_r10.plates)("isUpdateOperationEnabled", false);
  }
}
function ServiceOperationComponent_ng_container_195_tr_1_td_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const c_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", c_r39.laneId, " ");
  }
}
function ServiceOperationComponent_ng_container_195_tr_1_td_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const l_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", l_r36.laneName, " ");
  }
}
function ServiceOperationComponent_ng_container_195_tr_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, ServiceOperationComponent_ng_container_195_tr_1_td_1_Template, 2, 1, "td", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, ServiceOperationComponent_ng_container_195_tr_1_td_2_Template, 2, 1, "td", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const c_r39 = ctx.$implicit;
    const l_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", l_r36.laneId == c_r39.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", l_r36.laneId == c_r39.laneId);
  }
}
function ServiceOperationComponent_ng_container_195_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, ServiceOperationComponent_ng_container_195_tr_1_Template, 3, 2, "tr", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx_r13.currentLane);
  }
}
function ServiceOperationComponent_div_217_option_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "option", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const categ_r47 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", categ_r47.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", categ_r47.descriptionEn, " ");
  }
}
function ServiceOperationComponent_div_217_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 24)(1, "div", 94)(2, "select", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, ServiceOperationComponent_div_217_option_3_Template, 2, 2, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 94)(5, "button", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_div_217_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r49);
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r48.addServiceCateg());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](6, " Add ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx_r14.vehicleCategoryList);
  }
}
function ServiceOperationComponent_tr_226_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ct_r50 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ct_r50.vehicleCategoryEn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ct_r50.vehicleCategoryAr, " ");
  }
}
function ServiceOperationComponent_div_247_option_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "option", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const st_r52 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", st_r52.stationId);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", st_r52.stationNameEn, " ");
  }
}
function ServiceOperationComponent_div_247_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 24)(1, "div", 94)(2, "select", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, ServiceOperationComponent_div_247_option_3_Template, 2, 2, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "div", 94)(5, "button", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_div_247_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r54);
      const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r53.addStationServ());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](6, " Add ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx_r16.stationFilter);
  }
}
function ServiceOperationComponent_tr_256_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const st_r55 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", st_r55.stationNameEn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", st_r55.stationNameAr, " ");
  }
}
class ServiceOperationComponent {
  constructor(lookupService, route, fb, sideNav, appAdmin, router, sysAdmin, sharedLookupService, renderer, vehicleService) {
    this.lookupService = lookupService;
    this.route = route;
    this.fb = fb;
    this.sideNav = sideNav;
    this.appAdmin = appAdmin;
    this.router = router;
    this.sysAdmin = sysAdmin;
    this.sharedLookupService = sharedLookupService;
    this.renderer = renderer;
    this.vehicleService = vehicleService;
    this.classifications = [];
    this.serviceTypes = [];
    this.sourceLane = [];
    this.currentLane = [];
    this.formatLane = {
      add: 'Available Lanes',
      remove: 'Service Lanes'
    };
    this.yesNoList = [{
      id: 1,
      name: 'Yes'
    }, {
      id: 0,
      name: 'No'
    }];
    this.plates = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.plateHeaders = [{
      JsonPropName: 'plateTypeEn',
      showName: 'Plate Type En'
    }, {
      JsonPropName: 'plateTypeAr',
      showName: 'Plate Type Ar'
    }];
    this.showPT = false;
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 94);
    this.userId = parseInt(localStorage.getItem('userId'));
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.classification).subscribe(types => this.classifications = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.insClassification).subscribe(types => this.serviceTypes = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.feetype).subscribe(types => this.feeType = types);
    this.checkViewInsertUpdateMode();
    this.createServiceForm();
    this.loadPlateTypes();
    this.loadServiceLanes();
    this.loadCategories();
    this.loadStations();
  }
  onServiceSelection(event) {
    console.log("test select");
  }
  createServiceForm() {
    this.serviceForm = this.fb.group({
      serviceId: [null],
      prefix: [''],
      serviceName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      descriptionEn: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      descriptionAr: [''],
      serviceClassification: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      serviceType: [null],
      smsFlag: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      emailFlag: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      moiUpdateRequired: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      includeMOIReport: [1],
      requiredReport: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      reportFeesType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      reportFee: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      includeEstemara: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      supportDocument: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      registrationValidity: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      reInspectionValidity: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      inspectionType: [null],
      applyStaffRate: [null],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required],
      createdBy: [null],
      createdDate: [null],
      updatedBy: [null],
      updatedDate: [null],
      serviceTypeAr: [''],
      serviceTypeEn: [''],
      serviceClassificationAr: [''],
      serviceClassificationEn: ['']
    });
    this.plateForm = this.fb.group({
      selectedPlateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required]
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.serviceId = +params['serviceId'];
      if (this.serviceId > 0) {
        this.loadServices();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
      this.showPlatesSection = true;
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "New";
      this.action = "Created";
      this.disableNav = true;
      this.showPlatesSection = false;
    }
  }
  loadServices() {
    this.appAdmin.getStationInpsectionServiceTypes({
      serviceId: this.serviceId
    }).subscribe(response => {
      this.serviceForm.patchValue(response.items[0]);
      this.serviceForm.get('reportFeesType').setValue(parseInt(response.items[0].reportFeesType));
      this.services = response.items[0];
      this.serviceName = response.items[0].serviceName;
    });
  }
  loadPlateTypes() {
    this.appAdmin.getPlateTypesByServiceId({
      serviceId: this.serviceId
    }).subscribe(response => {
      this.currentPlateTypes = response.items;
      this.plates.data = response.items;
      this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.plateType).subscribe(data => {
        this.plateTypeList = data.items;
        console.log(this.plateTypeList);
        this.plateTypeFilter = this.plateTypeList.filter(plateType => {
          // Check if the plateType's identifier is not present in currentPlateTypes
          return !this.currentPlateTypes.some(currentPlateType => currentPlateType.plateTypeId === plateType.lkCodeValue);
        });
      });
      console.log(this.plateTypeFilter);
    });
  }
  loadServiceLanes() {
    this.appAdmin.getLanes({}).subscribe(response => {
      this.sourceLane = response.items;
    });
    this.appAdmin.getLaneServiceType({
      serviceType: this.serviceId
    }).subscribe(response => {
      this.currentLane = response.items;
    });
  }
  loadCategories() {
    this.createCategForm();
    this.appAdmin.getCategoryByServiceId({
      serviceId: this.serviceId
    }).subscribe(response => {
      this.categList = response.items;
      this.vehicleService.getVehicleCategories().subscribe(response => {
        this.vehicleCategoryList = response.items.filter(categ => {
          return !this.categList.some(categList => categList.vehicleCategoryEn === categ.descriptionEn);
        });
      });
    });
  }
  createCategForm() {
    this.categForm = this.fb.group({
      selectedServCateg: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required]
    });
  }
  createStationServForm() {
    this.stationServForm = this.fb.group({
      selectedStation: [null]
    });
  }
  loadStations() {
    this.createStationServForm();
    this.appAdmin.getStationByServiceId({
      serviceId: this.serviceId
    }).subscribe(response => {
      this.stationList = response.items;
      this.sysAdmin.getStations({}).subscribe(response => {
        this.stationFilter = response.items.filter(st => {
          return !this.stationList.some(stationList => stationList.stationId === st.stationId);
        });
      });
    });
  }
  addPlateService() {
    const addpt = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert,
      serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupValueCodes.Inspection,
      subServiceId: this.serviceId,
      plateTypeId: parseInt(this.plateForm.get('selectedPlateType').value)
    };
    this.appAdmin.plateTypesServiceOperation(addpt).subscribe(response => {
      if (response.items > 0) {
        this.showPT = false;
        this.loadPlateTypes();
      }
    });
  }
  openDeleteModal(item) {
    const modal = this.confirmModal.nativeElement;
    this.renderer.addClass(modal, 'show');
    this.renderer.setStyle(modal, 'display', 'block');
    this.selectDeletePlate = item;
  }
  closeModal() {
    const modal = this.confirmModal.nativeElement;
    this.renderer.addClass(modal, 'hide');
    this.renderer.setStyle(modal, 'display', 'none');
    this.selectDeletePlate = null;
  }
  deletePlateService() {
    const deletePlateService = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType["delete"],
      serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupValueCodes.Inspection,
      subServiceId: this.serviceId,
      plateTypeId: this.selectDeletePlate.plateTypeId
    };
    console.log(deletePlateService);
    this.appAdmin.plateTypesServiceOperation(deletePlateService).subscribe(response => {
      this.closeModal();
      this.loadPlateTypes();
    });
  }
  saveServiceDetails() {
    const servDets = {
      operationType: this.operation,
      serviceId: this.serviceId,
      prefix: this.serviceForm.get('prefix').value,
      serviceName: this.serviceForm.get('serviceName').value,
      descriptionEn: this.serviceForm.get('descriptionEn').value,
      descriptionAr: this.serviceForm.get('descriptionAr').value,
      serviceClassification: this.serviceForm.get('serviceClassification').value,
      serviceType: this.serviceForm.get('serviceType').value ? this.serviceForm.get('serviceType').value : src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupValueCodes.Inspection,
      smsFlag: this.serviceForm.get('smsFlag').value,
      emailFlag: this.serviceForm.get('emailFlag').value,
      moiUpdateRequired: this.serviceForm.get('moiUpdateRequired').value,
      includeMOIReport: this.serviceForm.get('includeMOIReport').value,
      requiredReport: this.serviceForm.get('requiredReport').value,
      reportFeesType: this.serviceForm.get('reportFeesType').value,
      reportFee: this.serviceForm.get('reportFee').value,
      includeEstemara: this.serviceForm.get('includeEstemara').value,
      supportDocument: this.serviceForm.get('supportDocument').value,
      registrationValidity: this.serviceForm.get('registrationValidity').value.toString(),
      reInspectionValidity: this.serviceForm.get('reInspectionValidity').value.toString(),
      inspectionType: this.serviceId,
      applyStaffRate: this.serviceForm.get('applyStaffRate').value,
      status: this.serviceForm.get('status').value,
      createdBy: this.userId,
      updatedBy: this.userId
    };
    this.appAdmin.stationInspectionServiceTypeOperation(servDets).subscribe(response => {
      if (response.items > 0) {
        if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
          this.appAdmin.getStationInpsectionServiceTypes({
            serviceName: this.serviceForm.get('serviceName').value
          }).subscribe(response => {
            this.serviceForm.patchValue(response.items[0]);
            this.serviceForm.get('reportFeesType').setValue(parseInt(response.items[0].reportFeesType));
            this.services = response.items[0];
            this.serviceName = response.items[0].serviceName;
            this.serviceId = response.items[0].serviceId;
          });
          this.showPlatesSection = true;
        }
        this.saveServiceModalButton.nativeElement.click();
      }
    });
  }
  addServiceCateg() {
    const servCateg = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert,
      serviceId: this.serviceId,
      categoryId: this.categForm.get('selectedServCateg').value,
      status: 1,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdmin.inspectionServiceCategoryOperation(servCateg).subscribe(response => {
      this.loadCategories();
    });
  }
  addStationServ() {
    const servSt = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert,
      stationId: parseInt(this.stationServForm.get('selectedStation').value),
      serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupValueCodes.Inspection,
      isActive: true,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    this.appAdmin.stationServicesOperation(servSt).subscribe(response => {
      this.loadStations();
    });
  }
  backToServices() {
    this.router.navigate(['/app-admin/station-services']);
  }
  static #_ = this.ɵfac = function ServiceOperationComponent_Factory(t) {
    return new (t || ServiceOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_6__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_13__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_7__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_8__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_11__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_9__.VehicleDetailsService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
    type: ServiceOperationComponent,
    selectors: [["app-service-operation"]],
    viewQuery: function ServiceOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵviewQuery"](_c2, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵloadQuery"]()) && (ctx.saveServiceModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵloadQuery"]()) && (ctx.confirmModal = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵloadQuery"]()) && (ctx.CheckSeviceActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵloadQuery"]()) && (ctx.CheckServiceActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 257,
    vars: 28,
    consts: [[1, "row"], [1, "inspection-tab-menu"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#st-details", "type", "button", "role", "tab", "aria-controls", "st-details", "aria-selected", "true", 1, "nav-link", "active"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "category", "aria-selected", "true", "data-bs-toggle", "tab", "data-bs-target", "#category", 1, "nav-link"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "station", "aria-selected", "true", "data-bs-toggle", "tab", "data-bs-target", "#stations", 1, "nav-link"], [1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], [1, "inspection-tab-content"], [1, "col-12"], ["id", "myTabContent", 1, "tab-content"], ["id", "st-details", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-lg-12"], [1, "st-label"], [1, "col-4"], ["type", "text", "formControlName", "serviceName", 1, "form-control"], ["type", "text", "formControlName", "descriptionEn", 1, "form-control"], ["formControlName", "serviceClassification", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], [1, "row", "justify-content-between"], [1, "col-lg-5"], ["class", "col-4", 4, "ngFor", "ngForOf"], ["type", "number", "formControlName", "registrationValidity", 1, "form-control"], ["type", "number", "formControlName", "reInspectionValidity", 1, "form-control"], ["type", "number", "formControlName", "reportFee", 1, "form-control"], ["class", "accordion section accordian", "id", "accordionExample012", 4, "ngIf"], ["id", "confirmPop", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["confirmPop", ""], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], [1, "modal-body"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], [1, "end-btns"], [1, "btn", "btn-orange", 3, "disabled", "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveServiceModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["id", "lane", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["id", "accordionExample3", 1, "accordion", "section", "accordian"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [1, "table", "table-bordered", "table-striped"], [4, "ngFor", "ngForOf"], ["id", "category", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["id", "accordionExample04", 1, "accordion", "section", "accordian"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search5", 1, "accordion-button"], ["id", "act-search5", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample04", 1, "accordion-collapse", "collapse", "show"], ["id", "titlename", 1, "row"], [1, "col-md-4"], [1, "btn", "btn-orange", 3, "click"], ["class", "row form-fields", 4, "ngIf"], [1, "table", "table-striped", "table-bordered"], ["id", "stations", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [3, "value"], [1, "btn-radio"], ["type", "radio", "name", "serviceType", "formControlName", "serviceType", 3, "id", "value"], [1, "w-100", 3, "for"], ["type", "radio", "name", "includeEstemara", "formControlName", "includeEstemara", 3, "id", "value"], [1, "w-50", 3, "for"], ["type", "radio", "name", "smsFlag", "formControlName", "smsFlag", 3, "id", "value"], ["type", "radio", "name", "supportDocument", "formControlName", "supportDocument", 3, "id", "value"], ["type", "radio", "name", "emailFlag", "formControlName", "emailFlag", 3, "id", "value"], ["type", "radio", "name", "moiUpdateRequired", "formControlName", "moiUpdateRequired", 3, "id", "value"], ["type", "radio", "name", "requiredReport", "formControlName", "requiredReport", 3, "id", "value"], ["type", "radio", "name", "status", "formControlName", "status", 3, "id", "value"], ["type", "radio", "name", "reportFeesType", "formControlName", "reportFeesType", 3, "id", "value"], ["id", "accordionExample012", 1, "accordion", "section", "accordian"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search32", 1, "accordion-button"], ["id", "act-search32", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample012", 1, "accordion-collapse", "collapse", "show"], [1, "container", "mt-4"], [1, "col-md-3"], [3, "tblHeaders", "tblValues", "isUpdateOperationEnabled", "deleteItemEvent"], ["formControlName", "selectedPlateType", 1, "form-control"], [1, "col-md-3", "btnadd"], [4, "ngIf"], [1, "col-lg-3"], ["formControlName", "selectedServCateg", 1, "form-control"], ["formControlName", "selectedStation", 1, "form-control"]],
    template: function ServiceOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "html")(1, "body")(2, "div", 0)(3, "div", 1)(4, "div", 2)(5, "ul", 3)(6, "li", 4)(7, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](8, " Main Information ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](9, "li", 4)(10, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](11, " Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](12, "li", 4)(13, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](14, " Stations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](15, "div", 8)(16, "a", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_Template_a_click_16_listener() {
          return ctx.backToServices();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](17, "i", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](18, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](19, "div", 11)(20, "div", 0)(21, "div", 12)(22, "div", 13)(23, "div", 14)(24, "div", 0)(25, "form", 15)(26, "div", 16)(27, "div", 17)(28, "div", 18)(29, "div", 19)(30, "h2", 20)(31, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](33, "div", 22)(34, "div", 23)(35, "div", 24)(36, "div", 25)(37, "div", 0)(38, "div", 12)(39, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](40, " Service Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](41, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](42, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](43, "div", 25)(44, "div", 0)(45, "div", 12)(46, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](47, " Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](48, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](49, "input", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](50, "div", 25)(51, "div", 0)(52, "div", 12)(53, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](54, " Classification ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](55, "div", 27)(56, "select", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](57, ServiceOperationComponent_option_57_Template, 2, 2, "option", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](58, "div", 32)(59, "div", 33)(60, "div", 0)(61, "div", 12)(62, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](63, " Service Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](64, ServiceOperationComponent_div_64_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](65, "div", 33)(66, "div", 0)(67, "div", 12)(68, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](69, " Include Estimara ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](70, ServiceOperationComponent_div_70_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](71, "div", 32)(72, "div", 33)(73, "div", 0)(74, "div", 12)(75, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](76, " SMS ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](77, ServiceOperationComponent_div_77_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](78, "div", 33)(79, "div", 0)(80, "div", 12)(81, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](82, " Support Document ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](83, ServiceOperationComponent_div_83_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](84, "div", 32)(85, "div", 33)(86, "div", 0)(87, "div", 12)(88, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](89, " Email ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](90, ServiceOperationComponent_div_90_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](91, "div", 33)(92, "div", 0)(93, "div", 12)(94, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](95, " Registration Validity ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](96, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](97, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](98, "div", 32)(99, "div", 33)(100, "div", 0)(101, "div", 12)(102, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](103, " MOI Update Required ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](104, ServiceOperationComponent_div_104_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](105, "div", 33)(106, "div", 0)(107, "div", 12)(108, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](109, " Re-inspection Validity ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](110, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](111, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](112, "div", 32)(113, "div", 33)(114, "div", 0)(115, "div", 12)(116, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](117, " Required Report ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](118, ServiceOperationComponent_div_118_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](119, "div", 33)(120, "div", 0)(121, "div", 12)(122, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](123, " Status ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](124, ServiceOperationComponent_div_124_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](125, "div", 32)(126, "div", 33)(127, "div", 0)(128, "div", 12)(129, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](130, " Report Fees Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](131, ServiceOperationComponent_div_131_Template, 5, 4, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](132, "div", 33)(133, "div", 0)(134, "div", 12)(135, "label", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](136, " Report Fee ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](137, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](138, "input", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](139, "form", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](140, ServiceOperationComponent_div_140_Template, 17, 6, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](141, "div", 39, 40)(143, "div", 41)(144, "div", 42)(145, "div", 43)(146, "h1", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](147, " Confirmation ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](148, "div", 45)(149, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](150, " Are You Sure You Want to Delete ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](151, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](152);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](153, " Plate Type from ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](154, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](155);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](156, " ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](157, "button", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_Template_button_click_157_listener() {
          return ctx.closeModal();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](158, "img", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](159, "button", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_Template_button_click_159_listener() {
          return ctx.deletePlateService();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](160, "img", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](161, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](162, "div", 49)(163, "button", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_Template_button_click_163_listener() {
          return ctx.saveServiceDetails();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](164, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](165, "button", 51, 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](167, "div", 53)(168, "div", 41)(169, "div", 42)(170, "div", 43)(171, "h1", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](172, "img", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](173);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](174, "button", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](175, "div", 56)(176, "div", 0)(177, "form")(178, "div", 16)(179, "div", 17)(180, "div", 57)(181, "div", 19)(182, "h2", 20)(183, "button", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](184, " Lane ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](185, "div", 59)(186, "div", 23)(187, "div", 24)(188, "table", 60)(189, "thead")(190, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](191, " Lane No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](192, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](193, " Lane Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](194, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](195, ServiceOperationComponent_ng_container_195_Template, 2, 1, "ng-container", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](196, "div", 62)(197, "div", 0)(198, "form", 15)(199, "div", 16)(200, "div", 17)(201, "div", 63)(202, "div", 19)(203, "h2", 20)(204, "button", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](205, " Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](206, "div", 65)(207, "div", 23)(208, "div", 66)(209, "i");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](210);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](211, " Category List ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](212, "div", 0)(213, "div", 67)(214, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_Template_button_click_214_listener() {
          return ctx.showCateg = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](215, " + Add Service Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](216, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](217, ServiceOperationComponent_div_217_Template, 7, 1, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](218, "div", 0)(219, "table", 70)(220, "thead")(221, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](222, " Category Name En ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](223, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](224, " Category Name Ar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](225, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](226, ServiceOperationComponent_tr_226_Template, 5, 2, "tr", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](227, "div", 71)(228, "div", 0)(229, "form", 15)(230, "div", 16)(231, "div", 17)(232, "div", 63)(233, "div", 19)(234, "h2", 20)(235, "button", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](236, " Stations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](237, "div", 65)(238, "div", 23)(239, "div", 66)(240, "i");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](241);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](242, " Station List ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](243, "div", 0)(244, "div", 67)(245, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function ServiceOperationComponent_Template_button_click_245_listener() {
          return ctx.showCateg = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](246, " + Add Service Station ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](247, ServiceOperationComponent_div_247_Template, 7, 1, "div", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](248, "div", 0)(249, "table", 70)(250, "thead")(251, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](252, " Station Name En ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](253, "th");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](254, " Station Name Ar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](255, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](256, ServiceOperationComponent_tr_256_Template, 5, 2, "tr", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()()()()()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](25);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.serviceForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate2"](" ", ctx.title, " ", ctx.serviceName, " Service ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](25);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.classifications);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.serviceTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.yesNoList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.feeType);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.plateForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.showPlatesSection);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" \"", ctx.selectDeletePlate == null ? null : ctx.selectDeletePlate.plateTypeEn, "\" ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" \"", ctx.serviceName, "\" ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("disabled", !ctx.serviceForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.sourceLane);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.categForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx.serviceName, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.showCateg);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.categList);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.stationServForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", ctx.serviceName, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.showCateg);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx.stationList);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_12__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_12__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.NgForm, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_10__.DataTableComponent],
    styles: [".btn-radio[_ngcontent-%COMP%]   input[type=\"radio\"][_ngcontent-%COMP%], .btn-radio[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n    vertical-align: middle;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n.btnadd[_ngcontent-%COMP%] {\r\n    margin-top: 35px;\r\n}\r\n\r\n#titlename[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n}\r\n\r\n.left[_ngcontent-%COMP%] {\r\n    margin-left: 30px;\r\n}\r\n\r\n.right[_ngcontent-%COMP%] {\r\n    margin-left: 230px;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: #F89828;\r\n    font-weight: bold;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked, .btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:not(:checked) {\r\n    position: absolute;\r\n    left: -9999px;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked + label[_ngcontent-%COMP%], .btn-checkbox[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]:hover {\r\n    color: #fff;\r\n    background-color: #F89828;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:disabled + label[_ngcontent-%COMP%] {\r\n    opacity: 0.7;\r\n    cursor: not-allowed;\r\n    pointer-events: none;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\r\n    border-radius: 4px;\r\n    background: #F6F6F7;\r\n    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.25);\r\n    position: relative;\r\n    transition: all 0.5s;\r\n    color: #34312D;\r\n    font-size: 16px;\r\n    padding: 8px 20px;\r\n    min-width: 125px;\r\n    text-align: center;\r\n    float: left;\r\n    margin-top: 12px;\r\n    margin-right: 17px;\r\n    font-weight: 500;\r\n    margin-bottom: 5px;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3Ivc2VydmljZS1vcGVyYXRpb24vc2VydmljZS1vcGVyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7SUFFSSxxQkFBcUI7SUFDckIsc0JBQXNCO0FBQzFCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gseUJBQXlCO0lBQ3pCLGlCQUFpQjtBQUNyQjs7QUFFQTs7SUFFSSxrQkFBa0I7SUFDbEIsYUFBYTtBQUNqQjs7QUFFQTs7SUFFSSxXQUFXO0lBQ1gseUJBQXlCO0lBQ3pCLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG9CQUFvQjtBQUN4Qjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsK0NBQStDO0lBQy9DLGtCQUFrQjtJQUNsQixvQkFBb0I7SUFDcEIsY0FBYztJQUNkLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixnQkFBZ0I7SUFDaEIsa0JBQWtCO0FBQ3RCOztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEIiLCJzb3VyY2VzQ29udGVudCI6WyIuYnRuLXJhZGlvIGlucHV0W3R5cGU9XCJyYWRpb1wiXSxcclxuLmJ0bi1yYWRpbyBsYWJlbCB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59XHJcblxyXG4uYnRuYWRkIHtcclxuICAgIG1hcmdpbi10b3A6IDM1cHg7XHJcbn1cclxuXHJcbiN0aXRsZW5hbWUge1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5sZWZ0IHtcclxuICAgIG1hcmdpbi1sZWZ0OiAzMHB4O1xyXG59XHJcblxyXG4ucmlnaHQge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIzMHB4O1xyXG59XHJcblxyXG50aCB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5cclxuLmJ0bi1jaGVja2JveCBpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl06Y2hlY2tlZCxcclxuLmJ0bi1jaGVja2JveCBpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl06bm90KDpjaGVja2VkKSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiAtOTk5OXB4O1xyXG59XHJcblxyXG4uYnRuLWNoZWNrYm94IGlucHV0W3R5cGU9XCJjaGVja2JveFwiXTpjaGVja2VkK2xhYmVsLFxyXG4uYnRuLWNoZWNrYm94IGxhYmVsOmhvdmVyIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1jaGVja2JveCBpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl06ZGlzYWJsZWQrbGFiZWwge1xyXG4gICAgb3BhY2l0eTogMC43O1xyXG4gICAgY3Vyc29yOiBub3QtYWxsb3dlZDtcclxuICAgIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG59XHJcblxyXG4uYnRuLWNoZWNrYm94IGxhYmVsIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGJhY2tncm91bmQ6ICNGNkY2Rjc7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDRweCAwcHggcmdiYSgwLCAwLCAwLCAwLjI1KTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjVzO1xyXG4gICAgY29sb3I6ICMzNDMxMkQ7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBwYWRkaW5nOiA4cHggMjBweDtcclxuICAgIG1pbi13aWR0aDogMTI1cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIG1hcmdpbi10b3A6IDEycHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE3cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG59XHJcblxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uIHtcclxuICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5tb2RhbC1jb250ZW50IHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 75842:
/*!******************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/station-operation/station-operation.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationOperationComponent": () => (/* binding */ StationOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 71989);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 98977);
/* harmony import */ var src_app_core_models_adminstration_StationOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/StationOperation */ 57599);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);
















const _c0 = ["saveStationModalButton"];
function StationOperationComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 142)(1, "h4");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx_r0.stName, " Station ");
  }
}
function StationOperationComponent_div_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_59_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * End Time should be greater than start time ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_71_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_76_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r57 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", type_r57.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", type_r57.lkValueEname, " ");
  }
}
function StationOperationComponent_div_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_88_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r58 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", type_r58.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", type_r58.lkValueEname, " ");
  }
}
function StationOperationComponent_div_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r59 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", vc_r59.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", vc_r59.lkValueEname, " ");
  }
}
function StationOperationComponent_div_96_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_101_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_107_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_112_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_118_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_123_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_129_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const area_r60 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", area_r60.areaId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", area_r60.areaEname, " ");
  }
}
function StationOperationComponent_div_130_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_135_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const loc_r61 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", loc_r61.locationId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", loc_r61.locationEname, " ");
  }
}
function StationOperationComponent_div_136_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_148_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_150_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 145);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx_r24.stationForm.valid);
  }
}
function StationOperationComponent_div_169_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 146)(1, "div", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "input", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "label", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const vt_r62 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("id", "v" + vt_r62.lkCodeValue)("value", vt_r62.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("for", "v" + vt_r62.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", vt_r62.lkValueEname, " ");
  }
}
function StationOperationComponent_div_176_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "input", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "label", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const st_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("id", "s" + st_r63.lkCodeValue)("value", st_r63.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("for", "s" + st_r63.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", st_r63.lkValueEname, " ");
  }
}
function StationOperationComponent_div_176_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, StationOperationComponent_div_176_div_1_Template, 4, 4, "div", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const st_r63 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", st_r63.lkCodeValue != 3);
  }
}
function StationOperationComponent_div_184_Template(rf, ctx) {
  if (rf & 1) {
    const _r68 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div")(1, "div", 152)(2, "button", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_div_184_Template_button_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r68);
      const vc_r66 = restoredCtx.$implicit;
      const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r67.OnClickVehiclCategoryList(vc_r66));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const vc_r66 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](vc_r66.descriptionEn);
  }
}
function StationOperationComponent_div_188_Template(rf, ctx) {
  if (rf & 1) {
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div")(1, "div", 152)(2, "button", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_div_188_Template_button_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r71);
      const selCatg_r69 = restoredCtx.$implicit;
      const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r70.onSelectCategory(selCatg_r69));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const selCatg_r69 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](selCatg_r69.vehicleCategoryEn);
  }
}
function StationOperationComponent_option_217_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const lt_r72 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", lt_r72.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", lt_r72.lkValueEname, " ");
  }
}
function StationOperationComponent_option_222_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const lt_r73 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", lt_r73.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", lt_r73.lkValueEname, " ");
  }
}
function StationOperationComponent_div_229_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 155)(1, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "input", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "label", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ls_r74 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("id", "ls" + ls_r74.lkCodeValue)("value", ls_r74.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("for", "ls" + ls_r74.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ls_r74.lkValueEname, " ");
  }
}
function StationOperationComponent_div_236_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 146)(1, "div", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "input", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "label", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const vt_r75 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("id", "v2" + vt_r75.lkCodeValue)("value", vt_r75.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("for", "v2" + vt_r75.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", vt_r75.lkValueEname, " ");
  }
}
function StationOperationComponent_div_243_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "input", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](2, "label", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const st_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("id", "s2" + st_r76.lkCodeValue)("value", st_r76.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("for", "s2" + st_r76.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", st_r76.lkValueEname, " ");
  }
}
function StationOperationComponent_div_243_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, StationOperationComponent_div_243_div_1_Template, 4, 4, "div", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const st_r76 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", st_r76.lkCodeValue != 3);
  }
}
function StationOperationComponent_div_268_Template(rf, ctx) {
  if (rf & 1) {
    const _r80 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div")(1, "div", 157)(2, "button", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_div_268_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r80);
      const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r79.AddDeviceSection());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3, " Add New Device ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "i", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "h2", 24)(6, "button", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](7, " Section Devices ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](8, "div", 82)(9, "div", 27)(10, "app-data-table", 160);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("updateItemEvent", function StationOperationComponent_div_268_Template_app_data_table_updateItemEvent_10_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r80);
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r81.updateDeviceSection($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("tblHeaders", ctx_r34.sectionDeviceTbHeaders)("tblValues", ctx_r34.sectionDeviceData.data ? ctx_r34.sectionDeviceData : null)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", true)("selectedRow", ctx_r34.sectionDeviceData == null ? null : ctx_r34.sectionDeviceData.data[0]);
  }
}
function StationOperationComponent_div_270_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 174);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_270_option_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r85 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", type_r85.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", type_r85.lkValueEname, " ");
  }
}
function StationOperationComponent_div_270_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 174);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_270_Template(rf, ctx) {
  if (rf & 1) {
    const _r87 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div")(1, "form", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "input", 161)(3, "input", 162)(4, "input", 163)(5, "input", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](6, "div", 165)(7, "div", 166)(8, "label", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](9, "\u00A0 \u00A0 \u00A0 IP");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](10, "input", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](11, StationOperationComponent_div_270_div_11_Template, 2, 0, "div", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "div", 166)(13, "label", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](14, "\u00A0 \u00A0 Vendor ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](15, "select", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](16, StationOperationComponent_div_270_option_16_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](17, StationOperationComponent_div_270_div_17_Template, 2, 0, "div", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](18, "div", 166)(19, "div", 172)(20, "button", 173);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_div_270_Template_button_click_20_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r87);
      const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      $event.preventDefault();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r86.submitUpdates());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](21, "Save");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx_r35.deviceSectionForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hidden", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hidden", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hidden", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hidden", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", (ctx_r35.deviceSectionForm.get("ip").dirty || ctx_r35.deviceSectionForm.get("ip").touched) && ctx_r35.deviceSectionForm.get("ip").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r35.deviceVendors);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", (ctx_r35.deviceSectionForm.get("vendorId").dirty || ctx_r35.deviceSectionForm.get("vendorId").touched) && ctx_r35.deviceSectionForm.get("vendorId").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx_r35.deviceSectionForm.valid);
  }
}
function StationOperationComponent_option_288_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const l_r88 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", l_r88.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", l_r88.laneName, " ");
  }
}
function StationOperationComponent_div_293_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 28)(1, "div", 89)(2, "label", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3, " Section No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "input", 175);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function StationOperationComponent_div_294_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0)(1, "div", 67)(2, "button", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_div_294_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r90);
      const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r89.cancelSection());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3, " Cancel ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "button", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx_r38.sectionForm.valid);
  }
}
function StationOperationComponent_div_312_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 176);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "i", 177);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const instruction_r91 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", instruction_r91.instructionNameEn, " ");
  }
}
function StationOperationComponent_div_320_Template(rf, ctx) {
  if (rf & 1) {
    const _r93 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 28)(1, "div", 178);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "input", 179);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "div", 157)(4, "button", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_div_320_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r93);
      const ctx_r92 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r92.addNewInst());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](5, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
}
function StationOperationComponent_option_400_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const l_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", l_r94.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", l_r94.laneName, " ");
  }
}
function StationOperationComponent_option_405_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const b_r95 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", b_r95.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", b_r95.description, " ");
  }
}
function StationOperationComponent_tr_441_option_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const b_r99 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", b_r99.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", b_r99.description, " ");
  }
}
function StationOperationComponent_tr_441_option_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const s_r100 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", s_r100.sectionId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", s_r100.sectionName, " ");
  }
}
function StationOperationComponent_tr_441_option_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const l_r101 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", l_r101.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", l_r101.laneName, " ");
  }
}
function StationOperationComponent_tr_441_Template(rf, ctx) {
  if (rf & 1) {
    const _r103 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "tr")(1, "td")(2, "select", 180);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](3, StationOperationComponent_tr_441_option_3_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "td")(5, "select", 181);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, StationOperationComponent_tr_441_option_6_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "td")(8, "select", 182);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, StationOperationComponent_tr_441_option_9_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "td", 183)(11, "a", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_tr_441_Template_a_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r103);
      const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r102.newAssign = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](12, "i", 184);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "a")(14, "i", 185);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_tr_441_Template_i_click_14_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r103);
      const ctx_r104 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r104.newUser());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r43.boothList);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r43.sectionList);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r43.laneList);
  }
}
function StationOperationComponent_tr_442_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ua_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ua_r105.boothDescr, " ");
  }
}
function StationOperationComponent_tr_442_span_3_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const b_r118 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", b_r118.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", b_r118.description, " ");
  }
}
function StationOperationComponent_tr_442_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span")(1, "select", 180);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, StationOperationComponent_tr_442_span_3_option_2_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r108.boothList);
  }
}
function StationOperationComponent_tr_442_span_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ua_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ua_r105.sectionName, " ");
  }
}
function StationOperationComponent_tr_442_span_6_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const s_r121 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", s_r121.sectionId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", s_r121.sectionName, " ");
  }
}
function StationOperationComponent_tr_442_span_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span")(1, "select", 181);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, StationOperationComponent_tr_442_span_6_option_2_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r110.sectionList);
  }
}
function StationOperationComponent_tr_442_span_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span")(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ua_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ua_r105.laneName, " ");
  }
}
function StationOperationComponent_tr_442_span_9_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "option", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const l_r124 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", l_r124.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", l_r124.laneName, " ");
  }
}
function StationOperationComponent_tr_442_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "span")(1, "select", 182);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, StationOperationComponent_tr_442_span_9_option_2_Template, 2, 2, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r112 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r112.laneList);
  }
}
function StationOperationComponent_tr_442_i_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r127 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "i", 189);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_tr_442_i_11_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r127);
      const ctx_r126 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      const ua_r105 = ctx_r126.$implicit;
      const i_r106 = ctx_r126.index;
      const ctx_r125 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r125.editUser(ua_r105, i_r106));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_tr_442_i_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "i", 184);
  }
}
function StationOperationComponent_tr_442_i_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r130 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "i", 185);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_tr_442_i_15_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r130);
      const ctx_r129 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      const ua_r105 = ctx_r129.$implicit;
      const i_r106 = ctx_r129.index;
      const ctx_r128 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r128.saveUserEdit(ua_r105, i_r106));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_tr_442_Template(rf, ctx) {
  if (rf & 1) {
    const _r132 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](2, StationOperationComponent_tr_442_span_2_Template, 3, 1, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](3, StationOperationComponent_tr_442_span_3_Template, 3, 1, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](5, StationOperationComponent_tr_442_span_5_Template, 3, 1, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](6, StationOperationComponent_tr_442_span_6_Template, 3, 1, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, StationOperationComponent_tr_442_span_8_Template, 3, 1, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](9, StationOperationComponent_tr_442_span_9_Template, 3, 1, "span", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "td", 183);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](11, StationOperationComponent_tr_442_i_11_Template, 1, 0, "i", 186);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "a", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_tr_442_Template_a_click_12_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r132);
      const i_r106 = restoredCtx.index;
      const ctx_r131 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r131.cancelUserEdit(i_r106));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, StationOperationComponent_tr_442_i_13_Template, 1, 0, "i", 187);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](15, StationOperationComponent_tr_442_i_15_Template, 1, 0, "i", 188);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const i_r106 = ctx.index;
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r44.isEditUser[i_r106]);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx_r44.isEditUser[i_r106]);
  }
}
const _c1 = function (a0) {
  return {
    "active": a0
  };
};
function StationOperationComponent_li_448_Template(rf, ctx) {
  if (rf & 1) {
    const _r135 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "li", 190)(1, "a", 191);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_li_448_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r135);
      const i_r133 = restoredCtx.$implicit;
      const ctx_r134 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      ctx_r134.currentPage = i_r133 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r134.getUserPaged(ctx_r134.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r133 = ctx.$implicit;
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](2, _c1, ctx_r45.currentPage === i_r133 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"](i_r133 + 1);
  }
}
function StationOperationComponent_div_463_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Are You Sure You Want To Confirm Station Details ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_464_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Are You Sure You Want To Confirm Station Categories ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_465_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Are You Sure You Want To Confirm Station Lanes ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_466_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Are You Sure You Want To Confirm Station Sections ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_467_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1, " Are You Sure You Want To Confirm Station Booths ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_472_Template(rf, ctx) {
  if (rf & 1) {
    const _r137 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 192);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_button_472_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r137);
      const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r136.createUpdateStation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "img", 193);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_473_Template(rf, ctx) {
  if (rf & 1) {
    const _r139 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 192);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_button_473_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r139);
      const ctx_r138 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r138.saveCategory());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "img", 193);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_474_Template(rf, ctx) {
  if (rf & 1) {
    const _r141 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 192);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_button_474_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r141);
      const ctx_r140 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r140.saveLane());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "img", 193);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_475_Template(rf, ctx) {
  if (rf & 1) {
    const _r143 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 192);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_button_475_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r143);
      const ctx_r142 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r142.saveSection());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "img", 193);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_476_Template(rf, ctx) {
  if (rf & 1) {
    const _r145 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "button", 192);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_button_476_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r145);
      const ctx_r144 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](ctx_r144.saveBooth());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "img", 193);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
const _c2 = function (a0) {
  return {
    "disabled": a0
  };
};
class StationOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router, vehicleService, appAdminService, sideNav) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.vehicleService = vehicleService;
    this.appAdminService = appAdminService;
    this.sideNav = sideNav;
    this.currentPage = 1;
    this.itemsPerPage = 5;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType;
    this.validationEnabled = false;
    this.vehicleTypes = [];
    this.reservationTypes = [];
    this.classifications = [];
    this.isEditUser = Array().fill(false);
    this.instructionList = [];
    this.disableNav = false;
    this.disableAssign = true;
    this.disableSection = true;
    this.areaLst = [];
    this.locationLst = [];
    this.selectedCategory = [];
    this.selectedUpdatedCategories = [];
    this.deviceVendors = [];
    this.isDeviceUpdate = false;
    this.users = [];
    this.boothList = [];
    this.sectionList = [];
    this.laneList = [];
    this.newAssign = false;
    this.laneData = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.laneTbHeaders = [{
      JsonPropName: 'laneName',
      showName: 'Lane Name'
    }, {
      JsonPropName: 'laneClassificationDescriptionEn',
      showName: 'Lane Classification'
    }, {
      JsonPropName: 'laneTypeDescriptionEn',
      showName: 'Lane Type'
    }, {
      JsonPropName: 'stationId',
      showName: 'Station'
    }];
    this.sectionLanData = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.sectionLTbHeaders = [{
      JsonPropName: 'sectionName',
      showName: 'Section Name'
    },
    // { JsonPropName: 'sectionClassificationEn', showName: 'Section Classification' },
    {
      JsonPropName: 'laneName',
      showName: 'Lane Name'
    }
    // { JsonPropName: 'stationId', showName: 'Station' }
    ];

    this.sectionDeviceData = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.sectionDeviceTbHeaders = [{
      JsonPropName: 'ip',
      showName: 'Device IP'
    },
    // { JsonPropName: 'sectionClassificationEn', showName: 'Section Classification' },
    {
      JsonPropName: 'description',
      showName: 'Description'
    }
    // { JsonPropName: 'stationId', showName: 'Station' }
    ];

    this.sectionData = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.sectionTbHeaders = [{
      JsonPropName: 'sectionName',
      showName: 'Section Name'
    }, {
      JsonPropName: 'sectionClassificationEn',
      showName: 'Section Classification'
    }, {
      JsonPropName: 'laneName',
      showName: 'Lane Name'
    }, {
      JsonPropName: 'stationId',
      showName: 'Station'
    }];
    this.userData = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.userHeader = [{
      JsonPropName: 'username',
      showName: 'Username'
    }, {
      JsonPropName: 'userFullName',
      showName: 'Full Name'
    }, {
      JsonPropName: 'mail',
      showName: 'Email'
    }, {
      JsonPropName: 'phone',
      showName: 'Phone'
    }];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 93);
    //this.setActiveTab('category');
    this.setActiveTab('st-details');
    this.userId = parseInt(localStorage.getItem('userId'));
    this.laneData.data = [];
    this.sectionData.data = [];
    this.userData.data = [];
    this.sectionLanData.data = [];
    this.sectionDeviceData.data = [];
    this.checkViewInsertUpdateMode();
    this.createStationForm();
    this.setUpTimeValidators();
    this.createCategoryForm();
    this.createLaneForm();
    this.createSectionForm();
    this.createBoothForm();
    this.createDeviceForm();
    this.createUserForm();
    this.loadLookups();
    this.loadAreas();
    this.stationForm.get('startTime').valueChanges.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.debounceTime)(300), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)()).subscribe(() => {
      this.stationForm.get('startTime').updateValueAndValidity();
      this.stationForm.get('endTime').updateValueAndValidity();
    });
    this.stationForm.get('endTime').valueChanges.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.debounceTime)(300), (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.distinctUntilChanged)()).subscribe(() => {
      this.stationForm.get('endTime').updateValueAndValidity();
      this.stationForm.get('startTime').updateValueAndValidity();
    });
    this.userForm.get('username').valueChanges.subscribe(value => {
      this.getUser();
    });
    this.sectionForm.get('sectionNb').valueChanges.subscribe(value => {
      this.getInstructions();
    });
  }
  setActiveTab(tab) {
    this.activeTab = tab;
  }
  loadLookups() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.vehicleTypes).subscribe(types => this.vehicleTypes = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.reservationTypes).subscribe(types => this.reservationTypes = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.classification).subscribe(types => this.classifications = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.status).subscribe(status => this.statusList = status);
    this.vehicleService.getVehicleCategories().subscribe(categ => {
      this.vehicleCategories = categ.items;
      console.log(this.vehicleCategories, "vehicleCategories");
    });
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.laneTypes).subscribe(lt => {
      this.laneTypes = lt;
    });
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.laneClassification).subscribe(lt => {
      this.laneClassifications = lt;
    });
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.laneStatus).subscribe(lt => {
      this.laneStatuses = lt;
    });
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.laneServiceTypes).subscribe(lt => {
      this.laneServices = lt;
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.view) this.route.params.subscribe(params => {
      this.stationId = +params['stationId'];
      if (this.stationId > 0) {
        this.loadStation();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
      this.title = "New";
      this.action = "Created";
      this.disableNav = true;
    }
  }
  loadStation() {
    this.systemAdminService.getStations({
      stationId: this.stationId
    }).subscribe(result => {
      this.defaultArea = result.items[0].areaId;
      this.defaultLocation = result.items[0].locationId;
      this.loadLocation();
      this.stationForm.patchValue(result.items[0]);
      this.stName = this.stationForm.get('stationNameEn').value;
    });
  }
  createStationForm() {
    const dateFrom = new Date();
    // set the time from to 6 am
    dateFrom.setHours(6, 0, 0, 0);
    const timeTo = new Date(dateFrom.getTime());
    // set time to to 6 pm
    timeTo.setHours(18, 0, 0, 0);
    this.stationForm = this.fb.group({
      stationNameEn: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      stationNameAr: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      addressEn: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      addressAr: [null],
      descriptionEn: [null],
      descriptionAr: [null],
      contactNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      vehicleTypes: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      startTime: [dateFrom.toTimeString().slice(0, 5), [_angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required]],
      endTime: [timeTo.toTimeString().slice(0, 5), _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      classificationId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      reservationType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      slotsDuration: [null],
      latitude: [null],
      longitude: [null],
      areaId: [null],
      locationId: [null],
      status: [true],
      erpCode: ['']
    });
  }
  loadAreas() {
    this.systemAdminService.getAreas({}).subscribe(result => {
      this.areaLst = result.items;
      if (result.items.length > 0) {
        this.defaultArea = result.items[0].areaId;
      }
    });
  }
  onChangeLocation(event) {
    const selectedValue = event.target.value;
    this.defaultArea = selectedValue;
    this.loadLocation();
  }
  loadLocation() {
    this.systemAdminService.getAreaLocations({
      areaId: this.defaultArea
    }).subscribe(result => {
      this.locationLst = result.items;
      this.stationForm.get("locationId").setValue(result.items);
      if (this.defaultLocation) this.stationForm.get("locationId").patchValue(this.defaultLocation);
      // else
      // this.stationForm.get("locationId").setValue(this.defaultLocation);
    });
  }

  setUpTimeValidators() {
    this.stationForm.get('startTime').addValidators(this.validateTimeTo.bind(this));
    this.stationForm.get('startTime').updateValueAndValidity();
    this.stationForm.get('endTime').addValidators(this.validateTimeTo.bind(this));
    this.stationForm.get('endTime').updateValueAndValidity();
  }
  validateTimeTo() {
    const timeTo = this.stationForm.get('endTime').value;
    const timeFrom = this.stationForm.get('startTime').value;
    if (this.stationForm.get('endTime').value != this.stationForm.get('startTime').value) {
      return timeTo > timeFrom ? null : {
        invalidTimeRange: true
      };
    } else {
      return null;
    }
  }
  createCategoryForm() {
    this.categForm = this.fb.group({
      stationName: [''],
      vehicleType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      vehicleCategory: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      //vehicleCategory: [[]],//[null, Validators.required], this.fb.array([], Validators.required) ,
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required]
    });
    if (this.operation != src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
      const stationDets = {
        stationId: this.stationId
      };
      this.appAdminService.getStationCategoryDetails(stationDets).subscribe(response => {
        console.log(response, "category");
        if (response.items.length) {
          this.stationCategoryDetails = response.items[0];
          this.editCateg = true;
          this.categForm.get('vehicleType').setValue(this.stationCategoryDetails.categoryTypeId);
          this.categForm.get('status').setValue(this.stationCategoryDetails.status);
          this.selectedCategory = response.items;
          // response.items.forEach((serv) => {
          //   this.selectedCategory.push(serv);
          //   // this.selectedUpdatedCategories.push(serv.categoryId);
          //   // const control = new FormControl(serv.categoryId); // Assume first item is checked for demo purposes
          //   //  (this.categForm.controls.items as FormArray).push(control);
          // });
          // console.log(this.categForm.value,"form");
        }
      });
    }
  }

  createLaneForm() {
    this.laneForm = this.fb.group({
      laneName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      laneType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      laneClassification: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      laneService: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      vehicleType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required]
    });
  }
  createSectionForm() {
    this.sectionForm = this.fb.group({
      selectedLane: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      sectionNb: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      instName: ['']
    });
  }
  createBoothForm() {
    this.boothForm = this.fb.group({
      boothNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      boothName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      boothDescEn: [''],
      boothDescAr: [''],
      boothCam: [''],
      camLane: [null],
      camBooth: [null]
    });
  }
  createDeviceForm() {
    this.deviceForm = this.fb.group({
      deviceSelected: this.fb.array([], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required)
    });
  }
  createUserForm() {
    this.userForm = this.fb.group({
      username: [''],
      booth: [null],
      section: [null],
      lane: [null]
    });
  }
  onDeviceSelected(event, device) {
    const formArray = this.deviceForm.get('deviceSelected');
    if (event.target.checked) {
      formArray.push(this.fb.control(device.name));
    } else {
      let i = 0;
      formArray.controls.forEach(ctrl => {
        if (ctrl.value === device.name) {
          formArray.removeAt(i);
          return;
        }
        i++;
      });
    }
  }
  createUpdateStation() {
    let stationOper = new src_app_core_models_adminstration_StationOperation__WEBPACK_IMPORTED_MODULE_0__.StationOperation();
    stationOper = this.stationForm?.value;
    stationOper.classificationId = +this.stationForm?.value.classificationId;
    stationOper.reservationType = +this.stationForm?.value.reservationType;
    stationOper.vehicleTypes = +this.stationForm?.value.vehicleTypes;
    stationOper.areaId = this.stationForm?.value.areaId;
    stationOper.locationId = this.stationForm?.value.locationId.length > 0 ? this.stationForm?.value.locationId : 0;
    stationOper.status = this.stationForm?.value.status ? 1 : 0;
    stationOper.operationType = this.operation;
    stationOper.contactNo = stationOper.contactNo.toString();
    stationOper.addressAr = stationOper.addressEn;
    stationOper.erpCode = this.stationForm?.value.erpCode;
    if (this.stationId > 0) stationOper.stationId = this.stationId;
    this.systemAdminService.stationOperations(stationOper).subscribe(result => {
      if (result.items > 0) {
        this.saveStationModalButton.nativeElement.click();
        this.disableNav = false;
        this.setActiveTab('category');
        if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
          this.stationId = result.items;
          this.router.navigate(['app-admin/stations/edit', this.stationId]);
        }
      }
    });
  }
  backToStationsList() {
    this.router.navigate(['app-admin/station']);
  }
  getLane() {
    let laneParam;
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
      laneParam = {};
    } else {
      laneParam = {
        stationId: this.stationId
      };
    }
    this.appAdminService.getLanes(laneParam).subscribe(response => {
      this.laneList = response.items;
      this.laneData.data = this.laneList;
      this.updateSelectLane(this.laneData.data[0]);
      this.getLaneCategServ();
    });
  }
  getLaneCategServ() {
    this.appAdminService.getLaneServiceType({
      laneId: this.selectedLaneValue
    }).subscribe(response => {
      if (response.items) {
        response.items.forEach(serv => {
          if (serv.laneId == this.selectedLaneValue) {
            this.laneForm.get('laneService').setValue(serv.serviceType);
          }
        });
      } else {
        this.laneForm.get('laneService').setValue(null);
      }
    });
    this.appAdminService.getLaneCategoryType({}).subscribe(response => {
      let c = 0;
      let lane;
      response.items.forEach((cat, index, array) => {
        if (this.selectedLaneValue) {
          if (cat.laneId == this.selectedLaneValue) {
            if (index < array.length - 1) {
              const nextCat = array[index + 1];
              if (nextCat.laneId === cat.laneId) {
                lane = cat.categoryTypeId + nextCat.categoryTypeId;
              } else {
                lane = cat.categoryTypeId;
              }
            }
            this.laneForm.get('vehicleType').setValue(lane);
          }
        } else {
          if (cat.laneId == this.sectionForm.get('selectedLane').value) {
            this.laneForm.get('vehicleType').setValue(cat.categoryTypeId);
          }
        }
      });
    });
  }
  getSections() {
    let sectionParam;
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
      sectionParam = {};
    } else {
      sectionParam = {
        stationId: this.stationId
      };
    }
    this.appAdminService.getSections(sectionParam).subscribe(response => {
      this.sectionList = response.items;
      this.sectionData.data = this.sectionList;
      this.updateSelectedSection(this.sectionList[0]);
      this.getInstructions();
    });
  }
  getInstructions() {
    let instParam;
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
      instParam = {};
    } else {
      instParam = {
        sectionId: this.sectionForm.get('sectionNb').value
      };
    }
    this.appAdminService.getInspectionSectionInstructions(instParam).subscribe(response => {
      this.instructionList = response.items;
    });
  }
  addNewInst() {
    const instDets = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert,
      inspectionId: 1,
      sectionId: this.sectionForm.get('sectionNb').value,
      instructionNameEn: this.sectionForm.get('instName').value,
      instructionNameAr: this.sectionForm.get('instName').value,
      status: 1,
      createdBy: this.userId,
      updatedBy: this.userId
    };
    this.appAdminService.instructionOperation(instDets).subscribe(response => {
      this.newInst = false;
      this.sectionForm.get('instName').setValue('');
      this.getInstructions();
    });
  }
  getBooths() {
    let boothParam;
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert) {
      boothParam = {};
    } else {
      boothParam = {
        stationId: this.stationId
      };
    }
    this.appAdminService.getBooths(boothParam).subscribe(response => {
      this.boothList = response.items;
    });
  }
  getUser() {
    this.systemAdminService.getUsers({
      searchUsername: this.userForm.get('username').value
    }).subscribe(response => {
      this.users = response.items.users;
      this.userData.data = response.items.users;
    });
  }
  getUserPaged(page) {
    this.systemAdminService.getUsers({
      searchUsername: this.userForm.get('username').value,
      pageIndex: page,
      pageNumber: page
    }).subscribe(response => {
      this.users = response.items.users;
      this.userData.data = response.items.users;
    });
  }
  getUsers() {
    this.systemAdminService.getUsers({
      pageIndex: 0,
      pageNumber: 1
    }).subscribe(response => {
      this.users = response.items.users;
      this.userData.data = response.items.users;
      this.userData.data.sort((a, b) => a.userFullName.localeCompare(b.userFullName));
      this.onUserSelect(this.userData.data[0]);
      this.getBooths();
      this.getSections();
      this.getLane();
    });
    this.isEditUser = Array(this.users?.length).fill(false);
  }
  editUser(user, i) {
    this.isEditUser = Array(this.users?.length).fill(false);
    this.isEditUser[i] = true;
  }
  cancelUserEdit(index) {
    this.isEditUser[index] = false;
  }
  newUser() {
    const userData = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert,
      userId: this.selectedUserId,
      stationId: this.stationId,
      laneId: parseInt(this.userForm.get('lane').value),
      sectionId: parseInt(this.userForm.get('section').value),
      boothId: parseInt(this.userForm.get('booth').value),
      positionId: this.userAssign[0] ? this.userAssign[0].positionId : 1,
      isDeletedStatus: 0,
      createdBy: this.userId,
      updatedBy: this.userId
    };
    this.appAdminService.userAssignPositionOperation(userData).subscribe(response => {
      this.getUsers();
      this.newAssign = false;
    });
  }
  saveUserEdit(ua, index) {
    this.isEditUser[index] = false;
    const userData = {
      operationType: this.operation,
      assignId: ua.assignId,
      userId: ua.userId,
      stationId: this.stationId,
      laneId: parseInt(this.userForm.get('lane').value),
      sectionId: parseInt(this.userForm.get('section').value),
      boothId: parseInt(this.userForm.get('booth').value),
      positionId: ua.positionId,
      isDeletedStatus: 0,
      createdBy: this.userId,
      updatedBy: this.userId
    };
    this.appAdminService.userAssignPositionOperation(userData).subscribe(response => {
      this.getUsers();
    });
  }
  get totalPages() {
    if (this.users.length > this.itemsPerPage) {
      return Math.ceil(this.users.length / this.itemsPerPage);
    } else {
      return 1;
    }
  }
  pagesArray(totalPages) {
    return Array.from({
      length: totalPages
    }, (_, index) => index);
  }
  onSelectCategory(item) {
    if (this.selectedCategory.find(x => x.categoryId == item.categoryId)) {
      let index = this.selectedCategory.indexOf(item);
      if (index !== -1) this.selectedCategory.splice(index, 1);
    } else this.selectedCategory.push(item);
  }
  OnClickVehiclCategoryList(item) {
    if (this.selectedCategory.find(x => x.categoryId == item.categoryId)) {
      let index = this.selectedCategory.indexOf(item);
      if (index !== -1) this.selectedCategory.splice(index, 1);
    } else {
      item.vehicleCategoryEn = item.descriptionEn;
      this.selectedCategory.push(item);
    }
  }
  saveCategory() {
    debugger;
    const categoryOperation = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert,
      stationId: this.stationId,
      categoryId: parseInt(this.categForm.get('vehicleCategory').value),
      status: this.categForm.get('status').value,
      createdBy: this.userId,
      createdDate: new Date().toISOString(),
      updatedBy: this.userId,
      updatedDate: new Date().toISOString()
    };
    for (let i = 0; i < this.selectedCategory.length; i++) {
      categoryOperation.categoryId = this.selectedCategory[i].categoryId;
      this.appAdminService.stationCategoryOperation(categoryOperation).subscribe(response => {
        if (i + 1 === this.selectedCategory.length) {
          this.setActiveTab('lane');
          this.getLane();
        }
      });
    }
  }
  cancelCateg() {
    this.categForm.reset();
  }
  saveBooth() {
    const boothOperation = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert,
      boothId: parseInt(this.boothForm.get('boothNo').value),
      stationId: this.stationId,
      description: this.boothForm.get('boothName').value,
      status: 1
    };
    this.appAdminService.boothOperation(boothOperation).subscribe(response => {
      if (response.items) {
        this.cancelBooth();
        this.setActiveTab('assign');
        this.disableAssign = false;
        this.getUsers();
      }
    });
  }
  cancelBooth() {
    this.boothForm.reset();
  }
  updateSelectLane(lane) {
    this.cancelLane();
    this.currentLaneId = lane.laneId;
    this.LoadSectionsForSelectedLanes(lane.laneId);
    this.laneForm.get('laneName').setValue(lane.laneName);
    this.laneForm.get('laneType').setValue(lane.laneType);
    this.laneForm.get('laneClassification').setValue(lane.laneClassification);
    this.laneForm.get('status').setValue(parseInt(lane.status));
    this.selectedLaneValue = lane.laneId;
    this.getLaneCategServ();
  }
  LoadSectionsForSelectedLanes(laneId) {
    this.appAdminService.getSections({
      laneId: laneId
    }).subscribe(result => {
      this.sectionLanData.data = result.items;
      if (result.items.length > 0) {
        this.currentSectionId = result.items[0].sectionId;
        this.ShowDevices(result.items[0]);
      }
    });
  }
  ShowDevices(selectedSection) {
    this.currentSectionId = selectedSection.sectionId;
    this.appAdminService.GetsectionDevicesLst({
      sectionId: selectedSection.sectionId,
      stationId: this.stationId
    }).subscribe(result => {
      this.sectionDeviceData.data = result.items;
    });
  }
  createdeviceSectionForm() {
    this.deviceSectionForm = this.fb.group({
      deviceId: [null],
      vendorId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      stationId: [this.stationId, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      laneId: [this.currentLaneId, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      sectionId: [this.currentSectionId, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      ip: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required],
      status: [1, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.Validators.required]
    });
  }
  updateDeviceSection(item) {
    this.createdeviceSectionForm();
    this.loadVendors();
    this.isDeviceUpdate = true;
    this.deviceOperation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.update;
    this.deviceSectionForm.patchValue(item);
  }
  AddDeviceSection() {
    this.createdeviceSectionForm();
    this.loadVendors();
    this.isDeviceUpdate = true;
    this.deviceOperation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert;
    //this.deviceSectionForm.patchValue(item);
  }

  submitUpdates() {
    let request = this.deviceSectionForm.value;
    request.operationType = this.deviceOperation;
    request.updatedBy = this.userId;
    request.createdBy = this.userId;
    this.appAdminService.sectionDevicesDml(request).subscribe(result => {
      if (result.items > 0) {
        this.isDeviceUpdate = false;
        this.appAdminService.GetsectionDevicesLst({
          sectionId: this.currentSectionId,
          stationId: this.stationId
        }).subscribe(result => {
          this.sectionDeviceData.data = result.items;
        });
      }
    });
  }
  loadVendors() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.DeviceVendor).subscribe(types => {
      this.deviceVendors = types;
    });
  }
  updateSelectedSection(section) {
    this.sectionForm.get('selectedLane').setValue(section.laneId);
    this.sectionForm.get('sectionNb').setValue(section.sectionId);
    this.selectedStationDets = section;
  }
  onUserSelect(user) {
    this.appAdminService.getUserAssignPosition({
      userId: user.userId
    }).subscribe(response => {
      this.userAssign = response.items;
      this.selectedUserId = user.userId;
    });
  }
  saveLane() {
    const laneSave = {
      operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert,
      laneId: this.selectedLaneValue,
      stationId: this.stationId,
      laneName: this.laneForm.get('laneName').value,
      laneType: parseInt(this.laneForm.get('laneType').value),
      laneClassification: parseInt(this.laneForm.get('laneClassification').value),
      sectionSequenceFlag: 1,
      status: this.laneForm.get('status').value,
      createdBy: this.userId,
      updatedBy: this.userId
    };
    this.appAdminService.laneOperation(laneSave).subscribe(response => {
      this.setActiveTab('section');
      this.disableSection = false;
      this.getLane();
    });
  }
  cancelLane() {
    this.laneForm.reset();
  }
  addSection() {
    this.showSection = true;
  }
  saveSection() {
    let sectionOp;
    if (this.selectedStationDets) {
      sectionOp = {
        operationType: this.operation,
        laneId: this.selectedStationDets.laneId,
        stationId: this.stationId,
        laneName: this.selectedStationDets.laneName,
        laneType: this.selectedStationDets.laneType,
        laneClassification: this.selectedStationDets.laneClassification,
        sectionSequenceFlag: 0,
        status: 1,
        createdBy: this.userId,
        updatedBy: this.userId
      };
    } else {
      sectionOp = {
        operationType: src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert,
        laneId: this.sectionForm.get('selectedLane').value,
        stationId: this.stationId,
        laneName: this.sectionForm.get('selectedLane').value,
        laneType: 0,
        laneClassification: 0,
        sectionSequenceFlag: 0,
        status: 1,
        createdBy: this.userId,
        updatedBy: this.userId
      };
    }
    this.appAdminService.sectionOperation(sectionOp).subscribe(response => {
      this.cancelSection();
      this.setActiveTab('booth');
    });
  }
  cancelSection() {
    this.sectionNb = null;
    this.showSection = false;
  }
  saveDevice() {
    console.log(this.deviceForm.get('deviceSelected').value);
  }
  cancelDevice() {
    this.deviceForm.reset();
    this.deviceForm.get('deviceSelected').setValue([]);
  }
  static #_ = this.ɵfac = function StationOperationComponent_Factory(t) {
    return new (t || StationOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_5__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_6__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_7__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_8__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
    type: StationOperationComponent,
    selectors: [["app-station-operation"]],
    viewQuery: function StationOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵloadQuery"]()) && (ctx.saveStationModalButton = _t.first);
      }
    },
    decls: 487,
    vars: 132,
    consts: [[1, "row"], [1, "inspection-tab-menu"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "st-details", "aria-selected", "true", 1, "nav-link", "active", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "category", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "lane", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "section", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "booth", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "assign", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], ["id", "divtitle", 4, "ngIf"], [1, "inspection-tab-content"], [1, "col-12"], ["id", "myTabContent", 1, "tab-content"], ["id", "st-details", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3", "left"], ["type", "text", "formControlName", "stationNameAr", 1, "form-control"], ["class", "error-message", 4, "ngIf"], [1, "col-md-3", "col-lg-3", "right"], ["type", "time", "formControlName", "startTime", 1, "form-control"], ["type", "text", "formControlName", "stationNameEn", 1, "form-control"], ["type", "time", "formControlName", "endTime", 1, "form-control"], ["type", "text", "formControlName", "addressEn", 1, "form-control"], ["name", "ownerType", "formControlName", "classificationId", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "number", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "contactNo", 1, "form-control"], ["name", "ownerType", "formControlName", "reservationType", 1, "form-control"], ["formControlName", "vehicleTypes", 1, "form-control"], ["type", "number", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "slotsDuration", 1, "form-control"], [1, "col-md-2", "col-lg-3", "left"], ["type", "text", "formControlName", "descriptionAr", 1, "form-control"], ["type", "text", "formControlName", "latitude", "oninput", "this.value = this.value.replace(/[^0-9^.]/g, '');", 1, "form-control"], ["type", "text", "formControlName", "descriptionEn", 1, "form-control"], ["type", "text", "formControlName", "longitude", "oninput", "this.value = this.value.replace(/[^0-9^.]/g, '');", 1, "form-control"], ["formControlName", "areaId", 1, "form-control", 3, "change"], ["formControlName", "locationId", 1, "form-control"], [1, "st-label"], ["type", "text", "formControlName", "erpCode", 1, "form-control"], [1, "form-check"], ["type", "checkbox", "name", "lservice", "formControlName", "status", "id", "actid"], ["for", "actid", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal2", 3, "disabled", 4, "ngIf"], ["id", "category", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "id", "accCat", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "row", "justify-content-between"], [1, "col-lg-5"], ["class", "col-4", 4, "ngFor", "ngForOf"], [1, "col-lg-12"], [1, "col-lg-6"], [4, "ngFor", "ngForOf"], ["formControlName", "vehicleCategory", 3, "hidden", "ngModel", "ngModelChange"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmationModal2", 1, "btn", "btn-orange", 3, "disabled"], ["id", "lane", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["id", "accordionExample3", 1, "accordion", "section", "accordian"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search5", 1, "accordion-button"], ["id", "act-search5", "id", "accCat", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-2", "col-lg-3"], ["type", "text", "formControlName", "laneName", 1, "form-control"], ["formControlName", "laneType", 1, "form-control"], ["formControlName", "laneClassification", 1, "form-control"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search6", 1, "accordion-button"], ["id", "act-search6", "id", "accCat", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "selectedRow", "selectItemEvent"], ["id", "act-search6", "id", "accCat", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "selectItemEvent"], [4, "ngIf"], ["id", "section", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search7", 1, "accordion-button"], ["id", "act-search7", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["formControlName", "selectedLane", 1, "form-control"], [1, "col-md-3", "col-lg-3"], [1, "btn", "btn-orange", 3, "disabled", "click"], ["class", "row form-fields", 4, "ngIf"], ["class", "row", 4, "ngIf"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search8", 1, "accordion-button"], ["id", "act-search8", "id", "accCat", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["id", "accordionExample31", 1, "accordion", "section", "accordian"], ["id", "dinst", 4, "ngFor", "ngForOf"], [1, "btn", "btn-orange", 3, "click"], ["id", "device", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search9", 1, "accordion-button"], ["id", "act-search9", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["id", "booths", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search0", 1, "accordion-button"], ["id", "act-search0", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "number", "formControlName", "boothNo", 1, "form-control"], ["type", "text", "formControlName", "boothName", 1, "form-control"], ["type", "number", "formControlName", "boothDescEn", 1, "form-control"], ["type", "text", "formControlName", "boothDescAr", 1, "form-control"], ["id", "accordionExamplecam1", 1, "accordion", "section", "accordian"], ["id", "act-search0", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExamplecam1", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-3"], ["type", "text", "formControlName", "boothCam", 1, "form-control"], ["formControlName", "camLane", 1, "form-control"], ["formControlName", "camBooth", 1, "form-control"], ["id", "assign", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["type", "text", "formControlName", "username", 1, "form-control"], [1, "table", "table-bordered", "table-striped"], ["scope", "col"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], [1, "modal-footer", "text-center", "mt-2"], ["id", "confirmationModal2", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-body"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "class", "btn btn-outline-secondary border-0", "data-bs-dismiss", "modal", 3, "click", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveStationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["id", "divtitle"], [1, "error-message"], [3, "value"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal2", 1, "btn", "btn-orange", 3, "disabled"], [1, "col-4"], [1, "btn-radio"], ["type", "radio", "formControlName", "vehicleType", 3, "id", "value"], [1, "w-100", 3, "for"], ["class", "btn-radio", 4, "ngIf"], ["type", "radio", "formControlName", "status", 3, "id", "value"], [1, "btn-checkbox"], [1, "btn", "btn-outline-gray", 2, "margin-bottom", "2px", 3, "click"], [1, "btn", "btn-orange", 2, "margin-bottom", "2px", 3, "click"], [1, "col-lg-4"], ["type", "checkbox", "name", "laneService", "formControlName", "laneService", 3, "id", "value"], [1, "col-md-6"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "selectedRow", "updateItemEvent"], ["type", "text", "formControlName", "deviceId", 3, "hidden"], ["type", "text", "formControlName", "stationId", 3, "hidden"], ["type", "text", "formControlName", "laneId", 3, "hidden"], ["type", "text", "formControlName", "sectionId", 3, "hidden"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-4", "col-lg-4"], ["for", "iP"], ["type", "text", "id", "ip", "formControlName", "ip", 1, "form-control"], ["class", "validation-filed", 4, "ngIf"], ["for", "vendorId"], ["type", "text", "id", "vendorId", "formControlName", "vendorId", 1, "form-control"], [1, "endBt"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-orange", 2, "margin-top", "18px", 3, "disabled", "click"], [1, "validation-filed"], ["type", "number", "formControlName", "sectionNb", 1, "form-control"], ["id", "dinst"], [1, "bi", "bi-arrow-right-square-fill", 2, "font-size", "14px"], [1, "col-md-4"], ["type", "text", "formControlName", "instName", 1, "form-control"], ["formControlName", "booth", 1, "form-control"], ["formControlName", "section", 1, "form-control"], ["formControlName", "lane", 1, "form-control"], [2, "text-align", "center"], [1, "bi", "bi-x-circle-fill", "text-danger"], [1, "bi", "bi-check-circle-fill", "text-success", 3, "click"], ["class", "bi bi-pencil-fill", 3, "click", 4, "ngIf"], ["class", "bi bi-x-circle-fill text-danger", 4, "ngIf"], ["class", "bi bi-check-circle-fill text-success", 3, "click", 4, "ngIf"], [1, "bi", "bi-pencil-fill", 3, "click"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"]],
    template: function StationOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "ul", 3)(4, "li", 4)(5, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_5_listener() {
          return ctx.setActiveTab("st-details");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, " Main Information ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "li", 4)(8, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_8_listener() {
          return ctx.setActiveTab("category");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](9, " Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](10, "li", 4)(11, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_11_listener() {
          ctx.setActiveTab("lane");
          return ctx.getLane();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](12, " Lanes ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](13, "li", 4)(14, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_14_listener() {
          ctx.setActiveTab("section");
          return ctx.getSections();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](15, " Sections ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](16, "li", 4)(17, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_17_listener() {
          ctx.setActiveTab("booth");
          ctx.getBooths();
          return ctx.getLane();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](18, " Booths ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](19, "li", 4)(20, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_20_listener() {
          ctx.setActiveTab("assign");
          return ctx.getUsers();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](21, " User Assign ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](22, "div", 11)(23, "a", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_a_click_23_listener() {
          return ctx.backToStationsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](24, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](25, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](26, StationOperationComponent_div_26_Template, 3, 1, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](27, "div", 15)(28, "div", 0)(29, "div", 16)(30, "div", 17)(31, "div", 18)(32, "div", 0)(33, "form", 19)(34, "div", 20)(35, "div", 21)(36, "div", 22)(37, "div", 23)(38, "h2", 24)(39, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](40);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](41, "div", 26)(42, "div", 27)(43, "div", 28)(44, "div", 29)(45, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](46, "Station Arabic Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](47, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](48, StationOperationComponent_div_48_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](49, "div", 32)(50, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](51, "Start Time *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](52, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](53, StationOperationComponent_div_53_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](54, "div", 28)(55, "div", 29)(56, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](57, "Station English Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](58, "input", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](59, StationOperationComponent_div_59_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](60, "div", 32)(61, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](62, "End Time *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](63, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](64, StationOperationComponent_div_64_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](65, StationOperationComponent_div_65_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](66, "div", 28)(67, "div", 29)(68, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](69, "Address * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](70, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](71, StationOperationComponent_div_71_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](72, "div", 32)(73, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](74, "Classification *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](75, "select", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](76, StationOperationComponent_option_76_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](77, StationOperationComponent_div_77_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](78, "div", 28)(79, "div", 29)(80, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](81, "Contact No *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](82, "input", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](83, StationOperationComponent_div_83_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](84, "div", 32)(85, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](86, "Reservation Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](87, "select", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](88, StationOperationComponent_option_88_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](89, StationOperationComponent_div_89_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](90, "div", 28)(91, "div", 29)(92, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](93, "Vehicle Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](94, "select", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](95, StationOperationComponent_option_95_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](96, StationOperationComponent_div_96_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](97, "div", 32)(98, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](99, "Slots Duration");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](100, "input", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](101, StationOperationComponent_div_101_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](102, "div", 28)(103, "div", 43)(104, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](105, "Arabic Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](106, "input", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](107, StationOperationComponent_div_107_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](108, "div", 32)(109, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](110, "Latitude");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](111, "input", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](112, StationOperationComponent_div_112_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](113, "div", 28)(114, "div", 29)(115, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](116, " English Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](117, "input", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](118, StationOperationComponent_div_118_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](119, "div", 32)(120, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](121, "Longtiude");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](122, "input", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](123, StationOperationComponent_div_123_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](124, "div", 28)(125, "div", 29)(126, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](127, "Area");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](128, "select", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("change", function StationOperationComponent_Template_select_change_128_listener($event) {
          return ctx.onChangeLocation($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](129, StationOperationComponent_option_129_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](130, StationOperationComponent_div_130_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](131, "div", 32)(132, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](133, "Location");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](134, "select", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](135, StationOperationComponent_option_135_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](136, StationOperationComponent_div_136_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](137, "div", 28)(138, "div", 29)(139, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](140, " Site Number (ERP Code) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](141, "input", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](142, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](143, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](144, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](145, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](146, "label", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](147, " \u00A0 Active ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](148, StationOperationComponent_div_148_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](149, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](150, StationOperationComponent_button_150_Template, 2, 1, "button", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](151, "div", 57)(152, "div", 0)(153, "form", 19)(154, "div", 20)(155, "div", 21)(156, "div", 22)(157, "div", 23)(158, "h2", 24)(159, "button", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](160, " Station Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](161, "div", 59)(162, "div", 27)(163, "div", 60)(164, "div", 61)(165, "div", 0)(166, "div", 16)(167, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](168, " Vehicle Category Type * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](169, StationOperationComponent_div_169_Template, 5, 4, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](170, "div", 60)(171, "div", 61)(172, "div", 0)(173, "div", 16)(174, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](175, " Status * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](176, StationOperationComponent_div_176_Template, 2, 1, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](177, "div", 28)(178, "div", 63)(179, "div", 0)(180, "div", 16)(181, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](182, " Vehicle Categories List * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](183, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](184, StationOperationComponent_div_184_Template, 4, 1, "div", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](185, "div", 64)(186, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](187, " Selected Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](188, StationOperationComponent_div_188_Template, 4, 1, "div", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](189, "input", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ngModelChange", function StationOperationComponent_Template_input_ngModelChange_189_listener($event) {
          return ctx.selectedCategory = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](190, "div", 0)(191, "div", 67)(192, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_192_listener() {
          return ctx.cancelCateg();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](193, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](194, "button", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](195, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](196, "div", 70)(197, "div", 0)(198, "form", 19)(199, "div", 20)(200, "div", 21)(201, "div", 71)(202, "div", 23)(203, "h2", 24)(204, "button", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](205);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](206, "div", 73)(207, "div", 27)(208, "div", 28)(209, "div", 74)(210, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](211, " Lane Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](212, "input", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](213, "div", 74)(214, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](215, " Lane Type * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](216, "select", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](217, StationOperationComponent_option_217_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](218, "div", 74)(219, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](220, " Lane Classification * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](221, "select", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](222, StationOperationComponent_option_222_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](223, "div", 28)(224, "div", 64)(225, "div", 0)(226, "div", 16)(227, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](228, " Lane Service Types * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](229, StationOperationComponent_div_229_Template, 5, 4, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](230, "div", 60)(231, "div", 61)(232, "div", 0)(233, "div", 16)(234, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](235, "Vehicle Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](236, StationOperationComponent_div_236_Template, 5, 4, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](237, "div", 60)(238, "div", 61)(239, "div", 0)(240, "div", 16)(241, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](242, " Status * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](243, StationOperationComponent_div_243_Template, 2, 1, "div", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](244, "div", 0)(245, "div", 67)(246, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_246_listener() {
          return ctx.cancelLane();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](247, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](248, "button", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](249, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](250, "div", 20)(251, "div", 21)(252, "div", 71)(253, "div", 23)(254, "h2", 24)(255, "button", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](256, " Station Lanes ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](257, "div", 80)(258, "div", 27)(259, "app-data-table", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectItemEvent", function StationOperationComponent_Template_app_data_table_selectItemEvent_259_listener($event) {
          return ctx.updateSelectLane($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](260, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](261, "h2", 24)(262, "button", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](263, " Lane Sections ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](264, "div", 82)(265, "div", 27)(266, "app-data-table", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectItemEvent", function StationOperationComponent_Template_app_data_table_selectItemEvent_266_listener($event) {
          return ctx.ShowDevices($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](267, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](268, StationOperationComponent_div_268_Template, 11, 5, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](269, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](270, StationOperationComponent_div_270_Template, 22, 9, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](271, "div", 85)(272, "div", 0)(273, "form", 19)(274, "div", 20)(275, "div", 21)(276, "div", 22)(277, "div", 23)(278, "h2", 24)(279, "button", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](280);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](281, "div", 87)(282, "div", 27)(283, "div", 28)(284, "div", 74)(285, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](286, " Choose Lane * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](287, "select", 88);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](288, StationOperationComponent_option_288_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](289, "div", 28)(290, "div", 89)(291, "button", 90);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_291_listener() {
          return ctx.addSection();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](292, " + Add Section ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](293, StationOperationComponent_div_293_Template, 5, 0, "div", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](294, StationOperationComponent_div_294_Template, 6, 1, "div", 92);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](295, "div", 20)(296, "div", 21)(297, "div", 71)(298, "div", 23)(299, "h2", 24)(300, "button", 93);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](301, " Station Sections ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](302, "div", 94)(303, "div", 27)(304, "app-data-table", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectItemEvent", function StationOperationComponent_Template_app_data_table_selectItemEvent_304_listener($event) {
          return ctx.updateSelectedSection($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](305, "div", 20)(306, "div", 21)(307, "div", 95)(308, "div", 23)(309, "h2", 24)(310, "button", 93);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](311, " Section Instructions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](312, StationOperationComponent_div_312_Template, 3, 1, "div", 96);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](313, "br")(314, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](315, "div", 28)(316, "div", 16)(317, "button", 97);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_317_listener() {
          return ctx.newInst = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](318, " + New Instruction ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](319, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](320, StationOperationComponent_div_320_Template, 6, 0, "div", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](321, "div", 98)(322, "div", 0)(323, "form", 19)(324, "div", 20)(325, "div", 21)(326, "div", 22)(327, "div", 23)(328, "h2", 24)(329, "button", 99);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](330, " Station Devices ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](331, "div", 100)(332, "div", 27)(333, "div", 28)(334, "div", 64)(335, "div", 0)(336, "div", 16)(337, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](338, " Devices ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](339, "div", 0)(340, "div", 67)(341, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_341_listener() {
          return ctx.cancelDevice();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](342, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](343, "button", 97);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_343_listener() {
          return ctx.saveDevice();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](344, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](345, "div", 101)(346, "div", 0)(347, "form", 19)(348, "div", 20)(349, "div", 21)(350, "div", 22)(351, "div", 23)(352, "h2", 24)(353, "button", 102);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](354, " Station Booths ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](355, "div", 103)(356, "div", 27)(357, "div", 28)(358, "div", 74)(359, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](360, " Booth No * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](361, "input", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](362, "div", 74)(363, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](364, " Booth Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](365, "input", 105);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](366, "div", 28)(367, "div", 74)(368, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](369, " Booth Description En ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](370, "input", 106);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](371, "div", 74)(372, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](373, " Booth Description Ar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](374, "input", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](375, "div", 0)(376, "div", 67)(377, "button", 68);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_377_listener() {
          return ctx.cancelBooth();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](378, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](379, "button", 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](380, " Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](381, "div", 20)(382, "div", 21)(383, "div", 108)(384, "div", 23)(385, "h2", 24)(386, "button", 102);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](387, " Booth Camera ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](388, "div", 109)(389, "div", 27)(390, "div", 28)(391, "div", 110)(392, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](393, " Camera ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](394, "input", 111);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](395, "div", 28)(396, "div", 110)(397, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](398, "Lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](399, "select", 112);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](400, StationOperationComponent_option_400_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](401, "div", 110)(402, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](403, "Booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](404, "select", 113);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](405, StationOperationComponent_option_405_Template, 2, 2, "option", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](406, "div", 114)(407, "div", 0)(408, "form", 19)(409, "div", 20)(410, "div", 21)(411, "div", 22)(412, "div", 23)(413, "h2", 24)(414, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](415, " Station - Assign Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](416, "div", 26)(417, "div", 27)(418, "div", 28)(419, "label", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](420, " Username ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](421, "div", 110);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](422, "input", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](423, "app-data-table", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("selectItemEvent", function StationOperationComponent_Template_app_data_table_selectItemEvent_423_listener($event) {
          return ctx.onUserSelect($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](424, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](425, "button", 97);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_425_listener() {
          return ctx.newAssign = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](426, " + Assign New Positions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](427, "br")(428, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](429, "table", 116)(430, "thead")(431, "tr")(432, "th", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](433, "Booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](434, "th", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](435, "Section");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](436, "th", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](437, "Lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](438, "th", 117);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](439, "Action");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](440, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](441, StationOperationComponent_tr_441_Template, 15, 3, "tr", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](442, StationOperationComponent_tr_442_Template, 16, 9, "tr", 65);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](443, "div", 118)(444, "ul", 119)(445, "li", 120)(446, "a", 121);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_a_click_446_listener() {
          return ctx.currentPage = ctx.currentPage - 1;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](447, "i", 122);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](448, StationOperationComponent_li_448_Template, 3, 4, "li", 123);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](449, "li", 120)(450, "a", 121);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function StationOperationComponent_Template_a_click_450_listener() {
          ctx.currentPage = ctx.currentPage + 1;
          return ctx.getUserPaged(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](451, "i", 124);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](452, "div", 125);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](453, "div", 126)(454, "div", 127)(455, "div", 128);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](456, "div", 129);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](457, "div", 130)(458, "div", 0)(459, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](460, "img", 131);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](461, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](462, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](463, StationOperationComponent_div_463_Template, 2, 0, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](464, StationOperationComponent_div_464_Template, 2, 0, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](465, StationOperationComponent_div_465_Template, 2, 0, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](466, StationOperationComponent_div_466_Template, 2, 0, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](467, StationOperationComponent_div_467_Template, 2, 0, "div", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](468, "br")(469, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](470, "button", 132);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](471, "img", 133);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](472, StationOperationComponent_button_472_Template, 2, 0, "button", 134);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](473, StationOperationComponent_button_473_Template, 2, 0, "button", 134);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](474, StationOperationComponent_button_474_Template, 2, 0, "button", 134);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](475, StationOperationComponent_button_475_Template, 2, 0, "button", 134);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](476, StationOperationComponent_button_476_Template, 2, 0, "button", 134);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](477, "button", 135, 136);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](479, "div", 137)(480, "div", 138)(481, "div", 128)(482, "div", 129)(483, "h1", 139);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](484, "img", 140);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](485);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](486, "button", 141);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "st-details");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("pointer-events", ctx.disableNav ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "category");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("pointer-events", ctx.disableNav ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("pointer-events", ctx.disableSection && ctx.disableNav ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("pointer-events", ctx.disableNav ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵstyleProp"]("pointer-events", ctx.disableAssign && ctx.disableNav ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "assign");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.insert);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "st-details");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.stationForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx.title, " Station ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("stationNameAr").hasError("required") && ctx.stationForm.get("stationNameAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("startTime").hasError("required") && ctx.stationForm.get("startTime").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("stationNameEn").hasError("required") && ctx.stationForm.get("stationNameEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("endTime").hasError("required") && ctx.stationForm.get("endTime").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("endTime").hasError("invalidTimeRange") || ctx.stationForm.get("startTime").hasError("invalidTimeRange"));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("addressEn").hasError("required") && ctx.stationForm.get("addressEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.classifications);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("classificationId").hasError("required") && ctx.stationForm.get("classificationId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("contactNo").hasError("required") && ctx.stationForm.get("contactNo").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.reservationTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("reservationType").hasError("required") && ctx.stationForm.get("reservationType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.vehicleTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("vehicleTypes").hasError("required") && ctx.stationForm.get("vehicleTypes").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("slotsDuration").hasError("required") && ctx.stationForm.get("slotsDuration").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("descriptionAr").hasError("required") && ctx.stationForm.get("descriptionAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("latitude").hasError("latitude") && ctx.stationForm.get("latitude").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("descriptionEn").hasError("required") && ctx.stationForm.get("descriptionEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("longitude").hasError("longitude") && ctx.stationForm.get("longitude").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.areaLst);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("vehicleTypes").hasError("required") && ctx.stationForm.get("vehicleTypes").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.locationLst);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("locationId").hasError("locationId") && ctx.stationForm.get("locationId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.stationForm.get("status").hasError("required") && ctx.stationForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "category");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.categForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.vehicleTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.statusList);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.vehicleCategories);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.selectedCategory);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hidden", true)("ngModel", ctx.selectedCategory);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.categForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.laneForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx.title, " Station Lanes ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.laneTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.laneClassifications);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.laneServices);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.vehicleTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.statusList);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.laneForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("tblHeaders", ctx.laneTbHeaders)("tblValues", ctx.laneData.data ? ctx.laneData : null)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("selectedRow", ctx.laneData.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("tblHeaders", ctx.sectionLTbHeaders)("tblValues", ctx.sectionLanData.data ? ctx.sectionLanData : null)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.sectionLanData.data.length);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.isDeviceUpdate);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.sectionForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx.title, " Station Sections ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.laneList);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.sectionForm.get("selectedLane").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.showSection);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.showSection);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("tblHeaders", ctx.sectionTbHeaders)("tblValues", ctx.sectionData)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("selectedRow", ctx.sectionData.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.instructionList);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.newInst);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.deviceForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.boothForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](32);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("disabled", !ctx.boothForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.laneList);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.boothList);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("active", ctx.activeTab == "assign");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("formGroup", ctx.userForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("tblHeaders", ctx.userHeader)("tblValues", ctx.userData)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("selectedRow", ctx.userData.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.newAssign);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.userAssign);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](128, _c2, ctx.currentPage == 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx.pagesArray(ctx.totalPages));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpureFunction1"](130, _c2, ctx.currentPage * ctx.itemsPerPage >= ctx.totalPages));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "st-details");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "category");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "st-details");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "category");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "section");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.activeTab == "booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_13__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_13__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_13__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_9__.DataTableComponent],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n.left[_ngcontent-%COMP%] {\r\n    margin-left: 30px;\r\n}\r\n\r\n.right[_ngcontent-%COMP%] {\r\n    margin-left: 230px;\r\n}\r\n\r\n#catglist[_ngcontent-%COMP%] {\r\n    margin-top: 5px;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked, .btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:not(:checked) {\r\n    position: absolute;\r\n    left: -9999px;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked + label[_ngcontent-%COMP%], .btn-checkbox[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]:hover {\r\n    color: #fff;\r\n    background-color: #F89828;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:disabled + label[_ngcontent-%COMP%] {\r\n    opacity: 0.7;\r\n    cursor: not-allowed;\r\n    pointer-events: none;\r\n}\r\n\r\n.btn-checkbox[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\r\n    border-radius: 4px;\r\n    background: #F6F6F7;\r\n    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.25);\r\n    position: relative;\r\n    transition: all 0.5s;\r\n    color: #34312D;\r\n    font-size: 16px;\r\n    padding: 8px 20px;\r\n    min-width: 125px;\r\n    text-align: center;\r\n    float: left;\r\n    margin-top: 12px;\r\n    margin-right: 17px;\r\n    font-weight: 500;\r\n    margin-bottom: 5px;\r\n}\r\n\r\n.bi-pencil-fill[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n    cursor: pointer;\r\n    margin-right: 1%;\r\n    padding: 3% 3% 1.8% 3%;\r\n}\r\n\r\n.bi-check-circle-fill[_ngcontent-%COMP%], .bi-x-circle-fill[_ngcontent-%COMP%] {\r\n    font-size: 20px;\r\n    padding: 3% 3% 1.8% 3%;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: #F89828;\r\n    font-weight: bold;\r\n}\r\n\r\n.pagination-container[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin-left: 490px;\r\n}\r\n\r\n.page-item[_ngcontent-%COMP%] {\r\n    margin: 0 2px;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n    padding: 5px 5px;\r\n    text-decoration: none;\r\n}\r\n\r\n#pagesId[_ngcontent-%COMP%] {\r\n    background-color: #F89828;\r\n    color: white;\r\n}\r\n\r\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    color: #F89828;\r\n    font-weight: bold;\r\n    border-color: #F89828;\r\n}\r\n\r\n#divtitle[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n\r\n}\r\n\r\n#dinst[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3Ivc3RhdGlvbi1vcGVyYXRpb24vc3RhdGlvbi1vcGVyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGVBQWU7QUFDbkI7O0FBRUE7O0lBRUksa0JBQWtCO0lBQ2xCLGFBQWE7QUFDakI7O0FBRUE7O0lBRUksV0FBVztJQUNYLHlCQUF5QjtJQUN6QixlQUFlO0FBQ25COztBQUVBO0lBQ0ksWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixvQkFBb0I7QUFDeEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLCtDQUErQztJQUMvQyxrQkFBa0I7SUFDbEIsb0JBQW9CO0lBQ3BCLGNBQWM7SUFDZCxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtBQUMxQjs7QUFFQTs7SUFFSSxlQUFlO0lBQ2Ysc0JBQXNCO0FBQzFCOztBQUVBO0lBQ0ksV0FBVztJQUNYLHlCQUF5QjtJQUN6QixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsY0FBYztJQUNkLGlCQUFpQjtJQUNqQixxQkFBcUI7QUFDekI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxrQkFBa0I7O0FBRXRCOztBQUVBO0lBQ0ksY0FBYztBQUNsQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b24sXHJcbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24ge1xyXG4gICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xyXG4gICAgYXBwZWFyYW5jZTogbm9uZTtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufVxyXG5cclxuLmxlZnQge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDMwcHg7XHJcbn1cclxuXHJcbi5yaWdodCB7XHJcbiAgICBtYXJnaW4tbGVmdDogMjMwcHg7XHJcbn1cclxuXHJcbiNjYXRnbGlzdCB7XHJcbiAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbn1cclxuXHJcbi5idG4tY2hlY2tib3ggaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOmNoZWNrZWQsXHJcbi5idG4tY2hlY2tib3ggaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOm5vdCg6Y2hlY2tlZCkge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogLTk5OTlweDtcclxufVxyXG5cclxuLmJ0bi1jaGVja2JveCBpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl06Y2hlY2tlZCtsYWJlbCxcclxuLmJ0bi1jaGVja2JveCBsYWJlbDpob3ZlciB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4Mjg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tY2hlY2tib3ggaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdOmRpc2FibGVkK2xhYmVsIHtcclxuICAgIG9wYWNpdHk6IDAuNztcclxuICAgIGN1cnNvcjogbm90LWFsbG93ZWQ7XHJcbiAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcclxufVxyXG5cclxuLmJ0bi1jaGVja2JveCBsYWJlbCB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRjZGNkY3O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDFweCA0cHggMHB4IHJnYmEoMCwgMCwgMCwgMC4yNSk7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC41cztcclxuICAgIGNvbG9yOiAjMzQzMTJEO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgcGFkZGluZzogOHB4IDIwcHg7XHJcbiAgICBtaW4td2lkdGg6IDEyNXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxN3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG5cclxuLmJpLXBlbmNpbC1maWxsIHtcclxuICAgIGNvbG9yOiAjRjg5ODI4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxJTtcclxuICAgIHBhZGRpbmc6IDMlIDMlIDEuOCUgMyU7XHJcbn1cclxuXHJcbi5iaS1jaGVjay1jaXJjbGUtZmlsbCxcclxuLmJpLXgtY2lyY2xlLWZpbGwge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgcGFkZGluZzogMyUgMyUgMS44JSAzJTtcclxufVxyXG5cclxudGgge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uLWNvbnRhaW5lciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tbGVmdDogNDkwcHg7XHJcbn1cclxuXHJcbi5wYWdlLWl0ZW0ge1xyXG4gICAgbWFyZ2luOiAwIDJweDtcclxufVxyXG5cclxuLnBhZ2UtbGluayB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nOiA1cHggNXB4O1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcblxyXG4jcGFnZXNJZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG5saS5wYWdlLWl0ZW0uYWN0aXZlICNwYWdlc0lkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgY29sb3I6ICNGODk4Mjg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGJvcmRlci1jb2xvcjogI0Y4OTgyODtcclxufVxyXG5cclxuI2RpdnRpdGxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLm1vZGFsLWNvbnRlbnQge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxufVxyXG5cclxuI2RpbnN0IHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 51044:
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/station-services/station-services.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationServicesComponent": () => (/* binding */ StationServicesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);











const _c0 = ["saveServiceModalButton"];
const _c1 = ["CheckServiceActiveDeactiveModalBtn"];
class StationServicesComponent {
  constructor(systemAdmin, router, sideNav, appAdmin, lookupServ) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.sideNav = sideNav;
    this.appAdmin = appAdmin;
    this.lookupServ = lookupServ;
    this.services = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.serviceHeaders = [{
      JsonPropName: 'serviceName',
      showName: 'Service Name'
    }, {
      JsonPropName: 'descriptionEn',
      showName: 'Description'
    }, {
      JsonPropName: 'prefix',
      showName: 'Prefix'
    }, {
      JsonPropName: 'serviceClassificationEn',
      showName: 'Classification'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 94);
    this.stationsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null)
    });
    this.bindChange();
    this.loadServices();
  }
  loadServices() {
    this.appAdmin.getStationInpsectionServiceTypes({}).subscribe(response => {
      console.log(response.items);
      this.services.data = response.items;
    });
  }
  bindChange() {
    this.stationsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchStations(change);
    });
  }
  viewSelectedService(item) {
    this.router.navigate(['app-admin/services/view', item.lkCode]);
  }
  onModelStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "model");
    this.CheckServiceActiveDeactiveModalBtn.nativeElement.click();
  }
  onServiceStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "station");
    this.CheckServiceActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmServiceActiveDeactiveCahnge() {
    let ManufacOperation; //= new StationOperation(); 
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.stationOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveServiceModalButton.nativeElement.click();
      }
    });
  }
  onCancelServiceActiveDeactiveChange() {
    this.loadServices();
  }
  updateSelectedService(item) {
    this.router.navigate(['app-admin/service/edit', item.serviceId]);
  }
  searchStations(searchValue) {
    this.appAdmin.getStationInpsectionServiceTypes({
      serviceName: searchValue
    }).subscribe(result => {
      this.services.data = result.items;
    });
  }
  addNewService() {
    this.router.navigate(['app-admin/service/new']);
  }
  onServiceSelection(item) {
    this.selectedStationId = item.stationsId;
  }
  setActiveTab(tab) {
    this.activeTab = tab;
  }
  static #_ = this.ɵfac = function StationServicesComponent_Factory(t) {
    return new (t || StationServicesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_4__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_5__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: StationServicesComponent,
    selectors: [["app-station-services"]],
    viewQuery: function StationServicesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.saveServiceModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.CheckSeviceActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.CheckServiceActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 62,
    vars: 7,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "viewItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveStationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#stationConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckStationActiveDeactiveModalBtn", ""], ["id", "stationConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"]],
    template: function StationServicesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](13, " Services ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function StationServicesComponent_Template_button_click_19_listener() {
          return ctx.addNewService();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](20, " Add New Service ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 13)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](28, "Service Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](31, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](32, "app-data-table", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("updateItemEvent", function StationServicesComponent_Template_app_data_table_updateItemEvent_32_listener($event) {
          return ctx.updateSelectedService($event);
        })("viewItemEvent", function StationServicesComponent_Template_app_data_table_viewItemEvent_32_listener($event) {
          return ctx.viewSelectedService($event);
        })("selectItemEvent", function StationServicesComponent_Template_app_data_table_selectItemEvent_32_listener($event) {
          return ctx.onServiceSelection($event);
        })("checkboxEvent", function StationServicesComponent_Template_app_data_table_checkboxEvent_32_listener($event) {
          return ctx.onServiceStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](33, "button", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](35, "div", 23)(36, "div", 24)(37, "div", 25)(38, "div", 26)(39, "h1", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](40, "img", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](41);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](42, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](43, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](45, "div", 32)(46, "div", 33)(47, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](48, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](49, "div", 34)(50, "div", 1)(51, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](52, "img", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](53, "div", 3)(54, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](56, "br")(57, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](58, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function StationServicesComponent_Template_button_click_58_listener() {
          return ctx.onCancelServiceActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](59, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](60, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function StationServicesComponent_Template_button_click_60_listener() {
          return ctx.onConfirmServiceActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](61, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.stationsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("tblHeaders", ctx.serviceHeaders)("tblValues", ctx.services)("isDeleteOperationEnabled", false)("selectedRow", ctx.services.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_6__.DataTableComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 55286:
/*!*****************************************************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/system-blacklist/system-blacklist-operation/system-blacklist-operation.component.ts ***!
  \*****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemBlacklistOperationComponent": () => (/* binding */ SystemBlacklistOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/SystemBlacklistOperation */ 1485);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);











const _c0 = ["saveSystemBlacklistModalButton"];
function SystemBlacklistOperationComponent_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", type_r17.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", type_r17.lkValueEname, " ");
  }
}
function SystemBlacklistOperationComponent_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_span_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, "* ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_span_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, "* ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_option_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", type_r18.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", type_r18.lkValueEname, " ");
  }
}
function SystemBlacklistOperationComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_span_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, "* ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_div_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_span_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, "* ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_div_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_span_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, "* ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_div_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_div_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_div_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function SystemBlacklistOperationComponent_button_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "button", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function SystemBlacklistOperationComponent_button_66_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r20);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r19.createUpdateSystemBlacklist());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx_r15.systemBlacklistForm.valid);
  }
}
class SystemBlacklistOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, vehicleService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.vehicleService = vehicleService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.isCustomerEntryType = false;
    this.isReportEntryType = false;
    this.isVehicleEntryType = false;
    this.plateTypes = [];
    this.entryTypes = [];
  }
  ngOnInit() {
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.loadLookups();
    this.checkViewInsertUpdateMode();
    this.createSystemBlacklistForm();
    this.bindChanges();
  }
  bindChanges() {
    let Form = this.systemBlacklistForm.controls;
    // Form.plateNo.valueChanges.subscribe(change=>{
    //   if(Form.plateNo.value  != null && Form.plateType.value != null)
    //    this.getVehicleDetails()
    // })
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) Form.plateType.valueChanges.subscribe(change => {
      if (Form.plateNo.value != null && Form.plateType.value != null) this.getVehicleDetails();
    });
    Form.entryType.valueChanges.subscribe(change => {
      Form.pid.clearValidators();
      Form.plateNo.clearValidators();
      Form.plateType.clearValidators();
      Form.vinNo.clearValidators();
      Form.reportNumber.clearValidators();
      if (change == src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_0__.BlackListEntryType.Customer) {
        this.isCustomerEntryType = true;
        this.isVehicleEntryType = false;
        this.isReportEntryType = false;
        Form.pid.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]);
      } else if (change == src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_0__.BlackListEntryType.InspectionReport) {
        this.isCustomerEntryType = false;
        this.isVehicleEntryType = false;
        this.isReportEntryType = true;
        Form.reportNumber.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]);
      } else if (change == src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_0__.BlackListEntryType.Vehicle) {
        this.isCustomerEntryType = false;
        this.isVehicleEntryType = true;
        this.isReportEntryType = false;
        Form.vinNo.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]);
        Form.plateNo.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]);
        Form.plateType.setValidators([_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]);
      }
      Form.pid.updateValueAndValidity();
      Form.plateNo.updateValueAndValidity();
      Form.plateType.updateValueAndValidity();
      Form.vinNo.updateValueAndValidity();
      Form.reportNumber.updateValueAndValidity();
    });
  }
  getVehicleDetails() {
    let Form = this.systemBlacklistForm.controls;
    const vehDetails = {
      plateNo: Form.plateNo?.value,
      plateType: Form.plateType?.value,
      stationId: this.stationId
    };
    this.vehicleService.getVehicleDetails(vehDetails).subscribe(res => {
      this.systemBlacklistForm.patchValue({
        pid: res.items.ownerPID ? res.items.ownerPID.toString() : '',
        vinNo: res.items.vinNo
      }, {
        emitEvent: false
      });
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.entryId = +params['entryId'];
      if (this.entryId > 0) {
        this.loadSystemBlacklist();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadSystemBlacklist() {
    this.systemAdminService.getSystemBlacklist({
      entryId: this.entryId
    }).subscribe(result => {
      this.systemBlacklistForm.patchValue(result.items[0]);
    });
  }
  loadLookups() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.plateType).subscribe(types => this.plateTypes = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.entryType).subscribe(types => this.entryTypes = types);
  }
  createSystemBlacklistForm() {
    this.systemBlacklistForm = this.fb.group({
      entryType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      pid: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      plateNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      plateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      vinNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      reason: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      reportNumber: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
    });
  }
  createUpdateSystemBlacklist() {
    let blackListFormValue = this.systemBlacklistForm?.value;
    let systemBlacklist = new src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_0__.SystemBlacklistOperation();
    systemBlacklist = blackListFormValue;
    systemBlacklist.status = blackListFormValue.status ? 1 : 0;
    systemBlacklist.pid = blackListFormValue.pid;
    systemBlacklist.operationType = this.operation;
    if (this.entryId > 0) systemBlacklist.entryId = this.entryId;
    this.systemAdminService.systemBlacklistOperations(systemBlacklist).subscribe(result => {
      if (result.items > 0) this.saveSystemBlacklistModalButton.nativeElement.click();
    });
  }
  backToSystemBlacklistsList() {
    this.router.navigate(['app-admin/system-blacklist']);
  }
  static #_ = this.ɵfac = function SystemBlacklistOperationComponent_Factory(t) {
    return new (t || SystemBlacklistOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_5__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: SystemBlacklistOperationComponent,
    selectors: [["app-system-blacklist-operation"]],
    viewQuery: function SystemBlacklistOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveSystemBlacklistModalButton = _t.first);
      }
    },
    decls: 81,
    vars: 21,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3"], ["for", ""], ["name", "entryType", "formControlName", "entryType", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "error-message", 4, "ngIf"], [1, "col-md-3", "col-lg-3"], [4, "ngIf"], ["type", "number", "formControlName", "plateNo", 1, "form-control"], ["name", "plateType", "formControlName", "plateType", 1, "form-control"], ["type", "text", "formControlName", "vinNo", 1, "form-control"], ["type", "text", "formControlName", "pid", 1, "form-control"], ["type", "text", "formControlName", "reportNumber", 1, "form-control"], ["type", "text", "formControlName", "reason", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveSystemBlacklistModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [3, "value"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function SystemBlacklistOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, "Entry Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "select", 14)(17, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](18, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](19, SystemBlacklistOperationComponent_option_19_Template, 2, 2, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](20, SystemBlacklistOperationComponent_div_20_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "div", 18)(22, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](23, "Plate No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](24, SystemBlacklistOperationComponent_span_24_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](25, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](26, SystemBlacklistOperationComponent_div_26_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "div", 12)(28, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](29, "Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](30, SystemBlacklistOperationComponent_span_30_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "select", 21)(32, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](33, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](34, SystemBlacklistOperationComponent_option_34_Template, 2, 2, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](35, SystemBlacklistOperationComponent_div_35_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](36, "div", 18)(37, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](38, "VIN No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](39, SystemBlacklistOperationComponent_span_39_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](40, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](41, SystemBlacklistOperationComponent_div_41_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "div", 18)(43, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](44, "PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](45, SystemBlacklistOperationComponent_span_45_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](46, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](47, SystemBlacklistOperationComponent_div_47_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "div", 12)(49, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](50, "Report Number ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](51, SystemBlacklistOperationComponent_span_51_Template, 2, 0, "span", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](52, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](53, SystemBlacklistOperationComponent_div_53_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "div", 12)(55, "label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](56, "Reason *");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](57, "input", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](58, SystemBlacklistOperationComponent_div_58_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "div", 26)(60, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](61, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](62, "label", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](63, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](64, SystemBlacklistOperationComponent_div_64_Template, 2, 0, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](65, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](66, SystemBlacklistOperationComponent_button_66_Template, 2, 1, "button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](67, "div", 32)(68, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function SystemBlacklistOperationComponent_Template_button_click_68_listener() {
          return ctx.backToSystemBlacklistsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](69, "i", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](70, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](71, "button", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](73, "div", 37)(74, "div", 38)(75, "div", 39)(76, "div", 40)(77, "h1", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](78, "img", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](79);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](80, "button", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.systemBlacklistForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.title, " Blacklist Item ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.entryTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("entryType").hasError("required") && ctx.systemBlacklistForm.get("entryType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.isVehicleEntryType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("plateNo").hasError("required") && ctx.systemBlacklistForm.get("plateNo").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.isVehicleEntryType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("plateType").hasError("required") && ctx.systemBlacklistForm.get("plateType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.isVehicleEntryType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("vinNo").hasError("required") && ctx.systemBlacklistForm.get("vinNo").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.isCustomerEntryType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("pid").hasError("required") && ctx.systemBlacklistForm.get("pid").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.isReportEntryType);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("reportNumber").hasError("required") && ctx.systemBlacklistForm.get("reportNumber").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("reason").hasError("required") && ctx.systemBlacklistForm.get("reason").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.systemBlacklistForm.get("status").hasError("required") && ctx.systemBlacklistForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3Ivc3lzdGVtLWJsYWNrbGlzdC9zeXN0ZW0tYmxhY2tsaXN0LW9wZXJhdGlvbi9zeXN0ZW0tYmxhY2tsaXN0LW9wZXJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 12820:
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/system-blacklist/system-blacklist.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemBlacklistComponent": () => (/* binding */ SystemBlacklistComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/SystemBlacklistOperation */ 1485);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);












const _c0 = ["saveSystemBlacklistModalButton"];
const _c1 = ["CheckSystemBlacklistActiveDeactiveModalBtn"];
function SystemBlacklistComponent_option_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "option", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("value", type_r3.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", type_r3.lkValueEname, " ");
  }
}
class SystemBlacklistComponent {
  constructor(systemAdmin, router, lookupService) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.lookupService = lookupService;
    this.systemBlacklists = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.systemBlacklistHeaders = [{
      JsonPropName: 'pid',
      showName: 'PID'
    }, {
      JsonPropName: 'reportNumber',
      showName: 'Report No.'
    }, {
      JsonPropName: 'plateNo',
      showName: 'Plate No.'
    }, {
      JsonPropName: 'plateTypeEn',
      showName: 'Plate Type'
    }, {
      JsonPropName: 'vinNo',
      showName: 'VIN No.'
    }, {
      JsonPropName: 'entryTypeEn',
      showName: 'Entry Type'
    }, {
      JsonPropName: 'reason',
      showName: 'Reason'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.plateTypes = [];
  }
  ngOnInit() {
    this.systemBlacklistsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroup({
      pid: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null),
      reportNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null),
      plateNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null),
      plateType: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null),
      vinNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControl(null)
    });
    this.bindChange();
    this.loadPlateTypes();
    this.loadSystemBlacklists();
  }
  loadPlateTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.plateType).subscribe(types => this.plateTypes = types);
  }
  loadSystemBlacklists() {
    this.systemAdmin.getSystemBlacklist({}).subscribe(result => {
      this.systemBlacklists.data = result.items;
      if (this.systemBlacklists.data.length > 0) this.onSystemBlacklistSelection(this.systemBlacklists.data[0]);
    });
  }
  bindChange() {
    this.systemBlacklistsSearchForm.valueChanges.subscribe(change => {
      this.searchSystemBlacklists();
    });
  }
  onSystemBlacklistStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "blacklist vehicle");
    this.CheckSystemBlacklistActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmSystemBlacklistActiveDeactiveCahnge() {
    let blacklist = new src_app_core_models_adminstration_SystemBlacklistOperation__WEBPACK_IMPORTED_MODULE_2__.SystemBlacklistOperation();
    blacklist = this.checkedSelectedItem;
    blacklist.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    blacklist.status = blacklist.status ? 1 : 0;
    this.systemAdmin.systemBlacklistOperations(blacklist).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveSystemBlacklistModalButton.nativeElement.click();
      }
    });
  }
  onCancelSystemBlacklistActiveDeactiveChange() {
    this.loadSystemBlacklists();
  }
  updateSelectedSystemBlacklist(item) {
    this.router.navigate(['app-admin/system-blacklist/edit', item.entryId]);
  }
  searchSystemBlacklists() {
    this.systemAdmin.getSystemBlacklist(this.systemBlacklistsSearchForm?.value).subscribe(result => {
      this.systemBlacklists.data = result.items;
    });
  }
  AddNewSystemBlacklist() {
    this.router.navigate(['app-admin/system-blacklist/new']);
  }
  onSystemBlacklistSelection(item) {
    this.selectedSystemBlacklistId = item.systemBlacklistId;
    this.selectedSystemBlacklist = item;
  }
  static #_ = this.ɵfac = function SystemBlacklistComponent_Factory(t) {
    return new (t || SystemBlacklistComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_5__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: SystemBlacklistComponent,
    selectors: [["app-system-blacklist"]],
    viewQuery: function SystemBlacklistComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.saveSystemBlacklistModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckSystemBlacklistActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 78,
    vars: 8,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-6"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "formGroup"], [1, "col-md-3"], ["for", ""], ["type", "number", "id", "search", "formControlName", "pid", 1, "form-control", "searchBox"], ["type", "number", "id", "search", "formControlName", "reportNumber", 1, "form-control", "searchBox"], ["type", "number", "id", "search", "formControlName", "plateNo", 1, "form-control", "searchBox"], ["name", "plateType", "formControlName", "plateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "text", "id", "search", "formControlName", "vinNo", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveSystemBlacklistModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#systemBlacklistConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckSystemBlacklistActiveDeactiveModalBtn", ""], ["id", "systemBlacklistConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], [3, "value"]],
    template: function SystemBlacklistComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](13, " System Blacklist ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function SystemBlacklistComponent_Template_button_click_19_listener() {
          return ctx.AddNewSystemBlacklist();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](20, " Add New Item To Blacklist ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "form", 16)(25, "div", 1)(26, "div", 17)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, "PID");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](30, "div", 17)(31, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](32, "Report Number");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](33, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](34, "div", 17)(35, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](36, "Plate No.");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](37, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](38, "div", 17)(39, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](40, "Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](41, "select", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](42, SystemBlacklistComponent_option_42_Template, 2, 2, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](43, "div", 17)(44, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](45, "VIN No.");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](46, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](47, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](48, "app-data-table", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function SystemBlacklistComponent_Template_app_data_table_updateItemEvent_48_listener($event) {
          return ctx.updateSelectedSystemBlacklist($event);
        })("selectItemEvent", function SystemBlacklistComponent_Template_app_data_table_selectItemEvent_48_listener($event) {
          return ctx.onSystemBlacklistSelection($event);
        })("checkboxEvent", function SystemBlacklistComponent_Template_app_data_table_checkboxEvent_48_listener($event) {
          return ctx.onSystemBlacklistStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](49, "button", 26, 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](51, "div", 28)(52, "div", 29)(53, "div", 30)(54, "div", 31)(55, "h1", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](56, "img", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](57);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](58, "button", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](59, "button", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](61, "div", 37)(62, "div", 38)(63, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](64, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](65, "div", 39)(66, "div", 1)(67, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](68, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](69, "div", 3)(70, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](71);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](72, "br")(73, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](74, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function SystemBlacklistComponent_Template_button_click_74_listener() {
          return ctx.onCancelSystemBlacklistActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](75, "img", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](76, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function SystemBlacklistComponent_Template_button_click_76_listener() {
          return ctx.onConfirmSystemBlacklistActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](77, "img", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.systemBlacklistsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.systemBlacklistHeaders)("tblValues", ctx.systemBlacklists)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedSystemBlacklist);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_6__.DataTableComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 83489:
/*!**********************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/tems-condition-form/tems-condition-form.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TermsConditionFormComponent": () => (/* binding */ TermsConditionFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular2-notifications */ 55609);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










function TermsConditionFormComponent_form_4_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_4_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_4_option_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const obj_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", obj_r7.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", obj_r7.lkValueEname, " ");
  }
}
function TermsConditionFormComponent_form_4_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_4_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 4)(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "h2", 8)(5, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 10)(8, "div", 11)(9, "div", 12)(10, "div", 13)(11, "div", 14)(12, "label", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Description En*");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "textarea", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, "                                    ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](16, TermsConditionFormComponent_form_4_div_16_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div", 18)(18, "label", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](19, "Description Ar*");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "textarea", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](21, "                                    ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](22, TermsConditionFormComponent_form_4_div_22_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "br")(25, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 21)(27, "label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Terms Type*");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "select", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](30, TermsConditionFormComponent_form_4_option_30_Template, 2, 2, "option", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](31, TermsConditionFormComponent_form_4_div_31_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](32, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](34, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](36, "input", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "label", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](38, " Active * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](39, TermsConditionFormComponent_form_4_div_39_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](40, "br")(41, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](42, "div", 28)(43, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function TermsConditionFormComponent_form_4_Template_button_click_43_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.SubmitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](44, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r0.AddForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.title, " Terms & Condition ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddForm.get("descriptionEn").dirty || ctx_r0.AddForm.get("descriptionEn").touched) && ctx_r0.AddForm.get("descriptionEn").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddForm.get("descriptionAr").dirty || ctx_r0.AddForm.get("descriptionAr").touched) && ctx_r0.AddForm.get("descriptionAr").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.termsConditionTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddForm.get("termsType").dirty || ctx_r0.AddForm.get("termsType").touched) && ctx_r0.AddForm.get("termsType").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddForm.get("status").dirty || ctx_r0.AddForm.get("status").touched) && ctx_r0.AddForm.get("status").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx_r0.AddForm.valid);
  }
}
function TermsConditionFormComponent_form_5_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_5_div_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_5_option_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const obj_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", obj_r15.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", obj_r15.lkValueEname, " ");
  }
}
function TermsConditionFormComponent_form_5_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_5_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function TermsConditionFormComponent_form_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 4)(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "h2", 8)(5, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 10)(8, "div", 11)(9, "div", 12)(10, "div", 28)(11, "label", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Description En ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "textarea", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "                                ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, TermsConditionFormComponent_form_5_div_15_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 28)(17, "label", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Description Ar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "textarea", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, "                                ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](21, TermsConditionFormComponent_form_5_div_21_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "div", 28)(23, "label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "Terms Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "select", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](26, TermsConditionFormComponent_form_5_option_26_Template, 2, 2, "option", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](27, TermsConditionFormComponent_form_5_div_27_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "div", 28)(29, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](30, "input", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "label", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](32, " Active * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](33, TermsConditionFormComponent_form_5_div_33_Template, 2, 0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](34, "br")(35, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "div", 28)(37, "button", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function TermsConditionFormComponent_form_5_Template_button_click_37_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r16.SubmitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](38, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r1.AddForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r1.title, " Terms & Condition ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddForm.get("descriptionEn").dirty || ctx_r1.AddForm.get("descriptionEn").touched) && ctx_r1.AddForm.get("descriptionEn").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddForm.get("descriptionAr").dirty || ctx_r1.AddForm.get("descriptionAr").touched) && ctx_r1.AddForm.get("descriptionAr").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.termsConditionTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddForm.get("termsType").dirty || ctx_r1.AddForm.get("termsType").touched) && ctx_r1.AddForm.get("termsType").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddForm.get("status").dirty || ctx_r1.AddForm.get("status").touched) && ctx_r1.AddForm.get("status").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx_r1.AddForm.valid);
  }
}
class TermsConditionFormComponent {
  constructor(appAdmin, router, fb, notificationService, lookupService, route) {
    this.appAdmin = appAdmin;
    this.router = router;
    this.fb = fb;
    this.notificationService = notificationService;
    this.lookupService = lookupService;
    this.route = route;
    this.operation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert;
    this.isUpdated = false;
    this.termsConditionTypes = [];
  }
  backToTermsCondition() {
    this.router.navigate(['app-admin/terms-condition']);
  }
  ngOnInit() {
    this.userId = parseInt(localStorage.getItem('userId'));
    this.initForm();
    this.checkViewInsertUpdateMode();
    this.loadTermsType();
  }
  initForm() {
    this.AddForm = this.fb.group({
      id: [],
      descriptionEn: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      descriptionAr: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      termsType: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      status: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }
  loadTermsType() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.termsType).subscribe(types => this.termsConditionTypes = types);
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.view) this.route.params.subscribe(params => {
      this.termId = +params['termId'];
      if (this.termId != null) {
        this.loadTermsItem();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update) {
      this.title = "Update";
      this.operation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update;
      this.isUpdated = true;
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert) {
      this.title = "New";
      this.operation = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert;
      this.isUpdated = false;
    }
  }
  loadTermsItem() {
    this.appAdmin.GetTermsAndConditin({
      id: this.termId
    }).subscribe(result => {
      if (result.items.length > 0) {
        this.termId = result.items[0].id;
        this.updatedObject = result.items[0];
        this.AddForm.patchValue(result.items[0]);
      }
    });
  }
  SubmitForm() {
    let request = this.AddForm.value;
    request.status = this.AddForm?.value.status ? 1 : 0;
    request.createdBy = this.userId;
    request.updatedBy = this.userId;
    request.operationType = this.operation;
    this.appAdmin.POSTTermsCondition(request).subscribe(result => {
      if (result.items > 0) {
        this.AddForm.reset();
        this.backToTermsCondition();
        this.notificationService.success("Success", "Operation completed successfully", {
          timeOut: 3000,
          position: ['top', 'center']
        });
      }
    });
  }
  static #_ = this.ɵfac = function TermsConditionFormComponent_Factory(t) {
    return new (t || TermsConditionFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](angular2_notifications__WEBPACK_IMPORTED_MODULE_7__.NotificationsService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: TermsConditionFormComponent,
    selectors: [["tems-condition-form"]],
    decls: 6,
    vars: 2,
    consts: [[1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], [3, "formGroup", 4, "ngIf"], [3, "formGroup"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "row"], [1, "col-md-6", "col-lg-6", "left"], ["for", "descriptionEn"], ["type", "text", "formControlName", "descriptionEn", "rows", "10", 1, "form-control"], ["class", "validation-filed", 4, "ngIf"], [1, "col-md-6", "col-lg-6", "right"], ["for", "descriptionAr"], ["formControlName", "descriptionAr", "rows", "10", 1, "form-control"], [1, "col-md-4", "col-lg-4", "left"], ["for", "termsType"], ["formControlName", "termsType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "col-md-3", "col-lg-3", "left"], ["type", "button", 1, "btn", "btn-orange", "endBt", 3, "disabled", "click"], [1, "validation-filed"], [3, "value"], ["type", "text", "formControlName", "descriptionEn", 1, "form-control"], ["formControlName", "descriptionAr", 1, "form-control"]],
    template: function TermsConditionFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function TermsConditionFormComponent_Template_a_click_1_listener() {
          return ctx.backToTermsCondition();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, TermsConditionFormComponent_form_4_Template, 45, 8, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, TermsConditionFormComponent_form_5_Template, 39, 8, "form", 3);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isUpdated);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isUpdated);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName],
    styles: [".endBt[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3IvdGVtcy1jb25kaXRpb24tZm9ybS90ZW1zLWNvbmRpdGlvbi1mb3JtLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnQkFBZ0I7QUFDcEIiLCJzb3VyY2VzQ29udGVudCI6WyIuZW5kQnQge1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 92854:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/terms-condition/terms-condition.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TermsConditionComponent": () => (/* binding */ TermsConditionComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ 92938);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);








function TermsConditionComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 16)(1, "div", 9)(2, "div", 17)(3, "div", 0)(4, "div", 18)(5, "label", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6, "Description En ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "textarea", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 21)(10, "label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](11, "Description Ar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "textarea", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("                    ", ctx_r0.termsCondDetail.descriptionEn, "\n                ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("                    ", ctx_r0.termsCondDetail.descriptionAr, "\n                ");
  }
}
class TermsConditionComponent {
  constructor(appAdmin, sideNav, router) {
    this.appAdmin = appAdmin;
    this.sideNav = sideNav;
    this.router = router;
    this.termsConditionTbl = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.termsAndCondition = [];
    this.termsConditionTblHeaders = [
    //{ JsonPropName: 'id', showName: 'Id' },
    {
      JsonPropName: 'descriptionEn',
      showName: 'Description En'
    }, {
      JsonPropName: 'descriptionAr',
      showName: 'Description Ar'
    }, {
      JsonPropName: 'termsTypeDesc',
      showName: 'Terms Type'
    },
    //{ JsonPropName: 'createdBy', showName: 'CreatedBy' },
    // { JsonPropName: 'createdDate', showName: 'Created Date' },
    //{ JsonPropName: 'updatedBy', showName: 'Updated By' },
    //{ JsonPropName: 'updatedDate', showName: 'Updated Date' },
    {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.termsConditionTbl.data = [];
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 107);
    this.loadTermsAndCondition();
  }
  loadTermsAndCondition() {
    this.appAdmin.GetTermsAndConditin({}).subscribe(result => {
      this.termsAndCondition = result.items;
      const backup = (0,lodash__WEBPACK_IMPORTED_MODULE_1__.cloneDeep)(this.termsAndCondition);
      this.implementTermsCondition(backup);
    });
  }
  addTermsCondition() {
    this.router.navigate(['app-admin/terms-condition/new']);
  }
  updateTermsCondition(item) {
    this.router.navigate(['app-admin/terms-condition/edit/', item.id]);
  }
  implementTermsCondition(itemsArr) {
    itemsArr.forEach(element => {
      element.descriptionEn = element.descriptionEn.slice(0, 100);
      element.descriptionAr = element.descriptionAr.slice(0, 100);
    });
    this.termsConditionTbl.data = itemsArr;
  }
  viewTermsConditionDetails(item) {
    this.termsCondDetail = this.termsAndCondition.find(x => x.id == item.id);
  }
  static #_ = this.ɵfac = function TermsConditionComponent_Factory(t) {
    return new (t || TermsConditionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_3__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: TermsConditionComponent,
    selectors: [["app-terms-condition"]],
    decls: 19,
    vars: 6,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "tblHeaders", "isVewEnabled", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "viewItemEvent", "updateItemEvent"], ["id", "act-search3", "class", "accordion-collapse collapse show", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 4, "ngIf"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-6", "left"], ["for", "descriptionEn"], ["type", "text", "rows", "10", 1, "form-control", 3, "disabled"], [1, "col-md-6", "col-lg-6", "right"], ["for", "descriptionAr"], ["rows", "10", 1, "form-control", 3, "disabled"]],
    template: function TermsConditionComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, " Terms & Conditions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "div", 0)(13, "div", 11)(14, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function TermsConditionComponent_Template_button_click_14_listener() {
          return ctx.addTermsCondition();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, " Add Terms & Condition ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "app-data-table", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("viewItemEvent", function TermsConditionComponent_Template_app_data_table_viewItemEvent_17_listener($event) {
          return ctx.viewTermsConditionDetails($event);
        })("updateItemEvent", function TermsConditionComponent_Template_app_data_table_updateItemEvent_17_listener($event) {
          return ctx.updateTermsCondition($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](18, TermsConditionComponent_div_18_Template, 14, 4, "div", 15);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tblHeaders", ctx.termsConditionTblHeaders)("isVewEnabled", true)("tblValues", ctx.termsConditionTbl)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.termsCondDetail);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__.DataTableComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 78998:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/vehicl-registeration-view/vehicl-registeration-view.component.ts ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehiclRegisterationViewComponent": () => (/* binding */ VehiclRegisterationViewComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_application_admin_searchRegisterVehicleDto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/application-admin/searchRegisterVehicleDto */ 5716);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);












function VehiclRegisterationViewComponent_option_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "option", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", type_r3.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", type_r3.lkValueEname, " ");
  }
}
function VehiclRegisterationViewComponent_option_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "option", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", vc_r4.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", vc_r4.descriptionEn, " ");
  }
}
function VehiclRegisterationViewComponent_div_60_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 38)(5, "div", 5)(6, "h2", 39)(7, "button", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "div", 41)(10, "div", 9)(11, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](12, "app-data-table", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx_r2.requestID, " Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("tblHeaders", ctx_r2.RegisteredVehicleDetailsHeaders)("tblValues", ctx_r2.RegisteredVehicleDetails)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("backendOrdering", true)("backendPagination", true);
  }
}
class VehiclRegisterationViewComponent {
  constructor(fb, appAdmin, lookupService, sideNav, sharedLookup) {
    this.fb = fb;
    this.appAdmin = appAdmin;
    this.lookupService = lookupService;
    this.sideNav = sideNav;
    this.sharedLookup = sharedLookup;
    this.RegisteredVehicles = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.RegisteredVehicleDetails = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_1__.tableData();
    this.requestID = 0;
    this.plateTypes = [];
    this.pageSize = 5;
    this.vehicleCategories = [];
    this.RegisteredVehicleDetailsHeaders = [{
      JsonPropName: 'colorDescEn',
      showName: 'Color Desc'
    },
    //{ JsonPropName: 'subColorDescEn', showName: 'Sub Color Desc' },
    {
      JsonPropName: 'modelNameEn',
      showName: 'Model Name'
    }, {
      JsonPropName: 'mergedCol',
      showName: ' Manufacturers Name /Year'
    }, {
      JsonPropName: 'vehicleShapeDesc',
      showName: 'Vehicle Shape Desc'
    }, {
      JsonPropName: 'vehicleCategoryDesc',
      showName: 'Vehicle Category Desc'
    },
    //{ JsonPropName: 'departmentId', showName: 'Department ID' },
    // { JsonPropName: 'vehicleModelId', showName: 'Vehicle Model ID' },
    //{ JsonPropName: 'manufacturerYear', showName: ' Manufacturer Year' },
    {
      JsonPropName: 'noOfSeat',
      showName: 'No Of Seat'
    }, {
      JsonPropName: 'cylinders',
      showName: 'Cylinders'
    }, {
      JsonPropName: 'weight',
      showName: ' Weight'
    }, {
      JsonPropName: 'payloadWeight',
      showName: 'Payload Weight'
    }, {
      JsonPropName: 'shapeCode',
      showName: 'Shape Code'
    },
    //{ JsonPropName: 'ownerType', showName: 'Owner Type' },
    //{ JsonPropName: 'contactPersonPid', showName: 'Contact Person Pid' },
    {
      JsonPropName: 'contactPersonEmail',
      showName: ' Contact Person Email'
    }, {
      JsonPropName: 'contactPersonPhone',
      showName: 'Contact Person Phone'
    },
    //{ JsonPropName: 'ownerPidType', showName: 'Owner Pid Type' },
    // { JsonPropName: 'ownerPid', showName: 'Owner Pid' },
    {
      JsonPropName: 'ownerTypeEn',
      showName: 'Owner Type'
    }
    //{ JsonPropName: 'descriptionEn', showName: 'Description' },
    //{ JsonPropName: 'descriptionAr', showName: 'Description Ar' },
    //{ JsonPropName: 'ownerPIDTypeEn', showName: 'Owner PID Type' },
    //{ JsonPropName: 'updatedDate', showName: 'Updated Date' },
    //{ JsonPropName: 'status',  showName: 'Active' , ShowInCheckBox:true  },
    ];

    this.RegisteredVehiclesHeaders = [{
      JsonPropName: 'requestId',
      showName: 'Request ID'
    }, {
      JsonPropName: 'plateNo',
      showName: 'Plate No'
    }, {
      JsonPropName: 'plateTypeEn',
      showName: 'Plate Type'
    }, {
      JsonPropName: 'vinNo',
      showName: 'VIN No'
    }, {
      JsonPropName: 'vehicleCategoryDesc',
      showName: 'Category'
    },
    //{ JsonPropName: 'categoryId', showName: 'Category' },
    {
      JsonPropName: 'getMoiRegistrationDate',
      showName: 'Moi Registration Date'
    }, {
      JsonPropName: 'getLicenseExpiryDate',
      showName: 'License Expiry Date'
    }, {
      JsonPropName: 'ownerName',
      showName: 'Owner Name'
    }
    // { JsonPropName: 'manufacturerId', showName: 'Manufacturer ID' },
    //{ JsonPropName: 'createdDate', showName: 'Created Date' },
    //{ JsonPropName: 'status',  showName: 'Active' , ShowInCheckBox:true  },
    ];

    this.searchBody = new src_app_core_models_application_admin_searchRegisterVehicleDto__WEBPACK_IMPORTED_MODULE_0__.searchRegisterVehicleDto();
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(10, 106);
    this.initForm();
    this.loadPlateTypes();
    this.LoadCategories();
    this.LoadVehicleDetails();
    //  this.bindChange();
  }

  LoadCategories() {
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.vehicleCategories = data;
    });
  }
  initForm() {
    this.vehicleSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroup({
      requestId: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      plateNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      plateType: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      vinNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      categoryId: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      moiRegistrationDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      licenseExpiryDate: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      ownerName: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null)
    });
  }
  onRowSelection(item) {
    let selectedarr = [];
    this.SelectedElement = item;
    selectedarr.push(item);
    this.RegisteredVehicleDetails.data = selectedarr;
    this.requestID = item.requestId;
  }
  LoadVehicleDetails() {
    this.appAdmin.GetRegisteredVehicle({
      pageNumber: 1,
      pageSize: this.pageSize
    }).subscribe(result => {
      this.RegisteredVehicles.totalPages = result.items.pageCount / this.pageSize;
      if (this.RegisteredVehicles.totalPages > 0) {
        this.RegisteredVehicles.data = this.getMergedColumnData(result); // result.items.vehicles;
        this.SelectedElement = this.RegisteredVehicles.data[0];
        this.onRowSelection(this.RegisteredVehicles.data[0]);
      }
    });
  }
  onChangePage(change) {
    let request = this.vehicleSearchForm.value;
    request.pageNumber = change.pageIndex;
    this.appAdmin.GetRegisteredVehicle(request).subscribe(result => {
      this.RegisteredVehicles.data = this.getMergedColumnData(result);
      this.RegisteredVehicles.totalPages = result.items.pageCount / this.pageSize;
      this.SelectedElement = this.RegisteredVehicles.data[0];
      this.onRowSelection(this.RegisteredVehicles.data[0]);
    });
  }
  onChangeOrder(change) {
    console.log(change);
    console.log(this.RegisteredVehicles);
    let request = this.vehicleSearchForm.value;
    request.pageNumber = 1;
    request.orderBy = change.orderBy;
    request.sortOrder = change.sortOrder;
    this.appAdmin.GetRegisteredVehicle(request).subscribe(result => {
      this.RegisteredVehicles.data = this.getMergedColumnData(result);
      this.RegisteredVehicles.totalPages = result.items.pageCount / this.pageSize;
      this.SelectedElement = this.RegisteredVehicles.data[0];
      this.onRowSelection(this.RegisteredVehicles.data[0]);
    });
  }
  loadPlateTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.plateType).subscribe(types => this.plateTypes = types);
  }
  getMergedColumnData(result) {
    result.items.vehicles.forEach(element => {
      const mergedColValue = `${element.manufacturersEname} / ${element.manufacturerYear}`;
      element.mergedCol = mergedColValue;
    });
    return result.items.vehicles;
  }
  clearForm() {
    this.vehicleSearchForm.reset();
    this.LoadVehicleDetails();
  }
  submitForm() {
    let request = this.vehicleSearchForm.value;
    request.requestId = this.vehicleSearchForm.get("requestId").value ?? null;
    request.plateNo = this.vehicleSearchForm.get("plateNo").value ?? null;
    request.plateType = this.vehicleSearchForm.get("plateType").value ?? null;
    request.vinNo = this.vehicleSearchForm.get("vinNo").value ?? null;
    request.categoryId = this.vehicleSearchForm.get("categoryId").value ?? null;
    request.moiRegistrationDate = this.vehicleSearchForm.get("moiRegistrationDate").value ?? null;
    request.licenseExpiryDate = this.vehicleSearchForm.get("licenseExpiryDate").value ?? null;
    request.ownerName = this.vehicleSearchForm.get("ownerName").value ?? null;
    request.pageNumber = 1;
    request.pageSize = this.pageSize;
    this.appAdmin.GetRegisteredVehicle(request).subscribe(result => {
      this.RegisteredVehicles.data = this.getMergedColumnData(result); // result.items.vehicles;
      this.RegisteredVehicles.totalPages = result.items.pageCount / this.pageSize;
      if (this.RegisteredVehicles.totalPages > 0) {
        this.SelectedElement = this.RegisteredVehicles.data[0];
        this.onRowSelection(this.RegisteredVehicles.data[0]);
      }
    });
  }
  static #_ = this.ɵfac = function VehiclRegisterationViewComponent_Factory(t) {
    return new (t || VehiclRegisterationViewComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_3__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_6__.SharedLookupService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: VehiclRegisterationViewComponent,
    selectors: [["vehicl-registeration-view"]],
    decls: 61,
    vars: 19,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-3"], ["for", "requestId"], ["type", "text", "formControlName", "requestId", 1, "form-control", "searchBox", 3, "ngModel"], ["for", "plateNo"], ["type", "text", "id", "plateNo", "formControlName", "plateNo", 1, "form-control", "searchBox", 3, "value"], ["for", "plateType"], ["name", "plateType", "formControlName", "plateType", 1, "form-control", "searchBox", 3, "value"], [3, "value", 4, "ngFor", "ngForOf"], ["for", "vinNo"], ["type", "text", "id", "vinNo", "formControlName", "vinNo", 1, "form-control", "searchBox", 3, "value"], ["for", "categoryId"], ["name", "categoryId", "formControlName", "categoryId", 1, "form-control", "searchBox", 3, "value"], ["for", "moiRegistrationDate"], ["type", "date", "id", "moiRegistrationDate", "formControlName", "moiRegistrationDate", 1, "form-control", "searchBox", 3, "value"], ["for", "licenseExpiryDate"], ["type", "date", "id", "licenseExpiryDate", "formControlName", "licenseExpiryDate", 1, "form-control", "searchBox", 3, "value"], ["for", "ownerName"], ["type", "text", "id", "ownerName", "formControlName", "ownerName", 1, "form-control", "searchBox", 3, "value"], [1, "col-md-4", "col-lg-4"], [1, "row", "endBt"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-orange", 3, "click"], [1, "row", "endBt", 2, "margin-left", "2px"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "backendOrdering", "backendPagination", "selectedRow", "selectItemEvent", "paginationEvent", "orderingEvent"], ["class", "row", 4, "ngIf"], [3, "value"], ["id", "accordionExample3", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "backendOrdering", "backendPagination"]],
    template: function VehiclRegisterationViewComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8, " Registered Vehicles ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "form", 11)(13, "div", 12)(14, "div", 13)(15, "label", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](16, "Request Id");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](17, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](18, "div", 13)(19, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](20, "Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](21, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](22, "div", 13)(23, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](24, "Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](25, "select", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](26, VehiclRegisterationViewComponent_option_26_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](27, "div", 13)(28, "label", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](29, "VIN No");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](30, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](31, "div", 13)(32, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](33, "Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](34, "select", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](35, VehiclRegisterationViewComponent_option_35_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](36, "div", 13)(37, "label", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](38, "Moi Registration Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](39, "input", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](40, "div", 13)(41, "label", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](42, "License Expiry Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](43, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](44, "div", 13)(45, "label", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](46, "Owner Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](47, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](48, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](49, "div", 0)(50, "div", 31)(51, "div", 32)(52, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function VehiclRegisterationViewComponent_Template_button_click_52_listener($event) {
          $event.preventDefault();
          return ctx.submitForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](53, "Search");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](54, "div", 31)(55, "div", 34)(56, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function VehiclRegisterationViewComponent_Template_button_click_56_listener($event) {
          $event.preventDefault();
          return ctx.clearForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](57, "Clear");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](58, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](59, "app-data-table", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("selectItemEvent", function VehiclRegisterationViewComponent_Template_app_data_table_selectItemEvent_59_listener($event) {
          return ctx.onRowSelection($event);
        })("paginationEvent", function VehiclRegisterationViewComponent_Template_app_data_table_paginationEvent_59_listener($event) {
          return ctx.onChangePage($event);
        })("orderingEvent", function VehiclRegisterationViewComponent_Template_app_data_table_orderingEvent_59_listener($event) {
          return ctx.onChangeOrder($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](60, VehiclRegisterationViewComponent_div_60_Template, 13, 7, "div", 36);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.vehicleSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngModel", ctx.searchBody.requestId);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.plateNo);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.plateType);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.vinNo);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.categoryId);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngForOf", ctx.vehicleCategories);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.moiRegistrationDate);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.licenseExpiryDate);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("value", ctx.searchBody.ownerName);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("tblHeaders", ctx.RegisteredVehiclesHeaders)("tblValues", ctx.RegisteredVehicles)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", false)("backendOrdering", true)("backendPagination", true)("selectedRow", ctx.SelectedElement);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.SelectedElement);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_7__.DataTableComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 93254:
/*!******************************************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/waqod-details-operation/waqod-details-operation.component.ts ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WaqodDetailsOperationComponent": () => (/* binding */ WaqodDetailsOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var angular2_notifications__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! angular2-notifications */ 55609);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










function WaqodDetailsOperationComponent_form_4_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_4_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", type_r9.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", type_r9.lkValueEname, " ");
  }
}
function WaqodDetailsOperationComponent_form_4_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_4_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_4_option_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const instance_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", instance_r10.instanceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", instance_r10.instanceName, " ");
  }
}
function WaqodDetailsOperationComponent_form_4_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_4_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 4)(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "h2", 8)(5, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 10)(8, "div", 11)(9, "div", 12)(10, "div", 13)(11, "label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Plate No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "input", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, WaqodDetailsOperationComponent_form_4_div_14_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 13)(16, "label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "Plate Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "select", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, WaqodDetailsOperationComponent_form_4_option_19_Template, 2, 2, "option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](20, WaqodDetailsOperationComponent_form_4_div_20_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 13)(22, "label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "input", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](25, WaqodDetailsOperationComponent_form_4_div_25_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 13)(27, "label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Instance Id");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "select", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](30, WaqodDetailsOperationComponent_form_4_option_30_Template, 2, 2, "option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](31, WaqodDetailsOperationComponent_form_4_div_31_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "div", 13)(33, "label", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34, "Department Code");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](35, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](36, WaqodDetailsOperationComponent_form_4_div_36_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "div", 13)(38, "button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function WaqodDetailsOperationComponent_form_4_Template_button_click_38_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r11.SubmitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r0.AddWaqodDetailForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.title, " Vehicle Detail ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddWaqodDetailForm.get("plateNo").dirty || ctx_r0.AddWaqodDetailForm.get("plateNo").touched) && ctx_r0.AddWaqodDetailForm.get("plateNo").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.plateTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddWaqodDetailForm.get("plateType").dirty || ctx_r0.AddWaqodDetailForm.get("plateType").touched) && ctx_r0.AddWaqodDetailForm.get("plateType").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddWaqodDetailForm.get("vinNo").dirty || ctx_r0.AddWaqodDetailForm.get("vinNo").touched) && ctx_r0.AddWaqodDetailForm.get("vinNo").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r0.WaqodInstances);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddWaqodDetailForm.get("instanceId").dirty || ctx_r0.AddWaqodDetailForm.get("instanceId").touched) && ctx_r0.AddWaqodDetailForm.get("instanceId").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r0.AddWaqodDetailForm.get("departmentCode").dirty || ctx_r0.AddWaqodDetailForm.get("departmentCode").touched) && ctx_r0.AddWaqodDetailForm.get("departmentCode").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx_r0.AddWaqodDetailForm.valid);
  }
}
function WaqodDetailsOperationComponent_form_5_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_5_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", type_r20.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", type_r20.lkValueEname, " ");
  }
}
function WaqodDetailsOperationComponent_form_5_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_5_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_5_option_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const instance_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", instance_r21.instanceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", instance_r21.instanceName, " ");
  }
}
function WaqodDetailsOperationComponent_form_5_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_5_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " *Field is required ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function WaqodDetailsOperationComponent_form_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "form", 4)(1, "div", 5)(2, "div", 6)(3, "div", 7)(4, "h2", 8)(5, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 10)(8, "div", 11)(9, "div", 12)(10, "div", 13)(11, "label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](12, "Plate No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](13, "input", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, WaqodDetailsOperationComponent_form_5_div_14_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 13)(16, "label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "Plate Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "select", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, WaqodDetailsOperationComponent_form_5_option_19_Template, 2, 2, "option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](20, WaqodDetailsOperationComponent_form_5_div_20_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div", 13)(22, "label", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "VIN No");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "input", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](25, WaqodDetailsOperationComponent_form_5_div_25_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "div", 13)(27, "label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Instance Id");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](29, "select", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](30, WaqodDetailsOperationComponent_form_5_option_30_Template, 2, 2, "option", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](31, WaqodDetailsOperationComponent_form_5_div_31_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "div", 13)(33, "label", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34, "Department Code ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](35, "input", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](36, WaqodDetailsOperationComponent_form_5_div_36_Template, 2, 0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "div", 13)(38, "button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function WaqodDetailsOperationComponent_form_5_Template_button_click_38_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r23);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r22.SubmitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r1.AddWaqodDetailForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r1.title, " Vehicle Detail ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddWaqodDetailForm.get("plateNo").dirty || ctx_r1.AddWaqodDetailForm.get("plateNo").touched) && ctx_r1.AddWaqodDetailForm.get("plateNo").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.plateTypes);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddWaqodDetailForm.get("plateType").dirty || ctx_r1.AddWaqodDetailForm.get("plateType").touched) && ctx_r1.AddWaqodDetailForm.get("plateType").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddWaqodDetailForm.get("vinNo").dirty || ctx_r1.AddWaqodDetailForm.get("vinNo").touched) && ctx_r1.AddWaqodDetailForm.get("vinNo").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.WaqodInstances);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddWaqodDetailForm.get("instanceId").dirty || ctx_r1.AddWaqodDetailForm.get("instanceId").touched) && ctx_r1.AddWaqodDetailForm.get("instanceId").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r1.AddWaqodDetailForm.get("departmentCode").dirty || ctx_r1.AddWaqodDetailForm.get("departmentCode").touched) && ctx_r1.AddWaqodDetailForm.get("departmentCode").invalid);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx_r1.AddWaqodDetailForm.valid);
  }
}
class WaqodDetailsOperationComponent {
  constructor(route, appAdmin, notificationService, fb, lookupService, router) {
    this.route = route;
    this.appAdmin = appAdmin;
    this.notificationService = notificationService;
    this.fb = fb;
    this.lookupService = lookupService;
    this.router = router;
    this.isUpdated = false;
    this.plateTypes = [];
    this.WaqodInstances = [];
    this.isDisabled = true;
  }
  ngOnInit() {
    this.loadPlateTypes();
    this.loadWaqodInstance();
    this.GenerateWaqodVehicleDetailForm();
    this.userId = parseInt(localStorage.getItem('userId'));
    this.checkViewInsertUpdateMode();
  }
  GenerateWaqodVehicleDetailForm() {
    this.AddWaqodDetailForm = this.fb.group({
      plateNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      plateType: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      vinNo: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      instanceId: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      departmentCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }
  loadPlateTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.plateType).subscribe(types => this.plateTypes = types);
  }
  loadWaqodInstance() {
    this.appAdmin.GetWaqodInstance({}).subscribe(result => {
      this.WaqodInstances = result.items;
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.view) this.route.params.subscribe(params => {
      this.vinNo = params['vinNo'];
      if (this.vinNo != null) {
        this.loadVehicleUpdatedItem();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
      this.isUpdated = true;
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_0__.operationType.insert) {
      this.title = "New";
      this.action = "Created";
      this.isUpdated = false;
    }
  }
  loadVehicleUpdatedItem() {
    const editableObject = {
      vinNo: this.vinNo,
      pageNumber: 1,
      pageSize: 1
    };
    this.appAdmin.GetVehicleDetailLst(editableObject).subscribe(result => {
      if (result.items.details.length > 0) {
        this.vinNo = result.items.details[0].vINNo;
        this.vehicleDetailObj = result.items.details[0];
        this.AddWaqodDetailForm.patchValue(result.items.details[0]);
      }
    });
  }
  SubmitForm() {
    let request = this.AddWaqodDetailForm.value;
    request.operationType = this.operation;
    request.updatedBy = this.userId;
    request.createdBy = this.userId;
    this.appAdmin.VehicleDetailOperation(request).subscribe(result => {
      if (result.items > 0) {
        this.AddWaqodDetailForm.reset();
        this.notificationService.success("Success", "Operation completed successfully", {
          timeOut: 3000,
          position: ['top', 'center']
        });
      }
    });
  }
  backTovehicles() {
    this.router.navigate(['app-admin/waqod-vehicle']);
  }
  static #_ = this.ɵfac = function WaqodDetailsOperationComponent_Factory(t) {
    return new (t || WaqodDetailsOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](angular2_notifications__WEBPACK_IMPORTED_MODULE_7__.NotificationsService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: WaqodDetailsOperationComponent,
    selectors: [["app-waqod-details-operation"]],
    decls: 6,
    vars: 2,
    consts: [[1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], [3, "formGroup", 4, "ngIf"], [3, "formGroup"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3", "left"], ["for", "plateNo"], ["type", "text", "formControlName", "plateNo", 1, "form-control"], ["class", "validation-filed", 4, "ngIf"], ["for", "plateType"], ["name", "sectionId", "formControlName", "plateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["for", "vinNo"], ["type", "text", "name", "vinNo", "formControlName", "vinNo", "readonly", "", 1, "form-control"], ["for", "instanceId"], ["name", "instanceId", "formControlName", "instanceId", 1, "form-control"], ["for", "departmentCode"], ["type", "text", "name", "departmentCode", "formControlName", "departmentCode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", 1, "form-control"], ["type", "button", 1, "btn", "btn-orange", "endBt", 3, "disabled", "click"], [1, "validation-filed"], [3, "value"], ["type", "text", "name", "vinNo", "formControlName", "vinNo", 1, "form-control"], ["type", "number", "name", "departmentCode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "departmentCode", 1, "form-control"]],
    template: function WaqodDetailsOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function WaqodDetailsOperationComponent_Template_a_click_1_listener() {
          return ctx.backTovehicles();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, WaqodDetailsOperationComponent_form_4_Template, 40, 10, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, WaqodDetailsOperationComponent_form_5_Template, 40, 10, "form", 3);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isUpdated);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isUpdated);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName],
    styles: ["#loca[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n    position: relative;\r\n}\r\n\r\n#chRow[_ngcontent-%COMP%] {\r\n    margin-top: 10px;\r\n}\r\n\r\n\r\n.carchkbx[_ngcontent-%COMP%] {\r\n    width: 1.5em;\r\n    height: 1.5em;\r\n}\r\n\r\n.carchkbx[_ngcontent-%COMP%]:focus {\r\n    outline: none;\r\n    border: none;\r\n}\r\n\r\n.form-check-input[_ngcontent-%COMP%]   .carchkbx[_ngcontent-%COMP%]:checked {\r\n    background: #F89828 !important;\r\n    border: solid 1px #F89828 !important;\r\n}\r\n.endBt[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3Ivd2Fxb2QtZGV0YWlscy1vcGVyYXRpb24vd2Fxb2QtZGV0YWlscy1vcGVyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtJQUNoQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7OztBQUdBO0lBQ0ksWUFBWTtJQUNaLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLDhCQUE4QjtJQUM5QixvQ0FBb0M7QUFDeEM7QUFDQTtJQUNJLGdCQUFnQjtBQUNwQiIsInNvdXJjZXNDb250ZW50IjpbIiNsb2NhIHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbiNjaFJvdyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG5cclxuLmNhcmNoa2J4IHtcclxuICAgIHdpZHRoOiAxLjVlbTtcclxuICAgIGhlaWdodDogMS41ZW07XHJcbn1cclxuXHJcbi5jYXJjaGtieDpmb2N1cyB7XHJcbiAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG59XHJcblxyXG4uZm9ybS1jaGVjay1pbnB1dCAuY2FyY2hrYng6Y2hlY2tlZCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjRjg5ODI4ICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjRjg5ODI4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLmVuZEJ0IHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 47587:
/*!**********************************************************************************************!*\
  !*** ./src/app/modules/app-admin/app-administrator/waqod-vehicle/waqod-vehicle.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WaqodVehicleComponent": () => (/* binding */ WaqodVehicleComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../component/data-table/data-table.component */ 42797);










function WaqodVehicleComponent_option_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r1.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r1.lkValueEname, " ");
  }
}
class WaqodVehicleComponent {
  constructor(appAdmin, router, lookupService) {
    this.appAdmin = appAdmin;
    this.router = router;
    this.lookupService = lookupService;
    this.pageSize = 5;
    this.vehicleDetailDt = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.pageNumber = 1;
    this.plateTypes = [];
    this.vehicleDetailDtHeader = [{
      JsonPropName: 'vinNo',
      showName: 'Vin No'
    }, {
      JsonPropName: 'plateNo',
      showName: 'Plate No'
    }, {
      JsonPropName: 'plateTypeEn',
      showName: 'Plate Type'
    },
    // { JsonPropName: 'plateType', showName: 'Plate Type' },
    {
      JsonPropName: 'instanceName',
      showName: 'Instance Name'
    }, {
      JsonPropName: 'departmentCode',
      showName: 'Department Code'
    }
    //{ JsonPropName: 'plateTypeAr', showName: 'Plate Type Ar' },
    ];
  }

  ngOnInit() {
    this.loadVehicleDetails();
    this.initForm();
    this.loadPlateTypes();
  }
  initForm() {
    this.WoqodSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      plateNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      plateType: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      vinNo: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
  }
  loadPlateTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.plateType).subscribe(types => this.plateTypes = types);
  }
  loadVehicleDetails() {
    this.appAdmin.GetVehicleDetailLst({
      pageNumber: this.pageNumber,
      pageSize: this.pageSize
    }).subscribe(result => {
      this.vehicleDetailDt.totalPages = result.items.pageCount;
      this.vehicleDetailDt.data = result.items.details;
    });
  }
  addVehicleDetail() {
    this.router.navigate(['app-admin/waqod-vehicle/new']);
  }
  updateSelectedDefect(item) {
    this.selectedMainRow = item;
    this.router.navigate(['app-admin/waqod-vehicle/edit/', item.vinNo]);
  }
  onChangePage(change) {
    this.pageNumber = change.pageIndex;
    this.appAdmin.GetVehicleDetailLst({
      pageNumber: this.pageNumber,
      pageSize: this.pageSize
    }).subscribe(result => {
      this.vehicleDetailDt.data = result.items.details;
      this.vehicleDetailDt.totalPages = result.items.pageCount;
    });
  }
  submitForm() {
    let request = this.WoqodSearchForm.value;
    request.plateNo = this.WoqodSearchForm.get("plateNo").value ?? null;
    request.plateType = this.WoqodSearchForm.get("plateType").value ?? null;
    request.vinNo = this.WoqodSearchForm.get("vinNo").value ?? null;
    request.pageNumber = this.pageNumber;
    request.pageSize = this.pageSize;
    this.appAdmin.GetVehicleDetailLst(request).subscribe(result => {
      this.vehicleDetailDt.totalPages = result.items.pageCount;
      this.vehicleDetailDt.data = result.items.details;
    });
  }
  clearForm() {
    this.WoqodSearchForm.reset();
    this.loadVehicleDetails();
  }
  onChangeOrder(change) {
    this.appAdmin.GetVehicleDetailLst({
      pageNumber: 1,
      orderBy: change.orderBy,
      sortOrder: change.sortOrder,
      pageSize: this.pageSize
    }).subscribe(result => {
      this.vehicleDetailDt.data = result.items.details;
      this.vehicleDetailDt.totalPages = result.items.pageCount;
    });
  }
  static #_ = this.ɵfac = function WaqodVehicleComponent_Factory(t) {
    return new (t || WaqodVehicleComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_2__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: WaqodVehicleComponent,
    selectors: [["waqod-vehicle"]],
    decls: 50,
    vars: 8,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-4"], ["for", "plateNo"], ["type", "text", "id", "plateNo", "formControlName", "plateNo", 1, "form-control", "searchBox"], ["for", "plateType"], ["name", "plateType", "formControlName", "plateType", 1, "form-control", "searchBox"], [3, "value", 4, "ngFor", "ngForOf"], ["for", "vinNo"], ["type", "text", "id", "vinNo", "formControlName", "vinNo", 1, "form-control", "searchBox"], [1, "col-md-4", "col-lg-4"], [1, "row", "endBt"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-orange", 3, "click"], [1, "row", "endBt", 2, "margin-left", "2px"], ["type", "button", "data-bs-toggle", "modal", 1, "btn", "btn-outline-orange", 3, "click"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "isUpdateOperationEnabled", "backendOrdering", "backendPagination", "updateItemEvent", "paginationEvent", "orderingEvent"], [3, "value"]],
    template: function WaqodVehicleComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, " Woqod Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "form", 13)(18, "div", 14)(19, "div", 15)(20, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](21, "Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](22, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 15)(24, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25, "Plate Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "select", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](27, WaqodVehicleComponent_option_27_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "div", 15)(29, "label", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](30, "VIN No");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](31, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](32, "br")(33, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "div", 1)(35, "div", 23)(36, "div", 24)(37, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WaqodVehicleComponent_Template_button_click_37_listener($event) {
          $event.preventDefault();
          return ctx.submitForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](38, "Search");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "div", 23)(40, "div", 26)(41, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WaqodVehicleComponent_Template_button_click_41_listener($event) {
          $event.preventDefault();
          return ctx.clearForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](42, "Clear");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](43, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "div", 1)(45, "div", 28)(46, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WaqodVehicleComponent_Template_button_click_46_listener() {
          return ctx.addVehicleDetail();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](47, " Add Vehicle Detail ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](48, "i", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](49, "app-data-table", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("updateItemEvent", function WaqodVehicleComponent_Template_app_data_table_updateItemEvent_49_listener($event) {
          return ctx.updateSelectedDefect($event);
        })("paginationEvent", function WaqodVehicleComponent_Template_app_data_table_paginationEvent_49_listener($event) {
          return ctx.onChangePage($event);
        })("orderingEvent", function WaqodVehicleComponent_Template_app_data_table_orderingEvent_49_listener($event) {
          return ctx.onChangeOrder($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.WoqodSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.plateTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tblHeaders", ctx.vehicleDetailDtHeader)("tblValues", ctx.vehicleDetailDt)("isDeleteOperationEnabled", false)("isUpdateOperationEnabled", true)("backendOrdering", true)("backendPagination", true);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _component_data_table_data_table_component__WEBPACK_IMPORTED_MODULE_4__.DataTableComponent],
    styles: [".endBt[_ngcontent-%COMP%] {\r\n    margin-top: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vYXBwLWFkbWluaXN0cmF0b3Ivd2Fxb2QtdmVoaWNsZS93YXFvZC12ZWhpY2xlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnQkFBZ0I7QUFDcEIiLCJzb3VyY2VzQ29udGVudCI6WyIuZW5kQnQge1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 42797:
/*!********************************************************************************!*\
  !*** ./src/app/modules/app-admin/component/data-table/data-table.component.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataTableComponent": () => (/* binding */ DataTableComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);




function DataTableComponent_th_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "i", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_th_3_Template_i_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);
      const header_r4 = restoredCtx.$implicit;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r5.dataOrderingAscDesc(header_r4.JsonPropName, "asc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "i", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_th_3_Template_i_click_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);
      const header_r4 = restoredCtx.$implicit;
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r7.dataOrderingAscDesc(header_r4.JsonPropName, "desc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const header_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", header_r4.showName, " ");
  }
}
function DataTableComponent_th_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableComponent_tr_6_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td")(2, "input", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DataTableComponent_tr_6_ng_container_1_ng_container_1_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17);
      const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](row_r8[header_r11.JsonPropName] = $event);
    })("change", function DataTableComponent_tr_6_ng_container_1_ng_container_1_Template_input_change_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17);
      const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r19.getCheckBoxValue(header_r11.JsonPropName, row_r8[header_r11.JsonPropName], row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("highlighted", row_r8 == ctx_r12.selectedRow);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", row_r8[header_r11.JsonPropName]);
  }
}
function DataTableComponent_tr_6_ng_container_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_tr_6_ng_container_1_ng_template_2_Template_td_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r26);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r24.onRawSelection(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("highlighted", row_r8 == ctx_r14.selectedRow);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", row_r8[header_r11.JsonPropName], " ");
  }
}
function DataTableComponent_tr_6_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DataTableComponent_tr_6_ng_container_1_ng_container_1_Template, 3, 3, "ng-container", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DataTableComponent_tr_6_ng_container_1_ng_template_2_Template, 2, 3, "ng-template", null, 18, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const header_r11 = ctx.$implicit;
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", header_r11.ShowInCheckBox)("ngIfElse", _r13);
  }
}
function DataTableComponent_tr_6_td_2_i_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "i", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_tr_6_td_2_i_1_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r34);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r32.viewSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableComponent_tr_6_td_2_i_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "i", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_tr_6_td_2_i_2_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r37);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r35.updateSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableComponent_tr_6_td_2_i_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_tr_6_td_2_i_3_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r40);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r38.deleteSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableComponent_tr_6_td_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DataTableComponent_tr_6_td_2_i_1_Template, 1, 0, "i", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DataTableComponent_tr_6_td_2_i_2_Template, 1, 0, "i", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, DataTableComponent_tr_6_td_2_i_3_Template, 1, 0, "i", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("highlighted", row_r8 == ctx_r10.selectedRow);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.isVewEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.isUpdateOperationEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.isDeleteOperationEnabled);
  }
}
function DataTableComponent_tr_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DataTableComponent_tr_6_ng_container_1_Template, 4, 2, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DataTableComponent_tr_6_td_2_Template, 4, 5, "td", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r2.tblHeaders);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r2.isVewEnabled || ctx_r2.isUpdateOperationEnabled || ctx_r2.isDeleteOperationEnabled);
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function DataTableComponent_li_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 27)(1, "a", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_li_12_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r44);
      const page_r42 = restoredCtx.$implicit;
      const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r43.changePage(page_r42));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const page_r42 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c0, ctx_r3.currentPage === page_r42));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](page_r42);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
class DataTableComponent {
  constructor(cdr) {
    this.cdr = cdr;
    this.isDeleteOperationEnabled = true;
    this.isVewEnabled = false;
    this.isUpdateOperationEnabled = true;
    this.backendOrdering = false;
    this.backendPagination = false;
    this.viewItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.updateItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.deleteItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.selectItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.checkboxEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.orderingEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.paginationEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.isAscending = true;
    this.currentPage = 1;
    this.pageSize = 5;
    this.selectedRow = null;
  }
  ngOnInit() {
    if (this.tblHeaders.length > 0 && !this.backendOrdering) this.dataOrderingAscDesc(this.tblHeaders[0].JsonPropName, 'asc');
  }
  ngOnChanges(changes) {
    this.cdr.detectChanges(); // Manually trigger change detection
    if (changes.backendPagination) {
      this.totalPages();
    }
  }
  viewSelectedItem(item) {
    this.viewItemEvent.emit(item);
  }
  deleteSelectedItem(item) {
    this.deleteItemEvent.emit(item);
  }
  updateSelectedItem(item) {
    this.updateItemEvent.emit(item);
  }
  onRawSelection(item) {
    this.selectedRow = item;
    this.selectItemEvent.emit(item);
  }
  dataOrderingAscDesc(propertyName, sortOrder) {
    if (!this.backendOrdering) {
      if (this.tblValues.data?.length) this.tblValues.data.sort((a, b) => {
        let valueA = a[propertyName];
        let valueB = b[propertyName];
        valueA = valueA != null ? valueA.toUpperCase() : valueA;
        valueB = valueB != null ? valueB.toUpperCase() : valueB;
        if (valueA < valueB) {
          return sortOrder === 'asc' ? -1 : 1;
        } else if (valueA > valueB) {
          return sortOrder === 'asc' ? 1 : -1;
        } else {
          return 0;
        }
      });
    } else {
      this.orderingEvent.emit({
        sortOrder: sortOrder,
        orderBy: this.transformString(propertyName)
      });
    }
    this.currentPage = 1;
  }
  transformString(inputString) {
    const words = inputString.split(/(?=[A-Z])/);
    const capitalizedWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
    const result = capitalizedWords.join('_');
    return result;
  }
  totalPages() {
    let total = 0;
    if (!this.backendPagination) total = Math.ceil(this.tblValues.data?.length / this.pageSize);else total = this.tblValues.totalPages;
    return Array.from({
      length: total
    }, (_, i) => i + 1);
  }
  changePage(page) {
    if (page >= 1 && page <= this.totalPages().length) this.currentPage = page;
    if (this.backendPagination) this.paginationEvent.emit({
      pageIndex: page
    });
  }
  get paginatedData() {
    if (this.backendPagination) return this.tblValues.data;
    if (this.pageSize === -1) return this.tblValues.data; // Return all data when pageSize is -1
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = Math.min(startIndex + this.pageSize, this.tblValues.data?.length);
    return this.tblValues.data?.slice(startIndex, endIndex);
  }
  getCheckBoxValue(JsonPropName, value, item) {
    this.checkboxEvent.emit({
      JsonPropName: JsonPropName,
      value: value,
      selectedItem: item
    });
  }
  static #_ = this.ɵfac = function DataTableComponent_Factory(t) {
    return new (t || DataTableComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DataTableComponent,
    selectors: [["app-data-table"]],
    inputs: {
      tblHeaders: "tblHeaders",
      tblValues: "tblValues",
      isDeleteOperationEnabled: "isDeleteOperationEnabled",
      isVewEnabled: "isVewEnabled",
      isUpdateOperationEnabled: "isUpdateOperationEnabled",
      backendOrdering: "backendOrdering",
      backendPagination: "backendPagination",
      selectedRow: "selectedRow"
    },
    outputs: {
      viewItemEvent: "viewItemEvent",
      updateItemEvent: "updateItemEvent",
      deleteItemEvent: "deleteItemEvent",
      selectItemEvent: "selectItemEvent",
      checkboxEvent: "checkboxEvent",
      orderingEvent: "orderingEvent",
      paginationEvent: "paginationEvent"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
    decls: 16,
    vars: 10,
    consts: [[1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col", 4, "ngFor", "ngForOf"], ["scope", "col", "style", "width: 20px;", 4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], ["scope", "col"], [1, "bi", "bi-arrow-up", "up", 3, "click"], [1, "bi", "bi-arrow-down", "down", 3, "click"], ["scope", "col", 2, "width", "20px"], [3, "highlighted", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["textColumn", ""], ["type", "checkbox", 3, "ngModel", "ngModelChange", "change"], [3, "click"], ["class", "bi bi-eye-fill", 3, "click", 4, "ngIf"], ["class", "bi bi-pencil-fill", 3, "click", 4, "ngIf"], ["class", "bi bi-trash-fill", 3, "click", 4, "ngIf"], [1, "bi", "bi-eye-fill", 3, "click"], [1, "bi", "bi-pencil-fill", 3, "click"], [1, "bi", "bi-trash-fill", 3, "click"], [1, "page-item", 3, "ngClass"], [1, "page-link", 3, "click"]],
    template: function DataTableComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "table", 0)(1, "thead")(2, "tr", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, DataTableComponent_th_3_Template, 4, 1, "th", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, DataTableComponent_th_4_Template, 2, 0, "th", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, DataTableComponent_tr_6_Template, 3, 2, "tr", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5)(8, "ul", 6)(9, "li", 7)(10, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_Template_a_click_10_listener() {
          return ctx.changePage(ctx.currentPage - 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, DataTableComponent_li_12_Template, 3, 4, "li", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "li", 7)(14, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableComponent_Template_a_click_14_listener() {
          return ctx.changePage(ctx.currentPage + 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.tblHeaders);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.isVewEnabled || ctx.isUpdateOperationEnabled || ctx.isDeleteOperationEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.paginatedData);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](6, _c1, ctx.currentPage === 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.totalPages());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](8, _c1, ctx.currentPage === ctx.totalPages().length));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel],
    styles: [".container[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n    color: white;\r\n    background-color: #F89828;\r\n}\r\n\r\n\r\n.pagination-container[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin-top: 20px;\r\n}\r\n\r\n.pagination[_ngcontent-%COMP%] {\r\n    list-style-type: none;\r\n    display: flex;\r\n    margin: 0;\r\n    padding: 0;\r\n}\r\n\r\n.page-item[_ngcontent-%COMP%] {\r\n    margin: 0 2px;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n    padding: 5px 5px;\r\n    text-decoration: none;\r\n    color: #de981f;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%]:hover {\r\n    background-color: #de981f;\r\n    color: #fff;\r\n}\r\n\r\n.page-item.active[_ngcontent-%COMP%]   .page-link[_ngcontent-%COMP%] {\r\n    background-color: #F89828;\r\n    color: #fff;\r\n}\r\n\r\n\r\n.page-link[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\r\n    font-size: 18px;\r\n}\r\n\r\n\r\n\r\n\r\n.custom-table[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    color: black;\r\n    background-color: #ffdcb3;\r\n    border: 1px solid white;\r\n    border-collapse: collapse;\r\n    margin: 20px 0;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    color: red;\r\n    font-style: italic;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n#btndel[_ngcontent-%COMP%] {\r\n    padding: 5px;\r\n    border-radius: 40%;\r\n    border: none;\r\n    width: 30px;\r\n    height: 31px;\r\n    color: orange;\r\n    float: left;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin: 1px;\r\n    font-weight: 500;\r\n    font-size: 25px;\r\n}\r\n\r\n#btndel.hover[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: orange;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n#confirmationModal[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin: auto;\r\n}\r\n\r\n.modal-footer[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n#vehicleSummary[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    margin-left: 20px;\r\n    margin-top: 5px;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%], .warn[_ngcontent-%COMP%]::before, .warn[_ngcontent-%COMP%]::after {\r\n    position: relative;\r\n    padding: 0;\r\n    margin: 0;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%] {\r\n    font-size: 20px;\r\n    color: transparent;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n\r\n    top: 0.225em;\r\n\r\n    width: 1.15em;\r\n    height: 1.15em;\r\n\r\n    overflow: hidden;\r\n    border: none;\r\n    background-color: transparent;\r\n    border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::before {\r\n    content: \"\";\r\n    display: block;\r\n    top: -0.08em;\r\n    left: 0.0em;\r\n    position: absolute;\r\n    border: transparent 0.6em solid;\r\n    border-bottom-color: #448b23;\r\n    border-bottom-width: 1em;\r\n    border-top-width: 0;\r\n    box-shadow: #448b23 0 1px 1px;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::after {\r\n    display: block;\r\n    position: absolute;\r\n    top: 0.3em;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 0 1px;\r\n    text-align: center;\r\n    font-family: \"Garamond\";\r\n    content: \"!\";\r\n    font-size: 0.65em;\r\n    font-weight: bold;\r\n    color: white;\r\n}\r\n\r\n.woqod[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    box-shadow: #448b23 0 0.5px 0.5px;\r\n}\r\n\r\n\r\nth[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    cursor: pointer;\r\n}\r\n\r\n\r\n.sort-arrow[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n}\r\n\r\n.sort-arrow[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\r\n    color: white;\r\n}\r\n\r\n.sort-arrow[_ngcontent-%COMP%]   i.up[_ngcontent-%COMP%] {\r\n    margin-bottom: -4px;\r\n}\r\n\r\n.sort-arrow[_ngcontent-%COMP%]   i.down[_ngcontent-%COMP%] {\r\n    margin-top: -4px;\r\n}\r\n\r\n\r\n\r\n.bi-eye-fill[_ngcontent-%COMP%] {\r\n    color: white;\r\n    background-color: rgb(65, 190, 92);\r\n    cursor: pointer;\r\n    margin-right: 1%;\r\n    padding: 2% 2% 1.6% 2%;\r\n}\r\n\r\n.bi-pencil-fill[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n    cursor: pointer;\r\n    margin-right: 1%;\r\n    padding: 3% 3% 1.8% 3%;\r\n}\r\n\r\n.bi-trash-fill[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n    cursor: pointer;\r\n    margin-right: 1%;\r\n    padding: 2% 2% 1.6% 2%;\r\n}\r\n\r\n\r\n\r\n\r\n\r\ntr[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n}\r\n\r\ntable[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    border-collapse: collapse;\r\n}\r\n\r\nth[_ngcontent-%COMP%], td[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    padding: 8px;\r\n    border: 1px solid #ddd;\r\n}\r\n\r\n.highlighted[_ngcontent-%COMP%] {\r\n    background-color: rgb(255, 252, 214);\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hcHAtYWRtaW4vY29tcG9uZW50L2RhdGEtdGFibGUvZGF0YS10YWJsZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksWUFBWTtJQUNaLHlCQUF5QjtBQUM3Qjs7QUFFQSxhQUFhO0FBQ2I7SUFDSSxhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxxQkFBcUI7SUFDckIsYUFBYTtJQUNiLFNBQVM7SUFDVCxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGdCQUFnQjtJQUNoQixxQkFBcUI7SUFDckIsY0FBYztBQUNsQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixXQUFXO0FBQ2Y7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsV0FBVztBQUNmOztBQUVBLCtCQUErQjtBQUMvQjtJQUNJLGVBQWU7QUFDbkI7OztBQUdBLEdBQUc7O0FBRUg7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHlCQUF5QjtJQUN6Qix1QkFBdUI7SUFDdkIseUJBQXlCO0lBQ3pCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1Ysa0JBQWtCO0FBQ3RCOztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixXQUFXO0lBQ1gsWUFBWTtJQUNaLGFBQWE7SUFDYixXQUFXO0lBQ1gsYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksV0FBVztJQUNYLHdCQUF3QjtBQUM1Qjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGVBQWU7QUFDbkI7O0FBRUE7OztJQUdJLGtCQUFrQjtJQUNsQixVQUFVO0lBQ1YsU0FBUztBQUNiOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHFCQUFxQjs7SUFFckIsWUFBWTs7SUFFWixhQUFhO0lBQ2IsY0FBYzs7SUFFZCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsY0FBYztJQUNkLFlBQVk7SUFDWixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLCtCQUErQjtJQUMvQiw0QkFBNEI7SUFDNUIsd0JBQXdCO0lBQ3hCLG1CQUFtQjtJQUNuQiw2QkFBNkI7QUFDakM7O0FBRUE7SUFDSSxjQUFjO0lBQ2Qsa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixPQUFPO0lBQ1AsV0FBVztJQUNYLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsdUJBQXVCO0lBQ3ZCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSx1QkFBdUI7SUFDdkIsaUNBQWlDO0FBQ3JDOztBQUVBLGtCQUFrQjtBQUNsQjtJQUNJLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COzs7QUFHQTtJQUNJLGFBQWE7SUFDYixzQkFBc0I7SUFDdEIsbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksWUFBWTtBQUNoQjs7QUFFQTtJQUNJLG1CQUFtQjtBQUN2Qjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7O0FBR0EsVUFBVTtBQUNWO0lBQ0ksWUFBWTtJQUNaLGtDQUFrQztJQUNsQyxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtBQUMxQjs7QUFFQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtBQUMxQjs7QUFFQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHNCQUFzQjtBQUMxQjs7O0FBR0EsbUJBQW1COzs7QUFHbkI7SUFDSSxlQUFlO0FBQ25COztBQUVBO0lBQ0ksV0FBVztJQUNYLHlCQUF5QjtBQUM3Qjs7QUFFQTs7SUFFSSxrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLHNCQUFzQjtBQUMxQjs7QUFFQTtJQUNJLG9DQUFvQztBQUN4QyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG50aCB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xyXG59XHJcblxyXG4vKnBhZ2luYXRpb24qL1xyXG4ucGFnaW5hdGlvbi1jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ucGFnZS1pdGVtIHtcclxuICAgIG1hcmdpbjogMCAycHg7XHJcbn1cclxuXHJcbi5wYWdlLWxpbmsge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcGFkZGluZzogNXB4IDVweDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGNvbG9yOiAjZGU5ODFmO1xyXG59XHJcblxyXG4ucGFnZS1saW5rOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZTk4MWY7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLnBhZ2UtaXRlbS5hY3RpdmUgLnBhZ2UtbGluayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbi8qIEFkZCBzdHlsZXMgZm9yIGFycm93IGljb25zICovXHJcbi5wYWdlLWxpbmsgaSB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcblxyXG4vKiovXHJcblxyXG4uY3VzdG9tLXRhYmxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmRjYjM7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcclxuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICBtYXJnaW46IDIwcHggMDtcclxufVxyXG5cclxuLmVycm9yLW1lc3NhZ2Uge1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XHJcbiAgICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBhcHBlYXJhbmNlOiBub25lO1xyXG4gICAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4jYnRuZGVsIHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDQwJTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMXB4O1xyXG4gICAgY29sb3I6IG9yYW5nZTtcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbjogMXB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxufVxyXG5cclxuI2J0bmRlbC5ob3ZlciB7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufVxyXG5cclxuI2NvbmZpcm1hdGlvbk1vZGFsIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbjogYXV0bztcclxufVxyXG5cclxuLm1vZGFsLWZvb3RlciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbiN2ZWhpY2xlU3VtbWFyeSB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogNXB4O1xyXG59XHJcblxyXG4ud2FybixcclxuLndhcm46OmJlZm9yZSxcclxuLndhcm46OmFmdGVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi53YXJuIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbiB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblxyXG4gICAgdG9wOiAwLjIyNWVtO1xyXG5cclxuICAgIHdpZHRoOiAxLjE1ZW07XHJcbiAgICBoZWlnaHQ6IDEuMTVlbTtcclxuXHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwLjYyNWVtO1xyXG59XHJcblxyXG4ud2Fybi53YXJuaW5nLWdyZWVuOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgdG9wOiAtMC4wOGVtO1xyXG4gICAgbGVmdDogMC4wZW07XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3JkZXI6IHRyYW5zcGFyZW50IDAuNmVtIHNvbGlkO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzQ0OGIyMztcclxuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IDFlbTtcclxuICAgIGJvcmRlci10b3Atd2lkdGg6IDA7XHJcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMXB4IDFweDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbjo6YWZ0ZXIge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDAuM2VtO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcGFkZGluZzogMCAxcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LWZhbWlseTogXCJHYXJhbW9uZFwiO1xyXG4gICAgY29udGVudDogXCIhXCI7XHJcbiAgICBmb250LXNpemU6IDAuNjVlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ud29xb2Qge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMC41cHggMC41cHg7XHJcbn1cclxuXHJcbi8qb3JlZGVyaW5nIGFycm93Ki9cclxudGgge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG5cclxuLnNvcnQtYXJyb3cge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uc29ydC1hcnJvdyBpIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLnNvcnQtYXJyb3cgaS51cCB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtNHB4O1xyXG59XHJcblxyXG4uc29ydC1hcnJvdyBpLmRvd24ge1xyXG4gICAgbWFyZ2luLXRvcDogLTRweDtcclxufVxyXG5cclxuXHJcbi8qQWN0aW9ucyovXHJcbi5iaS1leWUtZmlsbCB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoNjUsIDE5MCwgOTIpO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxJTtcclxuICAgIHBhZGRpbmc6IDIlIDIlIDEuNiUgMiU7XHJcbn1cclxuXHJcbi5iaS1wZW5jaWwtZmlsbCB7XHJcbiAgICBjb2xvcjogI0Y4OTgyODtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG1hcmdpbi1yaWdodDogMSU7XHJcbiAgICBwYWRkaW5nOiAzJSAzJSAxLjglIDMlO1xyXG59XHJcblxyXG4uYmktdHJhc2gtZmlsbCB7XHJcbiAgICBjb2xvcjogI0Y4OTgyODtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG1hcmdpbi1yaWdodDogMSU7XHJcbiAgICBwYWRkaW5nOiAyJSAyJSAxLjYlIDIlO1xyXG59XHJcblxyXG5cclxuLypvbiByYXcgc2VsZWN0aW9uKi9cclxuXHJcblxyXG50ciB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbnRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxufVxyXG5cclxudGgsXHJcbnRkIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDhweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcbn1cclxuXHJcbi5oaWdobGlnaHRlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1LCAyNTIsIDIxNCk7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ })

}]);
//# sourceMappingURL=482.9e996549421728fb.js.map