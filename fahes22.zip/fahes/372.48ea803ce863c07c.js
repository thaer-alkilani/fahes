"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[372],{

/***/ 54611:
/*!*************************************************!*\
  !*** ./src/app/core/models/register-vehicle.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterVehicle": () => (/* binding */ RegisterVehicle)
/* harmony export */ });
class RegisterVehicle {
  constructor(details) {
    // Assign properties from the object
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 84908:
/*!************************************************!*\
  !*** ./src/app/core/models/service-request.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceRequest": () => (/* binding */ ServiceRequest)
/* harmony export */ });
class ServiceRequest {
  constructor(data) {
    Object.assign(this, data);
  }
}

/***/ }),

/***/ 11428:
/*!*************************************************************!*\
  !*** ./src/app/core/services/inspection-service.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionServiceService": () => (/* binding */ InspectionServiceService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class InspectionServiceService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Inspection/v1';
  }
  searchInpsectionRequestDetails(searchType, searchText, serviceType) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/SearchInpsectionRequestDetails`, {
      searchType,
      searchText,
      serviceType
    });
  }
  getInspectionDetailsByPlateNoAndPlateType(plateNo, plateType) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByPlateNoAndPlateType`, {
      plateNo,
      plateType
    });
  }
  getInspectionDetailsByVinNo(vinNo) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByVinNoDTO`, {
      vinNo
    });
  }
  getInspectionDetailsByRequestId(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByRequestId`, {
      requestId
    });
  }
  getInspectionDetailsByReceiptNo(receiptNo) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDetailsByReceiptNo`, {
      receiptNo
    });
  }
  createInspectionRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionRequest`, body);
  }
  getInspectionInstructionsByRequestId(inspectionId, sectionId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionInstructionsByRequestId`, {
      inspectionId,
      sectionId
    });
  }
  getInspectionDefects(inspectionRequest) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDefects`, {
      inspectionReqId: inspectionRequest
    });
  }
  deleteInspectionDefect(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/deleteInspectionDefect`, body);
  }
  getExternalInspectionRequests(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getExternalInspectionRequests`, body);
  }
  createInspectionStep(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionStep`, body);
  }
  submitTankerCertificateRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitTankerCertificateRequest`, body);
  }
  getQatarVinNumbersDetails(categoryId, requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getQatarVinNumbersDetails`, {
      categoryId,
      requestId
    });
  }
  submitVinStampingRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitVinStampingRequest`, body);
  }
  submitInspectionRequest(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitInspectionRequest`, {
      requestId
    });
  }
  getInspectedVehicleReportDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectedVehicleReportDetails`, body);
  }
  getSubServices(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSubServices`, body);
  }
  insertInspectionResultsReportLog(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/insertInspectionResultsReportLog`, body);
  }
  fillInspectionTankValues(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/fillInspectionTankValues`, body);
  }
  finishInspectionStep(inspectionStepId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/finishInspectionStep`, {
      inspectionStepId
    });
  }
  getFinalInspectionDeviceResult(deviceInspectionProcessDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getFinalInspectionDeviceResult`, deviceInspectionProcessDto);
  }
  getDeviceInspectionReads(deviceSectionInspectionDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDeviceInspectionReads`, deviceSectionInspectionDto);
  }
  getInspectionResultDetails(baseInspectionRequestDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionResultDetails`, baseInspectionRequestDto);
  }
  getVINSequences(body) {
    return this.fahesApiService.post(`${this.baseUrl}/MOI/v1/getVINSequences`, body);
  }
  calculateTankerCertificateVolume(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/calculateTankerCertificateVolume`, body);
  }
  startExternalInspectionRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/startExternalInspectionRequest`, body);
  }
  getInspectionRegisterVehicle(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionRegisterVehicle`, body);
  }
  static #_ = this.ɵfac = function InspectionServiceService_Factory(t) {
    return new (t || InspectionServiceService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: InspectionServiceService,
    factory: InspectionServiceService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 86074:
/*!**************************************************!*\
  !*** ./src/app/core/services/payment.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentService": () => (/* binding */ PaymentService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class PaymentService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Payment/v1';
  }
  submitPayment(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitPayment`, body);
  }
  static #_ = this.ɵfac = function PaymentService_Factory(t) {
    return new (t || PaymentService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: PaymentService,
    factory: PaymentService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 87010:
/*!***************************************************!*\
  !*** ./src/app/core/services/purchase.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PurchaseService": () => (/* binding */ PurchaseService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class PurchaseService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'AmpConnect/v1';
  }
  submitCardPayment(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/purchase`, body);
  }
  static #_ = this.ɵfac = function PurchaseService_Factory(t) {
    return new (t || PurchaseService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: PurchaseService,
    factory: PurchaseService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 43327:
/*!****************************************************************!*\
  !*** ./src/app/core/utilities/enums/inspectionServiceTypes.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionServiceTypes": () => (/* binding */ InspectionServiceTypes)
/* harmony export */ });
var InspectionServiceTypes;
(function (InspectionServiceTypes) {
  InspectionServiceTypes[InspectionServiceTypes["NormalInspection"] = 1] = "NormalInspection";
  InspectionServiceTypes[InspectionServiceTypes["JointPatrol"] = 2] = "JointPatrol";
  InspectionServiceTypes[InspectionServiceTypes["Import"] = 3] = "Import";
  InspectionServiceTypes[InspectionServiceTypes["MobileInspection"] = 4] = "MobileInspection";
  InspectionServiceTypes[InspectionServiceTypes["ExternalInspection"] = 5] = "ExternalInspection";
  InspectionServiceTypes[InspectionServiceTypes["Export"] = 6] = "Export";
  InspectionServiceTypes[InspectionServiceTypes["Investigation"] = 7] = "Investigation";
})(InspectionServiceTypes || (InspectionServiceTypes = {}));

/***/ }),

/***/ 81386:
/*!**************************************************************!*\
  !*** ./src/app/core/utilities/enums/payment-methods.enum.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentMethods": () => (/* binding */ PaymentMethods)
/* harmony export */ });
var PaymentMethods;
(function (PaymentMethods) {
  PaymentMethods[PaymentMethods["Cash"] = 1] = "Cash";
  PaymentMethods[PaymentMethods["Card"] = 2] = "Card";
  PaymentMethods[PaymentMethods["Online"] = 3] = "Online";
  PaymentMethods[PaymentMethods["CreditCustomer"] = 4] = "CreditCustomer";
})(PaymentMethods || (PaymentMethods = {}));

/***/ }),

/***/ 53805:
/*!*******************************************************************!*\
  !*** ./src/app/core/utilities/enums/system-lookup-value-codes.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemLookupValueCodes": () => (/* binding */ SystemLookupValueCodes)
/* harmony export */ });
var SystemLookupValueCodes;
(function (SystemLookupValueCodes) {
  //Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["Inspection"] = 1] = "Inspection";
  SystemLookupValueCodes[SystemLookupValueCodes["VINStamping"] = 2] = "VINStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["TankerCertificate"] = 3] = "TankerCertificate";
  SystemLookupValueCodes[SystemLookupValueCodes["Exempted"] = 4] = "Exempted";
  SystemLookupValueCodes[SystemLookupValueCodes["MobileInspection"] = 4] = "MobileInspection";
  //Registration Resource :
  SystemLookupValueCodes[SystemLookupValueCodes["MoblieApplication"] = 1] = "MoblieApplication";
  SystemLookupValueCodes[SystemLookupValueCodes["Booth"] = 2] = "Booth";
  SystemLookupValueCodes[SystemLookupValueCodes["BackOffice"] = 3] = "BackOffice";
  SystemLookupValueCodes[SystemLookupValueCodes["SupportDocuments"] = 1] = "SupportDocuments";
  SystemLookupValueCodes[SystemLookupValueCodes["InspectionImages"] = 2] = "InspectionImages";
  // Vin Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["NewStamping"] = 1] = "NewStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["ReStamping"] = 2] = "ReStamping";
})(SystemLookupValueCodes || (SystemLookupValueCodes = {}));

/***/ }),

/***/ 87580:
/*!******************************************************************!*\
  !*** ./node_modules/rxjs/dist/esm/internal/operators/timeout.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeoutError": () => (/* binding */ TimeoutError),
/* harmony export */   "timeout": () => (/* binding */ timeout)
/* harmony export */ });
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../scheduler/async */ 96936);
/* harmony import */ var _util_isDate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util/isDate */ 97885);
/* harmony import */ var _util_lift__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/lift */ 41944);
/* harmony import */ var _observable_innerFrom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../observable/innerFrom */ 54987);
/* harmony import */ var _util_createErrorClass__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/createErrorClass */ 27543);
/* harmony import */ var _OperatorSubscriber__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./OperatorSubscriber */ 93945);
/* harmony import */ var _util_executeSchedule__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../util/executeSchedule */ 1817);







const TimeoutError = (0,_util_createErrorClass__WEBPACK_IMPORTED_MODULE_0__.createErrorClass)(_super => function TimeoutErrorImpl(info = null) {
  _super(this);
  this.message = 'Timeout has occurred';
  this.name = 'TimeoutError';
  this.info = info;
});
function timeout(config, schedulerArg) {
  const {
    first,
    each,
    with: _with = timeoutErrorFactory,
    scheduler = schedulerArg !== null && schedulerArg !== void 0 ? schedulerArg : _scheduler_async__WEBPACK_IMPORTED_MODULE_1__.asyncScheduler,
    meta = null
  } = (0,_util_isDate__WEBPACK_IMPORTED_MODULE_2__.isValidDate)(config) ? {
    first: config
  } : typeof config === 'number' ? {
    each: config
  } : config;
  if (first == null && each == null) {
    throw new TypeError('No timeout provided.');
  }
  return (0,_util_lift__WEBPACK_IMPORTED_MODULE_3__.operate)((source, subscriber) => {
    let originalSourceSubscription;
    let timerSubscription;
    let lastValue = null;
    let seen = 0;
    const startTimer = delay => {
      timerSubscription = (0,_util_executeSchedule__WEBPACK_IMPORTED_MODULE_4__.executeSchedule)(subscriber, scheduler, () => {
        try {
          originalSourceSubscription.unsubscribe();
          (0,_observable_innerFrom__WEBPACK_IMPORTED_MODULE_5__.innerFrom)(_with({
            meta,
            lastValue,
            seen
          })).subscribe(subscriber);
        } catch (err) {
          subscriber.error(err);
        }
      }, delay);
    };
    originalSourceSubscription = source.subscribe(new _OperatorSubscriber__WEBPACK_IMPORTED_MODULE_6__.OperatorSubscriber(subscriber, value => {
      timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      seen++;
      subscriber.next(lastValue = value);
      each > 0 && startTimer(each);
    }, undefined, undefined, () => {
      if (!(timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.closed)) {
        timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      }
      lastValue = null;
    }));
    startTimer(first != null ? typeof first === 'number' ? first : +first - scheduler.now() : each);
  });
}
function timeoutErrorFactory(info) {
  throw new TimeoutError(info);
}

/***/ })

}]);
//# sourceMappingURL=372.48ea803ce863c07c.js.map