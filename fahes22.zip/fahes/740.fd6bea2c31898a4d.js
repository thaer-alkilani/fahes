"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[740],{

/***/ 59000:
/*!************************************************************!*\
  !*** ./src/app/core/models/adminstration/AreaOperation.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AreaOperation": () => (/* binding */ AreaOperation)
/* harmony export */ });
class AreaOperation {}

/***/ }),

/***/ 47298:
/*!********************************************************************!*\
  !*** ./src/app/core/models/adminstration/ClientAssetsOperation.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientAssetsOperation": () => (/* binding */ ClientAssetsOperation)
/* harmony export */ });
class ClientAssetsOperation {}

/***/ }),

/***/ 72434:
/*!******************************************************************!*\
  !*** ./src/app/core/models/adminstration/CreditCardOperation.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreditCardOperation": () => (/* binding */ CreditCardOperation)
/* harmony export */ });
class CreditCardOperation {}

/***/ }),

/***/ 87622:
/*!********************************************************************!*\
  !*** ./src/app/core/models/adminstration/DeviceVendorOperation.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectEvaluationOperation": () => (/* binding */ DefectEvaluationOperation),
/* harmony export */   "DeviceOutputDefectOperation": () => (/* binding */ DeviceOutputDefectOperation),
/* harmony export */   "DeviceVendorOperation": () => (/* binding */ DeviceVendorOperation),
/* harmony export */   "InputCodeOperation": () => (/* binding */ InputCodeOperation)
/* harmony export */ });
class DeviceVendorOperation {}
class InputCodeOperation {}
class DefectEvaluationOperation {}
class DeviceOutputDefectOperation {}

/***/ }),

/***/ 6524:
/*!**************************************************************!*\
  !*** ./src/app/core/models/adminstration/EntityOperation.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntityOperation": () => (/* binding */ EntityOperation)
/* harmony export */ });
class EntityOperation {}

/***/ }),

/***/ 64306:
/*!********************************************************************!*\
  !*** ./src/app/core/models/adminstration/GlobalConfigOperation.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalConfigOperation": () => (/* binding */ GlobalConfigOperation)
/* harmony export */ });
class GlobalConfigOperation {}

/***/ }),

/***/ 69346:
/*!****************************************************************!*\
  !*** ./src/app/core/models/adminstration/LocationOperation.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocationOperation": () => (/* binding */ LocationOperation)
/* harmony export */ });
class LocationOperation {}

/***/ }),

/***/ 40421:
/*!********************************************************************!*\
  !*** ./src/app/core/models/adminstration/ManufacturerOperation.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ManufacturerOperation": () => (/* binding */ ManufacturerOperation)
/* harmony export */ });
class ManufacturerOperation {}

/***/ }),

/***/ 88940:
/*!***************************************************************!*\
  !*** ./src/app/core/models/adminstration/MessageOperation.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MessageOperation": () => (/* binding */ MessageOperation)
/* harmony export */ });
class MessageOperation {}

/***/ }),

/***/ 16573:
/*!*************************************************************!*\
  !*** ./src/app/core/models/adminstration/ModelOperation.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModelOperation": () => (/* binding */ ModelOperation)
/* harmony export */ });
class ModelOperation {}

/***/ }),

/***/ 22516:
/*!**************************************************************!*\
  !*** ./src/app/core/models/adminstration/ModuleOperation.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModuleOperation": () => (/* binding */ ModuleOperation)
/* harmony export */ });
class ModuleOperation {}

/***/ }),

/***/ 58049:
/*!***********************************************************!*\
  !*** ./src/app/core/models/adminstration/POSOperation.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "POSOperation": () => (/* binding */ POSOperation)
/* harmony export */ });
class POSOperation {}

/***/ }),

/***/ 86171:
/*!************************************************************!*\
  !*** ./src/app/core/models/adminstration/RoleOperation.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "userRoleOperation": () => (/* binding */ userRoleOperation)
/* harmony export */ });
class userRoleOperation {}

/***/ }),

/***/ 24650:
/*!*************************************************************!*\
  !*** ./src/app/core/models/adminstration/ShapeOperation.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategoryShapesOperation": () => (/* binding */ CategoryShapesOperation),
/* harmony export */   "VehicleCategoryOperation": () => (/* binding */ VehicleCategoryOperation)
/* harmony export */ });
class CategoryShapesOperation {}
class VehicleCategoryOperation {}

/***/ }),

/***/ 97808:
/*!***********************************************************************!*\
  !*** ./src/app/core/models/adminstration/VehicleCategoryOperation.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleCategoryOperation": () => (/* binding */ VehicleCategoryOperation)
/* harmony export */ });
class VehicleCategoryOperation {}

/***/ }),

/***/ 72316:
/*!*******************************************************************!*\
  !*** ./src/app/core/models/adminstration/entityRoleOperations.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "entityRoleOperations": () => (/* binding */ entityRoleOperations)
/* harmony export */ });
class entityRoleOperations {}

/***/ }),

/***/ 12157:
/*!*******************************************************************!*\
  !*** ./src/app/core/models/adminstration/lookupValueOperation.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "lookupValueOperation": () => (/* binding */ lookupValueOperation)
/* harmony export */ });
class lookupValueOperation {}

/***/ }),

/***/ 13269:
/*!********************************************************************!*\
  !*** ./src/app/core/models/adminstration/systemLookupOperation.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "systemLookupOperation": () => (/* binding */ systemLookupOperation)
/* harmony export */ });
class systemLookupOperation {}

/***/ }),

/***/ 17201:
/*!******************************************************************!*\
  !*** ./src/app/core/models/adminstration/systemRoleOperation.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "systemRoleOperation": () => (/* binding */ systemRoleOperation)
/* harmony export */ });
class systemRoleOperation {}

/***/ }),

/***/ 17671:
/*!**********************************************************************!*\
  !*** ./src/app/core/models/adminstration/systemUserRoleOperation.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "systemUserRoleOperation": () => (/* binding */ systemUserRoleOperation)
/* harmony export */ });
class systemUserRoleOperation {}

/***/ }),

/***/ 45987:
/*!************************************************************!*\
  !*** ./src/app/core/models/adminstration/userOperation.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "userOperation": () => (/* binding */ userOperation)
/* harmony export */ });
class userOperation {}

/***/ }),

/***/ 88482:
/*!****************************************************************!*\
  !*** ./src/app/modules/administration/Pipes/highlight.pipe.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HighlightPipe": () => (/* binding */ HighlightPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 34497);


class HighlightPipe {
  constructor(_sanitizer) {
    this._sanitizer = _sanitizer;
  }
  // transform(items: any[], keyName: string, searchText: any): any {
  transform(list, keyName, searchText) {
    if (!list) {
      return [];
    }
    if (!searchText) {
      return list;
    }
    return list.filter(item => {
      const value = item[keyName].replace(searchText, `<span style='background-color:yellow'>${searchText}</span>`);
      return this._sanitizer.bypassSecurityTrustHtml(value);
    });
  }
  static #_ = this.ɵfac = function HighlightPipe_Factory(t) {
    return new (t || HighlightPipe)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.DomSanitizer, 16));
  };
  static #_2 = this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
    name: "highlight",
    type: HighlightPipe,
    pure: true
  });
}

/***/ }),

/***/ 27860:
/*!******************************************************************!*\
  !*** ./src/app/modules/administration/Pipes/text-search.pipe.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TextSearchPipe": () => (/* binding */ TextSearchPipe)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class TextSearchPipe {
  transform(items, keyName, text) {
    if (!text || !keyName) {
      return items;
    }
    const regEx = new RegExp("" + text, "i");
    return items.filter(item => {
      // if(item.display && typeof item.display === 'string'){
      //   return item.display.toLowerCase().indexOf(text.toLowerCase())> -1;
      // }
      if (item[keyName] && typeof item[keyName] === 'string') {
        // return item[keyName].toLowerCase().indexOf(text.toLowerCase())> -1;
        const itemString = item[keyName];
        const wordsList = itemString.split(" ");
        let resultFound = false;
        for (let s of wordsList) {
          resultFound = regEx.test(s);
          if (resultFound) {
            return resultFound;
          }
        }
        // const match = regEx.test(item[keyName]);
        // return match;
      }

      return false;
    });
  }
  static #_ = this.ɵfac = function TextSearchPipe_Factory(t) {
    return new (t || TextSearchPipe)();
  };
  static #_2 = this.ɵpipe = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({
    name: "textSearch",
    type: TextSearchPipe,
    pure: true
  });
}

/***/ }),

/***/ 83740:
/*!*****************************************************************!*\
  !*** ./src/app/modules/administration/administration.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdministrationModule": () => (/* binding */ AdministrationModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/data-table-viewer/data-table-viewer.component */ 75984);
/* harmony import */ var _systemAdmin_lookups_lookups_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./systemAdmin/lookups/lookups.component */ 20462);
/* harmony import */ var _systemAdmin_lookups_lookup_operation_lookup_operation_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./systemAdmin/lookups/lookup-operation/lookup-operation.component */ 38083);
/* harmony import */ var _systemAdmin_lookups_lookup_value_lookup_value_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./systemAdmin/lookups/lookup-value/lookup-value.component */ 45304);
/* harmony import */ var _systemAdmin_roles_roles_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./systemAdmin/roles/roles.component */ 9207);
/* harmony import */ var _systemAdmin_roles_role_operation_role_operation_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./systemAdmin/roles/role-operation/role-operation.component */ 51603);
/* harmony import */ var _Pipes_highlight_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Pipes/highlight.pipe */ 88482);
/* harmony import */ var _Pipes_text_search_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Pipes/text-search.pipe */ 27860);
/* harmony import */ var _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./components/select-dropdown-component/select-dropdown.component */ 55306);
/* harmony import */ var _systemAdmin_users_users_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./systemAdmin/users/users.component */ 81391);
/* harmony import */ var _systemAdmin_users_user_opertation_user_opertation_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./systemAdmin/users/user-opertation/user-opertation.component */ 14357);
/* harmony import */ var _systemAdmin_manufacturers_manufacturers_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./systemAdmin/manufacturers/manufacturers.component */ 77081);
/* harmony import */ var _systemAdmin_manufacturers_models_models_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./systemAdmin/manufacturers/models/models.component */ 85369);
/* harmony import */ var _systemAdmin_manufacturers_manufacturers_operation_manufacturers_operation_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./systemAdmin/manufacturers/manufacturers-operation/manufacturers-operation.component */ 5715);
/* harmony import */ var _systemAdmin_areas_areas_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./systemAdmin/areas/areas.component */ 26250);
/* harmony import */ var _systemAdmin_areas_areas_operation_areas_operation_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./systemAdmin/areas/areas-operation/areas-operation.component */ 23767);
/* harmony import */ var _systemAdmin_areas_locations_locations_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./systemAdmin/areas/locations/locations.component */ 20803);
/* harmony import */ var _systemAdmin_moddules_moddules_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./systemAdmin/moddules/moddules.component */ 76410);
/* harmony import */ var _systemAdmin_moddules_moddule_operation_moddule_operation_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./systemAdmin/moddules/moddule-operation/moddule-operation.component */ 26934);
/* harmony import */ var _systemAdmin_moddules_entities_entities_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./systemAdmin/moddules/entities/entities.component */ 41578);
/* harmony import */ var _systemAdmin_system_messages_system_messages_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./systemAdmin/system-messages/system-messages.component */ 85919);
/* harmony import */ var _systemAdmin_system_messages_system_messages_operation_system_messages_operation_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./systemAdmin/system-messages/system-messages-operation/system-messages-operation.component */ 37859);
/* harmony import */ var _systemAdmin_global_configurations_global_configurations_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./systemAdmin/global-configurations/global-configurations.component */ 93715);
/* harmony import */ var _systemAdmin_global_configurations_global_config_operation_global_config_operation_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./systemAdmin/global-configurations/global-config-operation/global-config-operation.component */ 74489);
/* harmony import */ var _station_admin_lanes_lanes_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./station-admin/lanes/lanes.component */ 41324);
/* harmony import */ var _station_admin_lanes_lane_operation_lane_operation_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./station-admin/lanes/lane-operation/lane-operation.component */ 1593);
/* harmony import */ var _station_admin_stations_stations_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./station-admin/stations/stations.component */ 93472);
/* harmony import */ var _station_admin_stations_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./station-admin/stations/station-operation/station-operation.component */ 90306);
/* harmony import */ var _station_admin_sections_sections_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./station-admin/sections/sections.component */ 22189);
/* harmony import */ var _station_admin_sections_section_operation_section_operation_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./station-admin/sections/section-operation/section-operation.component */ 20331);
/* harmony import */ var _systemAdmin_client_assets_client_assets_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./systemAdmin/client-assets/client-assets.component */ 79024);
/* harmony import */ var _systemAdmin_client_assets_client_assets_operation_client_assets_operation_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./systemAdmin/client-assets/client-assets-operation/client-assets-operation.component */ 23601);
/* harmony import */ var _systemAdmin_credit_card_types_credit_card_types_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./systemAdmin/credit-card-types/credit-card-types.component */ 15310);
/* harmony import */ var _systemAdmin_credit_card_types_credit_card_operation_credit_card_operation_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./systemAdmin/credit-card-types/credit-card-operation/credit-card-operation.component */ 24750);
/* harmony import */ var _systemAdmin_category_shapes_category_shapes_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./systemAdmin/category-shapes/category-shapes.component */ 44096);
/* harmony import */ var _systemAdmin_category_shapes_vehicle_category_operation_vehicle_category_operation_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./systemAdmin/category-shapes/vehicle-category-operation/vehicle-category-operation.component */ 30161);
/* harmony import */ var _administration_routing__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./administration.routing */ 77880);
/* harmony import */ var _systemAdmin_pos_terminal_pos_terminal_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./systemAdmin/pos-terminal/pos-terminal.component */ 28505);
/* harmony import */ var _systemAdmin_pos_terminal_pos_terminal_operation_pos_terminal_operation_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./systemAdmin/pos-terminal/pos-terminal-operation/pos-terminal-operation.component */ 75082);
/* harmony import */ var _systemAdmin_device_vendors_device_vendors_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./systemAdmin/device-vendors/device-vendors.component */ 25288);
/* harmony import */ var _systemAdmin_device_vendors_device_vendor_operation_device_vendor_operation_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./systemAdmin/device-vendors/device-vendor-operation/device-vendor-operation.component */ 81025);
/* harmony import */ var _systemAdmin_device_vendors_input_code_operation_input_code_operation_component__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./systemAdmin/device-vendors/input-code-operation/input-code-operation.component */ 76142);
/* harmony import */ var _systemAdmin_device_vendors_defect_evaluation_operation_defect_evaluation_operation_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./systemAdmin/device-vendors/defect-evaluation-operation/defect-evaluation-operation.component */ 87538);
/* harmony import */ var _systemAdmin_device_vendors_output_defect_output_defect_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./systemAdmin/device-vendors/output-defect/output-defect.component */ 21872);
/* harmony import */ var _systemAdmin_device_vendors_output_defect_output_defect_operation_output_defect_operation_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./systemAdmin/device-vendors/output-defect/output-defect-operation/output-defect-operation.component */ 24899);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! @angular/core */ 22560);

















































class AdministrationModule {
  static #_ = this.ɵfac = function AdministrationModule_Factory(t) {
    return new (t || AdministrationModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_46__["ɵɵdefineNgModule"]({
    type: AdministrationModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_46__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_47__.CommonModule, _administration_routing__WEBPACK_IMPORTED_MODULE_37__.AdministrationRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_48__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_46__["ɵɵsetNgModuleScope"](AdministrationModule, {
    declarations: [_components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_1__.DataTableViewerComponent, _systemAdmin_lookups_lookups_component__WEBPACK_IMPORTED_MODULE_2__.LookupsComponent, _systemAdmin_lookups_lookup_operation_lookup_operation_component__WEBPACK_IMPORTED_MODULE_3__.LookupOperationComponent, _systemAdmin_lookups_lookup_value_lookup_value_component__WEBPACK_IMPORTED_MODULE_4__.LookupValueComponent, _systemAdmin_roles_roles_component__WEBPACK_IMPORTED_MODULE_5__.RolesComponent, _systemAdmin_roles_role_operation_role_operation_component__WEBPACK_IMPORTED_MODULE_6__.RoleOperationComponent, _Pipes_highlight_pipe__WEBPACK_IMPORTED_MODULE_7__.HighlightPipe, _Pipes_text_search_pipe__WEBPACK_IMPORTED_MODULE_8__.TextSearchPipe, _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_9__.SelectDropdownComponent, _systemAdmin_users_users_component__WEBPACK_IMPORTED_MODULE_10__.UsersComponent, _systemAdmin_users_user_opertation_user_opertation_component__WEBPACK_IMPORTED_MODULE_11__.UserOpertationComponent, _systemAdmin_manufacturers_manufacturers_component__WEBPACK_IMPORTED_MODULE_12__.ManufacturersComponent, _systemAdmin_manufacturers_models_models_component__WEBPACK_IMPORTED_MODULE_13__.ModelsComponent, _systemAdmin_manufacturers_manufacturers_operation_manufacturers_operation_component__WEBPACK_IMPORTED_MODULE_14__.ManufacturersOperationComponent, _systemAdmin_areas_areas_component__WEBPACK_IMPORTED_MODULE_15__.AreasComponent, _systemAdmin_areas_areas_operation_areas_operation_component__WEBPACK_IMPORTED_MODULE_16__.AreasOperationComponent, _systemAdmin_areas_locations_locations_component__WEBPACK_IMPORTED_MODULE_17__.LocationsComponent, _systemAdmin_moddules_moddules_component__WEBPACK_IMPORTED_MODULE_18__.ModdulesComponent, _systemAdmin_moddules_moddule_operation_moddule_operation_component__WEBPACK_IMPORTED_MODULE_19__.ModduleOperationComponent, _systemAdmin_moddules_entities_entities_component__WEBPACK_IMPORTED_MODULE_20__.EntitiesComponent, _systemAdmin_system_messages_system_messages_component__WEBPACK_IMPORTED_MODULE_21__.SystemMessagesComponent, _systemAdmin_system_messages_system_messages_operation_system_messages_operation_component__WEBPACK_IMPORTED_MODULE_22__.SystemMessagesOperationComponent, _systemAdmin_global_configurations_global_configurations_component__WEBPACK_IMPORTED_MODULE_23__.GlobalConfigurationsComponent, _systemAdmin_global_configurations_global_config_operation_global_config_operation_component__WEBPACK_IMPORTED_MODULE_24__.GlobalConfigOperationComponent, _station_admin_stations_stations_component__WEBPACK_IMPORTED_MODULE_27__.StationsComponent, _station_admin_lanes_lanes_component__WEBPACK_IMPORTED_MODULE_25__.LanesComponent, _station_admin_lanes_lane_operation_lane_operation_component__WEBPACK_IMPORTED_MODULE_26__.LaneOperationComponent, _station_admin_stations_stations_component__WEBPACK_IMPORTED_MODULE_27__.StationsComponent, _station_admin_stations_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_28__.StationOperationComponent, _station_admin_sections_sections_component__WEBPACK_IMPORTED_MODULE_29__.SectionsComponent, _station_admin_sections_section_operation_section_operation_component__WEBPACK_IMPORTED_MODULE_30__.SectionOperationComponent, _systemAdmin_client_assets_client_assets_component__WEBPACK_IMPORTED_MODULE_31__.ClientAssetsComponent, _systemAdmin_client_assets_client_assets_operation_client_assets_operation_component__WEBPACK_IMPORTED_MODULE_32__.ClientAssetsOperationComponent, _systemAdmin_credit_card_types_credit_card_types_component__WEBPACK_IMPORTED_MODULE_33__.CreditCardTypesComponent, _systemAdmin_credit_card_types_credit_card_operation_credit_card_operation_component__WEBPACK_IMPORTED_MODULE_34__.CreditCardOperationComponent, _systemAdmin_category_shapes_category_shapes_component__WEBPACK_IMPORTED_MODULE_35__.CategoryShapesComponent, _systemAdmin_category_shapes_vehicle_category_operation_vehicle_category_operation_component__WEBPACK_IMPORTED_MODULE_36__.VehicleCategoryOperationComponent, _systemAdmin_pos_terminal_pos_terminal_component__WEBPACK_IMPORTED_MODULE_38__.PosTerminalComponent, _systemAdmin_pos_terminal_pos_terminal_operation_pos_terminal_operation_component__WEBPACK_IMPORTED_MODULE_39__.PosTerminalOperationComponent, _systemAdmin_device_vendors_device_vendors_component__WEBPACK_IMPORTED_MODULE_40__.DeviceVendorsComponent, _systemAdmin_device_vendors_device_vendor_operation_device_vendor_operation_component__WEBPACK_IMPORTED_MODULE_41__.DeviceVendorOperationComponent, _systemAdmin_device_vendors_input_code_operation_input_code_operation_component__WEBPACK_IMPORTED_MODULE_42__.InputCodeOperationComponent, _systemAdmin_device_vendors_defect_evaluation_operation_defect_evaluation_operation_component__WEBPACK_IMPORTED_MODULE_43__.DefectEvaluationOperationComponent, _systemAdmin_device_vendors_output_defect_output_defect_component__WEBPACK_IMPORTED_MODULE_44__.OutputDefectComponent, _systemAdmin_device_vendors_output_defect_output_defect_operation_output_defect_operation_component__WEBPACK_IMPORTED_MODULE_45__.OutputDefectOperationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_47__.CommonModule, _administration_routing__WEBPACK_IMPORTED_MODULE_37__.AdministrationRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_48__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule],
    exports: [_components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_1__.DataTableViewerComponent, _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_9__.SelectDropdownComponent]
  });
})();

/***/ }),

/***/ 77880:
/*!******************************************************************!*\
  !*** ./src/app/modules/administration/administration.routing.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AdministrationRoutingModule": () => (/* binding */ AdministrationRoutingModule)
/* harmony export */ });
/* harmony import */ var _systemAdmin_lookups_lookups_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./systemAdmin/lookups/lookups.component */ 20462);
/* harmony import */ var _systemAdmin_lookups_lookup_operation_lookup_operation_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./systemAdmin/lookups/lookup-operation/lookup-operation.component */ 38083);
/* harmony import */ var _systemAdmin_lookups_lookup_value_lookup_value_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./systemAdmin/lookups/lookup-value/lookup-value.component */ 45304);
/* harmony import */ var _systemAdmin_roles_roles_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./systemAdmin/roles/roles.component */ 9207);
/* harmony import */ var _systemAdmin_roles_role_operation_role_operation_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./systemAdmin/roles/role-operation/role-operation.component */ 51603);
/* harmony import */ var _systemAdmin_users_users_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./systemAdmin/users/users.component */ 81391);
/* harmony import */ var _systemAdmin_users_user_opertation_user_opertation_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./systemAdmin/users/user-opertation/user-opertation.component */ 14357);
/* harmony import */ var _systemAdmin_manufacturers_manufacturers_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./systemAdmin/manufacturers/manufacturers.component */ 77081);
/* harmony import */ var _systemAdmin_manufacturers_models_models_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./systemAdmin/manufacturers/models/models.component */ 85369);
/* harmony import */ var _systemAdmin_manufacturers_manufacturers_operation_manufacturers_operation_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./systemAdmin/manufacturers/manufacturers-operation/manufacturers-operation.component */ 5715);
/* harmony import */ var _systemAdmin_areas_areas_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./systemAdmin/areas/areas.component */ 26250);
/* harmony import */ var _systemAdmin_areas_areas_operation_areas_operation_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./systemAdmin/areas/areas-operation/areas-operation.component */ 23767);
/* harmony import */ var _systemAdmin_areas_locations_locations_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./systemAdmin/areas/locations/locations.component */ 20803);
/* harmony import */ var _systemAdmin_moddules_moddules_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./systemAdmin/moddules/moddules.component */ 76410);
/* harmony import */ var _systemAdmin_moddules_moddule_operation_moddule_operation_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./systemAdmin/moddules/moddule-operation/moddule-operation.component */ 26934);
/* harmony import */ var _systemAdmin_moddules_entities_entities_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./systemAdmin/moddules/entities/entities.component */ 41578);
/* harmony import */ var _systemAdmin_system_messages_system_messages_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./systemAdmin/system-messages/system-messages.component */ 85919);
/* harmony import */ var _systemAdmin_system_messages_system_messages_operation_system_messages_operation_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./systemAdmin/system-messages/system-messages-operation/system-messages-operation.component */ 37859);
/* harmony import */ var _systemAdmin_global_configurations_global_configurations_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./systemAdmin/global-configurations/global-configurations.component */ 93715);
/* harmony import */ var _systemAdmin_global_configurations_global_config_operation_global_config_operation_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./systemAdmin/global-configurations/global-config-operation/global-config-operation.component */ 74489);
/* harmony import */ var _station_admin_stations_stations_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./station-admin/stations/stations.component */ 93472);
/* harmony import */ var _station_admin_stations_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./station-admin/stations/station-operation/station-operation.component */ 90306);
/* harmony import */ var _systemAdmin_client_assets_client_assets_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./systemAdmin/client-assets/client-assets.component */ 79024);
/* harmony import */ var _systemAdmin_client_assets_client_assets_operation_client_assets_operation_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./systemAdmin/client-assets/client-assets-operation/client-assets-operation.component */ 23601);
/* harmony import */ var _systemAdmin_credit_card_types_credit_card_types_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./systemAdmin/credit-card-types/credit-card-types.component */ 15310);
/* harmony import */ var _systemAdmin_credit_card_types_credit_card_operation_credit_card_operation_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./systemAdmin/credit-card-types/credit-card-operation/credit-card-operation.component */ 24750);
/* harmony import */ var _systemAdmin_category_shapes_category_shapes_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./systemAdmin/category-shapes/category-shapes.component */ 44096);
/* harmony import */ var _systemAdmin_category_shapes_vehicle_category_operation_vehicle_category_operation_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./systemAdmin/category-shapes/vehicle-category-operation/vehicle-category-operation.component */ 30161);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _systemAdmin_pos_terminal_pos_terminal_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./systemAdmin/pos-terminal/pos-terminal.component */ 28505);
/* harmony import */ var _systemAdmin_pos_terminal_pos_terminal_operation_pos_terminal_operation_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./systemAdmin/pos-terminal/pos-terminal-operation/pos-terminal-operation.component */ 75082);
/* harmony import */ var _systemAdmin_device_vendors_device_vendors_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./systemAdmin/device-vendors/device-vendors.component */ 25288);
/* harmony import */ var _systemAdmin_device_vendors_device_vendor_operation_device_vendor_operation_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./systemAdmin/device-vendors/device-vendor-operation/device-vendor-operation.component */ 81025);
/* harmony import */ var _systemAdmin_device_vendors_input_code_operation_input_code_operation_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./systemAdmin/device-vendors/input-code-operation/input-code-operation.component */ 76142);
/* harmony import */ var _systemAdmin_device_vendors_defect_evaluation_operation_defect_evaluation_operation_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./systemAdmin/device-vendors/defect-evaluation-operation/defect-evaluation-operation.component */ 87538);
/* harmony import */ var _systemAdmin_device_vendors_output_defect_output_defect_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./systemAdmin/device-vendors/output-defect/output-defect.component */ 21872);
/* harmony import */ var _systemAdmin_device_vendors_output_defect_output_defect_operation_output_defect_operation_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./systemAdmin/device-vendors/output-defect/output-defect-operation/output-defect-operation.component */ 24899);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/core */ 22560);







































const routes = [
//lookups
{
  path: 'lookups',
  component: _systemAdmin_lookups_lookups_component__WEBPACK_IMPORTED_MODULE_0__.LookupsComponent
}, {
  path: 'lookups/new',
  component: _systemAdmin_lookups_lookup_operation_lookup_operation_component__WEBPACK_IMPORTED_MODULE_1__.LookupOperationComponent
}, {
  path: 'lookups/:selectionId',
  component: _systemAdmin_lookups_lookups_component__WEBPACK_IMPORTED_MODULE_0__.LookupsComponent
}, {
  path: 'lookups/view/:id',
  component: _systemAdmin_lookups_lookup_operation_lookup_operation_component__WEBPACK_IMPORTED_MODULE_1__.LookupOperationComponent
}, {
  path: 'lookups/edit/:id',
  component: _systemAdmin_lookups_lookup_operation_lookup_operation_component__WEBPACK_IMPORTED_MODULE_1__.LookupOperationComponent
}, {
  path: 'lookupValue/new/:lookupId',
  component: _systemAdmin_lookups_lookup_value_lookup_value_component__WEBPACK_IMPORTED_MODULE_2__.LookupValueComponent
}, {
  path: 'lookupValue/view/:lookupId/:lookupValueId',
  component: _systemAdmin_lookups_lookup_value_lookup_value_component__WEBPACK_IMPORTED_MODULE_2__.LookupValueComponent
}, {
  path: 'lookupValue/edit/:lookupId/:lookupValueId',
  component: _systemAdmin_lookups_lookup_value_lookup_value_component__WEBPACK_IMPORTED_MODULE_2__.LookupValueComponent
},
//roles
{
  path: 'roles',
  component: _systemAdmin_roles_roles_component__WEBPACK_IMPORTED_MODULE_3__.RolesComponent
}, {
  path: 'roles/new',
  component: _systemAdmin_roles_role_operation_role_operation_component__WEBPACK_IMPORTED_MODULE_4__.RoleOperationComponent
}, {
  path: 'roles/:selectionId',
  component: _systemAdmin_roles_roles_component__WEBPACK_IMPORTED_MODULE_3__.RolesComponent
}, {
  path: 'roles/view/:id',
  component: _systemAdmin_roles_role_operation_role_operation_component__WEBPACK_IMPORTED_MODULE_4__.RoleOperationComponent
}, {
  path: 'roles/edit/:id',
  component: _systemAdmin_roles_role_operation_role_operation_component__WEBPACK_IMPORTED_MODULE_4__.RoleOperationComponent
}
//users
, {
  path: 'users',
  component: _systemAdmin_users_users_component__WEBPACK_IMPORTED_MODULE_5__.UsersComponent
}, {
  path: 'users/new',
  component: _systemAdmin_users_user_opertation_user_opertation_component__WEBPACK_IMPORTED_MODULE_6__.UserOpertationComponent
}, {
  path: 'users/:selectionId',
  component: _systemAdmin_users_users_component__WEBPACK_IMPORTED_MODULE_5__.UsersComponent
}, {
  path: 'users/edit/:id',
  component: _systemAdmin_users_user_opertation_user_opertation_component__WEBPACK_IMPORTED_MODULE_6__.UserOpertationComponent
},
//Manufactur and models
{
  path: 'manufacturers',
  component: _systemAdmin_manufacturers_manufacturers_component__WEBPACK_IMPORTED_MODULE_7__.ManufacturersComponent
}, {
  path: 'manufacturers/new',
  component: _systemAdmin_manufacturers_manufacturers_operation_manufacturers_operation_component__WEBPACK_IMPORTED_MODULE_9__.ManufacturersOperationComponent
}, {
  path: 'manufacturers/:selectionId',
  component: _systemAdmin_manufacturers_manufacturers_component__WEBPACK_IMPORTED_MODULE_7__.ManufacturersComponent
}, {
  path: 'manufacturers/edit/:manufacturerId',
  component: _systemAdmin_manufacturers_manufacturers_operation_manufacturers_operation_component__WEBPACK_IMPORTED_MODULE_9__.ManufacturersOperationComponent
}, {
  path: 'models/new/:manufacturerId',
  component: _systemAdmin_manufacturers_models_models_component__WEBPACK_IMPORTED_MODULE_8__.ModelsComponent
}, {
  path: 'models/edit/:manufacturerId/:modelId',
  component: _systemAdmin_manufacturers_models_models_component__WEBPACK_IMPORTED_MODULE_8__.ModelsComponent
},
//Areas and Locations
{
  path: 'areas',
  component: _systemAdmin_areas_areas_component__WEBPACK_IMPORTED_MODULE_10__.AreasComponent
}, {
  path: 'areas/new',
  component: _systemAdmin_areas_areas_operation_areas_operation_component__WEBPACK_IMPORTED_MODULE_11__.AreasOperationComponent
}, {
  path: 'areas/:selectionId',
  component: _systemAdmin_areas_areas_component__WEBPACK_IMPORTED_MODULE_10__.AreasComponent
}, {
  path: 'areas/edit/:areaId',
  component: _systemAdmin_areas_areas_operation_areas_operation_component__WEBPACK_IMPORTED_MODULE_11__.AreasOperationComponent
}, {
  path: 'locations/new/:areaId',
  component: _systemAdmin_areas_locations_locations_component__WEBPACK_IMPORTED_MODULE_12__.LocationsComponent
}, {
  path: 'locations/edit/:areaId/:locationId',
  component: _systemAdmin_areas_locations_locations_component__WEBPACK_IMPORTED_MODULE_12__.LocationsComponent
},
// Modules and Entities
{
  path: 'modules',
  component: _systemAdmin_moddules_moddules_component__WEBPACK_IMPORTED_MODULE_13__.ModdulesComponent
}, {
  path: 'modules/new',
  component: _systemAdmin_moddules_moddule_operation_moddule_operation_component__WEBPACK_IMPORTED_MODULE_14__.ModduleOperationComponent
}, {
  path: 'modules/:selectionId',
  component: _systemAdmin_moddules_moddules_component__WEBPACK_IMPORTED_MODULE_13__.ModdulesComponent
}, {
  path: 'modules/edit/:moduleId',
  component: _systemAdmin_moddules_moddule_operation_moddule_operation_component__WEBPACK_IMPORTED_MODULE_14__.ModduleOperationComponent
}, {
  path: 'entities/new/:moduleId',
  component: _systemAdmin_moddules_entities_entities_component__WEBPACK_IMPORTED_MODULE_15__.EntitiesComponent
}, {
  path: 'entities/edit/:moduleId/:entityId',
  component: _systemAdmin_moddules_entities_entities_component__WEBPACK_IMPORTED_MODULE_15__.EntitiesComponent
},
// SystemMessages
{
  path: 'messages',
  component: _systemAdmin_system_messages_system_messages_component__WEBPACK_IMPORTED_MODULE_16__.SystemMessagesComponent
}, {
  path: 'messages/new',
  component: _systemAdmin_system_messages_system_messages_operation_system_messages_operation_component__WEBPACK_IMPORTED_MODULE_17__.SystemMessagesOperationComponent
}, {
  path: 'messages/:selectionId',
  component: _systemAdmin_system_messages_system_messages_component__WEBPACK_IMPORTED_MODULE_16__.SystemMessagesComponent
}, {
  path: 'messages/edit/:messageId',
  component: _systemAdmin_system_messages_system_messages_operation_system_messages_operation_component__WEBPACK_IMPORTED_MODULE_17__.SystemMessagesOperationComponent
},
//Global Conifg
{
  path: 'configurations',
  component: _systemAdmin_global_configurations_global_configurations_component__WEBPACK_IMPORTED_MODULE_18__.GlobalConfigurationsComponent
}, {
  path: 'configurations/new',
  component: _systemAdmin_global_configurations_global_config_operation_global_config_operation_component__WEBPACK_IMPORTED_MODULE_19__.GlobalConfigOperationComponent
}, {
  path: 'configurations/:selectionId',
  component: _systemAdmin_global_configurations_global_configurations_component__WEBPACK_IMPORTED_MODULE_18__.GlobalConfigurationsComponent
}, {
  path: 'configurations/edit/:configId',
  component: _systemAdmin_global_configurations_global_config_operation_global_config_operation_component__WEBPACK_IMPORTED_MODULE_19__.GlobalConfigOperationComponent
},
//Client Assets
{
  path: 'client-assets',
  component: _systemAdmin_client_assets_client_assets_component__WEBPACK_IMPORTED_MODULE_22__.ClientAssetsComponent
}, {
  path: 'client-assets/new',
  component: _systemAdmin_client_assets_client_assets_operation_client_assets_operation_component__WEBPACK_IMPORTED_MODULE_23__.ClientAssetsOperationComponent
}, {
  path: 'client-assets/:selectionId',
  component: _systemAdmin_client_assets_client_assets_component__WEBPACK_IMPORTED_MODULE_22__.ClientAssetsComponent
}, {
  path: 'client-assets/edit/:clientId',
  component: _systemAdmin_client_assets_client_assets_operation_client_assets_operation_component__WEBPACK_IMPORTED_MODULE_23__.ClientAssetsOperationComponent
},
// station
{
  path: 'stations',
  component: _station_admin_stations_stations_component__WEBPACK_IMPORTED_MODULE_20__.StationsComponent
}, {
  path: 'stations/new',
  component: _station_admin_stations_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_21__.StationOperationComponent
}, {
  path: 'stations/:selectionId',
  component: _station_admin_stations_stations_component__WEBPACK_IMPORTED_MODULE_20__.StationsComponent
}, {
  path: 'stations/edit/:stationId',
  component: _station_admin_stations_station_operation_station_operation_component__WEBPACK_IMPORTED_MODULE_21__.StationOperationComponent
},
// CreditCardTypes
{
  path: 'credit-cards',
  component: _systemAdmin_credit_card_types_credit_card_types_component__WEBPACK_IMPORTED_MODULE_24__.CreditCardTypesComponent
}, {
  path: 'credit-cards/new',
  component: _systemAdmin_credit_card_types_credit_card_operation_credit_card_operation_component__WEBPACK_IMPORTED_MODULE_25__.CreditCardOperationComponent
}, {
  path: 'credit-cards/:selectionId',
  component: _systemAdmin_credit_card_types_credit_card_types_component__WEBPACK_IMPORTED_MODULE_24__.CreditCardTypesComponent
}, {
  path: 'credit-cards/edit/:cardId',
  component: _systemAdmin_credit_card_types_credit_card_operation_credit_card_operation_component__WEBPACK_IMPORTED_MODULE_25__.CreditCardOperationComponent
},
//PosTerminal
{
  path: 'POS',
  component: _systemAdmin_pos_terminal_pos_terminal_component__WEBPACK_IMPORTED_MODULE_28__.PosTerminalComponent
}, {
  path: 'POS/new',
  component: _systemAdmin_pos_terminal_pos_terminal_operation_pos_terminal_operation_component__WEBPACK_IMPORTED_MODULE_29__.PosTerminalOperationComponent
}, {
  path: 'POS/:selectionId',
  component: _systemAdmin_pos_terminal_pos_terminal_component__WEBPACK_IMPORTED_MODULE_28__.PosTerminalComponent
}, {
  path: 'POS/edit/:posId',
  component: _systemAdmin_pos_terminal_pos_terminal_operation_pos_terminal_operation_component__WEBPACK_IMPORTED_MODULE_29__.PosTerminalOperationComponent
},
//Category Shapes
{
  path: 'vehicle-category-shapes',
  component: _systemAdmin_category_shapes_category_shapes_component__WEBPACK_IMPORTED_MODULE_26__.CategoryShapesComponent
}, {
  path: 'vehicle-category-shapes/new',
  component: _systemAdmin_category_shapes_vehicle_category_operation_vehicle_category_operation_component__WEBPACK_IMPORTED_MODULE_27__.VehicleCategoryOperationComponent
}, {
  path: 'vehicle-category-shapes/:selectionId',
  component: _systemAdmin_category_shapes_category_shapes_component__WEBPACK_IMPORTED_MODULE_26__.CategoryShapesComponent
}, {
  path: 'vehicle-category-shapes/edit/:categoryId',
  component: _systemAdmin_category_shapes_vehicle_category_operation_vehicle_category_operation_component__WEBPACK_IMPORTED_MODULE_27__.VehicleCategoryOperationComponent
},
//device vendors
{
  path: 'device-vendors',
  component: _systemAdmin_device_vendors_device_vendors_component__WEBPACK_IMPORTED_MODULE_30__.DeviceVendorsComponent
}, {
  path: 'device-vendors/new',
  component: _systemAdmin_device_vendors_device_vendor_operation_device_vendor_operation_component__WEBPACK_IMPORTED_MODULE_31__.DeviceVendorOperationComponent
}, {
  path: 'device-vendors/:selectionId',
  component: _systemAdmin_device_vendors_device_vendors_component__WEBPACK_IMPORTED_MODULE_30__.DeviceVendorsComponent
}, {
  path: 'device-vendors/edit/:deviceId/:vendorId',
  component: _systemAdmin_device_vendors_device_vendor_operation_device_vendor_operation_component__WEBPACK_IMPORTED_MODULE_31__.DeviceVendorOperationComponent
}, {
  path: 'device-Input-code/edit/:deviceId/:codeId/:codeOperation',
  component: _systemAdmin_device_vendors_input_code_operation_input_code_operation_component__WEBPACK_IMPORTED_MODULE_32__.InputCodeOperationComponent
}, {
  path: 'device-Input-code/new/:vendorId',
  component: _systemAdmin_device_vendors_input_code_operation_input_code_operation_component__WEBPACK_IMPORTED_MODULE_32__.InputCodeOperationComponent
}, {
  path: 'device-defect-evaluation/edit/:vendorId',
  component: _systemAdmin_device_vendors_defect_evaluation_operation_defect_evaluation_operation_component__WEBPACK_IMPORTED_MODULE_33__.DefectEvaluationOperationComponent
}, {
  path: 'device-defect-evaluation/new/:vendorId',
  component: _systemAdmin_device_vendors_defect_evaluation_operation_defect_evaluation_operation_component__WEBPACK_IMPORTED_MODULE_33__.DefectEvaluationOperationComponent
}, {
  path: 'device-defect-evaluation/:vendorId/:outputCode/output-defects',
  component: _systemAdmin_device_vendors_output_defect_output_defect_component__WEBPACK_IMPORTED_MODULE_34__.OutputDefectComponent
}, {
  path: 'device-defect-evaluation/:vendorId/:outputCode/output-defects/edit/:defCommentId',
  component: _systemAdmin_device_vendors_output_defect_output_defect_operation_output_defect_operation_component__WEBPACK_IMPORTED_MODULE_35__.OutputDefectOperationComponent
}, {
  path: 'device-defect-evaluation/:vendorId/:outputCode/output-defects/new',
  component: _systemAdmin_device_vendors_output_defect_output_defect_operation_output_defect_operation_component__WEBPACK_IMPORTED_MODULE_35__.OutputDefectOperationComponent
}];
class AdministrationRoutingModule {
  static #_ = this.ɵfac = function AdministrationRoutingModule_Factory(t) {
    return new (t || AdministrationRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_36__["ɵɵdefineNgModule"]({
    type: AdministrationRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_36__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_37__.RouterModule.forChild(routes)]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_36__["ɵɵsetNgModuleScope"](AdministrationRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_37__.RouterModule]
  });
})();

/***/ }),

/***/ 75984:
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/administration/components/data-table-viewer/data-table-viewer.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataTableViewerComponent": () => (/* binding */ DataTableViewerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);




function DataTableViewerComponent_th_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "i", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_th_3_Template_i_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);
      const header_r4 = restoredCtx.$implicit;
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r5.dataOrderingAscDesc(header_r4.JsonPropName, "asc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "i", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_th_3_Template_i_click_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6);
      const header_r4 = restoredCtx.$implicit;
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r7.dataOrderingAscDesc(header_r4.JsonPropName, "desc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const header_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", header_r4.showName, " ");
  }
}
function DataTableViewerComponent_th_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "th", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, " Action ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableViewerComponent_tr_6_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "td")(2, "input", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DataTableViewerComponent_tr_6_ng_container_1_ng_container_1_Template_input_ngModelChange_2_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17);
      const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](row_r8[header_r11.JsonPropName] = $event);
    })("change", function DataTableViewerComponent_tr_6_ng_container_1_ng_container_1_Template_input_change_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r17);
      const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r19.getCheckBoxValue(header_r11.JsonPropName, row_r8[header_r11.JsonPropName], row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("highlighted", row_r8 == ctx_r12.selectedRow);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", row_r8[header_r11.JsonPropName]);
  }
}
function DataTableViewerComponent_tr_6_ng_container_1_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_tr_6_ng_container_1_ng_template_2_Template_td_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r26);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r24.onRawSelection(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const header_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("highlighted", row_r8 == ctx_r14.selectedRow);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", row_r8[header_r11.JsonPropName], " ");
  }
}
function DataTableViewerComponent_tr_6_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DataTableViewerComponent_tr_6_ng_container_1_ng_container_1_Template, 3, 3, "ng-container", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DataTableViewerComponent_tr_6_ng_container_1_ng_template_2_Template, 2, 3, "ng-template", null, 17, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const header_r11 = ctx.$implicit;
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", header_r11.ShowInCheckBox)("ngIfElse", _r13);
  }
}
function DataTableViewerComponent_tr_6_td_2_i_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "i", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_tr_6_td_2_i_1_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r35);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r33.viewSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableViewerComponent_tr_6_td_2_i_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "i", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_tr_6_td_2_i_2_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r38);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r36.updateSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableViewerComponent_tr_6_td_2_i_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "i", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_tr_6_td_2_i_3_Template_i_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r41);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r39.deleteSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
}
function DataTableViewerComponent_tr_6_td_2_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_tr_6_td_2_button_4_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r44);
      const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
      const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r42.navigateSelectedItem(row_r8));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r32.navigationBtn.label, " ");
  }
}
function DataTableViewerComponent_tr_6_td_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DataTableViewerComponent_tr_6_td_2_i_1_Template, 1, 0, "i", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DataTableViewerComponent_tr_6_td_2_i_2_Template, 1, 0, "i", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, DataTableViewerComponent_tr_6_td_2_i_3_Template, 1, 0, "i", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, DataTableViewerComponent_tr_6_td_2_button_4_Template, 2, 1, "button", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const row_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("highlighted", row_r8 == ctx_r10.selectedRow);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.isVewEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.isUpdateOperationEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.isDeleteOperationEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r10.navigationBtn.isEnabled);
  }
}
function DataTableViewerComponent_tr_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DataTableViewerComponent_tr_6_ng_container_1_Template, 4, 2, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, DataTableViewerComponent_tr_6_td_2_Template, 5, 6, "td", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r2.tblHeaders);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx_r2.isVewEnabled || ctx_r2.isUpdateOperationEnabled || ctx_r2.isDeleteOperationEnabled) && ctx_r2.showActions);
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function DataTableViewerComponent_li_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 28)(1, "a", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_li_12_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48);
      const page_r46 = restoredCtx.$implicit;
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r47.changePage(page_r46));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const page_r46 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c0, ctx_r3.currentPage === page_r46));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](page_r46);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
class DataTableViewerComponent {
  constructor(cdr) {
    this.cdr = cdr;
    this.isDeleteOperationEnabled = true;
    this.isVewEnabled = false;
    this.showActions = true;
    this.isUpdateOperationEnabled = true;
    this.backendOrdering = false;
    this.backendPagination = false;
    this.navigationBtn = {
      isEnabled: false,
      label: null
    };
    this.viewItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.updateItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.deleteItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.selectItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.checkboxEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.orderingEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.paginationEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.navigateItemEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.isAscending = true;
    this.currentPage = 1;
    this.pageSize = 5;
    this.selectedRow = null;
  }
  ngOnInit() {
    if (this.tblHeaders.length > 0 && !this.backendOrdering) this.dataOrderingAscDesc(this.tblHeaders[0].JsonPropName, 'asc');
  }
  ngOnChanges(changes) {
    this.cdr.detectChanges(); // Manually trigger change detection
    if (changes.backendPagination) {
      this.totalPages();
    }
  }
  viewSelectedItem(item) {
    this.viewItemEvent.emit(item);
  }
  deleteSelectedItem(item) {
    this.deleteItemEvent.emit(item);
  }
  updateSelectedItem(item) {
    this.updateItemEvent.emit(item);
  }
  onRawSelection(item) {
    this.selectedRow = item;
    this.selectItemEvent.emit(item);
  }
  dataOrderingAscDesc(propertyName, sortOrder) {
    if (!this.backendOrdering) {
      if (this.tblValues.data?.length) this.tblValues.data.sort((a, b) => {
        let valueA = a[propertyName];
        let valueB = b[propertyName];
        valueA = valueA != null ? valueA.toUpperCase() : valueA;
        valueB = valueB != null ? valueB.toUpperCase() : valueB;
        if (valueA < valueB) {
          return sortOrder === 'asc' ? -1 : 1;
        } else if (valueA > valueB) {
          return sortOrder === 'asc' ? 1 : -1;
        } else {
          return 0;
        }
      });
    } else {
      this.orderingEvent.emit({
        sortOrder: sortOrder,
        orderBy: this.transformString(propertyName)
      });
    }
    this.currentPage = 1;
  }
  transformString(inputString) {
    const words = inputString.split(/(?=[A-Z])/);
    const capitalizedWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
    const result = capitalizedWords.join('_');
    return result;
  }
  totalPages() {
    let total = 0;
    if (!this.backendPagination) total = Math.ceil(this.tblValues.data?.length / this.pageSize);else total = this.tblValues.totalPages;
    return Array.from({
      length: total
    }, (_, i) => i + 1);
  }
  changePage(page) {
    if (page >= 1 && page <= this.totalPages().length) this.currentPage = page;
    if (this.backendPagination) this.paginationEvent.emit({
      pageIndex: page
    });
  }
  get paginatedData() {
    if (this.backendPagination) return this.tblValues.data;
    if (this.pageSize === -1) return this.tblValues.data; // Return all data when pageSize is -1
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = Math.min(startIndex + this.pageSize, this.tblValues.data?.length);
    return this.tblValues.data?.slice(startIndex, endIndex);
  }
  getCheckBoxValue(JsonPropName, value, item) {
    this.checkboxEvent.emit({
      JsonPropName: JsonPropName,
      value: value,
      selectedItem: item
    });
  }
  navigateSelectedItem(item) {
    this.selectedRow = item;
    this.navigateItemEvent.emit(item);
  }
  static #_ = this.ɵfac = function DataTableViewerComponent_Factory(t) {
    return new (t || DataTableViewerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DataTableViewerComponent,
    selectors: [["app-data-table-viewer"]],
    inputs: {
      tblHeaders: "tblHeaders",
      tblValues: "tblValues",
      isDeleteOperationEnabled: "isDeleteOperationEnabled",
      isVewEnabled: "isVewEnabled",
      showActions: "showActions",
      isUpdateOperationEnabled: "isUpdateOperationEnabled",
      backendOrdering: "backendOrdering",
      backendPagination: "backendPagination",
      navigationBtn: "navigationBtn",
      selectedRow: "selectedRow"
    },
    outputs: {
      viewItemEvent: "viewItemEvent",
      updateItemEvent: "updateItemEvent",
      deleteItemEvent: "deleteItemEvent",
      selectItemEvent: "selectItemEvent",
      checkboxEvent: "checkboxEvent",
      orderingEvent: "orderingEvent",
      paginationEvent: "paginationEvent",
      navigateItemEvent: "navigateItemEvent"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
    decls: 16,
    vars: 10,
    consts: [[1, "table", "table-striped", "table-bordered"], ["id", "headertb"], ["scope", "col", 4, "ngFor", "ngForOf"], ["scope", "col", 4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], ["scope", "col"], [1, "bi", "bi-arrow-up", "up", 3, "click"], [1, "bi", "bi-arrow-down", "down", 3, "click"], [3, "highlighted", 4, "ngIf"], [4, "ngIf", "ngIfElse"], ["textColumn", ""], ["type", "checkbox", 3, "ngModel", "ngModelChange", "change"], [3, "click"], ["class", "bi bi-eye-fill", 3, "click", 4, "ngIf"], ["class", "bi bi-pencil-fill", 3, "click", 4, "ngIf"], ["class", "bi bi-trash-fill", 3, "click", 4, "ngIf"], ["class", "btn btn-outline-orange small-text", 3, "click", 4, "ngIf"], [1, "bi", "bi-eye-fill", 3, "click"], [1, "bi", "bi-pencil-fill", 3, "click"], [1, "bi", "bi-trash-fill", 3, "click"], [1, "btn", "btn-outline-orange", "small-text", 3, "click"], [1, "page-item", 3, "ngClass"], [1, "page-link", 3, "click"]],
    template: function DataTableViewerComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "table", 0)(1, "thead")(2, "tr", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, DataTableViewerComponent_th_3_Template, 4, 1, "th", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, DataTableViewerComponent_th_4_Template, 2, 0, "th", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, DataTableViewerComponent_tr_6_Template, 3, 2, "tr", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 5)(8, "ul", 6)(9, "li", 7)(10, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_Template_a_click_10_listener() {
          return ctx.changePage(ctx.currentPage - 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](11, "i", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, DataTableViewerComponent_li_12_Template, 3, 4, "li", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "li", 7)(14, "a", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DataTableViewerComponent_Template_a_click_14_listener() {
          return ctx.changePage(ctx.currentPage + 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "i", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.tblHeaders);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", (ctx.isVewEnabled || ctx.isUpdateOperationEnabled || ctx.isDeleteOperationEnabled) && ctx.showActions);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.paginatedData);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](6, _c1, ctx.currentPage === 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.totalPages());
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](8, _c1, ctx.currentPage === ctx.totalPages().length));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel],
    styles: [".container[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\nth[_ngcontent-%COMP%] {\r\n    color: white;\r\n    background-color: #F89828;\r\n}\r\n\r\n\r\n.pagination-container[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin-top: 20px;\r\n}\r\n\r\n.pagination[_ngcontent-%COMP%] {\r\n    list-style-type: none;\r\n    display: flex;\r\n    margin: 0;\r\n    padding: 0;\r\n}\r\n\r\n.page-item[_ngcontent-%COMP%] {\r\n    margin: 0 2px;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n    padding: 5px 5px ;\r\n    text-decoration: none;\r\n    color: #de981f;  \r\n}\r\n\r\n.page-link[_ngcontent-%COMP%]:hover {\r\n    background-color: #de981f;\r\n    color: #fff;\r\n}\r\n\r\n.page-item.active[_ngcontent-%COMP%]   .page-link[_ngcontent-%COMP%] {\r\n    background-color: #F89828 ;\r\n    color: #fff;\r\n}\r\n\r\n\r\n.page-link[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\r\n    font-size: 18px;\r\n}\r\n\r\n\r\n\r\n\r\n.custom-table[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    color: black;\r\n    background-color: #ffdcb3;\r\n    border: 1px solid white;\r\n    border-collapse: collapse;\r\n    margin: 20px 0;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    color: red;\r\n    font-style: italic;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n#btndel[_ngcontent-%COMP%] {\r\n    padding: 5px;\r\n    border-radius: 40%;\r\n    border: none;\r\n    width: 30px;\r\n    height: 31px;\r\n    color: orange;\r\n    float: left;\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    margin: 1px;\r\n    font-weight: 500;\r\n    font-size: 25px;\r\n}\r\n\r\n#btndel.hover[_ngcontent-%COMP%] {\r\n    color: #fff;\r\n    background-color: orange;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n#confirmationModal[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin: auto;\r\n}\r\n\r\n.modal-footer[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n#vehicleSummary[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    margin-left: 20px;\r\n    margin-top: 5px;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%], .warn[_ngcontent-%COMP%]::before, .warn[_ngcontent-%COMP%]::after {\r\n    position: relative;\r\n    padding: 0;\r\n    margin: 0;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%] {\r\n    font-size: 20px;\r\n    color: transparent;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%] {\r\n    display: inline-block;\r\n\r\n    top: 0.225em;\r\n\r\n    width: 1.15em;\r\n    height: 1.15em;\r\n\r\n    overflow: hidden;\r\n    border: none;\r\n    background-color: transparent;\r\n    border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::before {\r\n    content: \"\";\r\n    display: block;\r\n    top: -0.08em;\r\n    left: 0.0em;\r\n    position: absolute;\r\n    border: transparent 0.6em solid;\r\n    border-bottom-color: #448b23;\r\n    border-bottom-width: 1em;\r\n    border-top-width: 0;\r\n    box-shadow: #448b23 0 1px 1px;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::after {\r\n    display: block;\r\n    position: absolute;\r\n    top: 0.3em;\r\n    left: 0;\r\n    width: 100%;\r\n    padding: 0 1px;\r\n    text-align: center;\r\n    font-family: \"Garamond\";\r\n    content: \"!\";\r\n    font-size: 0.65em;\r\n    font-weight: bold;\r\n    color: white;\r\n}\r\n\r\n.woqod[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    box-shadow: #448b23 0 0.5px 0.5px;\r\n}\r\n \r\n \r\nth[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    cursor: pointer;\r\n}\r\n \r\n\r\n.sort-arrow[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n}\r\n\r\n.sort-arrow[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\r\n    color: white;\r\n}\r\n\r\n.sort-arrow[_ngcontent-%COMP%]   i.up[_ngcontent-%COMP%] {\r\n    margin-bottom: -4px;\r\n}\r\n\r\n.sort-arrow[_ngcontent-%COMP%]   i.down[_ngcontent-%COMP%] {\r\n    margin-top: -4px;\r\n}\r\n\r\n\r\n\r\n.bi-eye-fill[_ngcontent-%COMP%]  {\r\n    color: white;\r\n    background-color: rgb(65, 190, 92);\r\n    cursor: pointer; \r\n    margin-right: 1%;\r\n    padding: 2% 2% 1.6% 2%; \r\n}\r\n \r\n.bi-pencil-fill[_ngcontent-%COMP%]{ \r\n    color:  #de981f;\r\n    cursor: pointer;\r\n    margin-right: 1%;\r\n    padding: 2% 2% 1.6% 2%; \r\n}\r\n\r\n.bi-trash-fill[_ngcontent-%COMP%] { \r\n    color: rgb(233, 50, 17);\r\n    cursor: pointer;\r\n    margin-right: 1%;\r\n    padding: 2% 2% 1.6% 2%; \r\n}\r\n\r\n\r\n\r\n \r\n\r\ntr[_ngcontent-%COMP%]{\r\n    cursor: pointer;\r\n}\r\n \r\ntable[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    border-collapse: collapse;\r\n}\r\n\r\nth[_ngcontent-%COMP%], td[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    padding: 8px;\r\n    border: 1px solid #ddd;\r\n}\r\n\r\n.highlighted[_ngcontent-%COMP%]{  background-color:rgb(255, 252, 214); }\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL2RhdGEtdGFibGUtdmlld2VyL2RhdGEtdGFibGUtdmlld2VyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxZQUFZO0lBQ1oseUJBQXlCO0FBQzdCOztBQUVBLGFBQWE7QUFDYjtJQUNJLGFBQWE7SUFDYix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLHFCQUFxQjtJQUNyQixhQUFhO0lBQ2IsU0FBUztJQUNULFVBQVU7QUFDZDs7QUFFQTtJQUNJLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLHFCQUFxQjtJQUNyQixjQUFjO0FBQ2xCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFdBQVc7QUFDZjs7QUFFQTtJQUNJLDBCQUEwQjtJQUMxQixXQUFXO0FBQ2Y7O0FBRUEsK0JBQStCO0FBQy9CO0lBQ0ksZUFBZTtBQUNuQjs7O0FBR0EsR0FBRzs7QUFFSDtJQUNJLGtCQUFrQjtJQUNsQixZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLHVCQUF1QjtJQUN2Qix5QkFBeUI7SUFDekIsY0FBYztBQUNsQjs7QUFFQTtJQUNJLFVBQVU7SUFDVixrQkFBa0I7QUFDdEI7O0FBRUE7O0lBR0ksZ0JBQWdCO0lBQ2hCLFNBQVM7QUFDYjs7QUFFQTtJQUNJLFlBQVk7SUFDWixrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLFdBQVc7SUFDWCxZQUFZO0lBQ1osYUFBYTtJQUNiLFdBQVc7SUFDWCxhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsZ0JBQWdCO0lBQ2hCLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsd0JBQXdCO0FBQzVCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsZUFBZTtBQUNuQjs7QUFFQTs7O0lBR0ksa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxlQUFlO0lBQ2Ysa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0kscUJBQXFCOztJQUVyQixZQUFZOztJQUVaLGFBQWE7SUFDYixjQUFjOztJQUVkLGdCQUFnQjtJQUNoQixZQUFZO0lBQ1osNkJBQTZCO0lBQzdCLHNCQUFzQjtBQUMxQjs7QUFFQTtJQUNJLFdBQVc7SUFDWCxjQUFjO0lBQ2QsWUFBWTtJQUNaLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsK0JBQStCO0lBQy9CLDRCQUE0QjtJQUM1Qix3QkFBd0I7SUFDeEIsbUJBQW1CO0lBQ25CLDZCQUE2QjtBQUNqQzs7QUFFQTtJQUNJLGNBQWM7SUFDZCxrQkFBa0I7SUFDbEIsVUFBVTtJQUNWLE9BQU87SUFDUCxXQUFXO0lBQ1gsY0FBYztJQUNkLGtCQUFrQjtJQUNsQix1QkFBdUI7SUFDdkIsWUFBWTtJQUNaLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLHVCQUF1QjtJQUN2QixpQ0FBaUM7QUFDckM7O0NBRUMsa0JBQWtCO0FBQ25CO0lBQ0ksa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkI7OztBQUdBO0lBQ0ksYUFBYTtJQUNiLHNCQUFzQjtJQUN0QixtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksbUJBQW1CO0FBQ3ZCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCOzs7QUFHQSxVQUFVO0FBQ1Y7SUFDSSxZQUFZO0lBQ1osa0NBQWtDO0lBQ2xDLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsc0JBQXNCO0FBQzFCOztBQUVBO0lBQ0ksZUFBZTtJQUNmLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsc0JBQXNCO0FBQzFCOztBQUVBO0lBQ0ksdUJBQXVCO0lBQ3ZCLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsc0JBQXNCO0FBQzFCOzs7QUFHQSxtQkFBbUI7OztBQUduQjtJQUNJLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxXQUFXO0lBQ1gseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFlBQVk7SUFDWixzQkFBc0I7QUFDMUI7O0FBRUEsZUFBZSxtQ0FBbUMsRUFBRSIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG50aCB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xyXG59XHJcblxyXG4vKnBhZ2luYXRpb24qL1xyXG4ucGFnaW5hdGlvbi1jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi5wYWdpbmF0aW9uIHtcclxuICAgIGxpc3Qtc3R5bGUtdHlwZTogbm9uZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG59XHJcblxyXG4ucGFnZS1pdGVtIHtcclxuICAgIG1hcmdpbjogMCAycHg7XHJcbn1cclxuXHJcbi5wYWdlLWxpbmsge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcGFkZGluZzogNXB4IDVweCA7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBjb2xvcjogI2RlOTgxZjsgIFxyXG59XHJcblxyXG4ucGFnZS1saW5rOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZTk4MWY7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLnBhZ2UtaXRlbS5hY3RpdmUgLnBhZ2UtbGluayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4IDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4vKiBBZGQgc3R5bGVzIGZvciBhcnJvdyBpY29ucyAqL1xyXG4ucGFnZS1saW5rIGkge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcblxyXG5cclxuLyoqL1xyXG5cclxuLmN1c3RvbS10YWJsZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZkY2IzO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gICAgbWFyZ2luOiAyMHB4IDA7XHJcbn1cclxuXHJcbi5lcnJvci1tZXNzYWdlIHtcclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbn1cclxuXHJcbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtaW5uZXItc3Bpbi1idXR0b24sXHJcbmlucHV0W3R5cGU9XCJudW1iZXJcIl06Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24ge1xyXG4gICAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xyXG4gICAgYXBwZWFyYW5jZTogbm9uZTtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuI2J0bmRlbCB7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0MCU7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICB3aWR0aDogMzBweDtcclxuICAgIGhlaWdodDogMzFweDtcclxuICAgIGNvbG9yOiBvcmFuZ2U7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDFweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbn1cclxuXHJcbiNidG5kZWwuaG92ZXIge1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBvcmFuZ2U7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn1cclxuXHJcbiNjb25maXJtYXRpb25Nb2RhbCB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbn1cclxuXHJcbi5tb2RhbC1mb290ZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4jdmVoaWNsZVN1bW1hcnkge1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxufVxyXG5cclxuLndhcm4sXHJcbi53YXJuOjpiZWZvcmUsXHJcbi53YXJuOjphZnRlciB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4ud2FybiB7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7XHJcbn1cclxuXHJcbi53YXJuLndhcm5pbmctZ3JlZW4ge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cclxuICAgIHRvcDogMC4yMjVlbTtcclxuXHJcbiAgICB3aWR0aDogMS4xNWVtO1xyXG4gICAgaGVpZ2h0OiAxLjE1ZW07XHJcblxyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMC42MjVlbTtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbjo6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHRvcDogLTAuMDhlbTtcclxuICAgIGxlZnQ6IDAuMGVtO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm9yZGVyOiB0cmFuc3BhcmVudCAwLjZlbSBzb2xpZDtcclxuICAgIGJvcmRlci1ib3R0b20tY29sb3I6ICM0NDhiMjM7XHJcbiAgICBib3JkZXItYm90dG9tLXdpZHRoOiAxZW07XHJcbiAgICBib3JkZXItdG9wLXdpZHRoOiAwO1xyXG4gICAgYm94LXNoYWRvdzogIzQ0OGIyMyAwIDFweCAxcHg7XHJcbn1cclxuXHJcbi53YXJuLndhcm5pbmctZ3JlZW46OmFmdGVyIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwLjNlbTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBhZGRpbmc6IDAgMXB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiR2FyYW1vbmRcIjtcclxuICAgIGNvbnRlbnQ6IFwiIVwiO1xyXG4gICAgZm9udC1zaXplOiAwLjY1ZW07XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLndvcW9kIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgYm94LXNoYWRvdzogIzQ0OGIyMyAwIDAuNXB4IDAuNXB4O1xyXG59XHJcbiBcclxuIC8qb3JlZGVyaW5nIGFycm93Ki9cclxudGgge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbiBcclxuXHJcbi5zb3J0LWFycm93IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLnNvcnQtYXJyb3cgaSB7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5zb3J0LWFycm93IGkudXAge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogLTRweDtcclxufVxyXG5cclxuLnNvcnQtYXJyb3cgaS5kb3duIHtcclxuICAgIG1hcmdpbi10b3A6IC00cHg7XHJcbn1cclxuXHJcblxyXG4vKkFjdGlvbnMqL1xyXG4uYmktZXllLWZpbGwgIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYig2NSwgMTkwLCA5Mik7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7IFxyXG4gICAgbWFyZ2luLXJpZ2h0OiAxJTtcclxuICAgIHBhZGRpbmc6IDIlIDIlIDEuNiUgMiU7IFxyXG59XHJcbiBcclxuLmJpLXBlbmNpbC1maWxseyBcclxuICAgIGNvbG9yOiAgI2RlOTgxZjtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIG1hcmdpbi1yaWdodDogMSU7XHJcbiAgICBwYWRkaW5nOiAyJSAyJSAxLjYlIDIlOyBcclxufVxyXG5cclxuLmJpLXRyYXNoLWZpbGwgeyBcclxuICAgIGNvbG9yOiByZ2IoMjMzLCA1MCwgMTcpO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxJTtcclxuICAgIHBhZGRpbmc6IDIlIDIlIDEuNiUgMiU7IFxyXG59XHJcblxyXG5cclxuLypvbiByYXcgc2VsZWN0aW9uKi9cclxuIFxyXG5cclxudHJ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuIFxyXG50YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbn1cclxuXHJcbnRoLCB0ZCB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xyXG59XHJcblxyXG4uaGlnaGxpZ2h0ZWR7ICBiYWNrZ3JvdW5kLWNvbG9yOnJnYigyNTUsIDI1MiwgMjE0KTsgfSBcclxuICJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 55306:
/*!**********************************************************************************************************!*\
  !*** ./src/app/modules/administration/components/select-dropdown-component/select-dropdown.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SelectDropdownComponent": () => (/* binding */ SelectDropdownComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 76317);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 23280);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 60116);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _Pipes_highlight_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../Pipes/highlight.pipe */ 88482);
/* harmony import */ var _Pipes_text_search_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../Pipes/text-search.pipe */ 27860);









const _c0 = ["filterInput"];
const _c1 = ["displayLabel"];
const _c2 = ["listItems"];
const _c3 = function (a0) {
  return {
    "dd-active dd-hightlight-item": a0
  };
};
function SelectDropdownComponent_ng_container_15_li_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "li", 15, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function SelectDropdownComponent_ng_container_15_li_2_Template_li_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r10);
      const item_r6 = restoredCtx.$implicit;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r9.onItemSelect(item_r6));
    })("mouseover", function SelectDropdownComponent_ng_container_15_li_2_Template_li_mouseover_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r10);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r11.onHover($event));
    })("mouseout", function SelectDropdownComponent_ng_container_15_li_2_Template_li_mouseout_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r10);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r12.onHover($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const i_r7 = ctx.index;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpropertyInterpolate"]("id", "-chosen-search-result-" + i_r7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpropertyInterpolate"]("title", item_r6[ctx_r4.displayMember]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](5, _c3, ctx_r4.isSelected(item_r6)))("innerHTML", item_r6[ctx_r4.displayMember], _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeHtml"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵattribute"]("data-dd-value", ctx_r4.stringify(item_r6));
  }
}
function SelectDropdownComponent_ng_container_15_p_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " No results found ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
}
function SelectDropdownComponent_ng_container_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ul");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, SelectDropdownComponent_ng_container_15_li_2_Template, 2, 7, "li", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "textSearch");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](4, "highlight");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, SelectDropdownComponent_ng_container_15_p_5_Template, 2, 0, "p", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const result_r3 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind3"](3, 2, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind3"](4, 6, ctx_r2.items, ctx_r2.displayMember, ctx_r2.searchText), ctx_r2.displayMember, ctx_r2.searchText));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", result_r3.length == 0);
  }
}
const _c4 = function () {
  return {
    id: "",
    display: "Select"
  };
};
const KEY_CODE = {
  enter: 13,
  arrowUp: 38,
  arrowDown: 40,
  esc: 27
};
const CSS_CLASS_NAMES = {
  highLight: 'dd-highlight-item'
};
class SelectDropdownComponent {
  constructor(elemRef) {
    this.elemRef = elemRef;
    this._items = [];
    this._list = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    this.valueChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    this._display = 'Select';
    this.isListHide = true;
    this.searchText = '';
    this.disabled = false;
    this.onChange = () => {};
    this.onTouched = () => {};
    this.keyDowns = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.fromEvent)(this.elemRef.nativeElement, 'keydown');
    this.pressEnterKey = this.keyDowns.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.filter)(e => e.keyCode === KEY_CODE.enter));
  }
  onClick(ev) {
    const clickInside = this.elemRef.nativeElement.contains(ev.target);
    if (!clickInside) {
      this.isListHide = true;
    }
  }
  set list(list) {
    this._list.next(list);
  }
  set items(list) {
    this._items = list;
  }
  get items() {
    return this._items;
  }
  get value() {
    return this._value;
  }
  set value(val) {
    this._value = val;
  }
  get display() {
    return this._display;
  }
  set display(value) {
    this._display = value;
  }
  ngOnInit() {
    this._list.subscribe(list => {
      this.items = list;
      this.setItem(this.findItem(this.value));
    });
    this.pressEnterKey.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.filter)(() => !this.isListHide)).subscribe(() => {
      const hightLightItem = this.listItems.find(elem => elem.nativeElement.classList.contains(CSS_CLASS_NAMES.highLight));
      if (hightLightItem) {
        const item = JSON.parse(hightLightItem.nativeElement.getAttribute('data-dd-value'));
        this.setItem(item);
        // this.onChange(item.id);
        this.onChange(item[this.idMember]);
        this.valueChanged.emit(item);
      }
    });
    this.pressEnterKey.subscribe(e => {
      this.toggle();
    });
    this.keyDowns.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.filter)(e => e.keyCode === KEY_CODE.esc)).subscribe(() => {
      this.isListHide = true;
      this.focus();
    });
    this.keyDowns.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.filter)(e => (e.keyCode === KEY_CODE.arrowDown || e.keyCode === KEY_CODE.arrowUp) && !this.isListHide)).subscribe(e => {
      this.moveUpAndDown(e.keyCode);
    });
  }
  scrollToView(elem) {
    if (elem) {
      setTimeout(() => elem.scrollIntoView({
        behavior: "smooth",
        block: "end"
      }), 0);
    } else {
      const selectedItem = this.listItems.find(item => JSON.parse(item.nativeElement.getAttribute('data-dd-value'))[this.idMember] === this.value);
      if (selectedItem) {
        setTimeout(() => selectedItem.nativeElement.scrollIntoView(), 0);
      }
    }
  }
  toggle() {
    if (this.disabled) return;
    this.isListHide = !this.isListHide;
    this.searchText = '';
    if (!this.isListHide) {
      setTimeout(() => this.filterInput.nativeElement.focus(), 0);
      this.listItems.forEach(item => {
        if (JSON.parse(item.nativeElement.getAttribute('data-dd-value'))['id'] === this.value) {
          this.addHightLightClass(item.nativeElement);
          this.scrollToView(item.nativeElement);
        } else {
          this.removeHightLightClass(item.nativeElement);
        }
      });
    }
  }
  focus() {
    setTimeout(() => this.displayLabel.nativeElement.focus(), 0);
  }
  onItemSelect(item) {
    console.log(item);
    this.setItem(item);
    this.toggle();
    if (item !== undefined) {
      // this.onChange(item.id);
      this.onChange(item[this.idMember]);
    } else {
      this.onChange('');
    }
    this.valueChanged.emit(item);
    this.focus();
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }
  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  setDisabledState(isDisabled) {
    this.disabled = isDisabled;
  }
  findItem(value) {
    // return this.items.find((item) => +item.id === +value);
    return this.items.find(item => +item[this.idMember] === +value);
  }
  writeValue(value) {
    const item = this.findItem(value);
    this.value = value;
    // this.display = item ? item.display : '';
    this.display = item ? item[this.displayMember] : '';
  }
  setItem(item) {
    if (item) {
      // if (item.id) {
      //   this.value = item.id;
      // }
      if (item[this.idMember]) {
        this.value = item[this.idMember];
      }
      if (item[this.displayMember]) {
        // this.display = item.display;
        this.display = item[this.displayMember];
      }
    } else {
      this.value = '';
      this.display = this.placeholder;
    }
  }
  onKeyPress(e) {
    if (e.keyCode === KEY_CODE.enter) {
      this.focus();
      return false;
    }
    return true;
  }
  addHightLightClass(elem) {
    elem.classList.add(CSS_CLASS_NAMES.highLight);
  }
  removeHightLightClass(elem) {
    elem.classList.remove(CSS_CLASS_NAMES.highLight);
  }
  moveUpAndDown(key) {
    const selectedItem = this.listItems.find(li => li.nativeElement.classList.contains(CSS_CLASS_NAMES.highLight));
    if (selectedItem) {
      let hightLightedItem;
      if (key === KEY_CODE.arrowUp) {
        //check for first element
        if (selectedItem !== this.listItems.first) {
          hightLightedItem = selectedItem.nativeElement.previousSibling;
        }
      } else if (key === KEY_CODE.arrowDown) {
        //check for last element
        if (selectedItem !== this.listItems.last) {
          hightLightedItem = selectedItem.nativeElement.nextSibling;
        }
      }
      if (hightLightedItem) {
        this.clearHlightClass();
        this.removeHightLightClass(selectedItem.nativeElement);
        this.addHightLightClass(hightLightedItem);
        this.scrollToView(hightLightedItem);
      }
    } else {
      let highLightedItem;
      if (key === KEY_CODE.arrowUp) {
        highLightedItem = this.listItems.last;
      } else if (key === KEY_CODE.arrowDown) {
        highLightedItem = this.listItems.first;
      }
      if (highLightedItem) {
        this.addHightLightClass(highLightedItem.nativeElement);
        this.scrollToView(highLightedItem.nativeElement);
      }
    }
  }
  isSelected(item) {
    // return +item.id === +this.value;
    return +item[this.idMember] === +this.value;
  }
  stringify(item) {
    return JSON.stringify(item);
  }
  onHover(event) {
    this.clearHlightClass();
    const target = event.target;
    if (event.type === 'mouseover') {
      target.classList.add(CSS_CLASS_NAMES.highLight);
    } else {
      target.classList.remove(CSS_CLASS_NAMES.highLight);
    }
  }
  clearHlightClass() {
    this.listItems.forEach(item => {
      this.removeHightLightClass(item.nativeElement);
    });
  }
  static #_ = this.ɵfac = function SelectDropdownComponent_Factory(t) {
    return new (t || SelectDropdownComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: SelectDropdownComponent,
    selectors: [["app-select-dropdown"]],
    viewQuery: function SelectDropdownComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.filterInput = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.displayLabel = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵloadQuery"]()) && (ctx.listItems = _t);
      }
    },
    hostBindings: function SelectDropdownComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function SelectDropdownComponent_click_HostBindingHandler($event) {
          return ctx.onClick($event);
        }, false, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresolveDocument"]);
      }
    },
    inputs: {
      placeholder: "placeholder",
      displayMember: "displayMember",
      idMember: "idMember",
      searchPlaceholder: "searchPlaceholder",
      setStyleObject: "setStyleObject",
      setClassToDropdown: "setClassToDropdown",
      setClassToSelectedBox: "setClassToSelectedBox",
      dropDownWidth: "dropDownWidth",
      dropDownHeight: "dropDownHeight",
      list: "list"
    },
    outputs: {
      valueChanged: "valueChanged"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵProvidersFeature"]([{
      provide: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NG_VALUE_ACCESSOR,
      useExisting: (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.forwardRef)(() => SelectDropdownComponent),
      multi: true
    }])],
    decls: 17,
    vars: 16,
    consts: [[1, "dd-container"], ["tabindex", "0", 3, "ngClass", "click"], ["displayLabel", ""], ["role", "textbox", 1, "dd-display-item"], [1, "pull-right"], [1, "fa", "fa-caret-down"], [1, "dd-list-container", 3, "hidden", "ngStyle", "ngClass"], [1, "chosen-drop"], [1, "chosen-search"], ["type", "text", 1, "drop-input", 3, "disabled", "placeholder", "ngModel", "ngModelChange", "keypress"], ["filterInput", ""], ["id", "-chosen-search-result", 1, "dd-items-container"], [1, "dd-list-item"], [4, "ngIf"], ["class", "dd-list-item ", "role", "option", 3, "ngClass", "id", "title", "innerHTML", "click", "mouseover", "mouseout", 4, "ngFor", "ngForOf"], ["role", "option", 1, "dd-list-item", 3, "ngClass", "id", "title", "innerHTML", "click", "mouseover", "mouseout"], ["listItems", ""]],
    template: function SelectDropdownComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "div", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function SelectDropdownComponent_Template_div_click_1_listener() {
          return ctx.toggle();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "span", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 6)(8, "div", 7)(9, "div", 8)(10, "input", 9, 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function SelectDropdownComponent_Template_input_ngModelChange_10_listener($event) {
          return ctx.searchText = $event;
        })("keypress", function SelectDropdownComponent_Template_input_keypress_10_listener($event) {
          return ctx.onKeyPress($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "div", 11)(13, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](15, SelectDropdownComponent_ng_container_15_Template, 6, 10, "ng-container", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](16, "textSearch");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngClass", ctx.setClassToSelectedBox);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", ctx.display, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("hidden", ctx.isListHide)("ngStyle", ctx.setStyleObject)("ngClass", ctx.setClassToDropdown);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.disabled)("placeholder", ctx.placeholder)("ngModel", ctx.searchText);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵattribute"]("data-dd-value", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](15, _c4));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", ctx.placeholder, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind3"](16, 11, ctx.items, ctx.displayMember, ctx.searchText));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _Pipes_highlight_pipe__WEBPACK_IMPORTED_MODULE_0__.HighlightPipe, _Pipes_text_search_pipe__WEBPACK_IMPORTED_MODULE_1__.TextSearchPipe],
    styles: [".dd-container[_ngcontent-%COMP%] {\r\n  position: relative;\r\n  -webkit-user-select: none;\r\n          user-select: none;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-display-item[_ngcontent-%COMP%] {\r\n  border: 1px solid #ddd;\r\n  padding: 6px 10px;\r\n  border-radius: 3px;\r\n  font-size: 15px;\r\n  display: block;\r\n  cursor: pointer;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%] {\r\n  position: absolute;\r\n  height: auto;\r\n  box-sizing: border-box;\r\n  min-width: 320px;\r\n  width: 100%;\r\n  padding: 0.5rem;\r\n  border: 1px solid #d0d0d0;\r\n  top: 30px;\r\n  background-color: #FFF;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .chosen-drop[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .chosen-drop[_ngcontent-%COMP%]   .chosen-search[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .chosen-drop[_ngcontent-%COMP%]   .chosen-search[_ngcontent-%COMP%]   .drop-input[_ngcontent-%COMP%] {\r\n  text-indent: 5px;\r\n  font-size: 18px;\r\n  z-index: 10;\r\n  width: 100%;\r\n  box-sizing: border-box;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .dd-items-container[_ngcontent-%COMP%] {\r\n  background-color: #fff;\r\n  height: 300px;\r\n  overflow-y: auto;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .dd-items-container[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\r\n  list-style: none;\r\n  padding: 0;\r\n  margin: 0;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .dd-items-container[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\r\n  text-overflow: ellipsis;\r\n  overflow: hidden;\r\n  white-space: nowrap;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .dd-items-container[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   .dd-list-item[_ngcontent-%COMP%] {\r\n  padding: 2px 5px;\r\n  cursor: pointer;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .dd-items-container[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   .dd-active[_ngcontent-%COMP%] {\r\n  background-color: #ddd;\r\n}\r\n.dd-container[_ngcontent-%COMP%]   .dd-list-container[_ngcontent-%COMP%]   .dd-items-container[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   .dd-highlight-item[_ngcontent-%COMP%] {\r\n  background-color: #F89828;\r\n  color: #fff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9jb21wb25lbnRzL3NlbGVjdC1kcm9wZG93bi1jb21wb25lbnQvc2VsZWN0LWRyb3Bkb3duLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBa0I7RUFDbEIseUJBQWlCO1VBQWpCLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0Usc0JBQXNCO0VBQ3RCLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGNBQWM7RUFDZCxlQUFlO0FBQ2pCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLHNCQUFzQjtFQUN0QixnQkFBZ0I7RUFDaEIsV0FBVztFQUNYLGVBQWU7RUFDZix5QkFBeUI7RUFDekIsU0FBUztFQUNULHNCQUFzQjtBQUN4QjtBQUNBO0VBQ0UsV0FBVztBQUNiO0FBQ0E7RUFDRSxXQUFXO0FBQ2I7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsV0FBVztFQUNYLFdBQVc7RUFDWCxzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLHNCQUFzQjtFQUN0QixhQUFhO0VBQ2IsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxnQkFBZ0I7RUFDaEIsVUFBVTtFQUNWLFNBQVM7QUFDWDtBQUNBO0VBQ0UsdUJBQXVCO0VBQ3ZCLGdCQUFnQjtFQUNoQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixlQUFlO0FBQ2pCO0FBQ0E7RUFDRSxzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLHlCQUF5QjtFQUN6QixXQUFXO0FBQ2IiLCJzb3VyY2VzQ29udGVudCI6WyIuZGQtY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdXNlci1zZWxlY3Q6IG5vbmU7XHJcbn1cclxuLmRkLWNvbnRhaW5lciAuZGQtZGlzcGxheS1pdGVtIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xyXG4gIHBhZGRpbmc6IDZweCAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbi5kZC1jb250YWluZXIgLmRkLWxpc3QtY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgbWluLXdpZHRoOiAzMjBweDtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAwLjVyZW07XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2QwZDBkMDtcclxuICB0b3A6IDMwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRjtcclxufVxyXG4uZGQtY29udGFpbmVyIC5kZC1saXN0LWNvbnRhaW5lciAuY2hvc2VuLWRyb3Age1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcbi5kZC1jb250YWluZXIgLmRkLWxpc3QtY29udGFpbmVyIC5jaG9zZW4tZHJvcCAuY2hvc2VuLXNlYXJjaCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLmRkLWNvbnRhaW5lciAuZGQtbGlzdC1jb250YWluZXIgLmNob3Nlbi1kcm9wIC5jaG9zZW4tc2VhcmNoIC5kcm9wLWlucHV0IHtcclxuICB0ZXh0LWluZGVudDogNXB4O1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICB6LWluZGV4OiAxMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG59XHJcbi5kZC1jb250YWluZXIgLmRkLWxpc3QtY29udGFpbmVyIC5kZC1pdGVtcy1jb250YWluZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgaGVpZ2h0OiAzMDBweDtcclxuICBvdmVyZmxvdy15OiBhdXRvO1xyXG59XHJcbi5kZC1jb250YWluZXIgLmRkLWxpc3QtY29udGFpbmVyIC5kZC1pdGVtcy1jb250YWluZXIgdWwge1xyXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgcGFkZGluZzogMDtcclxuICBtYXJnaW46IDA7XHJcbn1cclxuLmRkLWNvbnRhaW5lciAuZGQtbGlzdC1jb250YWluZXIgLmRkLWl0ZW1zLWNvbnRhaW5lciB1bCBsaSB7XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG59XHJcbi5kZC1jb250YWluZXIgLmRkLWxpc3QtY29udGFpbmVyIC5kZC1pdGVtcy1jb250YWluZXIgdWwgLmRkLWxpc3QtaXRlbSB7XHJcbiAgcGFkZGluZzogMnB4IDVweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmRkLWNvbnRhaW5lciAuZGQtbGlzdC1jb250YWluZXIgLmRkLWl0ZW1zLWNvbnRhaW5lciB1bCAuZGQtYWN0aXZlIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkO1xyXG59XHJcbi5kZC1jb250YWluZXIgLmRkLWxpc3QtY29udGFpbmVyIC5kZC1pdGVtcy1jb250YWluZXIgdWwgLmRkLWhpZ2hsaWdodC1pdGVtIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjg5ODI4O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    changeDetection: 0
  });
}

/***/ }),

/***/ 1593:
/*!*******************************************************************************************************!*\
  !*** ./src/app/modules/administration/station-admin/lanes/lane-operation/lane-operation.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LaneOperationComponent": () => (/* binding */ LaneOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class LaneOperationComponent {
  static #_ = this.ɵfac = function LaneOperationComponent_Factory(t) {
    return new (t || LaneOperationComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: LaneOperationComponent,
    selectors: [["app-lane-operation"]],
    decls: 2,
    vars: 0,
    template: function LaneOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "lane-operation works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 41324:
/*!*******************************************************************************!*\
  !*** ./src/app/modules/administration/station-admin/lanes/lanes.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LanesComponent": () => (/* binding */ LanesComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class LanesComponent {
  static #_ = this.ɵfac = function LanesComponent_Factory(t) {
    return new (t || LanesComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: LanesComponent,
    selectors: [["app-lanes"]],
    decls: 2,
    vars: 0,
    template: function LanesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "lanes works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 20331:
/*!****************************************************************************************************************!*\
  !*** ./src/app/modules/administration/station-admin/sections/section-operation/section-operation.component.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SectionOperationComponent": () => (/* binding */ SectionOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class SectionOperationComponent {
  static #_ = this.ɵfac = function SectionOperationComponent_Factory(t) {
    return new (t || SectionOperationComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SectionOperationComponent,
    selectors: [["app-section-operation"]],
    decls: 2,
    vars: 0,
    template: function SectionOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "section-operation works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 22189:
/*!*************************************************************************************!*\
  !*** ./src/app/modules/administration/station-admin/sections/sections.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SectionsComponent": () => (/* binding */ SectionsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class SectionsComponent {
  static #_ = this.ɵfac = function SectionsComponent_Factory(t) {
    return new (t || SectionsComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: SectionsComponent,
    selectors: [["app-sections"]],
    decls: 2,
    vars: 0,
    template: function SectionsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "sections works!");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 90306:
/*!****************************************************************************************************************!*\
  !*** ./src/app/modules/administration/station-admin/stations/station-operation/station-operation.component.ts ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationOperationComponent": () => (/* binding */ StationOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_StationOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/StationOperation */ 57599);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveStationModalButton"];
function StationOperationComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r20.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r20.lkValueEname, " ");
  }
}
function StationOperationComponent_div_62_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_67_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r21.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r21.lkValueEname, " ");
  }
}
function StationOperationComponent_div_78_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_option_83_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r22.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r22.lkValueEname, " ");
  }
}
function StationOperationComponent_div_84_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_89_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_div_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function StationOperationComponent_button_102_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationOperationComponent_button_102_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r23.createUpdateStation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r18.stationForm.valid);
  }
}
class StationOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.vehicleTypes = [];
    this.reservationTypes = [];
    this.classifications = [];
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createStationForm();
    this.loadLookups();
  }
  loadLookups() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.vehicleTypes).subscribe(types => this.vehicleTypes = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.reservationTypes).subscribe(types => this.reservationTypes = types);
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.classification).subscribe(types => this.classifications = types);
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.stationId = +params['stationId'];
      if (this.stationId > 0) {
        this.loadStation();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadStation() {
    this.systemAdminService.getStations({
      stationId: this.stationId
    }).subscribe(result => {
      this.stationForm.patchValue(result.items[0]);
    });
  }
  createStationForm() {
    this.stationForm = this.fb.group({
      stationNameEn: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      stationNameAr: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      addressEn: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      addressAr: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      descriptionEn: [null],
      descriptionAr: [null],
      contactNo: [null],
      vehicleTypes: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      startTime: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      endTime: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      classificationId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      reservationType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      slotsDuration: [null],
      geoCoordinate: [null],
      status: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
  }
  createUpdateStation() {
    let stationOper = new src_app_core_models_adminstration_StationOperation__WEBPACK_IMPORTED_MODULE_0__.StationOperation();
    stationOper = this.stationForm?.value;
    stationOper.classificationId = +this.stationForm?.value.classificationId;
    stationOper.reservationType = +this.stationForm?.value.reservationType;
    stationOper.vehicleTypes = +this.stationForm?.value.vehicleTypes;
    stationOper.status = this.stationForm?.value.status ? 1 : 0;
    stationOper.operationType = this.operation;
    if (this.stationId > 0) stationOper.stationId = this.stationId;
    this.systemAdminService.stationOperations(stationOper).subscribe(result => {
      if (result.items > 0) this.saveStationModalButton.nativeElement.click();
    });
  }
  backToStationsList() {
    this.router.navigate(['system-admin/stations']);
  }
  static #_ = this.ɵfac = function StationOperationComponent_Factory(t) {
    return new (t || StationOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: StationOperationComponent,
    selectors: [["app-station-operation"]],
    viewQuery: function StationOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveStationModalButton = _t.first);
      }
    },
    decls: 117,
    vars: 22,
    consts: [[1, "inspection-tab-menu"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "v-details", "aria-selected", "true", 1, "nav-link"], [1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "stationNameEn", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "stationNameAr", 1, "form-control"], ["type", "text", "formControlName", "addressEn", 1, "form-control"], ["type", "text", "formControlName", "addressAr", 1, "form-control"], ["type", "text", "formControlName", "descriptionEn", 1, "form-control"], ["type", "text", "formControlName", "descriptionAr", 1, "form-control"], ["type", "text", "formControlName", "contactNo", 1, "form-control"], ["name", "ownerType", "formControlName", "vehicleTypes", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "time", "formControlName", "startTime", 1, "form-control"], ["type", "time", "formControlName", "endTime", 1, "form-control"], ["name", "ownerType", "formControlName", "classificationId", 1, "form-control"], ["name", "ownerType", "formControlName", "reservationType", 1, "form-control"], ["type", "number", "formControlName", "slotsDuration", 1, "form-control"], ["type", "text", "formControlName", "geoCoordinate", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveStationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function StationOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "ul", 2)(3, "li", 3)(4, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, " Main Information ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "li", 3)(7, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](8, " Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](9, "div", 5)(10, "div", 6)(11, "form", 7)(12, "div", 8)(13, "div", 9)(14, "div", 10)(15, "div", 11)(16, "h2", 12)(17, "button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "div", 14)(20, "div", 15)(21, "div", 16)(22, "div", 17)(23, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24, "Station Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](25, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, StationOperationComponent_div_26_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "div", 17)(28, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](29, "Arabic Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](30, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](31, StationOperationComponent_div_31_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](32, "div", 17)(33, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](34, "Address * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](35, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](36, StationOperationComponent_div_36_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 17)(38, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](39, "Arabic Address *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](40, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](41, StationOperationComponent_div_41_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](42, "div", 17)(43, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](44, " Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](45, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](46, StationOperationComponent_div_46_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "div", 17)(48, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](49, "Arabic Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](50, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](51, StationOperationComponent_div_51_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](52, "div", 17)(53, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](54, "Contact No.");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](55, "input", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](56, StationOperationComponent_div_56_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](57, "div", 17)(58, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](59, "Vehicle Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](60, "select", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](61, StationOperationComponent_option_61_Template, 2, 2, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](62, StationOperationComponent_div_62_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](63, "div", 17)(64, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](65, "Start Time *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](66, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](67, StationOperationComponent_div_67_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](68, "div", 17)(69, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](70, "End Time *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](71, "input", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](72, StationOperationComponent_div_72_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](73, "div", 17)(74, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](75, "Classification *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](76, "select", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](77, StationOperationComponent_option_77_Template, 2, 2, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](78, StationOperationComponent_div_78_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](79, "div", 17)(80, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](81, "Reservation Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](82, "select", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](83, StationOperationComponent_option_83_Template, 2, 2, "option", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](84, StationOperationComponent_div_84_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](85, "div", 17)(86, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](87, "Slots Duration");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](88, "input", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](89, StationOperationComponent_div_89_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](90, "div", 17)(91, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](92, "Geo Coordinate");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](93, "input", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](94, StationOperationComponent_div_94_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](95, "div", 34)(96, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](97, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](98, "label", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](99, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](100, StationOperationComponent_div_100_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](101, "div", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](102, StationOperationComponent_button_102_Template, 2, 1, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](103, "div", 40)(104, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationOperationComponent_Template_button_click_104_listener() {
          return ctx.backToStationsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](105, "i", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](106, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](107, "button", 43, 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](109, "div", 45)(110, "div", 46)(111, "div", 47)(112, "div", 48)(113, "h1", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](114, "img", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](115);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](116, "button", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.stationForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Station ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("stationNameEn").hasError("required") && ctx.stationForm.get("stationNameEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("stationNameAr").hasError("required") && ctx.stationForm.get("stationNameAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("addressEn").hasError("required") && ctx.stationForm.get("addressEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("addressAr").hasError("required") && ctx.stationForm.get("addressAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("descriptionEn").hasError("required") && ctx.stationForm.get("descriptionEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("descriptionAr").hasError("required") && ctx.stationForm.get("descriptionAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("contactNo").hasError("required") && ctx.stationForm.get("contactNo").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.vehicleTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("vehicleTypes").hasError("required") && ctx.stationForm.get("vehicleTypes").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("startTime").hasError("required") && ctx.stationForm.get("startTime").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("endTime").hasError("required") && ctx.stationForm.get("endTime").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.classifications);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("classificationId").hasError("required") && ctx.stationForm.get("classificationId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.reservationTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("reservationType").hasError("required") && ctx.stationForm.get("reservationType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("slotsDuration").hasError("required") && ctx.stationForm.get("slotsDuration").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("geoCoordinate").hasError("required") && ctx.stationForm.get("geoCoordinate").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.stationForm.get("status").hasError("required") && ctx.stationForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zdGF0aW9uLWFkbWluL3N0YXRpb25zL3N0YXRpb24tb3BlcmF0aW9uL3N0YXRpb24tb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 93472:
/*!*************************************************************************************!*\
  !*** ./src/app/modules/administration/station-admin/stations/stations.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationsComponent": () => (/* binding */ StationsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);








const _c0 = ["saveStationModalButton"];
const _c1 = ["CheckStationActiveDeactiveModalBtn"];
const _c2 = ["CheckModelActiveDeactiveModalBtn"];
class StationsComponent {
  constructor(systemAdmin, router) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.stations = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.stationHeaders = [{
      JsonPropName: 'stationNameEn',
      showName: 'Station Name'
    }, {
      JsonPropName: 'descriptionEn',
      showName: 'Description'
    }, {
      JsonPropName: 'classificationDescriptionEn',
      showName: 'Classification'
    }, {
      JsonPropName: 'reservationTypeEn',
      showName: 'Reservation Type'
    }, {
      JsonPropName: 'addressEn',
      showName: 'Address'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.stationsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(null)
    });
    this.bindChange();
    this.loadStations();
  }
  loadStations() {
    this.systemAdmin.getStations({}).subscribe(result => {
      this.stations.data = result.items;
      this.stations.data.sort();
      if (this.stations.data.length > 0) this.onStationSelection(this.stations.data[this.stations.data.length - 1]);
    });
  }
  bindChange() {
    this.stationsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchStations(change);
    });
  }
  viewSelectedStation(item) {
    this.router.navigate(['system-admin/stations/view', item.lkCode]);
  }
  onModelStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "model");
    this.CheckModelActiveDeactiveModalBtn.nativeElement.click();
  }
  onStationStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "station");
    this.CheckStationActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmStationActiveDeactiveCahnge() {
    let ManufacOperation; //= new StationOperation(); 
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.stationOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveStationModalButton.nativeElement.click();
      }
    });
  }
  onCancelStationActiveDeactiveChange() {
    this.loadStations();
  }
  updateSelectedStation(item) {
    this.router.navigate(['system-admin/stations/edit', item.stationId]);
  }
  searchStations(searchValue) {
    this.systemAdmin.getStations({
      containsText: searchValue
    }).subscribe(result => {
      this.stations.data = result.items;
    });
  }
  AddNewStation() {
    this.router.navigate(['system-admin/stations/new']);
  }
  onStationSelection(item) {
    this.selectedStationId = item.stationsId;
  }
  setActiveTab(tab) {
    this.activeTab = tab;
  }
  static #_ = this.ɵfac = function StationsComponent_Factory(t) {
    return new (t || StationsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: StationsComponent,
    selectors: [["app-stations"]],
    viewQuery: function StationsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveStationModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.CheckStationActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.CheckModelActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 84,
    vars: 11,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "viewItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveStationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#stationConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckStationActiveDeactiveModalBtn", ""], ["id", "stationConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], [1, "inspection-tab-menu", "col-12"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#v-details", "type", "button", "role", "tab", "aria-controls", "v-details", "aria-selected", "true", 1, "nav-link", "active", 3, "click"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#instructions", "type", "button", "role", "tab", "aria-controls", "instructions", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "inspection-tab-content"], ["id", "myTabContent", 1, "tab-content"], ["id", "v-details", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], ["id", "instructions", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"]],
    template: function StationsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, " Stations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationsComponent_Template_button_click_19_listener() {
          return ctx.AddNewStation();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Add Station ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 13)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Station Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](31, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](32, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("updateItemEvent", function StationsComponent_Template_app_data_table_viewer_updateItemEvent_32_listener($event) {
          return ctx.updateSelectedStation($event);
        })("viewItemEvent", function StationsComponent_Template_app_data_table_viewer_viewItemEvent_32_listener($event) {
          return ctx.viewSelectedStation($event);
        })("selectItemEvent", function StationsComponent_Template_app_data_table_viewer_selectItemEvent_32_listener($event) {
          return ctx.onStationSelection($event);
        })("checkboxEvent", function StationsComponent_Template_app_data_table_viewer_checkboxEvent_32_listener($event) {
          return ctx.onStationStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](33, "button", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "div", 23)(36, "div", 24)(37, "div", 25)(38, "div", 26)(39, "h1", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](40, "img", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](41);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](42, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](43, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](45, "div", 32)(46, "div", 33)(47, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](48, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](49, "div", 34)(50, "div", 1)(51, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](52, "img", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](53, "div", 3)(54, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](56, "br")(57, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](58, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationsComponent_Template_button_click_58_listener() {
          return ctx.onCancelStationActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](59, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](60, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationsComponent_Template_button_click_60_listener() {
          return ctx.onConfirmStationActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](61, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](62, "div", 1)(63, "div", 39)(64, "div", 40)(65, "ul", 41)(66, "li", 42)(67, "button", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationsComponent_Template_button_click_67_listener() {
          return ctx.setActiveTab("details");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](68, " Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](69, "li", 42)(70, "button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function StationsComponent_Template_button_click_70_listener() {
          return ctx.setActiveTab("inst");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](71, " Entities ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](72, "div", 45)(73, "div", 1)(74, "div", 3)(75, "div", 46)(76, "div", 47)(77, "div", 1)(78, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](79, " 11111111111111111 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](80, "div", 48)(81, "div", 1)(82, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](83, " 2222222222222222222 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.stationsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tblHeaders", ctx.stationHeaders)("tblValues", ctx.stations)("isDeleteOperationEnabled", false)("selectedRow", ctx.stations.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_3__.DataTableViewerComponent],
    styles: [".inspection-tab-menu[_ngcontent-%COMP%]{\r\n    width: 1230px;\r\n    margin-left: 15px;\r\n    margin-top: 1%;\r\n }\r\n\r\n @media (max-width: 768px) {\r\n    .inspection-tab-menu[_ngcontent-%COMP%] {\r\n        margin-left: 0;\r\n        padding: 0 15px;\r\n    }\r\n}\r\n\r\n\r\n\r\n.outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zdGF0aW9uLWFkbWluL3N0YXRpb25zL3N0YXRpb25zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0lBQ2IsaUJBQWlCO0lBQ2pCLGNBQWM7Q0FDakI7O0NBRUE7SUFDRztRQUNJLGNBQWM7UUFDZCxlQUFlO0lBQ25CO0FBQ0o7Ozs7QUFJQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyIuaW5zcGVjdGlvbi10YWItbWVudXtcclxuICAgIHdpZHRoOiAxMjMwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICAgIG1hcmdpbi10b3A6IDElO1xyXG4gfVxyXG5cclxuIEBtZWRpYSAobWF4LXdpZHRoOiA3NjhweCkge1xyXG4gICAgLmluc3BlY3Rpb24tdGFiLW1lbnUge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwO1xyXG4gICAgICAgIHBhZGRpbmc6IDAgMTVweDtcclxuICAgIH1cclxufVxyXG5cclxuXHJcblxyXG4ub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 23767:
/*!*******************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/areas/areas-operation/areas-operation.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AreasOperationComponent": () => (/* binding */ AreasOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_AreaOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/AreaOperation */ 59000);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveAreaModalButton"];
function AreasOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function AreasOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function AreasOperationComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function AreasOperationComponent_button_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function AreasOperationComponent_button_30_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.createUpdateArea());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r3.areaForm.valid);
  }
}
class AreasOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createAreaForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.areaId = +params['areaId'];
      if (this.areaId > 0) {
        this.loadArea();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadArea() {
    this.systemAdminService.getAreas({
      areaId: this.areaId
    }).subscribe(result => {
      this.areaForm.patchValue(result.items[0]);
    });
  }
  createAreaForm() {
    this.areaForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      areaAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      areaEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
    });
  }
  createUpdateArea() {
    let areaOper = new src_app_core_models_adminstration_AreaOperation__WEBPACK_IMPORTED_MODULE_0__.AreaOperation();
    areaOper = this.areaForm?.value;
    areaOper.status = this.areaForm?.value.status ? 1 : 0;
    areaOper.operationType = this.operation;
    if (this.areaId > 0) areaOper.areaId = this.areaId;
    this.systemAdminService.areaOperations(areaOper).subscribe(result => {
      if (result.items > 0) this.saveAreaModalButton.nativeElement.click();
    });
  }
  backToAreasList() {
    if (this.areaId > 0) this.router.navigate(['system-admin/areas/' + this.areaId]);else this.router.navigate(['system-admin/areas']);
  }
  static #_ = this.ɵfac = function AreasOperationComponent_Factory(t) {
    return new (t || AreasOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: AreasOperationComponent,
    selectors: [["app-area-operation"]],
    viewQuery: function AreasOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveAreaModalButton = _t.first);
      }
    },
    decls: 45,
    vars: 7,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "areaEname", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "areaAname", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveAreaModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function AreasOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Area Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, AreasOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Area Arabic Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, AreasOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 16)(24, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](25, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](28, AreasOperationComponent_div_28_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](30, AreasOperationComponent_button_30_Template, 2, 1, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "div", 22)(32, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function AreasOperationComponent_Template_button_click_32_listener() {
          return ctx.backToAreasList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](33, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](34, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](35, "button", 25, 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "div", 27)(38, "div", 28)(39, "div", 29)(40, "div", 30)(41, "h1", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](43);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](44, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.areaForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Area ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.areaForm.get("areaEname").hasError("required") && ctx.areaForm.get("areaEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.areaForm.get("areaAname").hasError("required") && ctx.areaForm.get("areaAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.areaForm.get("status").hasError("required") && ctx.areaForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9hcmVhcy9hcmVhcy1vcGVyYXRpb24vYXJlYXMtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 26250:
/*!*****************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/areas/areas.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AreasComponent": () => (/* binding */ AreasComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_LocationOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/LocationOperation */ 69346);
/* harmony import */ var src_app_core_models_adminstration_AreaOperation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/adminstration/AreaOperation */ 59000);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);










const _c0 = ["saveAreaModalButton"];
const _c1 = ["CheckAreaActiveDeactiveModalBtn"];
const _c2 = ["CheckLocationActiveDeactiveModalBtn"];
class AreasComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.areas = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.locations = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.areaHeaders = [{
      JsonPropName: 'areaEname',
      showName: 'Area Name'
    }, {
      JsonPropName: 'areaAname',
      showName: 'Area Arabic Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.locationsHeaders = [{
      JsonPropName: 'locationEname',
      showName: 'Location Name'
    }, {
      JsonPropName: 'locationAname',
      showName: 'Location Arabic Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.createAreaForms();
    this.bindChange();
    this.loadAreas();
  }
  createAreaForms() {
    this.areasSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
    this.locationsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
  }
  loadAreas() {
    this.systemAdmin.getAreas({}).subscribe(result => {
      this.areas.data = result.items;
      if (this.areas.data.length > 0) {
        if (this.recordSelectionId > 0) this.onAreaSelection(this.areas.data.find(x => x.areaId == this.recordSelectionId));else this.onAreaSelection(this.areas.data[0]);
      }
    });
  }
  bindChange() {
    this.areasSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchAreas(change);
    });
    this.locationsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchAreaLocations(change);
    });
  }
  onLocationStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "location");
    this.CheckLocationActiveDeactiveModalBtn.nativeElement.click();
  }
  onAreaStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "area");
    this.CheckAreaActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmAreaActiveDeactiveCahnge() {
    let ManufacOperation = new src_app_core_models_adminstration_AreaOperation__WEBPACK_IMPORTED_MODULE_3__.AreaOperation();
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.areaOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveAreaModalButton.nativeElement.click();
      }
    });
  }
  onCancelAreaActiveDeactiveChange() {
    this.loadAreas();
  }
  onConfirmLocationActiveDeactiveCahnge() {
    let locationOperation = new src_app_core_models_adminstration_LocationOperation__WEBPACK_IMPORTED_MODULE_2__.LocationOperation();
    locationOperation = this.checkedSelectedItem;
    locationOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    locationOperation.status = locationOperation.status ? 1 : 0;
    this.systemAdmin.locationOperations(locationOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveAreaModalButton.nativeElement.click();
      }
    });
  }
  onCancelLocationActiveDeactiveChange() {
    this.loadAreaLocations();
  }
  loadAreaLocations() {
    this.systemAdmin.getAreaLocations({
      areaId: this.selectedAreaId
    }).subscribe(result => {
      this.locations.data = result.items;
    });
  }
  updateSelectedArea(item) {
    this.router.navigate(['system-admin/areas/edit', item.areaId]);
  }
  updateSelectedLocation(item) {
    this.router.navigate(['system-admin/locations/edit', item.areaId, item.locationId]);
  }
  viewSelectedLocation(item) {
    //this.router.navigate(['system-admin/location/view', item.areaId, item.lkCodeValue])
  }
  searchAreas(searchValue) {
    this.systemAdmin.getAreas({
      containsText: searchValue
    }).subscribe(result => {
      this.areas.data = result.items;
    });
  }
  searchAreaLocations(searchValue) {
    this.systemAdmin.getAreaLocations({
      areaId: this.selectedAreaId,
      containsText: searchValue
    }).subscribe(result => {
      this.locations.data = result.items;
    });
  }
  AddNewArea() {
    this.router.navigate(['system-admin/areas/new']);
  }
  onAreaSelection(item) {
    this.locationTitleName = item.areaEname;
    this.selectedAreaId = item.areaId;
    this.selectedArea = item;
    this.systemAdmin.getAreaLocations({
      areaId: item.areaId
    }).subscribe(result => {
      this.locations.data = result.items;
    });
  }
  AddNewLocation() {
    this.router.navigate(['system-admin/locations/new', this.selectedAreaId]);
  }
  static #_ = this.ɵfac = function AreasComponent_Factory(t) {
    return new (t || AreasComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: AreasComponent,
    selectors: [["app-areas"]],
    viewQuery: function AreasComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.saveAreaModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckAreaActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckLocationActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 112,
    vars: 13,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["id", "accordionExample3", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "updateItemEvent", "viewItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveAreaModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#areaConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckAreaActiveDeactiveModalBtn", ""], ["id", "areaConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#locationConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckLocationActiveDeactiveModalBtn", ""], ["id", "locationConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"]],
    template: function AreasComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](13, " Areas ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AreasComponent_Template_button_click_19_listener() {
          return ctx.AddNewArea();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](20, " Add Area ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, "Area Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function AreasComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedArea($event);
        })("selectItemEvent", function AreasComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onAreaSelection($event);
        })("checkboxEvent", function AreasComponent_Template_app_data_table_viewer_checkboxEvent_31_listener($event) {
          return ctx.onAreaStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](32, "section", 0)(33, "div", 1)(34, "div", 2)(35, "div", 1)(36, "div", 2)(37, "div", 1)(38, "div", 3)(39, "div", 4)(40, "div", 5)(41, "div", 21)(42, "div", 7)(43, "h2", 22)(44, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](46, "div", 24)(47, "div", 11)(48, "div", 12)(49, "div", 1)(50, "div", 13)(51, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AreasComponent_Template_button_click_51_listener() {
          return ctx.AddNewLocation();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](52, " Add Location ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](53, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](54, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](55, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](56, "form", 17)(57, "div", 1)(58, "div", 16)(59, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](60, "Location Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](61, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](62, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](63, "app-data-table-viewer", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function AreasComponent_Template_app_data_table_viewer_updateItemEvent_63_listener($event) {
          return ctx.updateSelectedLocation($event);
        })("viewItemEvent", function AreasComponent_Template_app_data_table_viewer_viewItemEvent_63_listener($event) {
          return ctx.viewSelectedLocation($event);
        })("checkboxEvent", function AreasComponent_Template_app_data_table_viewer_checkboxEvent_63_listener($event) {
          return ctx.onLocationStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](64, "button", 26, 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](66, "div", 28)(67, "div", 29)(68, "div", 30)(69, "div", 31)(70, "h1", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](71, "img", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](72);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](73, "button", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](74, "button", 35, 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](76, "div", 37)(77, "div", 38)(78, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](79, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](80, "div", 39)(81, "div", 1)(82, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](83, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](84, "div", 3)(85, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](86);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](87, "br")(88, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](89, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AreasComponent_Template_button_click_89_listener() {
          return ctx.onCancelAreaActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](90, "img", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](91, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AreasComponent_Template_button_click_91_listener() {
          return ctx.onConfirmAreaActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](92, "img", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](93, "button", 44, 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](95, "div", 46)(96, "div", 38)(97, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](98, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](99, "div", 39)(100, "div", 1)(101, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](102, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](103, "div", 3)(104, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](105);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](106, "br")(107, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](108, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AreasComponent_Template_button_click_108_listener() {
          return ctx.onCancelLocationActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](109, "img", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](110, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function AreasComponent_Template_button_click_110_listener() {
          return ctx.onConfirmLocationActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](111, "img", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.areasSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.areaHeaders)("tblValues", ctx.areas)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedArea);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.locationTitleName, " locations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.locationsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.locationsHeaders)("tblValues", ctx.locations)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9hcmVhcy9hcmVhcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksVUFBVTtJQUNWLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2hCb3h7XHJcbiAgICB3aWR0aDogMjUlOyBcclxuICAgIG1hcmdpbi1ib3R0b206IDElOyBcclxufSBcclxuIFxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 20803:
/*!*******************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/areas/locations/locations.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocationsComponent": () => (/* binding */ LocationsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_LocationOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/LocationOperation */ 69346);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveLocationModalButton"];
function LocationsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LocationsComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LocationsComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LocationsComponent_button_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LocationsComponent_button_30_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.createUpdateLocation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r3.locationForm.valid);
  }
}
class LocationsComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createLocationForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[1].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    this.route.params.subscribe(params => {
      this.locationId = +params['locationId'];
      this.areaId = +params['areaId'];
      if (this.locationId > 0 && this.areaId > 0) {
        this.loadLocation();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadLocation() {
    this.systemAdminService.getAreaLocations({
      locationId: this.locationId,
      areaId: this.areaId
    }).subscribe(result => {
      this.locationForm.patchValue(result.items[0]);
    });
  }
  createLocationForm() {
    this.locationForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      locationAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      locationEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
    });
  }
  createUpdateLocation() {
    let locationOper = new src_app_core_models_adminstration_LocationOperation__WEBPACK_IMPORTED_MODULE_0__.LocationOperation();
    locationOper = this.locationForm?.value;
    locationOper.status = this.locationForm?.value.status ? 1 : 0;
    locationOper.areaId = this.areaId;
    locationOper.operationType = this.operation;
    if (this.locationId > 0) locationOper.locationId = this.locationId;
    this.systemAdminService.locationOperations(locationOper).subscribe(result => {
      if (result.items > 0) this.saveLocationModalButton.nativeElement.click();
    });
  }
  backToLocationsList() {
    this.router.navigate(['system-admin/areas/' + this.areaId]);
  }
  static #_ = this.ɵfac = function LocationsComponent_Factory(t) {
    return new (t || LocationsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: LocationsComponent,
    selectors: [["app-locations"]],
    viewQuery: function LocationsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveLocationModalButton = _t.first);
      }
    },
    decls: 45,
    vars: 7,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "locationEname", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "locationAname", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveLocationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function LocationsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Location Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, LocationsComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Location Arabic Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, LocationsComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 16)(24, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](25, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](28, LocationsComponent_div_28_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](30, LocationsComponent_button_30_Template, 2, 1, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "div", 22)(32, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LocationsComponent_Template_button_click_32_listener() {
          return ctx.backToLocationsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](33, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](34, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](35, "button", 25, 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "div", 27)(38, "div", 28)(39, "div", 29)(40, "div", 30)(41, "h1", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](43);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](44, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.locationForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Location ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.locationForm.get("locationEname").hasError("required") && ctx.locationForm.get("locationEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.locationForm.get("locationAname").hasError("required") && ctx.locationForm.get("locationAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.locationForm.get("status").hasError("required") && ctx.locationForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9hcmVhcy9sb2NhdGlvbnMvbG9jYXRpb25zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 44096:
/*!*************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/category-shapes/category-shapes.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CategoryShapesComponent": () => (/* binding */ CategoryShapesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_ShapeOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/ShapeOperation */ 24650);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);
/* harmony import */ var _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/select-dropdown-component/select-dropdown.component */ 55306);











const _c0 = ["saveCategoryModalButton"];
const _c1 = ["CheckCategoryActiveDeactiveModalBtn"];
const _c2 = ["CheckShapeActiveDeactiveModalBtn"];
function CategoryShapesComponent_div_135_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
class CategoryShapesComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.categories = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.shapes = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.categoryHeaders = [{
      JsonPropName: 'categoryTypeDescEn',
      showName: 'Vehicle Category Type'
    }, {
      JsonPropName: 'descriptionEn',
      showName: 'Category Description'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.shapesHeaders = [{
      JsonPropName: 'shapeCode',
      showName: 'Shape Code'
    }, {
      JsonPropName: 'shapeDescEn',
      showName: 'Shape Description'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.shapesNotInCategory = [];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.createForms();
    this.bindChange();
    this.loadCategories();
  }
  createForms() {
    this.categoriesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null)
    });
    this.shapesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null)
    });
    this.shapesNoAssignedToCategoryForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup({
      shapeId: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required),
      status: new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required)
    });
  }
  loadCategories() {
    this.systemAdmin.getVehicleCategories({}).subscribe(result => {
      this.categories.data = result.items;
      if (this.categories.data.length > 0) {
        if (this.recordSelectionId > 0) this.onCategorySelection(this.categories.data.find(x => x.categoryId == this.recordSelectionId));else this.onCategorySelection(this.categories.data[0]);
      }
    });
  }
  bindChange() {
    this.categoriesSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchCategories(change);
    });
    this.shapesSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchCategoryShapes(change);
    });
  }
  onShapeStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "vehicle category shape");
    this.CheckShapeActiveDeactiveModalBtn.nativeElement.click();
  }
  onCategoryStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "vehicle category");
    this.CheckCategoryActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmCategoryActiveDeactiveCahnge() {
    let categoryOperation = new src_app_core_models_adminstration_ShapeOperation__WEBPACK_IMPORTED_MODULE_2__.VehicleCategoryOperation();
    categoryOperation = this.checkedSelectedItem;
    categoryOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    categoryOperation.status = categoryOperation.status ? 1 : 0;
    this.systemAdmin.vehicleCategoryOperations(categoryOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveCategoryModalButton.nativeElement.click();
      }
    });
  }
  onCancelCategoryActiveDeactiveChange() {
    this.loadCategories();
  }
  onConfirmShapeActiveDeactiveCahnge() {
    let shapeOperation = new src_app_core_models_adminstration_ShapeOperation__WEBPACK_IMPORTED_MODULE_2__.CategoryShapesOperation();
    shapeOperation = this.checkedSelectedItem;
    shapeOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    shapeOperation.status = shapeOperation.status ? 1 : 0;
    shapeOperation.categoryId = this.selectedCategoryId;
    this.systemAdmin.categoryShapesOperations(shapeOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveCategoryModalButton.nativeElement.click();
      }
    });
  }
  onCancelShapeActiveDeactiveChange() {
    this.loadCategoryShapes();
  }
  loadCategoryShapes() {
    this.systemAdmin.getCategoryShapes({
      categoryId: this.selectedCategoryId
    }).subscribe(result => {
      this.shapes.data = result.items;
    });
  }
  updateSelectedCategory(item) {
    this.router.navigate(['system-admin/vehicle-category-shapes/edit', item.categoryId]);
  }
  searchCategories(searchValue) {
    this.systemAdmin.getVehicleCategories({
      containsText: searchValue
    }).subscribe(result => {
      this.categories.data = result.items;
    });
  }
  searchCategoryShapes(searchValue) {
    this.systemAdmin.getCategoryShapes({
      categoryId: this.selectedCategoryId,
      containsText: searchValue
    }).subscribe(result => {
      this.shapes.data = result.items;
    });
  }
  AddNewCategory() {
    this.router.navigate(['system-admin/vehicle-category-shapes/new']);
  }
  onCategorySelection(item) {
    this.shapeTitleName = item.descriptionEn;
    this.selectedCategoryId = item.categoryId;
    this.selectedCategory = item;
    this.loadShapesNotInCategory(item.categoryId);
    this.loadShapes(item.categoryId);
  }
  loadShapes(categoryId) {
    this.systemAdmin.getCategoryShapes({
      categoryId: categoryId
    }).subscribe(result => {
      this.shapes.data = result.items;
    });
  }
  loadShapesNotInCategory(categoryId) {
    this.systemAdmin.geShapesNotAssignedToCategory({
      categoryId: categoryId
    }).subscribe(result => {
      this.shapesNotInCategory = result.items;
    });
  }
  addNewShapeToCategory() {
    let newShape = this.shapesNoAssignedToCategoryForm.value;
    newShape.status = newShape.status ? 1 : 0;
    newShape.categoryId = this.selectedCategoryId;
    newShape.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    this.systemAdmin.categoryShapesOperations(newShape).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveCategoryModalButton.nativeElement.click();
        this.loadShapes(this.selectedCategoryId);
      }
    });
  }
  onValueChange(item) {
    console.log(item);
  }
  static #_ = this.ɵfac = function CategoryShapesComponent_Factory(t) {
    return new (t || CategoryShapesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: CategoryShapesComponent,
    selectors: [["app-category-shapes"]],
    viewQuery: function CategoryShapesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveCategoryModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckCategoryActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckShapeActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 145,
    vars: 20,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#addShapeCategoryModel", 1, "btn", "btn-orange"], [3, "tblHeaders", "tblValues", "isUpdateOperationEnabled", "isDeleteOperationEnabled", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveCategoryModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#categoryConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckCategoryActiveDeactiveModalBtn", ""], ["id", "categoryConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#shapeConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckShapeActiveDeactiveModalBtn", ""], ["id", "shapeConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["id", "addShapeCategoryModel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "col-md-4"], [1, "form-check"], ["for", "search"], ["formControlName", "shapeId", "placeholder", "Select Shape", 3, "list", "displayMember", "idMember", "valueChanged"], [1, "col-md-2", "col-lg-3"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], ["class", "error-message", 4, "ngIf"], [1, "row", "justify-content-end"], [1, "col-6"], ["type", "button", 1, "btn", "btn-orange", "col-md-3", 3, "click"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-light", "col-md-3"], [1, "error-message"]],
    template: function CategoryShapesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13, " Vehicle Categories ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CategoryShapesComponent_Template_button_click_19_listener() {
          return ctx.AddNewCategory();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, " Add Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Category Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function CategoryShapesComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedCategory($event);
        })("selectItemEvent", function CategoryShapesComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onCategorySelection($event);
        })("checkboxEvent", function CategoryShapesComponent_Template_app_data_table_viewer_checkboxEvent_31_listener($event) {
          return ctx.onCategoryStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "section", 0)(33, "div", 1)(34, "div", 2)(35, "div", 1)(36, "div", 2)(37, "div", 1)(38, "div", 3)(39, "div", 4)(40, "div", 5)(41, "div", 6)(42, "div", 7)(43, "h2", 8)(44, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "div", 22)(47, "div", 11)(48, "div", 12)(49, "div", 1)(50, "div", 13)(51, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](52, " Assign Shape ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](53, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](54, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "form", 17)(57, "div", 1)(58, "div", 16)(59, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](60, "Shape Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](61, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](62, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](63, "app-data-table-viewer", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("checkboxEvent", function CategoryShapesComponent_Template_app_data_table_viewer_checkboxEvent_63_listener($event) {
          return ctx.onShapeStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](64, "button", 25, 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "div", 27)(67, "div", 28)(68, "div", 29)(69, "div", 30)(70, "h1", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](71, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](72);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](73, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](74, "button", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](76, "div", 36)(77, "div", 37)(78, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](79, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](80, "div", 38)(81, "div", 1)(82, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](83, "img", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](84, "div", 3)(85, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](86);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](87, "br")(88, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](89, "button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CategoryShapesComponent_Template_button_click_89_listener() {
          return ctx.onCancelCategoryActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](90, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](91, "button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CategoryShapesComponent_Template_button_click_91_listener() {
          return ctx.onConfirmCategoryActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](92, "img", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](93, "button", 43, 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](95, "div", 45)(96, "div", 37)(97, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](98, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](99, "div", 38)(100, "div", 1)(101, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](102, "img", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](103, "div", 3)(104, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](105);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](106, "br")(107, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](108, "button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CategoryShapesComponent_Template_button_click_108_listener() {
          return ctx.onCancelShapeActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](109, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](110, "button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CategoryShapesComponent_Template_button_click_110_listener() {
          return ctx.onConfirmShapeActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](111, "img", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](112, "div", 46)(113, "div", 37)(114, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](115, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](116, "div", 38)(117, "div", 1)(118, "div", 3)(119, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](120);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](121, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](122, "div", 3)(123, "form", 17)(124, "div", 1)(125, "div", 47)(126, "div", 48)(127, "label", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](128, "Shape Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](129, "app-select-dropdown", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("valueChanged", function CategoryShapesComponent_Template_app_select_dropdown_valueChanged_129_listener($event) {
          return ctx.onValueChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](130, "div", 51)(131, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](132, "input", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](133, "label", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](134, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](135, CategoryShapesComponent_div_135_Template, 2, 0, "div", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](136, "div", 55)(137, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](138, "div", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](139, "div", 56)(140, "div", 1)(141, "button", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function CategoryShapesComponent_Template_button_click_141_listener() {
          return ctx.addNewShapeToCategory();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](142, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](143, "button", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](144, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.categoriesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.categoryHeaders)("tblValues", ctx.categories)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedCategory);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.shapeTitleName, " Shapes ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.shapesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.shapesHeaders)("tblValues", ctx.shapes)("isUpdateOperationEnabled", false)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" Add Shape To ", ctx.shapeTitleName, " Vehicles");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.shapesNoAssignedToCategoryForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("list", ctx.shapesNotInCategory)("displayMember", "descriptionEn")("idMember", "shapeId");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.shapesNoAssignedToCategoryForm.get("status").hasError("required") && ctx.shapesNoAssignedToCategoryForm.get("status").touched);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent, _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_5__.SelectDropdownComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9jYXRlZ29yeS1zaGFwZXMvY2F0ZWdvcnktc2hhcGVzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxVQUFVO0lBQ1YsaUJBQWlCO0FBQ3JCIiwic291cmNlc0NvbnRlbnQiOlsiLnNlYXJjaEJveHtcclxuICAgIHdpZHRoOiAyNSU7IFxyXG4gICAgbWFyZ2luLWJvdHRvbTogMSU7IFxyXG59IFxyXG5cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 30161:
/*!***************************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/category-shapes/vehicle-category-operation/vehicle-category-operation.component.ts ***!
  \***************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleCategoryOperationComponent": () => (/* binding */ VehicleCategoryOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_VehicleCategoryOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/VehicleCategoryOperation */ 97808);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveVehicleCategoryModalButton"];
function VehicleCategoryOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VehicleCategoryOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VehicleCategoryOperationComponent_option_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r7.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r7.lkValueEname, " ");
  }
}
function VehicleCategoryOperationComponent_div_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VehicleCategoryOperationComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function VehicleCategoryOperationComponent_button_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VehicleCategoryOperationComponent_button_38_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r8.createUpdateVehicleCategory());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r5.vehicleCategoryForm.valid);
  }
}
class VehicleCategoryOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.vehicleTypes = [];
    this.reasons = [];
    this.entryTypes = [];
  }
  ngOnInit() {
    this.loadCategoryType();
    this.checkViewInsertUpdateMode();
    this.createVehicleCategoryForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.categoryId = +params['categoryId'];
      if (this.categoryId > 0) {
        this.loadVehicleCategory();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadVehicleCategory() {
    this.systemAdminService.getVehicleCategories({
      categoryId: this.categoryId
    }).subscribe(result => {
      this.vehicleCategoryForm.patchValue(result.items[0]);
    });
  }
  loadCategoryType() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.vehicleTypes).subscribe(types => this.vehicleTypes = types);
  }
  createVehicleCategoryForm() {
    this.vehicleCategoryForm = this.fb.group({
      categoryTypeId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      descriptionEn: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      descriptionAr: [null]
    });
  }
  createUpdateVehicleCategory() {
    let vehicleCategory = new src_app_core_models_adminstration_VehicleCategoryOperation__WEBPACK_IMPORTED_MODULE_0__.VehicleCategoryOperation();
    vehicleCategory = this.vehicleCategoryForm?.value;
    vehicleCategory.status = this.vehicleCategoryForm?.value.status ? 1 : 0;
    vehicleCategory.operationType = this.operation;
    if (this.categoryId > 0) vehicleCategory.categoryId = this.categoryId;
    this.systemAdminService.vehicleCategoryOperations(vehicleCategory).subscribe(result => {
      if (result.items > 0) this.saveVehicleCategoryModalButton.nativeElement.click();
    });
  }
  backToVehicleCategorysList() {
    this.router.navigate(['system-admin/vehicle-category-shapes']);
  }
  static #_ = this.ɵfac = function VehicleCategoryOperationComponent_Factory(t) {
    return new (t || VehicleCategoryOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: VehicleCategoryOperationComponent,
    selectors: [["app-vehicle-category-operation"]],
    viewQuery: function VehicleCategoryOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveVehicleCategoryModalButton = _t.first);
      }
    },
    decls: 53,
    vars: 10,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "descriptionEn", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "descriptionAr", 1, "form-control"], [1, "col-md-3"], ["for", ""], ["name", "categoryTypeId", "formControlName", "categoryTypeId", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveVehicleCategoryModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function VehicleCategoryOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, "Category Description * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, VehicleCategoryOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, "Arabic Description * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, VehicleCategoryOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 16)(24, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25, "Category Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "select", 18)(27, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](29, VehicleCategoryOperationComponent_option_29_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, VehicleCategoryOperationComponent_div_30_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 21)(32, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](33, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](35, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](36, VehicleCategoryOperationComponent_div_36_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, VehicleCategoryOperationComponent_button_38_Template, 2, 1, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "div", 27)(40, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function VehicleCategoryOperationComponent_Template_button_click_40_listener() {
          return ctx.backToVehicleCategorysList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](41, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](42, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](43, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](45, "div", 32)(46, "div", 33)(47, "div", 34)(48, "div", 35)(49, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](50, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](51);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](52, "button", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.vehicleCategoryForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Vehicle Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.vehicleCategoryForm.get("descriptionEn").hasError("required") && ctx.vehicleCategoryForm.get("descriptionEn").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.vehicleCategoryForm.get("descriptionAr").hasError("required") && ctx.vehicleCategoryForm.get("descriptionAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.vehicleTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.vehicleCategoryForm.get("categoryTypeId").hasError("required") && ctx.vehicleCategoryForm.get("categoryTypeId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.vehicleCategoryForm.get("status").hasError("required") && ctx.vehicleCategoryForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9jYXRlZ29yeS1zaGFwZXMvdmVoaWNsZS1jYXRlZ29yeS1vcGVyYXRpb24vdmVoaWNsZS1jYXRlZ29yeS1vcGVyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyIub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 23601:
/*!*******************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/client-assets/client-assets-operation/client-assets-operation.component.ts ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientAssetsOperationComponent": () => (/* binding */ ClientAssetsOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_ClientAssetsOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/ClientAssetsOperation */ 47298);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveClientAssetsModalButton"];
function ClientAssetsOperationComponent_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r11.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r11.lkValueEname, " ");
  }
}
function ClientAssetsOperationComponent_div_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function ClientAssetsOperationComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function ClientAssetsOperationComponent_option_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const station_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", station_r12.stationId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", station_r12.stationNameEn, " ");
  }
}
function ClientAssetsOperationComponent_option_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const booth_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", booth_r13.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", booth_r13.description, " ");
  }
}
function ClientAssetsOperationComponent_option_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const lane_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", lane_r14.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", lane_r14.laneName, " ");
  }
}
function ClientAssetsOperationComponent_option_53_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const section_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", section_r15.sectionId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", section_r15.sectionName, " ");
  }
}
function ClientAssetsOperationComponent_div_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function ClientAssetsOperationComponent_div_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function ClientAssetsOperationComponent_button_66_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ClientAssetsOperationComponent_button_66_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r16.createUpdateClientAssets());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r9.clientAssetsForm.valid);
  }
}
class ClientAssetsOperationComponent {
  constructor(fb, route, systemAdmin, router, lookupService) {
    this.fb = fb;
    this.route = route;
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.lookupService = lookupService;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.stations = [];
    this.booths = [];
    this.lanes = [];
    this.sections = [];
    this.clientTypes = [];
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createClientAssetsForm();
    this.bindChange();
    this.loadStations();
    this.loadClientTypes();
  }
  loadClientTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.clientAssetsType).subscribe(types => {
      this.clientTypes = types;
    });
  }
  bindChange() {
    this.clientAssetsForm.controls.stationId.valueChanges.subscribe(res => {
      this.selectedStationId = res;
      this.loadLanes(this.selectedStationId);
      this.loadBooths(this.selectedStationId);
    });
    this.clientAssetsForm.controls.laneId.valueChanges.subscribe(res => {
      this.selectedLaneId = res;
      this.loadSections(this.selectedStationId, this.selectedLaneId);
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.clientId = +params['clientId'];
      if (this.clientId > 0) {
        this.loadClientAssets();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadClientAssets() {
    this.systemAdmin.getClientAssets({
      clientId: this.clientId
    }).subscribe(result => {
      this.clientAssetsForm.patchValue(result.items[0]);
    });
  }
  loadSections(stationId = null, laneId = null) {
    this.systemAdmin.getSections({
      stationId: stationId,
      laneId: laneId
    }).subscribe(result => {
      this.sections = result.items;
    });
  }
  loadLanes(stationId = null) {
    this.systemAdmin.getLanes({
      stationId: stationId
    }).subscribe(result => {
      this.lanes = result.items;
    });
  }
  loadStations() {
    this.systemAdmin.getStations({}).subscribe(result => {
      this.stations = result.items;
    });
  }
  loadBooths(stationId = null) {
    this.systemAdmin.getBooths({
      stationId: stationId
    }).subscribe(result => {
      this.booths = result.items;
    });
  }
  createClientAssetsForm() {
    this.clientAssetsForm = this.fb.group({
      type: [null],
      ipAddress: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      destination: [null],
      stationId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      boothId: [null],
      laneId: [null],
      sectionId: [null],
      statusId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
  }
  createUpdateClientAssets() {
    let clientAssetsOper = new src_app_core_models_adminstration_ClientAssetsOperation__WEBPACK_IMPORTED_MODULE_0__.ClientAssetsOperation();
    clientAssetsOper = this.clientAssetsForm?.value;
    clientAssetsOper.statusId = this.clientAssetsForm?.value.statusId ? 1 : 0;
    clientAssetsOper.operationType = this.operation;
    if (this.clientId > 0) clientAssetsOper.clientId = this.clientId;
    this.systemAdmin.clientAssetsOperations(clientAssetsOper).subscribe(result => {
      if (result.items > 0) this.saveClientAssetsModalButton.nativeElement.click();
    });
  }
  backToClientAssetssList() {
    this.router.navigate(['system-admin/client-assets/' + this.clientId]);
  }
  static #_ = this.ɵfac = function ClientAssetsOperationComponent_Factory(t) {
    return new (t || ClientAssetsOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: ClientAssetsOperationComponent,
    selectors: [["app-client-assets-operation"]],
    viewQuery: function ClientAssetsOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveClientAssetsModalButton = _t.first);
      }
    },
    decls: 81,
    vars: 18,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["name", "type", "formControlName", "type", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "ipAddress", 1, "form-control"], [1, "col-md-3"], ["formControlName", "stationId", 1, "form-control"], ["formControlName", "boothId", 1, "form-control"], ["formControlName", "laneId", 1, "form-control"], ["formControlName", "sectionId", 1, "form-control"], ["type", "number", "formControlName", "destination", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "statusId", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveClientAssetsModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [3, "value"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function ClientAssetsOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, " Client Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](16, "select", 13)(17, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, ClientAssetsOperationComponent_option_19_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, ClientAssetsOperationComponent_div_20_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 12)(22, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23, "IP Address * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](24, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, ClientAssetsOperationComponent_div_25_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 18)(27, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Station *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "select", 19)(30, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31, "Select Station --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](32, ClientAssetsOperationComponent_option_32_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "div", 18)(34, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](35, "Booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "select", 20)(37, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](38, "Select Booth --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, ClientAssetsOperationComponent_option_39_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](40, "div", 18)(41, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](42, "Lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](43, "select", 21)(44, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](45, "Select Lane --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](46, ClientAssetsOperationComponent_option_46_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "div", 18)(48, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](49, "Section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](50, "select", 22)(51, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](52, "Select Section --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](53, ClientAssetsOperationComponent_option_53_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](54, "div", 12)(55, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](56, "Destination ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](57, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](58, ClientAssetsOperationComponent_div_58_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](59, "div", 24)(60, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](61, "input", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](62, "label", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](63, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](64, ClientAssetsOperationComponent_div_64_Template, 2, 0, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](65, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](66, ClientAssetsOperationComponent_button_66_Template, 2, 1, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](67, "div", 30)(68, "button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ClientAssetsOperationComponent_Template_button_click_68_listener() {
          return ctx.backToClientAssetssList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](69, "i", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](70, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](71, "button", 33, 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](73, "div", 35)(74, "div", 36)(75, "div", 37)(76, "div", 38)(77, "h1", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](78, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](79);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](80, "button", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.clientAssetsForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Client ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.clientTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.clientAssetsForm.get("type").hasError("required") && ctx.clientAssetsForm.get("type").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.clientAssetsForm.get("ipAddress").hasError("required") && ctx.clientAssetsForm.get("ipAddress").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.stations);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.booths);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.lanes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.sections);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.clientAssetsForm.get("destination").hasError("required") && ctx.clientAssetsForm.get("destination").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.clientAssetsForm.get("statusId").hasError("required") && ctx.clientAssetsForm.get("statusId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9jbGllbnQtYXNzZXRzL2NsaWVudC1hc3NldHMtb3BlcmF0aW9uL2NsaWVudC1hc3NldHMtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 79024:
/*!*********************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/client-assets/client-assets.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClientAssetsComponent": () => (/* binding */ ClientAssetsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_ClientAssetsOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/ClientAssetsOperation */ 47298);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);










const _c0 = ["saveClientAssetsModalButton"];
const _c1 = ["CheckClientAssetsActiveDeactiveModalBtn"];
function ClientAssetsComponent_option_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const station_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", station_r6.stationId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", station_r6.stationNameEn, " ");
  }
}
function ClientAssetsComponent_option_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const booth_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", booth_r7.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", booth_r7.description, " ");
  }
}
function ClientAssetsComponent_option_50_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const lane_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", lane_r8.laneId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", lane_r8.laneName, " ");
  }
}
function ClientAssetsComponent_option_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const section_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", section_r9.sectionId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", section_r9.sectionName, " ");
  }
}
class ClientAssetsComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.clientAssets = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.clientAssetsHeaders = [{
      JsonPropName: 'ipAddress',
      showName: 'IP Address'
    }, {
      JsonPropName: 'clientType',
      showName: 'Client Type'
    }, {
      JsonPropName: 'stationNameEn',
      showName: 'Station'
    }, {
      JsonPropName: 'description',
      showName: 'Booth'
    }, {
      JsonPropName: 'laneName',
      showName: 'Lane'
    }, {
      JsonPropName: 'sectionName',
      showName: 'section'
    }, {
      JsonPropName: 'statusId',
      showName: 'Enabled',
      ShowInCheckBox: true
    }];
    this.stations = [];
    this.booths = [];
    this.lanes = [];
    this.sections = [];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.loadClientAssetss();
    this.createClientAssetsForm();
    this.bindChange();
    this.loadStations();
  }
  createClientAssetsForm() {
    this.clientAssetsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      stationId: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      boothId: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      laneId: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      sectionId: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      ipAddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
  }
  loadSections(stationId = null, laneId = null) {
    this.systemAdmin.getSections({
      stationId: stationId,
      laneId: laneId
    }).subscribe(result => {
      this.sections = result.items;
    });
  }
  loadLanes(stationId = null) {
    this.systemAdmin.getLanes({
      stationId: stationId
    }).subscribe(result => {
      this.lanes = result.items;
    });
  }
  loadStations() {
    this.systemAdmin.getStations({}).subscribe(result => {
      this.stations = result.items;
    });
  }
  loadBooths(stationId = null) {
    this.systemAdmin.getBooths({
      stationId: stationId
    }).subscribe(result => {
      this.booths = result.items;
    });
  }
  loadClientAssetss() {
    this.systemAdmin.getClientAssets({}).subscribe(result => {
      this.clientAssets.data = result.items;
      if (this.clientAssets.data.length > 0) {
        if (this.recordSelectionId > 0) this.onClientAssetsSelection(this.clientAssets.data.find(x => x.clientId == this.recordSelectionId));else this.onClientAssetsSelection(this.clientAssets.data[0]);
      }
    });
  }
  onClientAssetsSelection(item) {
    this.selectedClientAssetsId = item.clientAssetsId;
    this.selectedClientAssets = item;
  }
  bindChange() {
    let formControls = this.clientAssetsSearchForm.controls;
    formControls.ipAddress.valueChanges.subscribe(change => {
      this.searchClientAssetss({
        stationId: this.selectedStationId,
        laneId: this.selectedLaneId,
        boothId: this.selectedBoothId,
        sectionId: this.selectedSectionId,
        ipAddress: this.clientAssetsSearchForm.controls.ipAddress?.value
      });
    });
    formControls.stationId?.valueChanges.subscribe(change => {
      this.selectedStationId = change;
      this.searchClientAssetss({
        stationId: this.selectedStationId,
        laneId: this.selectedLaneId,
        boothId: this.selectedBoothId,
        sectionId: this.selectedSectionId,
        ipAddress: this.clientAssetsSearchForm.controls.ipAddress?.value
      });
      this.loadBooths(this.selectedStationId);
      this.loadLanes(this.selectedStationId);
    });
    formControls.laneId?.valueChanges.subscribe(change => {
      this.selectedLaneId = change;
      this.searchClientAssetss({
        stationId: this.selectedStationId,
        laneId: this.selectedLaneId,
        boothId: this.selectedBoothId,
        sectionId: this.selectedSectionId,
        ipAddress: this.clientAssetsSearchForm.controls.ipAddress?.value
      });
      this.loadSections(this.selectedStationId, this.selectedLaneId);
    });
    formControls.sectionId?.valueChanges.subscribe(change => {
      this.selectedSectionId = change;
      this.searchClientAssetss({
        stationId: this.selectedStationId,
        laneId: this.selectedLaneId,
        boothId: this.selectedBoothId,
        sectionId: this.selectedSectionId,
        ipAddress: this.clientAssetsSearchForm.controls.ipAddress?.value
      });
    });
    formControls.boothId?.valueChanges.subscribe(change => {
      this.selectedBoothId = change;
      this.searchClientAssetss({
        stationId: this.selectedStationId,
        laneId: this.selectedLaneId,
        boothId: this.selectedBoothId,
        sectionId: this.selectedSectionId,
        ipAddress: this.clientAssetsSearchForm.controls.ipAddress?.value
      });
    });
  }
  onClientAssetsStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "client");
    this.CheckClientAssetsActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmClientAssetsActiveDeactiveCahnge() {
    let clientAssets = new src_app_core_models_adminstration_ClientAssetsOperation__WEBPACK_IMPORTED_MODULE_2__.ClientAssetsOperation();
    clientAssets = this.checkedSelectedItem;
    clientAssets.statusId = clientAssets.statusId ? 1 : 0;
    clientAssets.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    this.systemAdmin.clientAssetsOperations(clientAssets).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveClientAssetsModalButton.nativeElement.click();
      }
    });
  }
  onCancelClientAssetsActiveDeactiveChange() {
    this.loadClientAssetss();
  }
  updateSelectedClientAssets(item) {
    this.router.navigate(['system-admin/client-assets/edit', item.clientId]);
  }
  searchClientAssetss(body) {
    this.systemAdmin.getClientAssets(body).subscribe(result => {
      this.clientAssets.data = result.items;
    });
  }
  AddNewClientAssets() {
    this.router.navigate(['system-admin/client-assets/new']);
  }
  resetForm() {
    this.clientAssetsSearchForm.controls.boothId.patchValue(null, {
      emitEvent: false
    });
    this.clientAssetsSearchForm.controls.stationId.patchValue(null, {
      emitEvent: false
    });
    this.clientAssetsSearchForm.controls.laneId.patchValue(null, {
      emitEvent: false
    });
    this.clientAssetsSearchForm.controls.sectionId.patchValue(null, {
      emitEvent: false
    });
    this.clientAssetsSearchForm.controls.ipAddress.patchValue(null, {
      emitEvent: false
    });
    this.searchClientAssetss({});
  }
  static #_ = this.ɵfac = function ClientAssetsComponent_Factory(t) {
    return new (t || ClientAssetsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: ClientAssetsComponent,
    selectors: [["app-client-assets"]],
    viewQuery: function ClientAssetsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveClientAssetsModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.CheckClientAssetsActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 93,
    vars: 15,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "ipAddress", 1, "form-control"], ["formControlName", "stationId", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["formControlName", "boothId", 1, "form-control"], ["formControlName", "laneId", 1, "form-control"], ["formControlName", "sectionId", 1, "form-control"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveClientAssetsModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#clientAssetsConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckClientAssetsActiveDeactiveModalBtn", ""], ["id", "clientAssetsConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], [3, "value"]],
    template: function ClientAssetsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, " Client Assets ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ClientAssetsComponent_Template_button_click_19_listener() {
          return ctx.AddNewClientAssets();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " New Client ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 18)(27, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "IP Address");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](30, "div", 13)(31, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](32, "Station");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "select", 20)(34, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](35, "Select Station --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](36, ClientAssetsComponent_option_36_Template, 2, 2, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 13)(38, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](39, "Booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](40, "select", 23)(41, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](42, "Select Booth --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](43, ClientAssetsComponent_option_43_Template, 2, 2, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "div", 13)(45, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](46, "Lane");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "select", 24)(48, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](49, "Select Lane --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](50, ClientAssetsComponent_option_50_Template, 2, 2, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](51, "div", 13)(52, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](53, "Section");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](54, "select", 25)(55, "option", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](56, "Select Section --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](57, ClientAssetsComponent_option_57_Template, 2, 2, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](58, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](59, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](60, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ClientAssetsComponent_Template_button_click_60_listener() {
          return ctx.resetForm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](61, " Reset Filters ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](62, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](63, "app-data-table-viewer", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("updateItemEvent", function ClientAssetsComponent_Template_app_data_table_viewer_updateItemEvent_63_listener($event) {
          return ctx.updateSelectedClientAssets($event);
        })("selectItemEvent", function ClientAssetsComponent_Template_app_data_table_viewer_selectItemEvent_63_listener($event) {
          return ctx.onClientAssetsSelection($event);
        })("checkboxEvent", function ClientAssetsComponent_Template_app_data_table_viewer_checkboxEvent_63_listener($event) {
          return ctx.onClientAssetsStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](64, "button", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](66, "div", 29)(67, "div", 30)(68, "div", 31)(69, "div", 32)(70, "h1", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](71, "img", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](72);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](73, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](74, "button", 36, 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](76, "div", 38)(77, "div", 39)(78, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](79, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](80, "div", 40)(81, "div", 1)(82, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](83, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](84, "div", 3)(85, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](86);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](87, "br")(88, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](89, "button", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ClientAssetsComponent_Template_button_click_89_listener() {
          return ctx.onCancelClientAssetsActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](90, "img", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](91, "button", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ClientAssetsComponent_Template_button_click_91_listener() {
          return ctx.onConfirmClientAssetsActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](92, "img", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.clientAssetsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.stations);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.booths);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.lanes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.sections);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tblHeaders", ctx.clientAssetsHeaders)("tblValues", ctx.clientAssets)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedClientAssets);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9jbGllbnQtYXNzZXRzL2NsaWVudC1hc3NldHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFVBQVU7SUFDVixpQkFBaUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VhcmNoQm94e1xyXG4gICAgd2lkdGg6IDI1JTsgXHJcbiAgICBtYXJnaW4tYm90dG9tOiAxJTsgXHJcbn0gXHJcbiAiXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 24750:
/*!*******************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/credit-card-types/credit-card-operation/credit-card-operation.component.ts ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreditCardOperationComponent": () => (/* binding */ CreditCardOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_CreditCardOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/CreditCardOperation */ 72434);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveCreditCardModalButton"];
function CreditCardOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function CreditCardOperationComponent_option_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r6.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r6.lkValueEname, " ");
  }
}
function CreditCardOperationComponent_div_29_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function CreditCardOperationComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function CreditCardOperationComponent_button_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function CreditCardOperationComponent_button_36_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r8);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r7.createUpdateCreditCard());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r4.creditCardForm.valid);
  }
}
class CreditCardOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.commissionTypes = [];
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createCreditCardForm();
    this.loadCommissionTypes();
  }
  loadCommissionTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.commissionType).subscribe(types => this.commissionTypes = types);
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.cardId = +params['cardId'];
      if (this.cardId > 0) {
        this.loadCreditCard();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadCreditCard() {
    this.systemAdminService.getCreditCards({
      typeId: this.cardId
    }).subscribe(result => {
      this.creditCardForm.patchValue(result.items[0]);
    });
  }
  createCreditCardForm() {
    this.creditCardForm = this.fb.group({
      cardName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      commissionType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      commissionAmount: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      comments: [null]
    });
  }
  createUpdateCreditCard() {
    let creditCard = new src_app_core_models_adminstration_CreditCardOperation__WEBPACK_IMPORTED_MODULE_0__.CreditCardOperation();
    creditCard = this.creditCardForm?.value;
    creditCard.operationType = this.operation;
    if (this.cardId > 0) creditCard.typeId = this.cardId;
    this.systemAdminService.creditCardOperation(creditCard).subscribe(result => {
      if (result.items > 0) this.saveCreditCardModalButton.nativeElement.click();
    });
  }
  backToCreditCardsList() {
    this.router.navigate(['system-admin/credit-cards']);
  }
  static #_ = this.ɵfac = function CreditCardOperationComponent_Factory(t) {
    return new (t || CreditCardOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: CreditCardOperationComponent,
    selectors: [["app-credit-card-operation"]],
    viewQuery: function CreditCardOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveCreditCardModalButton = _t.first);
      }
    },
    decls: 51,
    vars: 9,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "cardName", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["name", "commissionType", "formControlName", "commissionType", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "number", "formControlName", "commissionAmount", 1, "form-control"], ["type", "text", "formControlName", "comments", 1, "form-control"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveCreditCardModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function CreditCardOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, "Credit Card Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, CreditCardOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Commission Type * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "select", 15)(22, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, CreditCardOperationComponent_option_24_Template, 2, 2, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "div", 12)(26, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](27, "Commission Amount *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](28, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](29, CreditCardOperationComponent_div_29_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](30, "div", 12)(31, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](32, "Comments");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](33, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](34, CreditCardOperationComponent_div_34_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](36, CreditCardOperationComponent_button_36_Template, 2, 1, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 22)(38, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function CreditCardOperationComponent_Template_button_click_38_listener() {
          return ctx.backToCreditCardsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](39, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](40, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](41, "button", 25, 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](43, "div", 27)(44, "div", 28)(45, "div", 29)(46, "div", 30)(47, "h1", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](48, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](49);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](50, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.creditCardForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Card ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.creditCardForm.get("cardName").hasError("required") && ctx.creditCardForm.get("cardName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.commissionTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.creditCardForm.get("commissionAmount").hasError("required") && ctx.creditCardForm.get("commissionAmount").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.creditCardForm.get("comments").hasError("required") && ctx.creditCardForm.get("comments").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9jcmVkaXQtY2FyZC10eXBlcy9jcmVkaXQtY2FyZC1vcGVyYXRpb24vY3JlZGl0LWNhcmQtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 15310:
/*!*****************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/credit-card-types/credit-card-types.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreditCardTypesComponent": () => (/* binding */ CreditCardTypesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);







const _c0 = ["saveCreditCardModalButton"];
const _c1 = ["CheckCreditCardActiveDeactiveModalBtn"];
class CreditCardTypesComponent {
  constructor(systemAdmin, router) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.creditCards = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.creditCardHeaders = [{
      JsonPropName: 'cardName',
      showName: 'Credit Card Name'
    }, {
      JsonPropName: 'commissionTypeName',
      showName: 'Commission Type'
    }, {
      JsonPropName: 'commissionAmount',
      showName: 'Commission Amount'
    }, {
      JsonPropName: 'comments',
      showName: 'Comment'
    }];
  }
  ngOnInit() {
    this.creditCardsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null)
    });
    this.bindChange();
    this.loadCreditCards();
  }
  loadCreditCards() {
    this.systemAdmin.getCreditCards({}).subscribe(result => {
      this.creditCards.data = result.items;
      if (this.creditCards.data.length > 0) this.onCreditCardSelection(this.creditCards.data[0]);
    });
  }
  onCreditCardSelection(item) {
    this.selectedCreditCardId = item.creditCardId;
    this.selectedCreditCard = item;
  }
  bindChange() {
    this.creditCardsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchCreditCards(change);
    });
  }
  updateSelectedCreditCard(item) {
    this.router.navigate(['system-admin/credit-cards/edit', item.typeId]);
  }
  searchCreditCards(searchValue) {
    this.systemAdmin.getCreditCards({
      searchField: searchValue
    }).subscribe(result => {
      this.creditCards.data = result.items;
    });
  }
  AddNewCreditCard() {
    this.router.navigate(['system-admin/credit-cards/new']);
  }
  static #_ = this.ɵfac = function CreditCardTypesComponent_Factory(t) {
    return new (t || CreditCardTypesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_1__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: CreditCardTypesComponent,
    selectors: [["app-credit-card-types"]],
    viewQuery: function CreditCardTypesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.saveCreditCardModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.CheckCreditCardActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 32,
    vars: 5,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent"]],
    template: function CreditCardTypesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, " Credit Cards ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function CreditCardTypesComponent_Template_button_click_19_listener() {
          return ctx.AddNewCreditCard();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20, " New Credit Card ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, "Credit Card Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("updateItemEvent", function CreditCardTypesComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedCreditCard($event);
        })("selectItemEvent", function CreditCardTypesComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onCreditCardSelection($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx.creditCardsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("tblHeaders", ctx.creditCardHeaders)("tblValues", ctx.creditCards)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedCreditCard);
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_2__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9jcmVkaXQtY2FyZC10eXBlcy9jcmVkaXQtY2FyZC10eXBlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksVUFBVTtJQUNWLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2hCb3h7XHJcbiAgICB3aWR0aDogMjUlOyBcclxuICAgIG1hcmdpbi1ib3R0b206IDElOyBcclxufSBcclxuIFxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 87538:
/*!****************************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/device-vendors/defect-evaluation-operation/defect-evaluation-operation.component.ts ***!
  \****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectEvaluationOperationComponent": () => (/* binding */ DefectEvaluationOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/DeviceVendorOperation */ 87622);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveDefectEvaluationModalButton"];
function DefectEvaluationOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_option_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r11.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r11.lkValueEname, " ");
  }
}
function DefectEvaluationOperationComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_div_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_option_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r12.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r12.lkValueEname, " ");
  }
}
function DefectEvaluationOperationComponent_div_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_div_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DefectEvaluationOperationComponent_button_56_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DefectEvaluationOperationComponent_button_56_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r13.createUpdateDefectEvaluation());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r9.defectEvaluationForm.valid);
  }
}
class DefectEvaluationOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.codeOperations = [];
    this.codeValues = [];
    this.operationTypes = [];
    this.outputCategoryTypes = [];
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createDefectEvaluationForm();
    this.loadOperations();
    this.loadOutputCategoryTypes();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    this.route.params.subscribe(params => {
      this.vendorId = +params['vendorId'];
      if (this.vendorId > 0 && this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
        this.loadDefectEvaluation();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadDefectEvaluation() {
    let deviceOutputCode = localStorage.getItem('evaluation');
    this.systemAdminService.getDevicesDefectEvaluation({
      vendorId: this.vendorId,
      deviceOutputCode: deviceOutputCode
    }).subscribe(result => {
      this.defectEvaluationForm.patchValue(result.items[0]);
      localStorage.removeItem('evaluation');
    });
  }
  loadOperations() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.DevicesDefectEvaluationOperation).subscribe(types => {
      this.operationTypes = types;
    });
  }
  loadOutputCategoryTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.DevicesDefectEvaluationCategory).subscribe(types => {
      this.outputCategoryTypes = types;
    });
  }
  createDefectEvaluationForm() {
    this.defectEvaluationForm = this.fb.group({
      deviceOutputCode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      outputCategory: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      limitValue: [null],
      description: [null],
      customValue: [null],
      operation: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
  }
  createUpdateDefectEvaluation() {
    let defectEvaluation = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__.DefectEvaluationOperation();
    defectEvaluation = this.defectEvaluationForm?.value;
    defectEvaluation.status = this.defectEvaluationForm?.value.status ? 1 : 0;
    defectEvaluation.operationType = this.operation;
    if (this.vendorId > 0) {
      defectEvaluation.vendorId = this.vendorId;
    }
    this.systemAdminService.devicesDefectEvaluationOperations(defectEvaluation).subscribe(result => {
      if (result.items > 0) this.saveDefectEvaluationModalButton.nativeElement.click();
    });
  }
  backToDefectEvaluationsList() {
    this.router.navigate(['system-admin/device-vendors/' + this.vendorId]);
  }
  static #_ = this.ɵfac = function DefectEvaluationOperationComponent_Factory(t) {
    return new (t || DefectEvaluationOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: DefectEvaluationOperationComponent,
    selectors: [["app-defect-evaluation-operation"]],
    viewQuery: function DefectEvaluationOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveDefectEvaluationModalButton = _t.first);
      }
    },
    decls: 71,
    vars: 15,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "deviceOutputCode", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["name", "type", "formControlName", "outputCategory", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "text", "formControlName", "description", 1, "form-control"], ["name", "type", "formControlName", "operation", 1, "form-control"], ["type", "number", "formControlName", "limitValue", 1, "form-control"], ["type", "text", "formControlName", "customValue", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveDefectEvaluationModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function DefectEvaluationOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, " Device Output Code * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, DefectEvaluationOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Output Category * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "select", 15)(22, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23, "Select Output Category --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, DefectEvaluationOperationComponent_option_24_Template, 2, 2, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, DefectEvaluationOperationComponent_div_25_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 12)(27, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, " Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](29, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, DefectEvaluationOperationComponent_div_30_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 12)(32, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33, " Operation * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "select", 19)(35, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](36, "Select Operation --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](37, DefectEvaluationOperationComponent_option_37_Template, 2, 2, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, DefectEvaluationOperationComponent_div_38_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "div", 12)(40, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](41, " Limit Value * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](42, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](43, DefectEvaluationOperationComponent_div_43_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "div", 12)(45, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](46, " Custom Value");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](47, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](48, DefectEvaluationOperationComponent_div_48_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](49, "div", 22)(50, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](51, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](52, "label", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](53, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](54, DefectEvaluationOperationComponent_div_54_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](55, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](56, DefectEvaluationOperationComponent_button_56_Template, 2, 1, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](57, "div", 28)(58, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DefectEvaluationOperationComponent_Template_button_click_58_listener() {
          return ctx.backToDefectEvaluationsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](59, "i", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](60, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](61, "button", 31, 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](63, "div", 33)(64, "div", 34)(65, "div", 35)(66, "div", 36)(67, "h1", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](68, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](70, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.defectEvaluationForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Defect Evaluation ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("deviceOutputCode").hasError("required") && ctx.defectEvaluationForm.get("deviceOutputCode").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.outputCategoryTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("outputCategory").hasError("required") && ctx.defectEvaluationForm.get("outputCategory").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("description").hasError("required") && ctx.defectEvaluationForm.get("description").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.operationTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("operation").hasError("required") && ctx.defectEvaluationForm.get("operation").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("limitValue").hasError("required") && ctx.defectEvaluationForm.get("limitValue").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("customValue").hasError("required") && ctx.defectEvaluationForm.get("customValue").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.defectEvaluationForm.get("status").hasError("required") && ctx.defectEvaluationForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9kZXZpY2UtdmVuZG9ycy9kZWZlY3QtZXZhbHVhdGlvbi1vcGVyYXRpb24vZGVmZWN0LWV2YWx1YXRpb24tb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 81025:
/*!********************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/device-vendors/device-vendor-operation/device-vendor-operation.component.ts ***!
  \********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceVendorOperationComponent": () => (/* binding */ DeviceVendorOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/DeviceVendorOperation */ 87622);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveDeviceVenorModalButton"];
function DeviceVendorOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_option_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r15.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r15.lkValueEname, " ");
  }
}
function DeviceVendorOperationComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_option_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r16.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r16.lkValueEname, " ");
  }
}
function DeviceVendorOperationComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_61_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_66_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_div_72_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function DeviceVendorOperationComponent_button_74_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DeviceVendorOperationComponent_button_74_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r17.createUpdateDeviceVenor());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r13.deviceVenorForm.valid);
  }
}
class DeviceVendorOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.integrationTypes = [];
    this.deviceVendors = [];
  }
  ngOnInit() {
    this.loadIntegrationType();
    this.loadVendors();
    this.checkViewInsertUpdateMode();
    this.createDeviceVenorForm();
  }
  loadVendors() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.DeviceVendor).subscribe(types => this.deviceVendors = types);
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 1].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.deviceId = +params['deviceId'];
      this.vendorId = +params['vendorId'];
      if (this.deviceId > 0 && this.vendorId > 0) {
        this.loadDeviceVenor();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadDeviceVenor() {
    this.systemAdminService.getInspectionDeviceVendors({
      deviceId: this.deviceId,
      vendorId: this.vendorId
    }).subscribe(result => {
      this.deviceVenorForm.patchValue(result.items[0]);
    });
  }
  loadIntegrationType() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.integrationType).subscribe(types => this.integrationTypes = types);
  }
  createDeviceVenorForm() {
    this.deviceVenorForm = this.fb.group({
      deviceName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      description: [null],
      manufacturing: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      version: [null],
      integrationType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      requestBaseAPIUrl: [null],
      responseBaseAPIUrl: [null],
      inputFilePath: [null],
      outputFilePath: [null],
      vendorId: [null]
    });
  }
  createUpdateDeviceVenor() {
    let deviceVendor = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__.DeviceVendorOperation();
    deviceVendor = this.deviceVenorForm?.value;
    deviceVendor.status = this.deviceVenorForm?.value.status ? 1 : 0;
    deviceVendor.operationType = this.operation;
    if (this.deviceId > 0 && this.vendorId > 0) {
      deviceVendor.deviceId = this.deviceId;
      deviceVendor.vendorId = this.vendorId;
    }
    this.systemAdminService.inspectionDeviceVendorsOperations(deviceVendor).subscribe(result => {
      if (result.items > 0) this.saveDeviceVenorModalButton.nativeElement.click();
    });
  }
  backToDeviceVenorsList() {
    this.router.navigate(['system-admin/device-vendors']);
  }
  static #_ = this.ɵfac = function DeviceVendorOperationComponent_Factory(t) {
    return new (t || DeviceVendorOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: DeviceVendorOperationComponent,
    selectors: [["app-device-vendor-operation"]],
    viewQuery: function DeviceVendorOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveDeviceVenorModalButton = _t.first);
      }
    },
    decls: 89,
    vars: 18,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "deviceName", 1, "form-control"], ["class", "error-message", 4, "ngIf"], [1, "col-md-3"], ["for", ""], ["name", "categoryTypeId", "formControlName", "vendorId", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "text", "formControlName", "description", 1, "form-control"], ["type", "text", "formControlName", "manufacturing", 1, "form-control"], ["type", "text", "formControlName", "version", 1, "form-control"], ["name", "categoryTypeId", "formControlName", "integrationType", 1, "form-control"], ["disabled", "", 3, "ngValue"], ["type", "text", "formControlName", "requestBaseAPIUrl", 1, "form-control"], ["type", "text", "formControlName", "responseBaseAPIUrl", 1, "form-control"], ["type", "text", "formControlName", "inputFilePath", 1, "form-control"], ["type", "text", "formControlName", "outputFilePath", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveDeviceVenorModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function DeviceVendorOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, " Device Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, DeviceVendorOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 15)(19, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, "Vendor *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "select", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, DeviceVendorOperationComponent_option_22_Template, 2, 2, "option", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](23, DeviceVendorOperationComponent_div_23_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "div", 12)(25, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](26, " Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](27, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](28, DeviceVendorOperationComponent_div_28_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div", 12)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31, "Manufacturing *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](32, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](33, DeviceVendorOperationComponent_div_33_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "div", 12)(35, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](36, " Version");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](37, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](38, DeviceVendorOperationComponent_div_38_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](39, "div", 15)(40, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](41, "Integration Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](42, "select", 22)(43, "option", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](44, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](45, DeviceVendorOperationComponent_option_45_Template, 2, 2, "option", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](46, DeviceVendorOperationComponent_div_46_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "div", 12)(48, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](49, " Request Base API Url");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](50, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](51, DeviceVendorOperationComponent_div_51_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](52, "div", 12)(53, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](54, " Response Base API Url");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](55, "input", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](56, DeviceVendorOperationComponent_div_56_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](57, "div", 12)(58, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](59, " Input File Path");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](60, "input", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](61, DeviceVendorOperationComponent_div_61_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](62, "div", 12)(63, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](64, " Output File Path");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](65, "input", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](66, DeviceVendorOperationComponent_div_66_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](67, "div", 28)(68, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](69, "input", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](70, "label", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](71, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](72, DeviceVendorOperationComponent_div_72_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](73, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](74, DeviceVendorOperationComponent_button_74_Template, 2, 1, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](75, "div", 34)(76, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function DeviceVendorOperationComponent_Template_button_click_76_listener() {
          return ctx.backToDeviceVenorsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](77, "i", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](78, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](79, "button", 37, 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](81, "div", 39)(82, "div", 40)(83, "div", 41)(84, "div", 42)(85, "h1", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](86, "img", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](87);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](88, "button", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.deviceVenorForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Device Vendor ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("deviceName").hasError("required") && ctx.deviceVenorForm.get("deviceName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.deviceVendors);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("vendorId").hasError("required") && ctx.deviceVenorForm.get("vendorId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("description").hasError("required") && ctx.deviceVenorForm.get("description").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("manufacturing").hasError("required") && ctx.deviceVenorForm.get("manufacturing").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("version").hasError("required") && ctx.deviceVenorForm.get("version").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.integrationTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("integrationType").hasError("required") && ctx.deviceVenorForm.get("integrationType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("requestBaseAPIUrl").hasError("required") && ctx.deviceVenorForm.get("requestBaseAPIUrl").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("responseBaseAPIUrl").hasError("required") && ctx.deviceVenorForm.get("responseBaseAPIUrl").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("inputFilePath").hasError("required") && ctx.deviceVenorForm.get("inputFilePath").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("outputFilePath").hasError("required") && ctx.deviceVenorForm.get("outputFilePath").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.deviceVenorForm.get("status").hasError("required") && ctx.deviceVenorForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9kZXZpY2UtdmVuZG9ycy9kZXZpY2UtdmVuZG9yLW9wZXJhdGlvbi9kZXZpY2UtdmVuZG9yLW9wZXJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 25288:
/*!***********************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/device-vendors/device-vendors.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceVendorsComponent": () => (/* binding */ DeviceVendorsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/DeviceVendorOperation */ 87622);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);











const _c0 = ["saveDeviceVendorModalButton"];
const _c1 = ["CheckDeviceVendorActiveDeactiveModalBtn"];
const _c2 = ["CheckInputCodeActiveDeactiveModalBtn"];
const _c3 = ["CheckDefectEvaluationActiveDeactiveModalBtn"];
class DeviceVendorsComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.OutputNavigation = {
      isEnabled: true,
      label: 'Output Defects'
    };
    this.deviceVendors = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.inputCodes = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.defectEvaluations = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.deviceVendorHeaders = [{
      JsonPropName: 'deviceName',
      showName: 'Vendor Name'
    }, {
      JsonPropName: 'description',
      showName: 'Description'
    }, {
      JsonPropName: 'version',
      showName: 'Version'
    }, {
      JsonPropName: 'integrationTypeDesc',
      showName: 'Integration Type'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.inputCodesHeaders = [{
      JsonPropName: 'description',
      showName: 'Description'
    }, {
      JsonPropName: 'codeOperationDesc',
      showName: 'Code Operation'
    }, {
      JsonPropName: 'codeValueDesc',
      showName: 'Code Value'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.defectEvaluationsHeaders = [{
      JsonPropName: 'deviceOutputCode',
      showName: 'Code'
    }, {
      JsonPropName: 'outputCategoryDesc',
      showName: 'Category'
    }, {
      JsonPropName: 'description',
      showName: 'Description'
    }, {
      JsonPropName: 'operationDesc',
      showName: ''
    }, {
      JsonPropName: 'limitValue',
      showName: 'Limit'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.createDeviceVendorsForms();
    this.bindChanges();
    this.loadDeviceVendors();
  }
  createDeviceVendorsForms() {
    this.deviceVendorsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      deviceName: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
    this.inputCodesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      description: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
    this.defectEvaluationsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      description: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
  }
  loadDeviceVendors() {
    this.systemAdmin.getInspectionDeviceVendors({}).subscribe(result => {
      this.deviceVendors.data = result.items;
      this.deviceVendors.data.sort();
      if (this.deviceVendors.data.length > 0) {
        console.log(this.deviceVendors.data);
        if (this.recordSelectionId > 0) this.onDeviceVendorSelection(this.deviceVendors.data.find(x => x.deviceId == this.recordSelectionId));else this.onDeviceVendorSelection(this.deviceVendors.data[0]);
      }
    });
  }
  bindChanges() {
    this.deviceVendorsSearchForm.controls.deviceName?.valueChanges.subscribe(change => {
      this.searchDeviceVendors(change);
    });
    this.inputCodesSearchForm.controls.description?.valueChanges.subscribe(change => {
      console.log(change);
      this.searchInputCodes(change);
    });
    this.defectEvaluationsSearchForm.controls.description?.valueChanges.subscribe(change => {
      console.log(change);
      this.searchDefectEvaluation(change);
    });
  }
  searchDefectEvaluation(change) {
    this.systemAdmin.getDevicesDefectEvaluation({
      vendorId: this.selectedDeviceId,
      description: change
    }).subscribe(result => {
      this.defectEvaluations.data = result.items;
    });
  }
  searchInputCodes(change) {
    this.systemAdmin.getDevicesInputCode({
      deviceId: this.selectedDeviceId,
      description: change
    }).subscribe(result => {
      this.inputCodes.data = result.items;
    });
  }
  onInputCodeStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "input code");
    this.CheckInputCodeActiveDeactiveModalBtn.nativeElement.click();
  }
  onDefectEvaluationStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "defect evaluation");
    this.CheckDefectEvaluationActiveDeactiveModalBtn.nativeElement.click();
  }
  onDeviceVendorStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "device vendor");
    this.CheckDeviceVendorActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmDeviceVendorActiveDeactiveCahnge() {
    let deviceVendorOperation = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_2__.DeviceVendorOperation();
    deviceVendorOperation = this.checkedSelectedItem;
    deviceVendorOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    deviceVendorOperation.status = deviceVendorOperation.status ? 1 : 0;
    this.systemAdmin.inspectionDeviceVendorsOperations(deviceVendorOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveDeviceVendorModalButton.nativeElement.click();
      }
    });
  }
  onCancelDeviceVendorActiveDeactiveChange() {
    this.loadDeviceVendors();
  }
  onConfirmInputCodeActiveDeactiveCahnge() {
    let inputCodeOperation = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_2__.InputCodeOperation();
    inputCodeOperation = this.checkedSelectedItem;
    inputCodeOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    inputCodeOperation.status = inputCodeOperation.status ? 1 : 0;
    this.systemAdmin.devicesInputCodeOperations(inputCodeOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveDeviceVendorModalButton.nativeElement.click();
      }
    });
  }
  onConfirmDefectEvaluationActiveDeactiveCahnge() {
    let defectEvaluationOperation = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_2__.DefectEvaluationOperation();
    defectEvaluationOperation = this.checkedSelectedItem;
    defectEvaluationOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    defectEvaluationOperation.status = defectEvaluationOperation.status ? 1 : 0;
    this.systemAdmin.devicesDefectEvaluationOperations(defectEvaluationOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveDeviceVendorModalButton.nativeElement.click();
      }
    });
  }
  onCancelInputCodeActiveDeactiveChange() {
    this.loadInputCodes();
  }
  onCancelDefectEvaluationActiveDeactiveChange() {
    this.loadDefectEvaluations();
  }
  searchDeviceVendors(searchValue) {
    this.systemAdmin.getInspectionDeviceVendors({
      deviceName: searchValue
    }).subscribe(result => {
      this.deviceVendors.data = result.items;
    });
  }
  onDeviceVendorSelection(item) {
    this.deviceVendorSelectedRecord = item;
    this.deviceVendorTitleName = item.deviceName;
    this.selectedDeviceId = item.deviceId;
    this.selectedVendorId = item.vendorId;
    this.loadInputCodes();
    this.loadDefectEvaluations();
  }
  loadDefectEvaluations() {
    this.systemAdmin.getDevicesDefectEvaluation({
      vendorId: this.selectedDeviceId
    }).subscribe(result => {
      this.defectEvaluations.data = result.items;
    });
  }
  loadInputCodes() {
    this.systemAdmin.getDevicesInputCode({
      deviceId: this.selectedDeviceId
    }).subscribe(result => {
      this.inputCodes.data = result.items;
    });
  }
  updateSelectedDeviceVendor(item) {
    this.router.navigate(['system-admin/device-vendors/edit', item.deviceId, item.vendorId]);
  }
  updateSelectedInputCode(item) {
    this.router.navigate(['system-admin/device-Input-code/edit', item.deviceId, item.codeId, item.codeOperation]);
  }
  updateSelectedDefectEvaluation(item) {
    localStorage.setItem('evaluation', item.deviceOutputCode);
    this.router.navigate(['system-admin/device-defect-evaluation/edit', item.vendorId]);
  }
  AddNewDeviceVendor() {
    this.router.navigate(['system-admin/device-vendors/new']);
  }
  AddNewDefectEvaluation() {
    this.router.navigate(['system-admin/device-defect-evaluation/new', this.selectedDeviceId]);
  }
  AddNewInputCode() {
    this.router.navigate(['system-admin/device-Input-code/new', this.selectedDeviceId]);
  }
  setActiveTab(tab) {
    this.activeTab = tab;
  }
  navigateOutputDefectEvaluation(item) {
    this.router.navigate(['system-admin/device-defect-evaluation', this.selectedDeviceId, item.deviceOutputCode, 'output-defects']);
  }
  static #_ = this.ɵfac = function DeviceVendorsComponent_Factory(t) {
    return new (t || DeviceVendorsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: DeviceVendorsComponent,
    selectors: [["app-device-vendors"]],
    viewQuery: function DeviceVendorsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c2, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c3, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveDeviceVendorModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckDeviceVendorActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckInputCodeActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckDefectEvaluationActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 169,
    vars: 24,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-4"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], [1, "col-md-3"], ["for", "search"], ["type", "text", "id", "search", "formControlName", "deviceName", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "deviceVendor", "tablist", 1, "nav", "nav-tabs"], ["deviceVendor", "presentation", 1, "nav-item"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#v-details", "type", "button", "deviceVendor", "tab", "aria-controls", "v-details", "aria-selected", "true", 1, "nav-link", "active", 3, "click"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#instructions", "type", "button", "deviceVendor", "tab", "aria-controls", "instructions", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "inspection-tab-content"], ["id", "myTabContent", 1, "tab-content"], ["id", "v-details", "deviceVendor", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "col-md-8"], ["for", "inputCodename"], ["type", "text", "id", "inputCodename", "formControlName", "description", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "updateItemEvent", "checkboxEvent"], ["id", "instructions", "deviceVendor", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["id", "accordionExample3", 1, "accordion", "section", "accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], ["type", "text", "id", "search", "formControlName", "description", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "navigationBtn", "updateItemEvent", "checkboxEvent", "navigateItemEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveDeviceVendorModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#deviceVendorConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckDeviceVendorActiveDeactiveModalBtn", ""], ["id", "deviceVendorConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#defectEvaluationConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckDefectEvaluationActiveDeactiveModalBtn", ""], ["id", "defectEvaluationConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#inputCodeConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckInputCodeActiveDeactiveModalBtn", ""], ["id", "inputCodeConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"]],
    template: function DeviceVendorsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](8, " Device Vendors ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "div", 0)(13, "div", 11)(14, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_14_listener() {
          return ctx.AddNewDeviceVendor();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, " Add Device ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](16, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](17, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](18, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](19, "form", 15)(20, "div", 16)(21, "div", 17)(22, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](23, "Vendor Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](24, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](25, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](26, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_updateItemEvent_26_listener($event) {
          return ctx.updateSelectedDeviceVendor($event);
        })("selectItemEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_selectItemEvent_26_listener($event) {
          return ctx.onDeviceVendorSelection($event);
        })("checkboxEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_checkboxEvent_26_listener($event) {
          return ctx.onDeviceVendorStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "div", 0)(28, "div", 1)(29, "div", 2)(30, "div", 3)(31, "div", 4)(32, "div", 5)(33, "div", 1)(34, "div", 21)(35, "ul", 22)(36, "li", 23)(37, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_37_listener() {
          return ctx.setActiveTab("details");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](38, " Input Codes ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](39, "li", 23)(40, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_40_listener() {
          return ctx.setActiveTab("inst");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](41, " Defect Evaluations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "div", 26)(43, "div", 0)(44, "div", 1)(45, "div", 27)(46, "div", 28)(47, "div", 0)(48, "div", 1)(49, "div", 2)(50, "div", 3)(51, "div", 29)(52, "div", 5)(53, "h2", 30)(54, "button", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "div", 32)(57, "div", 9)(58, "div", 10)(59, "div", 0)(60, "div", 11)(61, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_61_listener() {
          return ctx.AddNewInputCode();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](62, " Add Input Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](63, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](64, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](65, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "form", 15)(67, "div", 16)(68, "div", 17)(69, "label", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](70, "Code Operation");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](71, "input", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](72, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](73, "app-data-table-viewer", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_updateItemEvent_73_listener($event) {
          return ctx.updateSelectedInputCode($event);
        })("checkboxEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_checkboxEvent_73_listener($event) {
          return ctx.onInputCodeStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](74, "div", 37)(75, "div", 0)(76, "div", 1)(77, "div", 2)(78, "div", 3)(79, "div", 38)(80, "div", 5)(81, "h2", 39)(82, "button", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](83);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](84, "div", 41)(85, "div", 9)(86, "div", 10)(87, "div", 0)(88, "div", 11)(89, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_89_listener() {
          return ctx.AddNewDefectEvaluation();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](90, " Add Defect Evaluation ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](91, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](92, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](93, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](94, "form", 15)(95, "div", 16)(96, "div", 17)(97, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](98, "Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](99, "input", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](100, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](101, "app-data-table-viewer", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_updateItemEvent_101_listener($event) {
          return ctx.updateSelectedDefectEvaluation($event);
        })("checkboxEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_checkboxEvent_101_listener($event) {
          return ctx.onDefectEvaluationStatusChange($event);
        })("navigateItemEvent", function DeviceVendorsComponent_Template_app_data_table_viewer_navigateItemEvent_101_listener($event) {
          return ctx.navigateOutputDefectEvaluation($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](102, "button", 44, 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](104, "div", 46)(105, "div", 47)(106, "div", 48)(107, "div", 49)(108, "h1", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](109, "img", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](110);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](111, "button", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](112, "button", 53, 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](114, "div", 55)(115, "div", 56)(116, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](117, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](118, "div", 57)(119, "div", 0)(120, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](121, "img", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](122, "div", 1)(123, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](124);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](125, "br")(126, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](127, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_127_listener() {
          return ctx.onCancelDeviceVendorActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](128, "img", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](129, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_129_listener() {
          return ctx.onConfirmDeviceVendorActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](130, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](131, "button", 62, 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](133, "div", 64)(134, "div", 56)(135, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](136, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](137, "div", 57)(138, "div", 0)(139, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](140, "img", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](141, "div", 1)(142, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](143);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](144, "br")(145, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](146, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_146_listener() {
          return ctx.onCancelDefectEvaluationActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](147, "img", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](148, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_148_listener() {
          return ctx.onConfirmDefectEvaluationActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](149, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](150, "button", 65, 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](152, "div", 67)(153, "div", 56)(154, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](155, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](156, "div", 57)(157, "div", 0)(158, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](159, "img", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](160, "div", 1)(161, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](162);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](163, "br")(164, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](165, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_165_listener() {
          return ctx.onCancelInputCodeActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](166, "img", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](167, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function DeviceVendorsComponent_Template_button_click_167_listener() {
          return ctx.onConfirmInputCodeActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](168, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.deviceVendorsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.deviceVendorHeaders)("tblValues", ctx.deviceVendors)("isDeleteOperationEnabled", false)("selectedRow", ctx.deviceVendorSelectedRecord);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.deviceVendorTitleName, " Input Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.inputCodesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.inputCodesHeaders)("tblValues", ctx.inputCodes)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.deviceVendorTitleName, " Defect Evaluation ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.defectEvaluationsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.defectEvaluationsHeaders)("tblValues", ctx.defectEvaluations)("isDeleteOperationEnabled", false)("navigationBtn", ctx.OutputNavigation);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent],
    styles: [".inspection-tab-menu[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    margin-left: 15px;\r\n    margin-top: 1%;\r\n }\r\n\r\n @media (max-width: 768px) {\r\n    .inspection-tab-menu[_ngcontent-%COMP%] {\r\n        margin-left: 0;\r\n        padding: 0 15px;\r\n    }\r\n}\r\n\r\n\r\n\r\n.outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9kZXZpY2UtdmVuZG9ycy9kZXZpY2UtdmVuZG9ycy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztJQUNYLGlCQUFpQjtJQUNqQixjQUFjO0NBQ2pCOztDQUVBO0lBQ0c7UUFDSSxjQUFjO1FBQ2QsZUFBZTtJQUNuQjtBQUNKOzs7O0FBSUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLmluc3BlY3Rpb24tdGFiLW1lbnV7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogMSU7XHJcbiB9XHJcblxyXG4gQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAuaW5zcGVjdGlvbi10YWItbWVudSB7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgICAgICAgcGFkZGluZzogMCAxNXB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5cclxuXHJcbi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 76142:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/device-vendors/input-code-operation/input-code-operation.component.ts ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InputCodeOperationComponent": () => (/* binding */ InputCodeOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/DeviceVendorOperation */ 87622);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveInputCodeModalButton"];
function InputCodeOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function InputCodeOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function InputCodeOperationComponent_option_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const code_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", code_r9.lkCode);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", code_r9.lkEname, " ");
  }
}
function InputCodeOperationComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function InputCodeOperationComponent_option_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const code_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", code_r10.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", code_r10.lkValueEname, " ");
  }
}
function InputCodeOperationComponent_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function InputCodeOperationComponent_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function InputCodeOperationComponent_button_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function InputCodeOperationComponent_button_45_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r11.createUpdateInputCode());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r7.inputCodeForm.valid);
  }
}
class InputCodeOperationComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.codeOperations = [];
    this.codeValues = [];
  }
  ngOnInit() {
    this.loadCodeOperations();
    this.checkViewInsertUpdateMode();
    this.createInputCodeForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      this.operation = segments.some(x => x.path === "new") ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) {
      this.route.params.subscribe(params => {
        this.deviceId = +params['deviceId'];
        this.codeId = +params['codeId'];
        this.codeOperation = +params['codeOperation'];
        if (this.deviceId > 0 && this.codeId > 0 && this.codeOperation > 0) {
          this.loadInputCode();
        }
      });
    } else {
      this.route.params.subscribe(params => {
        this.deviceId = +params['vendorId'];
      });
    }
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadInputCode() {
    this.systemAdminService.getDevicesInputCode({
      deviceId: this.deviceId,
      codeId: this.codeId,
      codeOperation: this.codeOperation
    }).subscribe(result => {
      this.inputCodeForm.patchValue(result.items[0]);
    });
  }
  loadCodeOperations() {
    this.systemAdminService.getDeviceOperationCodes().subscribe(result => {
      this.codeOperations = result.items;
    });
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.integrationType).subscribe(types => this.codeValues = types);
  }
  createInputCodeForm() {
    this.inputCodeForm = this.fb.group({
      codeOperation: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      codeValues: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      operationValue: [null],
      description: [null],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]
    });
  }
  createUpdateInputCode() {
    let inputCode = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__.InputCodeOperation();
    inputCode = this.inputCodeForm?.value;
    inputCode.status = this.inputCodeForm?.value.status ? 1 : 0;
    inputCode.operationType = this.operation;
    if (this.deviceId > 0 && this.codeId > 0 && this.codeOperation > 0) {
      inputCode.deviceId = this.deviceId;
      inputCode.codeId = this.codeId;
      inputCode.codeOperation = this.codeOperation;
    }
    this.systemAdminService.devicesInputCodeOperations(inputCode).subscribe(result => {
      if (result.items > 0) this.saveInputCodeModalButton.nativeElement.click();
    });
  }
  backToInputCodesList() {
    this.router.navigate(['system-admin/device-vendors/' + this.deviceId]);
  }
  static #_ = this.ɵfac = function InputCodeOperationComponent_Factory(t) {
    return new (t || InputCodeOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: InputCodeOperationComponent,
    selectors: [["app-input-code-operation"]],
    viewQuery: function InputCodeOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveInputCodeModalButton = _t.first);
      }
    },
    decls: 60,
    vars: 13,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "operationValue", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "description", 1, "form-control"], [1, "col-md-3"], ["for", ""], ["name", "categoryTypeId", "formControlName", "codeOperation", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["name", "categoryTypeId", "formControlName", "codeValues", 1, "form-control", 3, "disabled"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveInputCodeModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function InputCodeOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, " Operation Value * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, InputCodeOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, InputCodeOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 16)(24, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](25, "Code Operation *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "select", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](27, " Code Operation * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](29, "Select Code --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, InputCodeOperationComponent_option_30_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](31, InputCodeOperationComponent_div_31_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](32, "div", 16)(33, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](34, "Code Value *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](35, "select", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](36, InputCodeOperationComponent_option_36_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](37, InputCodeOperationComponent_div_37_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](38, "div", 22)(39, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](40, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](41, "label", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](42, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](43, InputCodeOperationComponent_div_43_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](45, InputCodeOperationComponent_button_45_Template, 2, 1, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](46, "div", 28)(47, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function InputCodeOperationComponent_Template_button_click_47_listener() {
          return ctx.backToInputCodesList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](48, "i", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](49, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](50, "button", 31, 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](52, "div", 33)(53, "div", 34)(54, "div", 35)(55, "div", 36)(56, "h1", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](57, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](58);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](59, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.inputCodeForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Input Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.inputCodeForm.get("operationValue").hasError("required") && ctx.inputCodeForm.get("operationValue").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.inputCodeForm.get("description").hasError("required") && ctx.inputCodeForm.get("description").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.codeOperations);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.inputCodeForm.get("codeOperation").hasError("required") && ctx.inputCodeForm.get("codeOperation").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", (ctx.inputCodeForm.controls.codeOperation == null ? null : ctx.inputCodeForm.controls.codeOperation.value) == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.codeValues);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.inputCodeForm.get("codeValues").hasError("required") && ctx.inputCodeForm.get("codeValues").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.inputCodeForm.get("status").hasError("required") && ctx.inputCodeForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9kZXZpY2UtdmVuZG9ycy9pbnB1dC1jb2RlLW9wZXJhdGlvbi9pbnB1dC1jb2RlLW9wZXJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 24899:
/*!**********************************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/device-vendors/output-defect/output-defect-operation/output-defect-operation.component.ts ***!
  \**********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OutputDefectOperationComponent": () => (/* binding */ OutputDefectOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/DeviceVendorOperation */ 87622);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/application-admin.service */ 67074);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);











const _c0 = ["saveOutputDefectModalButton"];
function OutputDefectOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function OutputDefectOperationComponent_option_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const comment_r8 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", comment_r8.defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", comment_r8.descriptionEn, " ");
  }
}
function OutputDefectOperationComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function OutputDefectOperationComponent_option_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", type_r9.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", type_r9.lkValueEname, " ");
  }
}
function OutputDefectOperationComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function OutputDefectOperationComponent_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function OutputDefectOperationComponent_button_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "button", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function OutputDefectOperationComponent_button_41_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r10.createUpdateOutputDefect());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx_r6.outputDefectForm.valid);
  }
}
class OutputDefectOperationComponent {
  constructor(fb, route, lookupService, appAdmin, systemAdminService, router, location) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.appAdmin = appAdmin;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.location = location;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.commentTypes = [];
    this.defectComments = [];
  }
  ngOnInit() {
    this.loadCommentTypes();
    this.loadDefectComments();
    this.checkViewInsertUpdateMode();
    this.createOutputDefectForm();
  }
  loadDefectComments() {
    this.appAdmin.getDefectComments({}).subscribe(res => {
      this.defectComments = res.items;
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      this.operation = segments.some(item => item.path === 'view') === true ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : segments.some(item => item.path === 'edit') === true ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.outputCode = params['outputCode'];
      this.vendorId = +params['vendorId'];
      this.defCommentId = +params['defCommentId'];
      if (this.defCommentId > 0 && this.vendorId > 0 && this.outputCode.length > 0) {
        this.loadOutputDefect();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadOutputDefect() {
    this.systemAdminService.getDevicesOutputDefect({
      deviceId: this.vendorId,
      defCommentId: this.defCommentId,
      outputCode: this.outputCode
    }).subscribe(result => {
      this.outputDefectForm.patchValue(result.items[0]);
    });
  }
  loadCommentTypes() {
    this.lookupService.loadLookupValues(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.commentType).subscribe(types => this.commentTypes = types);
  }
  createOutputDefectForm() {
    this.outputDefectForm = this.fb.group({
      commentType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      defCommentId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      deviceOutputCode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]
    });
  }
  createUpdateOutputDefect() {
    let deviceVendor = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_0__.DeviceOutputDefectOperation();
    deviceVendor = this.outputDefectForm?.value;
    deviceVendor.status = this.outputDefectForm?.value.status ? 1 : 0;
    deviceVendor.operationType = this.operation;
    deviceVendor.deviceId = this.vendorId;
    deviceVendor.deviceOutputCode = this.outputCode;
    if (this.defCommentId > 0) {
      deviceVendor.defCommentId = this.defCommentId;
    }
    this.systemAdminService.devicesOutputDefectOperations(deviceVendor).subscribe(result => {
      if (result.items > 0) this.saveOutputDefectModalButton.nativeElement.click();
    });
  }
  backToOutputDefectsList() {
    this.location.back();
  }
  static #_ = this.ɵfac = function OutputDefectOperationComponent_Factory(t) {
    return new (t || OutputDefectOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_application_admin_service__WEBPACK_IMPORTED_MODULE_4__.ApplicationAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_5__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_9__.Location));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: OutputDefectOperationComponent,
    selectors: [["app-output-defect-operation"]],
    viewQuery: function OutputDefectOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveOutputDefectModalButton = _t.first);
      }
    },
    decls: 56,
    vars: 12,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "deviceOutputCode", 1, "form-control"], ["class", "error-message", 4, "ngIf"], [1, "col-md-3"], ["for", ""], ["name", "defCommentId", "formControlName", "defCommentId", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["name", "categoryTypeId", "formControlName", "commentType", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveOutputDefectModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function OutputDefectOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, " Device Output Code * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](17, OutputDefectOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "div", 15)(19, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, "Defect Comment *");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "select", 17)(22, "option", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](23, "Select Defect Comment --");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](24, OutputDefectOperationComponent_option_24_Template, 2, 2, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](25, OutputDefectOperationComponent_div_25_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](26, "div", 15)(27, "label", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Comment Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](29, "select", 20)(30, "option", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](31, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](32, OutputDefectOperationComponent_option_32_Template, 2, 2, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](33, OutputDefectOperationComponent_div_33_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "div", 21)(35, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](36, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](37, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](38, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](39, OutputDefectOperationComponent_div_39_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](41, OutputDefectOperationComponent_button_41_Template, 2, 1, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "div", 27)(43, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function OutputDefectOperationComponent_Template_button_click_43_listener() {
          return ctx.backToOutputDefectsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](44, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](46, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "div", 32)(49, "div", 33)(50, "div", 34)(51, "div", 35)(52, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](53, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "button", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.outputDefectForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.title, " Device Output Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.outputDefectForm.get("deviceOutputCode").hasError("required") && ctx.outputDefectForm.get("deviceOutputCode").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.defectComments);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.outputDefectForm.get("defCommentId").hasError("required") && ctx.outputDefectForm.get("defCommentId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.commentTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.outputDefectForm.get("commentType").hasError("required") && ctx.outputDefectForm.get("commentType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.outputDefectForm.get("status").hasError("required") && ctx.outputDefectForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9kZXZpY2UtdmVuZG9ycy9vdXRwdXQtZGVmZWN0L291dHB1dC1kZWZlY3Qtb3BlcmF0aW9uL291dHB1dC1kZWZlY3Qtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 21872:
/*!************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/device-vendors/output-defect/output-defect.component.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OutputDefectComponent": () => (/* binding */ OutputDefectComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/DeviceVendorOperation */ 87622);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../components/data-table-viewer/data-table-viewer.component */ 75984);








const _c0 = ["saveOutputDefectModalButton"];
const _c1 = ["CheckOutputDefectActiveDeactiveModalBtn"];
class OutputDefectComponent {
  constructor(systemAdmin, router, route, lookupService) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.lookupService = lookupService;
    this.outputDefects = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.outputDefectHeaders = [{
      JsonPropName: 'deviceOutputCode',
      showName: 'Output Code'
    }, {
      JsonPropName: 'commentTypeDescEn',
      showName: 'Comment Type'
    }, {
      JsonPropName: 'defCommentDescEn',
      showName: 'Defect Comment'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.plateTypes = [];
  }
  ngOnInit() {
    this.loaDeviceOutputDefectInfo();
  }
  loaDeviceOutputDefectInfo() {
    this.route.params.subscribe(params => {
      this.vendorId = +params['vendorId'];
      this.outputCode = params['outputCode'];
      this.loadOutputDefects();
    });
  }
  loadOutputDefects() {
    this.systemAdmin.getDevicesOutputDefect({
      deviceId: this.vendorId,
      deviceOutputCode: this.outputCode
    }).subscribe(result => {
      console.log(result.items);
      this.outputDefects.data = result.items;
      if (this.outputDefects.data.length > 0) this.onOutputDefectSelection(this.outputDefects.data[0]);
    });
  }
  onOutputDefectStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "output defect");
    this.CheckOutputDefectActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmOutputDefectActiveDeactiveCahnge() {
    let OutputDefect = new src_app_core_models_adminstration_DeviceVendorOperation__WEBPACK_IMPORTED_MODULE_2__.DeviceOutputDefectOperation();
    OutputDefect = this.checkedSelectedItem;
    OutputDefect.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    OutputDefect.status = OutputDefect.status ? 1 : 0;
    this.systemAdmin.devicesOutputDefectOperations(OutputDefect).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveOutputDefectModalButton.nativeElement.click();
      }
    });
  }
  onCancelOutputDefectActiveDeactiveChange() {
    this.loadOutputDefects();
  }
  updateSelectedOutputDefect(item) {
    this.route.url.subscribe(segments => {
      const currentUrl = segments.map(segment => segment.path).join('/');
      const newUrl = `${currentUrl}/edit/${item.defCommentId}`;
      this.router.navigateByUrl("system-admin/" + newUrl);
    });
  }
  AddNewOutputDefect() {
    this.route.url.subscribe(segments => {
      const currentUrl = segments.map(segment => segment.path).join('/');
      const newUrl = `${currentUrl}/new`;
      this.router.navigateByUrl("system-admin/" + newUrl);
    });
  }
  onOutputDefectSelection(item) {
    this.selectedOutputDefectId = item.outputDefectId;
    this.selectedOutputDefect = item;
  }
  backToEvaluation() {
    this.router.navigate(['system-admin/device-vendors/' + this.vendorId]);
  }
  static #_ = this.ɵfac = function OutputDefectComponent_Factory(t) {
    return new (t || OutputDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_4__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: OutputDefectComponent,
    selectors: [["app-output-defect"]],
    viewQuery: function OutputDefectComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveOutputDefectModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckOutputDefectActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 58,
    vars: 6,
    consts: [[1, "header-content"], [3, "click"], [1, "bi", "bi-arrow-left"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-6"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveOutputDefectModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#outputDefectConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckOutputDefectActiveDeactiveModalBtn", ""], ["id", "outputDefectConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"]],
    template: function OutputDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 0)(1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function OutputDefectComponent_Template_a_click_1_listener() {
          return ctx.backToEvaluation();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "i", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "section", 3)(5, "div", 4)(6, "div", 5)(7, "div", 4)(8, "div", 5)(9, "div", 4)(10, "div", 6)(11, "div", 7)(12, "div", 8)(13, "div", 9)(14, "div", 10)(15, "h2", 11)(16, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](17, " Device Output Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "div", 13)(19, "div", 14)(20, "div", 15)(21, "div", 4)(22, "div", 16)(23, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function OutputDefectComponent_Template_button_click_23_listener() {
          return ctx.AddNewOutputDefect();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](24, " Add New Output Defect ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](25, "i", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](26, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](27, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "app-data-table-viewer", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function OutputDefectComponent_Template_app_data_table_viewer_updateItemEvent_28_listener($event) {
          return ctx.updateSelectedOutputDefect($event);
        })("selectItemEvent", function OutputDefectComponent_Template_app_data_table_viewer_selectItemEvent_28_listener($event) {
          return ctx.onOutputDefectSelection($event);
        })("checkboxEvent", function OutputDefectComponent_Template_app_data_table_viewer_checkboxEvent_28_listener($event) {
          return ctx.onOutputDefectStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](29, "button", 20, 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "div", 22)(32, "div", 23)(33, "div", 24)(34, "div", 25)(35, "h1", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](36, "img", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](38, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](39, "button", 29, 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](41, "div", 31)(42, "div", 32)(43, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](44, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](45, "div", 33)(46, "div", 4)(47, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](48, "img", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](49, "div", 6)(50, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](51);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](52, "br")(53, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function OutputDefectComponent_Template_button_click_54_listener() {
          return ctx.onCancelOutputDefectActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "img", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "button", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function OutputDefectComponent_Template_button_click_56_listener() {
          return ctx.onConfirmOutputDefectActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](57, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.outputDefectHeaders)("tblValues", ctx.outputDefects)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedOutputDefect);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__.DataTableViewerComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 74489:
/*!***************************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/global-configurations/global-config-operation/global-config-operation.component.ts ***!
  \***************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalConfigOperationComponent": () => (/* binding */ GlobalConfigOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_GlobalConfigOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/GlobalConfigOperation */ 64306);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveGlobalConfigModalButton"];
function GlobalConfigOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function GlobalConfigOperationComponent_div_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function GlobalConfigOperationComponent_button_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function GlobalConfigOperationComponent_button_25_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r4.createUpdateGlobalConfig());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r2.globalConfigForm.valid);
  }
}
class GlobalConfigOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createGlobalConfigForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.configId = +params['configId'];
      if (this.configId > 0) {
        this.loadGlobalConfig();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadGlobalConfig() {
    this.systemAdminService.getGlobalConfigurations({
      configId: this.configId
    }).subscribe(result => {
      this.globalConfigForm.patchValue(result.items[0]);
      this.globalConfigForm.controls.value.patchValue(result.items[0].value ? 1 : 0);
    });
  }
  createGlobalConfigForm() {
    this.globalConfigForm = this.fb.group({
      key: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      value: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
    });
  }
  createUpdateGlobalConfig() {
    let globalConfigOper = new src_app_core_models_adminstration_GlobalConfigOperation__WEBPACK_IMPORTED_MODULE_0__.GlobalConfigOperation();
    globalConfigOper = this.globalConfigForm?.value;
    globalConfigOper.value = this.globalConfigForm?.value.value;
    globalConfigOper.operationType = this.operation;
    if (this.configId > 0) globalConfigOper.ConfigId = this.configId;
    this.systemAdminService.globalConfigurationOperations(globalConfigOper).subscribe(result => {
      if (result.items > 0) this.saveGlobalConfigModalButton.nativeElement.click();
    });
  }
  backToGlobalConfigsList() {
    this.router.navigate(['system-admin/configurations']);
  }
  static #_ = this.ɵfac = function GlobalConfigOperationComponent_Factory(t) {
    return new (t || GlobalConfigOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: GlobalConfigOperationComponent,
    selectors: [["app-global-config-operation"]],
    viewQuery: function GlobalConfigOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveGlobalConfigModalButton = _t.first);
      }
    },
    decls: 40,
    vars: 6,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "key", 1, "form-control"], ["class", "error-message", 4, "ngIf"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "value", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveGlobalConfigModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function GlobalConfigOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Config Key * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, GlobalConfigOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 15)(19, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](20, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](22, " Value * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](23, GlobalConfigOperationComponent_div_23_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](24, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](25, GlobalConfigOperationComponent_button_25_Template, 2, 1, "button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "div", 21)(27, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function GlobalConfigOperationComponent_Template_button_click_27_listener() {
          return ctx.backToGlobalConfigsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](28, "i", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](29, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](30, "button", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](32, "div", 26)(33, "div", 27)(34, "div", 28)(35, "div", 29)(36, "h1", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](37, "img", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](38);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](39, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.globalConfigForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.globalConfigForm.get("key").hasError("required") && ctx.globalConfigForm.get("key").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.globalConfigForm.get("value").hasError("required") && ctx.globalConfigForm.get("value").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9nbG9iYWwtY29uZmlndXJhdGlvbnMvZ2xvYmFsLWNvbmZpZy1vcGVyYXRpb24vZ2xvYmFsLWNvbmZpZy1vcGVyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyIub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 93715:
/*!*************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/global-configurations/global-configurations.component.ts ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalConfigurationsComponent": () => (/* binding */ GlobalConfigurationsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_GlobalConfigOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/GlobalConfigOperation */ 64306);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);









const _c0 = ["saveGlobalConfigModalButton"];
const _c1 = ["CheckGlobalConfigActiveDeactiveModalBtn"];
class GlobalConfigurationsComponent {
  constructor(systemAdmin, router) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.globalConfigs = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.globalConfigHeaders = [{
      JsonPropName: 'key',
      showName: 'Configuration Name'
    }, {
      JsonPropName: 'value',
      showName: 'Value'
    }];
  }
  ngOnInit() {
    this.globalConfigsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
    this.bindChange();
    this.loadGlobalConfigs();
  }
  loadGlobalConfigs() {
    this.systemAdmin.getGlobalConfigurations({}).subscribe(result => {
      this.globalConfigs.data = result.items;
      if (this.globalConfigs.data.length > 0) this.onGlobalConfigSelection(this.globalConfigs.data[0]);
    });
  }
  onGlobalConfigSelection(item) {
    this.selectedGlobalConfigId = item.globalConfigId;
    this.selectedGlobalConfig = item;
  }
  bindChange() {
    this.globalConfigsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchGlobalConfigs(change);
    });
  }
  onGlobalConfigStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "configuration");
    this.CheckGlobalConfigActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmGlobalConfigActiveDeactiveCahnge() {
    let ManufacOperation = new src_app_core_models_adminstration_GlobalConfigOperation__WEBPACK_IMPORTED_MODULE_2__.GlobalConfigOperation();
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.value = ManufacOperation.value;
    this.systemAdmin.globalConfigurationOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveGlobalConfigModalButton.nativeElement.click();
      }
    });
  }
  onCancelGlobalConfigActiveDeactiveChange() {
    this.loadGlobalConfigs();
  }
  updateSelectedGlobalConfig(item) {
    this.router.navigate(['system-admin/configurations/edit', item.configId]);
  }
  searchGlobalConfigs(searchValue) {
    this.systemAdmin.getGlobalConfigurations({
      containsText: searchValue
    }).subscribe(result => {
      this.globalConfigs.data = result.items;
    });
  }
  AddNewGlobalConfig() {
    this.router.navigate(['system-admin/configurations/new']);
  }
  static #_ = this.ɵfac = function GlobalConfigurationsComponent_Factory(t) {
    return new (t || GlobalConfigurationsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: GlobalConfigurationsComponent,
    selectors: [["app-global-configurations"]],
    viewQuery: function GlobalConfigurationsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveGlobalConfigModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckGlobalConfigActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 61,
    vars: 7,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveGlobalConfigModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#globalConfigConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckGlobalConfigActiveDeactiveModalBtn", ""], ["id", "globalConfigConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"]],
    template: function GlobalConfigurationsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13, " Global Configurations ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function GlobalConfigurationsComponent_Template_button_click_19_listener() {
          return ctx.AddNewGlobalConfig();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, " New Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Configuration Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function GlobalConfigurationsComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedGlobalConfig($event);
        })("selectItemEvent", function GlobalConfigurationsComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onGlobalConfigSelection($event);
        })("checkboxEvent", function GlobalConfigurationsComponent_Template_app_data_table_viewer_checkboxEvent_31_listener($event) {
          return ctx.onGlobalConfigStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](32, "button", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "div", 23)(35, "div", 24)(36, "div", 25)(37, "div", 26)(38, "h1", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](39, "img", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](41, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](42, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "div", 32)(45, "div", 33)(46, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](47, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "div", 34)(49, "div", 1)(50, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](51, "img", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](52, "div", 3)(53, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](54);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "br")(56, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](57, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function GlobalConfigurationsComponent_Template_button_click_57_listener() {
          return ctx.onCancelGlobalConfigActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](58, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function GlobalConfigurationsComponent_Template_button_click_59_listener() {
          return ctx.onConfirmGlobalConfigActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](60, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.globalConfigsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.globalConfigHeaders)("tblValues", ctx.globalConfigs)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedGlobalConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9nbG9iYWwtY29uZmlndXJhdGlvbnMvZ2xvYmFsLWNvbmZpZ3VyYXRpb25zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxVQUFVO0lBQ1YsaUJBQWlCO0FBQ3JCIiwic291cmNlc0NvbnRlbnQiOlsiLnNlYXJjaEJveHtcclxuICAgIHdpZHRoOiAyNSU7IFxyXG4gICAgbWFyZ2luLWJvdHRvbTogMSU7IFxyXG59IFxyXG4gXHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 38083:
/*!***********************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/lookups/lookup-operation/lookup-operation.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LookupOperationComponent": () => (/* binding */ LookupOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_systemLookupOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/systemLookupOperation */ 13269);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["modalButton"];
function LookupOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupOperationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupOperationComponent_button_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LookupOperationComponent_button_29_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.createUpdateSystemLookup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r3.lookupForm.valid);
  }
}
class LookupOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createLookupForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.lookupCode = +params['id'];
      if (this.lookupCode > 0) {
        this.loadLookup();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadLookup() {
    this.systemAdminService.getSystemLookups({
      lkCode: this.lookupCode
    }).subscribe(result => {
      this.lookupForm.patchValue(result.items[0]);
    });
  }
  createLookupForm() {
    this.lookupForm = this.fb.group({
      lkEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      prefix: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      lkAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
    });
  }
  createUpdateSystemLookup() {
    let lookupOperation = new src_app_core_models_adminstration_systemLookupOperation__WEBPACK_IMPORTED_MODULE_0__.systemLookupOperation();
    lookupOperation = this.lookupForm?.value;
    lookupOperation.operationType = this.operation;
    if (this.lookupCode > 0) lookupOperation.lkCode = this.lookupCode;
    this.systemAdminService.systemLookupsOperations(lookupOperation).subscribe(result => {
      if (result.items > 0) this.modalButton.nativeElement.click();
    });
  }
  backToLookupsList() {
    this.router.navigate(['system-admin/lookups']);
  }
  static #_ = this.ɵfac = function LookupOperationComponent_Factory(t) {
    return new (t || LookupOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: LookupOperationComponent,
    selectors: [["app-lookup-operation"]],
    viewQuery: function LookupOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.modalButton = _t.first);
      }
    },
    decls: 44,
    vars: 7,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "text", "formControlName", "lkEname", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "lkAname", 1, "form-control"], ["type", "text", "formControlName", "prefix", 1, "form-control"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["modalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function LookupOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "lookup Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, LookupOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "lookup Arabic Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, LookupOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "prefix * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, LookupOperationComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](29, LookupOperationComponent_button_29_Template, 2, 1, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "div", 19)(31, "button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LookupOperationComponent_Template_button_click_31_listener() {
          return ctx.backToLookupsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](32, "i", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](33, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](34, "button", 22, 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 24)(37, "div", 25)(38, "div", 26)(39, "div", 27)(40, "h1", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](41, "img", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](42);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](43, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.lookupForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Lookup ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupForm.get("lkEname").hasError("required") && ctx.lookupForm.get("lkEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupForm.get("lkAname").hasError("required") && ctx.lookupForm.get("lkAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupForm.get("prefix").hasError("required") && ctx.lookupForm.get("prefix").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9sb29rdXBzL2xvb2t1cC1vcGVyYXRpb24vbG9va3VwLW9wZXJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 45304:
/*!***************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/lookups/lookup-value/lookup-value.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LookupValueComponent": () => (/* binding */ LookupValueComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_lookupValueOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/lookupValueOperation */ 12157);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["modalButton"];
function LookupValueComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupValueComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupValueComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupValueComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LookupValueComponent_button_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LookupValueComponent_button_35_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r6.createUpdateSystemLookup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r4.lookupValueForm.valid);
  }
}
class LookupValueComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createLookupForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[1].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    this.route.params.subscribe(params => {
      this.lookupCode = +params['lookupId'];
      this.lookupValueCode = +params['lookupValueId'];
      if (this.lookupCode > 0 && this.lookupValueCode > 0) {
        this.loadLookupValue();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadLookupValue() {
    this.systemAdminService.getLookupValues({
      lkCode: this.lookupCode,
      lkCodeValue: this.lookupValueCode
    }).subscribe(result => {
      this.lookupValueForm.patchValue(result.items[0]);
    });
  }
  createLookupForm() {
    this.lookupValueForm = this.fb.group({
      lkCodeValue: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      lkValueEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      enabledFlag: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      lkValueAname: [null]
    });
  }
  createUpdateSystemLookup() {
    let lookupOperation = new src_app_core_models_adminstration_lookupValueOperation__WEBPACK_IMPORTED_MODULE_0__.lookupValueOperation();
    lookupOperation = this.lookupValueForm?.value;
    lookupOperation.operationType = this.operation;
    lookupOperation.enabledFlag = this.lookupValueForm?.value.enabledFlag ? 1 : 0;
    if (this.lookupCode > 0) lookupOperation.lkCode = this.lookupCode;
    this.systemAdminService.systemLookupValuesOperations(lookupOperation).subscribe(result => {
      if (result.items == 1) this.modalButton.nativeElement.click();
    });
  }
  backToLookupsList() {
    if (this.lookupCode > 0) this.router.navigate(['system-admin/lookups/' + this.lookupCode]);else this.router.navigate(['system-admin/lookups']);
  }
  static #_ = this.ɵfac = function LookupValueComponent_Factory(t) {
    return new (t || LookupValueComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: LookupValueComponent,
    selectors: [["app-lookup-value"]],
    viewQuery: function LookupValueComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.modalButton = _t.first);
      }
    },
    decls: 50,
    vars: 8,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "number", "formControlName", "lkCodeValue", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "lkValueEname", 1, "form-control"], ["type", "text", "formControlName", "lkValueAname", 1, "form-control"], [1, "form-check"], ["type", "checkbox", "formControlName", "enabledFlag", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["modalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function LookupValueComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Lookup Value * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, LookupValueComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Lookup Value Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, LookupValueComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, " Arabic Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, LookupValueComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 12)(29, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](30, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, " Active ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](33, LookupValueComponent_div_33_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](35, LookupValueComponent_button_35_Template, 2, 1, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 22)(37, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LookupValueComponent_Template_button_click_37_listener() {
          return ctx.backToLookupsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](38, "i", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](39, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](40, "button", 25, 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](42, "div", 27)(43, "div", 28)(44, "div", 29)(45, "div", 30)(46, "h1", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](47, "img", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](49, "button", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.lookupValueForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Lookup Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupValueForm.get("lkCodeValue").hasError("required") && ctx.lookupValueForm.get("lkCodeValue").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupValueForm.get("lkValueEname").hasError("required") && ctx.lookupValueForm.get("lkValueEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupValueForm.get("lkValueAname").hasError("required") && ctx.lookupValueForm.get("lkValueAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.lookupValueForm.get("enabledFlag").hasError("required") && ctx.lookupValueForm.get("enabledFlag").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9sb29rdXBzL2xvb2t1cC12YWx1ZS9sb29rdXAtdmFsdWUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyIub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 20462:
/*!*********************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/lookups/lookups.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LookupsComponent": () => (/* binding */ LookupsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_lookupValueOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/lookupValueOperation */ 12157);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);









const _c0 = ["saveLookupModalButton"];
const _c1 = ["CheckLookupActiveDeactiveModalBtn"];
class LookupsComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.loockups = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.loockupValues = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.loockupHeaders = [{
      JsonPropName: 'lkEname',
      showName: 'Lookup English Name'
    }, {
      JsonPropName: 'lkAname',
      showName: 'Lookup Arabic Name'
    }, {
      JsonPropName: 'prefix',
      showName: 'Prefix'
    }];
    this.loockupValuesHeaders = [{
      JsonPropName: 'lkCodeValue',
      showName: 'Lookup Value'
    }, {
      JsonPropName: 'lkValueEname',
      showName: 'Value Description'
    }, {
      JsonPropName: 'enabledFlag',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.createLookupSearchForm();
    this.bindChange();
    this.loadLookups();
  }
  createLookupSearchForm() {
    this.lookupsSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
  }
  loadLookups() {
    this.systemAdmin.getSystemLookups({}).subscribe(result => {
      this.loockups.data = result.items;
      if (this.loockups.data.length > 0) {
        if (this.recordSelectionId > 0) this.onLookupSelection(this.loockups.data.find(x => x.lkCode == this.recordSelectionId));else this.onLookupSelection(this.loockups.data[0]);
      }
    });
  }
  bindChange() {
    this.lookupsSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchLookups(change);
    });
  }
  viewSelectedLookup(item) {
    this.router.navigate(['system-admin/lookups/view', item.lkCode]);
  }
  onLookupValueStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "lookup value");
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
    this.CheckLookupActiveDeactiveModalBtn.nativeElement.click();
  }
  onConfirmLookupActiveDeactiveCahnge() {
    let lookupOperation = new src_app_core_models_adminstration_lookupValueOperation__WEBPACK_IMPORTED_MODULE_2__.lookupValueOperation();
    lookupOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    lookupOperation.updatedBy = this.checkedSelectedItem.updatedBy;
    lookupOperation.lkCodeValue = this.checkedSelectedItem.lkCodeValue;
    lookupOperation.lkValueAname = this.checkedSelectedItem.lkValueAname;
    lookupOperation.lkValueEname = this.checkedSelectedItem.lkValueEname;
    lookupOperation.enabledFlag = this.checkedSelectedItem.enabledFlag ? 1 : 0;
    if (this.SelectedlookupCode) lookupOperation.lkCode = +this.SelectedlookupCode;
    this.systemAdmin.systemLookupValuesOperations(lookupOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveLookupModalButton.nativeElement.click();
      }
    });
  }
  onCancelLookupActiveDeactiveChange() {
    this.loadLookups();
  }
  updateSelectedLookup(item) {
    this.router.navigate(['system-admin/lookups/edit', item.lkCode]);
  }
  updateSelectedLookupValue(item) {
    this.router.navigate(['system-admin/lookupValue/edit', item.lkCode, item.lkCodeValue]);
  }
  viewSelectedLookupValue(item) {
    this.router.navigate(['system-admin/lookupValue/view', item.lkCode, item.lkCodeValue]);
  }
  searchLookups(searchValue) {
    this.systemAdmin.getSystemLookups({
      containestext: searchValue
    }).subscribe(result => {
      this.loockups.data = result.items;
    });
  }
  AddNewLookup() {
    this.router.navigate(['system-admin/lookups/new']);
  }
  onLookupSelection(item) {
    this.selectedRow = item;
    this.lookupValueTitleName = item.lkEname;
    this.SelectedlookupCode = item.lkCode;
    this.systemAdmin.getLookupValues({
      lkCode: item.lkCode
    }).subscribe(result => {
      this.loockupValues.data = result.items;
    });
  }
  AddNewLookupValue() {
    this.router.navigate(['system-admin/lookupValue/new', this.SelectedlookupCode]);
  }
  static #_ = this.ɵfac = function LookupsComponent_Factory(t) {
    return new (t || LookupsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: LookupsComponent,
    selectors: [["app-lookups"]],
    viewQuery: function LookupsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.saveLookupModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckLookupActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 86,
    vars: 11,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "viewItemEvent", "selectItemEvent"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "updateItemEvent", "viewItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveLookupModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#lookupConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckLookupActiveDeactiveModalBtn", ""], ["id", "lookupConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"]],
    template: function LookupsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13, " System Lookups ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LookupsComponent_Template_button_click_19_listener() {
          return ctx.AddNewLookup();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, " Add Lookup ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Lookup Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function LookupsComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedLookup($event);
        })("viewItemEvent", function LookupsComponent_Template_app_data_table_viewer_viewItemEvent_31_listener($event) {
          return ctx.viewSelectedLookup($event);
        })("selectItemEvent", function LookupsComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onLookupSelection($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](32, "section", 0)(33, "div", 1)(34, "div", 2)(35, "div", 1)(36, "div", 2)(37, "div", 1)(38, "div", 3)(39, "div", 4)(40, "div", 5)(41, "div", 6)(42, "div", 7)(43, "h2", 8)(44, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "div", 22)(47, "div", 11)(48, "div", 12)(49, "div", 1)(50, "div", 13)(51, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LookupsComponent_Template_button_click_51_listener() {
          return ctx.AddNewLookupValue();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](52, " Add Lookup value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](53, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](54, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "app-data-table-viewer", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function LookupsComponent_Template_app_data_table_viewer_updateItemEvent_56_listener($event) {
          return ctx.updateSelectedLookupValue($event);
        })("viewItemEvent", function LookupsComponent_Template_app_data_table_viewer_viewItemEvent_56_listener($event) {
          return ctx.viewSelectedLookupValue($event);
        })("checkboxEvent", function LookupsComponent_Template_app_data_table_viewer_checkboxEvent_56_listener($event) {
          return ctx.onLookupValueStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](57, "button", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "div", 26)(60, "div", 27)(61, "div", 28)(62, "div", 29)(63, "h1", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](64, "img", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](65);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](66, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](67, "button", 33, 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](69, "div", 35)(70, "div", 36)(71, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](72, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](73, "div", 37)(74, "div", 1)(75, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](76, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](77, "div", 3)(78, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](79);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](80, "br")(81, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](82, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LookupsComponent_Template_button_click_82_listener() {
          return ctx.onCancelLookupActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](83, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](84, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LookupsComponent_Template_button_click_84_listener() {
          return ctx.onConfirmLookupActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](85, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.lookupsSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.loockupHeaders)("tblValues", ctx.loockups)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedRow);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.lookupValueTitleName, " lookup values ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.loockupValuesHeaders)("tblValues", ctx.loockupValues)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9sb29rdXBzL2xvb2t1cHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFVBQVU7SUFDVixpQkFBaUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VhcmNoQm94e1xyXG4gICAgd2lkdGg6IDI1JTsgXHJcbiAgICBtYXJnaW4tYm90dG9tOiAxJTsgXHJcbn0gXHJcbiBcclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 5715:
/*!*******************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/manufacturers/manufacturers-operation/manufacturers-operation.component.ts ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ManufacturersOperationComponent": () => (/* binding */ ManufacturersOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_ManufacturerOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/ManufacturerOperation */ 40421);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveManufacturerModalButton"];
function ManufacturersOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ManufacturersOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ManufacturersOperationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ManufacturersOperationComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ManufacturersOperationComponent_button_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ManufacturersOperationComponent_button_35_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r6.createUpdateManufacturer());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r4.manufacturerForm.valid);
  }
}
class ManufacturersOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createManufacturerForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.manufacturerId = +params['manufacturerId'];
      if (this.manufacturerId > 0) {
        this.loadManufacturer();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadManufacturer() {
    this.systemAdminService.getManufacturers({
      manufacturersId: this.manufacturerId
    }).subscribe(result => {
      this.manufacturerForm.patchValue(result.items[0]);
    });
  }
  createManufacturerForm() {
    this.manufacturerForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      manufacturersAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      manufacturersEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      moiCode: [null]
    });
  }
  createUpdateManufacturer() {
    let manufacturerOper = new src_app_core_models_adminstration_ManufacturerOperation__WEBPACK_IMPORTED_MODULE_0__.ManufacturerOperation();
    manufacturerOper = this.manufacturerForm?.value;
    manufacturerOper.status = this.manufacturerForm?.value.status ? 1 : 0;
    manufacturerOper.operationType = this.operation;
    if (this.manufacturerId > 0) manufacturerOper.manufacturersId = this.manufacturerId;
    this.systemAdminService.manufacturerOperations(manufacturerOper).subscribe(result => {
      if (result.items > 0) this.saveManufacturerModalButton.nativeElement.click();
    });
  }
  backToManufacturersList() {
    this.router.navigate(['system-admin/manufacturers']);
  }
  static #_ = this.ɵfac = function ManufacturersOperationComponent_Factory(t) {
    return new (t || ManufacturersOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ManufacturersOperationComponent,
    selectors: [["app-manufacturers-operation"]],
    viewQuery: function ManufacturersOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveManufacturerModalButton = _t.first);
      }
    },
    decls: 50,
    vars: 8,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "manufacturersEname", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "manufacturersAname", 1, "form-control"], ["type", "text", "formControlName", "moiCode", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveManufacturerModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function ManufacturersOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Manufacturer Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, ManufacturersOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Manufacturer Arabic Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, ManufacturersOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "MOI Code * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, ManufacturersOperationComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 17)(29, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](30, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](33, ManufacturersOperationComponent_div_33_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](35, ManufacturersOperationComponent_button_35_Template, 2, 1, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 23)(37, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ManufacturersOperationComponent_Template_button_click_37_listener() {
          return ctx.backToManufacturersList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](38, "i", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](39, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](40, "button", 26, 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](42, "div", 28)(43, "div", 29)(44, "div", 30)(45, "div", 31)(46, "h1", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](47, "img", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](49, "button", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.manufacturerForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Manufacturer ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.manufacturerForm.get("manufacturersEname").hasError("required") && ctx.manufacturerForm.get("manufacturersEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.manufacturerForm.get("manufacturersAname").hasError("required") && ctx.manufacturerForm.get("manufacturersAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.manufacturerForm.get("moiCode").hasError("required") && ctx.manufacturerForm.get("moiCode").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.manufacturerForm.get("status").hasError("required") && ctx.manufacturerForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9tYW51ZmFjdHVyZXJzL21hbnVmYWN0dXJlcnMtb3BlcmF0aW9uL21hbnVmYWN0dXJlcnMtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 77081:
/*!*********************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/manufacturers/manufacturers.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ManufacturersComponent": () => (/* binding */ ManufacturersComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_ModelOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/ModelOperation */ 16573);
/* harmony import */ var src_app_core_models_adminstration_ManufacturerOperation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/adminstration/ManufacturerOperation */ 40421);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);










const _c0 = ["saveManufacturerModalButton"];
const _c1 = ["CheckManufacturerActiveDeactiveModalBtn"];
const _c2 = ["CheckModelActiveDeactiveModalBtn"];
class ManufacturersComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.manufacturers = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.models = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.manufacturerHeaders = [{
      JsonPropName: 'manufacturersEname',
      showName: 'Manufacturer Name'
    }, {
      JsonPropName: 'manufacturersAname',
      showName: 'Manufacturer Arabic Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.modelsHeaders = [{
      JsonPropName: 'modelEname',
      showName: 'Model Name'
    }, {
      JsonPropName: 'modelAname',
      showName: 'Model Arabic Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.createManufactureSearchForm();
    this.bindChange();
    this.loadManufacturers();
  }
  createManufactureSearchForm() {
    this.manufacturersSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
  }
  loadManufacturers() {
    this.systemAdmin.getManufacturers({}).subscribe(result => {
      this.manufacturers.data = result.items;
      this.manufacturers.data.sort();
      if (this.manufacturers.data.length > 0) {
        if (this.recordSelectionId > 0) this.onManufacturerSelection(this.manufacturers.data.find(x => x.manufacturersId == this.recordSelectionId));else this.onManufacturerSelection(this.manufacturers.data[0]);
      }
    });
  }
  bindChange() {
    this.manufacturersSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchManufacturers(change);
    });
  }
  viewSelectedManufacturer(item) {
    this.router.navigate(['system-admin/manufacturers/view', item.lkCode]);
  }
  onModelStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "model");
    this.CheckModelActiveDeactiveModalBtn.nativeElement.click();
  }
  onManufacturerStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "manufacturer");
    this.CheckManufacturerActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmManufacturerActiveDeactiveCahnge() {
    let ManufacOperation = new src_app_core_models_adminstration_ManufacturerOperation__WEBPACK_IMPORTED_MODULE_3__.ManufacturerOperation();
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.manufacturerOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveManufacturerModalButton.nativeElement.click();
      }
    });
  }
  onCancelManufacturerActiveDeactiveChange() {
    this.loadManufacturers();
  }
  onConfirmModelActiveDeactiveCahnge() {
    let modelOperation = new src_app_core_models_adminstration_ModelOperation__WEBPACK_IMPORTED_MODULE_2__.ModelOperation();
    modelOperation = this.checkedSelectedItem;
    modelOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    modelOperation.status = modelOperation.status ? 1 : 0;
    this.systemAdmin.vehicleModelOperations(modelOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveManufacturerModalButton.nativeElement.click();
      }
    });
  }
  onCancelModelActiveDeactiveChange() {
    this.loadManufatureModels();
  }
  loadManufatureModels() {
    this.systemAdmin.getVehicleModels({
      manufacturersId: this.selectedManufacturerId
    }).subscribe(result => {
      this.models.data = result.items;
    });
  }
  updateSelectedManufacturer(item) {
    this.router.navigate(['system-admin/manufacturers/edit', item.manufacturersId]);
  }
  updateSelectedModel(item) {
    this.router.navigate(['system-admin/models/edit', item.manufacturersId, item.modelId]);
  }
  viewSelectedModel(item) {
    //this.router.navigate(['system-admin/model/view', item.manufacturerId, item.lkCodeValue])
  }
  searchManufacturers(searchValue) {
    this.systemAdmin.getManufacturers({
      containsText: searchValue
    }).subscribe(result => {
      this.manufacturers.data = result.items;
    });
  }
  AddNewManufacturer() {
    this.router.navigate(['system-admin/manufacturers/new']);
  }
  onManufacturerSelection(item) {
    this.selectedRecord = item;
    this.modelTitleName = item.manufacturersEname;
    this.selectedManufacturerId = item.manufacturersId;
    this.systemAdmin.getVehicleModels({
      manufacturersId: item.manufacturersId
    }).subscribe(result => {
      this.models.data = result.items;
    });
  }
  AddNewModel() {
    this.router.navigate(['system-admin/models/new', this.selectedManufacturerId]);
  }
  static #_ = this.ɵfac = function ManufacturersComponent_Factory(t) {
    return new (t || ManufacturersComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: ManufacturersComponent,
    selectors: [["app-manufacturers"]],
    viewQuery: function ManufacturersComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.saveManufacturerModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckManufacturerActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckModelActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 105,
    vars: 12,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "viewItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "updateItemEvent", "viewItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveManufacturerModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#manufacturerConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckManufacturerActiveDeactiveModalBtn", ""], ["id", "manufacturerConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#modelConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckModelActiveDeactiveModalBtn", ""], ["id", "modelConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"]],
    template: function ManufacturersComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](13, " Manufacturers ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ManufacturersComponent_Template_button_click_19_listener() {
          return ctx.AddNewManufacturer();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](20, " Add Manufacturer ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, "Manufacturer Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function ManufacturersComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedManufacturer($event);
        })("viewItemEvent", function ManufacturersComponent_Template_app_data_table_viewer_viewItemEvent_31_listener($event) {
          return ctx.viewSelectedManufacturer($event);
        })("selectItemEvent", function ManufacturersComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onManufacturerSelection($event);
        })("checkboxEvent", function ManufacturersComponent_Template_app_data_table_viewer_checkboxEvent_31_listener($event) {
          return ctx.onManufacturerStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](32, "section", 0)(33, "div", 1)(34, "div", 2)(35, "div", 1)(36, "div", 2)(37, "div", 1)(38, "div", 3)(39, "div", 4)(40, "div", 5)(41, "div", 6)(42, "div", 7)(43, "h2", 8)(44, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](46, "div", 22)(47, "div", 11)(48, "div", 12)(49, "div", 1)(50, "div", 13)(51, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ManufacturersComponent_Template_button_click_51_listener() {
          return ctx.AddNewModel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](52, " Add Model ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](53, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](54, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](55, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](56, "app-data-table-viewer", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function ManufacturersComponent_Template_app_data_table_viewer_updateItemEvent_56_listener($event) {
          return ctx.updateSelectedModel($event);
        })("viewItemEvent", function ManufacturersComponent_Template_app_data_table_viewer_viewItemEvent_56_listener($event) {
          return ctx.viewSelectedModel($event);
        })("checkboxEvent", function ManufacturersComponent_Template_app_data_table_viewer_checkboxEvent_56_listener($event) {
          return ctx.onModelStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](57, "button", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](59, "div", 26)(60, "div", 27)(61, "div", 28)(62, "div", 29)(63, "h1", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](64, "img", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](65);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](66, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](67, "button", 33, 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](69, "div", 35)(70, "div", 36)(71, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](72, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](73, "div", 37)(74, "div", 1)(75, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](76, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](77, "div", 3)(78, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](79);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](80, "br")(81, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](82, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ManufacturersComponent_Template_button_click_82_listener() {
          return ctx.onCancelManufacturerActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](83, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](84, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ManufacturersComponent_Template_button_click_84_listener() {
          return ctx.onConfirmManufacturerActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](85, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](86, "button", 42, 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](88, "div", 44)(89, "div", 36)(90, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](91, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](92, "div", 37)(93, "div", 1)(94, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](95, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](96, "div", 3)(97, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](98);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](99, "br")(100, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](101, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ManufacturersComponent_Template_button_click_101_listener() {
          return ctx.onCancelModelActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](102, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](103, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ManufacturersComponent_Template_button_click_103_listener() {
          return ctx.onConfirmModelActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](104, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.manufacturersSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.manufacturerHeaders)("tblValues", ctx.manufacturers)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedRecord);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.modelTitleName, " models ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.modelsHeaders)("tblValues", ctx.models)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9tYW51ZmFjdHVyZXJzL21hbnVmYWN0dXJlcnMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFVBQVU7SUFDVixpQkFBaUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VhcmNoQm94e1xyXG4gICAgd2lkdGg6IDI1JTsgXHJcbiAgICBtYXJnaW4tYm90dG9tOiAxJTsgXHJcbn0gXHJcbiBcclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 85369:
/*!*********************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/manufacturers/models/models.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModelsComponent": () => (/* binding */ ModelsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_ModelOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/ModelOperation */ 16573);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveModelModalButton"];
function ModelsComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModelsComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModelsComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModelsComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModelsComponent_button_35_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ModelsComponent_button_35_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r6.createUpdateModel());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r4.modelForm.valid);
  }
}
class ModelsComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createModelForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[1].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    this.route.params.subscribe(params => {
      this.modelId = +params['modelId'];
      this.manufacturerId = +params['manufacturerId'];
      if (this.modelId > 0 && this.manufacturerId > 0) {
        this.loadModel();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadModel() {
    this.systemAdminService.getVehicleModels({
      modelId: this.modelId
    }).subscribe(result => {
      this.modelForm.patchValue(result.items[0]);
    });
  }
  createModelForm() {
    this.modelForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      modelAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      modelEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      moiModelCode: [null]
    });
  }
  createUpdateModel() {
    let modelOper = new src_app_core_models_adminstration_ModelOperation__WEBPACK_IMPORTED_MODULE_0__.ModelOperation();
    modelOper = this.modelForm?.value;
    modelOper.status = this.modelForm?.value.status ? 1 : 0;
    modelOper.manufacturersId = this.manufacturerId;
    modelOper.operationType = this.operation;
    if (this.modelId > 0) modelOper.modelId = this.modelId;
    this.systemAdminService.vehicleModelOperations(modelOper).subscribe(result => {
      if (result.items > 0) this.saveModelModalButton.nativeElement.click();
    });
  }
  backToModelsList() {
    console.log(this.manufacturerId);
    if (this.manufacturerId > 1) this.router.navigate(['system-admin/manufacturers/' + this.manufacturerId]);else this.router.navigate(['system-admin/manufacturers']);
  }
  static #_ = this.ɵfac = function ModelsComponent_Factory(t) {
    return new (t || ModelsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ModelsComponent,
    selectors: [["app-models"]],
    viewQuery: function ModelsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveModelModalButton = _t.first);
      }
    },
    decls: 50,
    vars: 8,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "modelEname", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "modelAname", 1, "form-control"], ["type", "text", "formControlName", "moiModelCode", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveModelModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function ModelsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Model Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, ModelsComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Model Arabic Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, ModelsComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "MOI Code * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, ModelsComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 17)(29, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](30, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](33, ModelsComponent_div_33_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](35, ModelsComponent_button_35_Template, 2, 1, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 23)(37, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ModelsComponent_Template_button_click_37_listener() {
          return ctx.backToModelsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](38, "i", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](39, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](40, "button", 26, 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](42, "div", 28)(43, "div", 29)(44, "div", 30)(45, "div", 31)(46, "h1", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](47, "img", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](48);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](49, "button", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.modelForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Model ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.modelForm.get("modelEname").hasError("required") && ctx.modelForm.get("modelEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.modelForm.get("modelAname").hasError("required") && ctx.modelForm.get("modelAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.modelForm.get("moiModelCode").hasError("required") && ctx.modelForm.get("moiModelCode").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.modelForm.get("status").hasError("required") && ctx.modelForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9tYW51ZmFjdHVyZXJzL21vZGVscy9tb2RlbHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0FBQ25COztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7QUFDaEIiLCJzb3VyY2VzQ29udGVudCI6WyIub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 41578:
/*!********************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/moddules/entities/entities.component.ts ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EntitiesComponent": () => (/* binding */ EntitiesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_EntityOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/EntityOperation */ 6524);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);










const _c0 = ["saveEntityModalButton"];
function EntitiesComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function EntitiesComponent_option_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", type_r9.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", type_r9.lkValueEname, " ");
  }
}
function EntitiesComponent_div_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function EntitiesComponent_div_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function EntitiesComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function EntitiesComponent_div_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function EntitiesComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function EntitiesComponent_button_48_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function EntitiesComponent_button_48_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r10.createUpdateEntity());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !ctx_r7.entityForm.valid);
  }
}
class EntitiesComponent {
  constructor(fb, route, lookupService, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.lookupService = lookupService;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.entityTypes = [];
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createEntityForm();
    this.getEntityTypes();
  }
  getEntityTypes() {
    this.lookupService.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.entityType).subscribe(response => {
      this.entityTypes = response.items;
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[1].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    this.route.params.subscribe(params => {
      this.entityId = +params['entityId'];
      this.moduleId = +params['moduleId'];
      if (this.entityId > 0 && this.moduleId > 0) {
        this.loadEntity();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadEntity() {
    this.systemAdminService.getSystemEntityDef({
      entityId: this.entityId,
      moduleId: this.moduleId
    }).subscribe(result => {
      this.report = result.items[0];
      this.entityForm.patchValue(result.items[0]);
    });
  }
  createEntityForm() {
    this.entityForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      entityAdesc: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      entityName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      entityEdesc: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      entityType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      //reportFolderName: [null],
      //reportPath: [null],
      pageName: [null]
    });
  }
  createUpdateEntity() {
    let entityOper = new src_app_core_models_adminstration_EntityOperation__WEBPACK_IMPORTED_MODULE_0__.EntityOperation();
    entityOper = this.entityForm?.value;
    entityOper.status = this.entityForm?.value.status ? 1 : 0;
    entityOper.moduleId = this.moduleId;
    entityOper.reportFolderName = this.report?.reportFolderName;
    entityOper.reportPath = this.report?.reportPath;
    entityOper.operationType = this.operation;
    if (this.entityId > 0) entityOper.entityId = this.entityId;
    this.systemAdminService.entityOperations(entityOper).subscribe(result => {
      if (result.items > 0) this.saveEntityModalButton.nativeElement.click();
    });
  }
  backToEntitysList() {
    if (this.moduleId > 0) this.router.navigate(['system-admin/modules/' + this.moduleId]);else this.router.navigate(['system-admin/modules']);
  }
  static #_ = this.ɵfac = function EntitiesComponent_Factory(t) {
    return new (t || EntitiesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: EntitiesComponent,
    selectors: [["app-entities"]],
    viewQuery: function EntitiesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.saveEntityModalButton = _t.first);
      }
    },
    decls: 63,
    vars: 12,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "entityName", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["name", "ownerType", "formControlName", "entityType", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["type", "text", "formControlName", "entityEdesc", 1, "form-control"], ["type", "text", "formControlName", "entityAdesc", 1, "form-control"], ["type", "text", "formControlName", "pageName", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveEntityModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], [3, "value"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function EntitiesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, "Entity Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](17, EntitiesComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, "Entity Type *");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "select", 15)(22, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](23, "Select Type --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, EntitiesComponent_option_24_Template, 2, 2, "option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, EntitiesComponent_div_25_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 12)(27, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Entity Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](29, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, EntitiesComponent_div_30_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 12)(32, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33, "Entity Arabic Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](34, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](35, EntitiesComponent_div_35_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "div", 12)(37, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](38, "Page Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](39, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](40, EntitiesComponent_div_40_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](41, "div", 21)(42, "div", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](43, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "label", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](45, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](46, EntitiesComponent_div_46_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](47, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](48, EntitiesComponent_button_48_Template, 2, 1, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](49, "div", 27)(50, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function EntitiesComponent_Template_button_click_50_listener() {
          return ctx.backToEntitysList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](51, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](52, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](53, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](55, "div", 32)(56, "div", 33)(57, "div", 34)(58, "div", 35)(59, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](60, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](61);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](62, "button", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.entityForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.title, " Entity ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.entityForm.get("entityName").hasError("required") && ctx.entityForm.get("entityName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.entityTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.entityForm.get("entityType").hasError("required") && ctx.entityForm.get("entityType").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.entityForm.get("entityEdesc").hasError("required") && ctx.entityForm.get("entityEdesc").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.entityForm.get("entityAdesc").hasError("required") && ctx.entityForm.get("entityAdesc").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.entityForm.get("pageName").hasError("required") && ctx.entityForm.get("pageName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.entityForm.get("status").hasError("required") && ctx.entityForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9tb2RkdWxlcy9lbnRpdGllcy9lbnRpdGllcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 26934:
/*!**************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/moddules/moddule-operation/moddule-operation.component.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModduleOperationComponent": () => (/* binding */ ModduleOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_ModuleOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/ModuleOperation */ 22516);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveModuleModalButton"];
function ModduleOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModduleOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModduleOperationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModduleOperationComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModduleOperationComponent_div_38_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModduleOperationComponent_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ModduleOperationComponent_button_45_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ModduleOperationComponent_button_45_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r8.createUpdateModule());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r6.moduleForm.valid);
  }
}
class ModduleOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createModuleForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.moduleId = +params['moduleId'];
      if (this.moduleId > 0) {
        this.loadModule();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadModule() {
    this.systemAdminService.getModules({
      moduleId: this.moduleId
    }).subscribe(result => {
      this.moduleForm.patchValue(result.items[0]);
    });
  }
  createModuleForm() {
    this.moduleForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      moduleAName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      moduleEName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      moduleDescription: [null],
      order: [null],
      iconName: [null]
    });
  }
  createUpdateModule() {
    let moduleOper = new src_app_core_models_adminstration_ModuleOperation__WEBPACK_IMPORTED_MODULE_0__.ModuleOperation();
    moduleOper = this.moduleForm?.value;
    moduleOper.status = this.moduleForm?.value.status ? 1 : 0;
    moduleOper.operationType = this.operation;
    if (this.moduleId > 0) moduleOper.moduleId = this.moduleId;
    this.systemAdminService.moduleOperations(moduleOper).subscribe(result => {
      if (result.items > 0) this.saveModuleModalButton.nativeElement.click();
    });
  }
  backToModulesList() {
    this.router.navigate(['system-admin/modules']);
  }
  static #_ = this.ɵfac = function ModduleOperationComponent_Factory(t) {
    return new (t || ModduleOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ModduleOperationComponent,
    selectors: [["app-moddule-operation"]],
    viewQuery: function ModduleOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveModuleModalButton = _t.first);
      }
    },
    decls: 60,
    vars: 10,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "moduleEName", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "moduleAName", 1, "form-control"], ["type", "text", "formControlName", "moduleDescription", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], ["type", "number", "formControlName", "order", 1, "form-control"], ["type", "text", "formControlName", "iconName", 1, "form-control"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveModuleModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function ModduleOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Module Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, ModduleOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Module Arabic Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, ModduleOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "Module Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, ModduleOperationComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 17)(29, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](30, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "label", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](32, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](33, ModduleOperationComponent_div_33_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "div", 12)(35, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](36, "Order");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](37, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](38, ModduleOperationComponent_div_38_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "div", 12)(40, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](41, "Icon Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](43, ModduleOperationComponent_div_43_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](45, ModduleOperationComponent_button_45_Template, 2, 1, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "div", 25)(47, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ModduleOperationComponent_Template_button_click_47_listener() {
          return ctx.backToModulesList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](48, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](49, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](50, "button", 28, 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](52, "div", 30)(53, "div", 31)(54, "div", 32)(55, "div", 33)(56, "h1", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](57, "img", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](58);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](59, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.moduleForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Module ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.moduleForm.get("moduleEName").hasError("required") && ctx.moduleForm.get("moduleEName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.moduleForm.get("moduleAName").hasError("required") && ctx.moduleForm.get("moduleAName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.moduleForm.get("moduleDescription").hasError("required") && ctx.moduleForm.get("moduleDescription").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.moduleForm.get("status").hasError("required") && ctx.moduleForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.moduleForm.get("order").hasError("required") && ctx.moduleForm.get("order").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.moduleForm.get("iconName").hasError("required") && ctx.moduleForm.get("iconName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9tb2RkdWxlcy9tb2RkdWxlLW9wZXJhdGlvbi9tb2RkdWxlLW9wZXJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 76410:
/*!***********************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/moddules/moddules.component.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModdulesComponent": () => (/* binding */ ModdulesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_EntityOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/EntityOperation */ 6524);
/* harmony import */ var src_app_core_models_adminstration_ModuleOperation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/adminstration/ModuleOperation */ 22516);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);










const _c0 = ["saveModuleModalButton"];
const _c1 = ["CheckModuleActiveDeactiveModalBtn"];
const _c2 = ["CheckEntityActiveDeactiveModalBtn"];
class ModdulesComponent {
  constructor(systemAdmin, router, route) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.route = route;
    this.modules = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.entities = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.moduleHeaders = [{
      JsonPropName: 'moduleEName',
      showName: 'Module Name'
    }, {
      JsonPropName: 'moduleAName',
      showName: 'Module Arabic Name'
    }, {
      JsonPropName: 'moduleDescription',
      showName: 'Description'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.entitiesHeaders = [{
      JsonPropName: 'entityName',
      showName: 'Entity Name'
    }, {
      JsonPropName: 'entityEdesc',
      showName: 'Description'
    }, {
      JsonPropName: 'entityTypeName',
      showName: 'Entity Type'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.recordSelectionId = +params['selectionId'];
    });
    this.createModuleForms();
    this.bindChange();
    this.loadModules();
  }
  createModuleForms() {
    this.modulesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
    this.entitiesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
  }
  loadModules() {
    this.systemAdmin.getModules({}).subscribe(result => {
      this.modules.data = result.items;
      if (this.modules.data.length > 0) {
        if (this.recordSelectionId > 0) this.onModuleSelection(this.modules.data.find(x => x.moduleId == this.recordSelectionId));else this.onModuleSelection(this.modules.data[0]);
      }
    });
  }
  bindChange() {
    this.modulesSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchModules(change);
    });
    this.entitiesSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchModuleEntities(change);
    });
  }
  onEntityStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "entity");
    this.CheckEntityActiveDeactiveModalBtn.nativeElement.click();
  }
  onModuleStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "module");
    this.CheckModuleActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmModuleActiveDeactiveCahnge() {
    let ManufacOperation = new src_app_core_models_adminstration_ModuleOperation__WEBPACK_IMPORTED_MODULE_3__.ModuleOperation();
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.moduleOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveModuleModalButton.nativeElement.click();
      }
    });
  }
  onCancelModuleActiveDeactiveChange() {
    this.loadModules();
  }
  onConfirmEntityActiveDeactiveCahnge() {
    let entityOperation = new src_app_core_models_adminstration_EntityOperation__WEBPACK_IMPORTED_MODULE_2__.EntityOperation();
    entityOperation = this.checkedSelectedItem;
    entityOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    entityOperation.status = entityOperation.status ? 1 : 0;
    this.systemAdmin.entityOperations(entityOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.saveModuleModalButton.nativeElement.click();
      }
    });
  }
  onCancelEntityActiveDeactiveChange() {
    this.loadModuleEntities();
  }
  loadModuleEntities() {
    this.systemAdmin.getSystemEntityDef({
      moduleId: this.selectedModuleId
    }).subscribe(result => {
      this.entities.data = result.items;
    });
  }
  updateSelectedModule(item) {
    this.router.navigate(['system-admin/modules/edit', item.moduleId]);
  }
  updateSelectedEntity(item) {
    this.router.navigate(['system-admin/entities/edit', item.moduleId, item.entityId]);
  }
  viewSelectedEntity(item) {
    //this.router.navigate(['system-admin/entity/view', item.moduleId, item.lkCodeValue])
  }
  searchModules(searchValue) {
    this.systemAdmin.getModules({
      containsText: searchValue
    }).subscribe(result => {
      this.modules.data = result.items;
    });
  }
  searchModuleEntities(searchValue) {
    this.systemAdmin.getSystemEntityDef({
      moduleId: this.selectedModuleId,
      containsText: searchValue
    }).subscribe(result => {
      this.entities.data = result.items;
    });
  }
  AddNewModule() {
    this.router.navigate(['system-admin/modules/new']);
  }
  onModuleSelection(item) {
    this.entityTitleName = item.moduleEName;
    this.selectedModuleId = item.moduleId;
    this.selectedModule = item;
    this.systemAdmin.getSystemEntityDef({
      moduleId: item.moduleId
    }).subscribe(result => {
      this.entities.data = result.items;
    });
  }
  AddNewEntity() {
    this.router.navigate(['system-admin/entities/new', this.selectedModuleId]);
  }
  static #_ = this.ɵfac = function ModdulesComponent_Factory(t) {
    return new (t || ModdulesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_4__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: ModdulesComponent,
    selectors: [["app-moddules"]],
    viewQuery: function ModdulesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.saveModuleModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckModuleActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.CheckEntityActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 112,
    vars: 13,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "updateItemEvent", "viewItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveModuleModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#moduleConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckModuleActiveDeactiveModalBtn", ""], ["id", "moduleConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#entityConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckEntityActiveDeactiveModalBtn", ""], ["id", "entityConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"]],
    template: function ModdulesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](13, " Modules ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ModdulesComponent_Template_button_click_19_listener() {
          return ctx.AddNewModule();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](20, " Add Module ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28, "Module Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function ModdulesComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedModule($event);
        })("selectItemEvent", function ModdulesComponent_Template_app_data_table_viewer_selectItemEvent_31_listener($event) {
          return ctx.onModuleSelection($event);
        })("checkboxEvent", function ModdulesComponent_Template_app_data_table_viewer_checkboxEvent_31_listener($event) {
          return ctx.onModuleStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](32, "section", 0)(33, "div", 1)(34, "div", 2)(35, "div", 1)(36, "div", 2)(37, "div", 1)(38, "div", 3)(39, "div", 4)(40, "div", 5)(41, "div", 6)(42, "div", 7)(43, "h2", 8)(44, "button", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](45);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](46, "div", 22)(47, "div", 11)(48, "div", 12)(49, "div", 1)(50, "div", 13)(51, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ModdulesComponent_Template_button_click_51_listener() {
          return ctx.AddNewEntity();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](52, " Add Entity ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](53, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](54, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](55, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](56, "form", 17)(57, "div", 1)(58, "div", 16)(59, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](60, "Entity Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](61, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](62, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](63, "app-data-table-viewer", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("updateItemEvent", function ModdulesComponent_Template_app_data_table_viewer_updateItemEvent_63_listener($event) {
          return ctx.updateSelectedEntity($event);
        })("viewItemEvent", function ModdulesComponent_Template_app_data_table_viewer_viewItemEvent_63_listener($event) {
          return ctx.viewSelectedEntity($event);
        })("checkboxEvent", function ModdulesComponent_Template_app_data_table_viewer_checkboxEvent_63_listener($event) {
          return ctx.onEntityStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](64, "button", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](66, "div", 26)(67, "div", 27)(68, "div", 28)(69, "div", 29)(70, "h1", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](71, "img", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](72);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](73, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](74, "button", 33, 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](76, "div", 35)(77, "div", 36)(78, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](79, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](80, "div", 37)(81, "div", 1)(82, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](83, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](84, "div", 3)(85, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](86);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](87, "br")(88, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](89, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ModdulesComponent_Template_button_click_89_listener() {
          return ctx.onCancelModuleActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](90, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](91, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ModdulesComponent_Template_button_click_91_listener() {
          return ctx.onConfirmModuleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](92, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](93, "button", 42, 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](95, "div", 44)(96, "div", 36)(97, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](98, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](99, "div", 37)(100, "div", 1)(101, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](102, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](103, "div", 3)(104, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](105);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](106, "br")(107, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](108, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ModdulesComponent_Template_button_click_108_listener() {
          return ctx.onCancelEntityActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](109, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](110, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function ModdulesComponent_Template_button_click_110_listener() {
          return ctx.onConfirmEntityActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](111, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.modulesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.moduleHeaders)("tblValues", ctx.modules)("isDeleteOperationEnabled", false)("selectedRow", ctx.selectedModule);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.entityTitleName, " Entities ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.entitiesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("tblHeaders", ctx.entitiesHeaders)("tblValues", ctx.entities)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_5__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9tb2RkdWxlcy9tb2RkdWxlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksVUFBVTtJQUNWLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2hCb3h7XHJcbiAgICB3aWR0aDogMjUlOyBcclxuICAgIG1hcmdpbi1ib3R0b206IDElOyBcclxufSBcclxuIFxyXG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 75082:
/*!****************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/pos-terminal/pos-terminal-operation/pos-terminal-operation.component.ts ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PosTerminalOperationComponent": () => (/* binding */ PosTerminalOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_POSOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/POSOperation */ 58049);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);









const _c0 = ["savePOSModalButton"];
function PosTerminalOperationComponent_option_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const station_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", station_r11.stationId);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", station_r11.stationNameEn, " ");
  }
}
function PosTerminalOperationComponent_option_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const booth_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", booth_r12.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", booth_r12.description, " ");
  }
}
function PosTerminalOperationComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_div_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_div_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_div_51_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_div_62_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function PosTerminalOperationComponent_button_64_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function PosTerminalOperationComponent_button_64_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r13.createUpdatePOS());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx_r9.posForm.valid);
  }
}
class PosTerminalOperationComponent {
  constructor(fb, route, systemAdmin, router, lookupService) {
    this.fb = fb;
    this.route = route;
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.lookupService = lookupService;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
    this.stations = [];
    this.booths = [];
    this.lanes = [];
    this.sections = [];
    this.clientTypes = [];
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createPOSForm();
    this.bindChange();
    this.loadStations();
  }
  bindChange() {
    this.posForm.controls.stationId.valueChanges.subscribe(res => {
      this.selectedStationId = res;
      this.loadBooths(res);
    });
  }
  loadStations() {
    this.systemAdmin.getStations({}).subscribe(result => {
      this.stations = result.items;
    });
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.posId = +params['posId'];
      if (this.posId > 0) {
        this.loadPOS();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadPOS() {
    this.systemAdmin.getPosTerminalDef({
      posId: this.posId
    }).subscribe(result => {
      this.posForm.patchValue(result.items[0]);
    });
  }
  loadBooths(stationId = null) {
    this.systemAdmin.getBooths({
      stationId: stationId
    }).subscribe(result => {
      this.booths = result.items;
    });
  }
  createPOSForm() {
    this.posForm = this.fb.group({
      boothId: [null],
      authCode: [null],
      distinationIpAddress: [null],
      port: [null],
      posIpAddress: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      serialNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      stationId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      targetTerminal: [null],
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }
  createUpdatePOS() {
    let posOper = new src_app_core_models_adminstration_POSOperation__WEBPACK_IMPORTED_MODULE_0__.POSOperation();
    posOper = this.posForm?.value;
    posOper.status = this.posForm?.value.status ? 1 : 0;
    posOper.operationType = this.operation;
    if (this.posId > 0) posOper.posId = this.posId;
    this.systemAdmin.posTerminalDefOperations(posOper).subscribe(result => {
      if (result.items > 0) this.savePOSModalButton.nativeElement.click();
    });
  }
  backToPOSsList() {
    this.router.navigate(['system-admin/POS']);
  }
  static #_ = this.ɵfac = function PosTerminalOperationComponent_Factory(t) {
    return new (t || PosTerminalOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: PosTerminalOperationComponent,
    selectors: [["app-pos-terminal-operation"]],
    viewQuery: function PosTerminalOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.savePOSModalButton = _t.first);
      }
    },
    decls: 79,
    vars: 15,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3"], ["formControlName", "stationId", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["formControlName", "boothId", 1, "form-control"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "posIpAddress", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "serialNo", 1, "form-control"], ["type", "text", "formControlName", "distinationIpAddress", 1, "form-control"], ["type", "number", "formControlName", "port", 1, "form-control"], ["type", "text", "formControlName", "authCode", 1, "form-control"], ["type", "text", "formControlName", "targetTerminal", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["savePOSModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [3, "value"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function PosTerminalOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, "Station *");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "select", 13)(17, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Select Station--");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, PosTerminalOperationComponent_option_19_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "div", 12)(21, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "Booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "select", 16)(24, "option", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, "Select Booth--");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](26, PosTerminalOperationComponent_option_26_Template, 2, 2, "option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "div", 17)(28, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29, "POS IP Address * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](30, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](31, PosTerminalOperationComponent_div_31_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "div", 17)(33, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34, "Serial No. * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](35, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](36, PosTerminalOperationComponent_div_36_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "div", 17)(38, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](39, "Distination IP Address ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](40, "input", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](41, PosTerminalOperationComponent_div_41_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](42, "div", 17)(43, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](44, "Port ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](45, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](46, PosTerminalOperationComponent_div_46_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](47, "div", 17)(48, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](49, "Auth Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](50, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](51, PosTerminalOperationComponent_div_51_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](52, "div", 17)(53, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](54, "Target Terminal ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](55, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](56, PosTerminalOperationComponent_div_56_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](57, "div", 25)(58, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](59, "input", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](60, "label", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](61, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](62, PosTerminalOperationComponent_div_62_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](63, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](64, PosTerminalOperationComponent_button_64_Template, 2, 1, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](65, "div", 31)(66, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function PosTerminalOperationComponent_Template_button_click_66_listener() {
          return ctx.backToPOSsList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](67, "i", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](68, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](69, "button", 34, 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](71, "div", 36)(72, "div", 37)(73, "div", 38)(74, "div", 39)(75, "h1", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](76, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](77);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](78, "button", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx.posForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx.title, " Client ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.stations);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.booths);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("posIpAddress").hasError("required") && ctx.posForm.get("posIpAddress").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("serialNo").hasError("required") && ctx.posForm.get("serialNo").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("distinationIpAddress").hasError("required") && ctx.posForm.get("distinationIpAddress").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("port").hasError("required") && ctx.posForm.get("port").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("authCode").hasError("required") && ctx.posForm.get("authCode").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("targetTerminal").hasError("required") && ctx.posForm.get("targetTerminal").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.posForm.get("status").hasError("required") && ctx.posForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9wb3MtdGVybWluYWwvcG9zLXRlcm1pbmFsLW9wZXJhdGlvbi9wb3MtdGVybWluYWwtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 28505:
/*!*******************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/pos-terminal/pos-terminal.component.ts ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PosTerminalComponent": () => (/* binding */ PosTerminalComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_POSOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/POSOperation */ 58049);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);










const _c0 = ["savePOSModalButton"];
const _c1 = ["CheckPOSActiveDeactiveModalBtn"];
function PosTerminalComponent_option_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const station_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("value", station_r4.stationId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", station_r4.stationNameEn, " ");
  }
}
function PosTerminalComponent_option_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const booth_r5 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("disabled", !(ctx_r1.posSearchForm.controls.stationId == null ? null : ctx_r1.posSearchForm.controls.stationId.value))("value", booth_r5.boothId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", booth_r5.description, " ");
  }
}
class PosTerminalComponent {
  constructor(systemAdmin, router) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.pos = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.posHeaders = [{
      JsonPropName: 'serialNo',
      showName: 'Serial No'
    }, {
      JsonPropName: 'posipAddress',
      showName: 'POS IP Address'
    }, {
      JsonPropName: 'targetTerminal',
      showName: 'Target Terminal'
    }, {
      JsonPropName: 'stationNameEn',
      showName: 'Station Name'
    }, {
      JsonPropName: 'boothName',
      showName: 'Booth Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.plateTypes = [];
    this.stations = [];
    this.booths = [];
  }
  ngOnInit() {
    this.createPOSserchForm();
    this.bindChange();
    this.loadPOSTerminals();
    this.loadStations();
  }
  createPOSserchForm() {
    this.posSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroup({
      stationId: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null),
      boothId: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControl(null)
    });
  }
  loadStations() {
    this.systemAdmin.getStations({}).subscribe(result => {
      this.stations = result.items;
    });
  }
  loadBooths(stationId = null) {
    this.systemAdmin.getBooths({
      stationId: stationId
    }).subscribe(result => {
      console.log("b", result.items);
      this.booths = result.items;
    });
  }
  loadPOSTerminals() {
    this.systemAdmin.getPosTerminalDef({}).subscribe(result => {
      console.log(result.items);
      this.pos.data = result.items;
      if (this.pos.data.length > 0) this.onPOSTerminalSelection(this.pos.data[0]);
    });
  }
  bindChange() {
    this.posSearchForm.controls.stationId.valueChanges.subscribe(change => {
      this.selectedStationId = change;
      this.loadBooths(this.selectedStationId);
      this.searchPOSTerminals({
        stationId: this.selectedStationId
      });
    });
    this.posSearchForm.controls.boothId.valueChanges.subscribe(change => {
      this.selectedBoothId = change;
      this.searchPOSTerminals({
        stationId: this.selectedStationId,
        boothId: this.selectedBoothId
      });
    });
  }
  onPOSTerminalStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "POS Terminal");
    this.CheckPOSActiveDeactiveModalBtn.nativeElement.click();
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  onConfirmPOSActiveDeactiveCahnge() {
    let ManufacOperation = new src_app_core_models_adminstration_POSOperation__WEBPACK_IMPORTED_MODULE_2__.POSOperation();
    ManufacOperation = this.checkedSelectedItem;
    ManufacOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    ManufacOperation.status = ManufacOperation.status ? 1 : 0;
    this.systemAdmin.posTerminalDefOperations(ManufacOperation).subscribe(result => {
      if (result.items == 1) {
        this.action = "Updated";
        this.savePOSModalButton.nativeElement.click();
      }
    });
  }
  onCancelPOSActiveDeactiveChange() {
    this.loadPOSTerminals();
  }
  updateSelectedPOS(item) {
    this.router.navigate(['system-admin/POS/edit', item.posId]);
  }
  searchPOSTerminals(body) {
    this.systemAdmin.getPosTerminalDef(body).subscribe(result => {
      this.pos.data = result.items;
    });
  }
  AddNewPOS() {
    this.router.navigate(['system-admin/POS/new']);
  }
  onPOSTerminalSelection(item) {
    this.selectedPOSId = item.posId;
    this.selectedPOS = item;
  }
  static #_ = this.ɵfac = function PosTerminalComponent_Factory(t) {
    return new (t || PosTerminalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: PosTerminalComponent,
    selectors: [["app-pos-terminal"]],
    viewQuery: function PosTerminalComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.savePOSModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.CheckPOSActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 71,
    vars: 10,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-6"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [3, "formGroup"], [1, "col-md-3"], ["formControlName", "stationId", 1, "form-control"], ["disabled", "", 3, "ngValue"], [3, "value", 4, "ngFor", "ngForOf"], ["formControlName", "boothId", 1, "form-control"], [3, "disabled", "value", 4, "ngFor", "ngForOf"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "updateItemEvent", "selectItemEvent", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["savePOSModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#posConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckPOSActiveDeactiveModalBtn", ""], ["id", "posConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], [3, "value"], [3, "disabled", "value"]],
    template: function PosTerminalComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, " POS Terminal ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PosTerminalComponent_Template_button_click_19_listener() {
          return ctx.AddNewPOS();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](20, " Add New POS ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](22, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](24, "form", 16)(25, "div", 1)(26, "div", 17)(27, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](28, "Station");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "select", 18)(30, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31, "Select Station --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](32, PosTerminalComponent_option_32_Template, 2, 2, "option", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](33, "div", 17)(34, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](35, "Booth");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](36, "select", 21)(37, "option", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](38, "Select Booth --");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, PosTerminalComponent_option_39_Template, 2, 3, "option", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](40, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](41, "app-data-table-viewer", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("updateItemEvent", function PosTerminalComponent_Template_app_data_table_viewer_updateItemEvent_41_listener($event) {
          return ctx.updateSelectedPOS($event);
        })("selectItemEvent", function PosTerminalComponent_Template_app_data_table_viewer_selectItemEvent_41_listener($event) {
          return ctx.onPOSTerminalSelection($event);
        })("checkboxEvent", function PosTerminalComponent_Template_app_data_table_viewer_checkboxEvent_41_listener($event) {
          return ctx.onPOSTerminalStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](42, "button", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "div", 26)(45, "div", 27)(46, "div", 28)(47, "div", 29)(48, "h1", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](49, "img", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](50);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](51, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](52, "button", 33, 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](54, "div", 35)(55, "div", 36)(56, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](57, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](58, "div", 37)(59, "div", 1)(60, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](61, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](62, "div", 3)(63, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](64);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](65, "br")(66, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](67, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PosTerminalComponent_Template_button_click_67_listener() {
          return ctx.onCancelPOSActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](68, "img", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](69, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PosTerminalComponent_Template_button_click_69_listener() {
          return ctx.onConfirmPOSActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](70, "img", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formGroup", ctx.posSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.stations);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngValue", null);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.booths);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("tblHeaders", ctx.posHeaders)("tblValues", ctx.pos)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 51603:
/*!*****************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/roles/role-operation/role-operation.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RoleOperationComponent": () => (/* binding */ RoleOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_systemRoleOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/systemRoleOperation */ 17201);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveRoleModalButton"];
function RoleOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function RoleOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function RoleOperationComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function RoleOperationComponent_button_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function RoleOperationComponent_button_30_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.createUpdateSystemRole());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r3.roleForm.valid);
  }
}
class RoleOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createRoleForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.roleId = +params['id'];
      if (this.roleId > 0) {
        this.loadRole();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadRole() {
    this.systemAdminService.getSystemRoles({
      searchRoleId: this.roleId
    }).subscribe(result => {
      this.roleForm.patchValue(result.items[0]);
    });
  }
  createRoleForm() {
    this.roleForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      roleEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      roleAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
    });
  }
  createUpdateSystemRole() {
    let roleOperation = new src_app_core_models_adminstration_systemRoleOperation__WEBPACK_IMPORTED_MODULE_0__.systemRoleOperation();
    roleOperation = this.roleForm?.value;
    roleOperation.status = this.roleForm?.value.status ? 1 : 0;
    roleOperation.operationType = this.operation;
    if (this.roleId > 0) roleOperation.roleId = this.roleId;
    this.systemAdminService.systemRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) this.saveRoleModalButton.nativeElement.click();
    });
  }
  backToRolesList() {
    this.router.navigate(['system-admin/roles']);
  }
  static #_ = this.ɵfac = function RoleOperationComponent_Factory(t) {
    return new (t || RoleOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: RoleOperationComponent,
    selectors: [["app-role-operation"]],
    viewQuery: function RoleOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveRoleModalButton = _t.first);
      }
    },
    decls: 45,
    vars: 7,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "text", "formControlName", "roleEname", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "roleAname", 1, "form-control"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveRoleModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function RoleOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "role Name * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, RoleOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "role Arabic Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, RoleOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](25, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](27, " Active ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](28, RoleOperationComponent_div_28_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](30, RoleOperationComponent_button_30_Template, 2, 1, "button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](31, "div", 21)(32, "button", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function RoleOperationComponent_Template_button_click_32_listener() {
          return ctx.backToRolesList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](33, "i", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](34, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](35, "button", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "div", 26)(38, "div", 27)(39, "div", 28)(40, "div", 29)(41, "h1", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](42, "img", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](43);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](44, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.roleForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " Role ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.roleForm.get("roleEname").hasError("required") && ctx.roleForm.get("roleEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.roleForm.get("roleAname").hasError("required") && ctx.roleForm.get("roleAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.roleForm.get("status").hasError("required") && ctx.roleForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9yb2xlcy9yb2xlLW9wZXJhdGlvbi9yb2xlLW9wZXJhdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 9207:
/*!*****************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/roles/roles.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RolesComponent": () => (/* binding */ RolesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_models_adminstration_systemRoleOperation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/adminstration/systemRoleOperation */ 17201);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_systemUserRoleOperation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/adminstration/systemUserRoleOperation */ 17671);
/* harmony import */ var src_app_core_models_adminstration_RoleOperation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/models/adminstration/RoleOperation */ 86171);
/* harmony import */ var src_app_core_models_adminstration_entityRoleOperations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/models/adminstration/entityRoleOperations */ 72316);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);
/* harmony import */ var _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../components/select-dropdown-component/select-dropdown.component */ 55306);














const _c0 = ["saveRoleModalButton"];
const _c1 = ["CheckRoleActiveDeactiveModalBtn"];
const _c2 = ["CheckUserRoleActiveDeactiveModalBtn"];
function RolesComponent_div_194_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
  }
}
class RolesComponent {
  constructor(systemAdmin, router, formBuilder) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.formBuilder = formBuilder;
    this.roles = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.users = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.entities = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.roleHeaders = [{
      JsonPropName: 'roleEname',
      showName: 'Role Name'
    }, {
      JsonPropName: 'roleAname',
      showName: 'Role Arabic Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.usersHeaders = [{
      JsonPropName: 'username',
      showName: 'Username'
    }, {
      JsonPropName: 'userFullName',
      showName: 'Full Name'
    }, {
      JsonPropName: 'mail',
      showName: 'Email'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.entitiesHeaders = [{
      JsonPropName: 'entityName',
      showName: 'Entity Name'
    }, {
      JsonPropName: 'entityEdesc',
      showName: 'Entity Description'
    }, {
      JsonPropName: 'entityAdesc',
      showName: 'Arabic Description'
    }];
    this.usersNotInRole = [];
    this.entitiesNotInRole = [];
  }
  ngOnInit() {
    this.createRoleForms();
    this.bindChange();
    this.loadRoles();
  }
  createRoleForms() {
    this.RolesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
      roleName: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null)
    });
    this.RoleUsersSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
      username: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null),
      name: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null)
    });
    this.RoleEntitiesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null)
    });
    this.entitiesNotInRoleForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null),
      entityId: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null)
    });
    this.usersNotInRoleForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null),
      status: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required),
      userId: new _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.Validators.required)
    });
  }
  loadRoles() {
    this.systemAdmin.getSystemRoles({}).subscribe(result => {
      this.roles.data = result.items;
      this.onRoleSelection(this.roles.data[0]);
    });
  }
  bindChange() {
    this.bindFormControlChange(this.RoleUsersSearchForm.controls.username, 'searchUserName');
    this.bindFormControlChange(this.RoleUsersSearchForm.controls.name, 'searchUserFullName');
    this.RoleEntitiesSearchForm.controls.searchField.valueChanges.subscribe(change => {
      this.searchRoleEntities(change);
    });
    this.RolesSearchForm.controls.roleName.valueChanges.subscribe(change => {
      this.searchRoles(change);
    });
    this.entitiesNotInRoleForm.controls.searchField.valueChanges.subscribe(change => {
      this.systemAdmin.getEntitiesNotInRole({
        containsText: change,
        roleId: this.SelectedRoleId
      }).subscribe(result => {
        this.entitiesNotInRole = result.items;
      });
    });
  }
  bindFormControlChange(formControl, property) {
    if (formControl) {
      formControl.valueChanges.subscribe(change => {
        this.searchRoleUser({
          [property]: change,
          roleId: this.SelectedRoleId
        });
      });
    }
  }
  searchRoleUser(searchParams) {
    this.systemAdmin.getRoleUsers(searchParams).subscribe(result => {
      this.users.data = result.items;
    });
  }
  searchRoleEntities(change) {
    this.systemAdmin.getRoleEntities({
      searchEntityName: change,
      searchRoleId: this.SelectedRoleId
    }).subscribe(result => {
      this.entities.data = result.items;
    });
  }
  searchRoles(searchValue) {
    this.systemAdmin.getSystemRoles({
      searchRoleName: searchValue
    }).subscribe(result => {
      this.roles.data = result.items;
    });
  }
  onRoleSelection(item) {
    this.UserTitleName = item.roleEname;
    this.SelectedRoleId = item.roleId;
    this.seletedRole = item;
    this.RoleUsersSearchForm.controls.name.reset();
    this.RoleUsersSearchForm.controls.username.reset();
    this.RoleEntitiesSearchForm.controls.searchField.reset();
    this.loadRoleUsers();
    this.loadRoleEntities();
    this.loadUsersNotInRole();
    this.loadEntitiesNotInRole();
  }
  loadUsersNotInRole() {
    this.systemAdmin.getUsersNotInRole({
      roleId: this.SelectedRoleId
    }).subscribe(result => {
      this.usersNotInRole = result.items;
    });
  }
  loadEntitiesNotInRole() {
    this.systemAdmin.getEntitiesNotInRole({
      roleId: this.SelectedRoleId
    }).subscribe(result => {
      this.entitiesNotInRole = result.items;
    });
  }
  loadRoleEntities() {
    this.systemAdmin.getRoleEntities({
      searchRoleId: this.SelectedRoleId
    }).subscribe(result => {
      this.entities.data = result.items;
    });
  }
  loadRoleUsers() {
    this.systemAdmin.getRoleUsers({
      roleId: this.SelectedRoleId
    }).subscribe(result => {
      this.users.data = result.items;
    });
  }
  onRoleStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "user role");
  }
  onUserRoleStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "role");
  }
  onConfirmRoleActiveDeactiveCahnge() {
    let roleOperation = new src_app_core_models_adminstration_systemRoleOperation__WEBPACK_IMPORTED_MODULE_1__.systemRoleOperation();
    roleOperation = this.checkedSelectedItem;
    roleOperation.status = roleOperation.status ? 1 : 0;
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.update;
    this.systemAdmin.systemRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Updated";
        this.saveRoleModalButton.nativeElement.click();
      }
    });
  }
  onCancelRoleActiveDeactiveCahnge() {
    this.loadRoles();
  }
  onConfirmUserRoleActiveDeactiveCahnge() {
    let roleOperation = new src_app_core_models_adminstration_systemUserRoleOperation__WEBPACK_IMPORTED_MODULE_3__.systemUserRoleOperation();
    roleOperation = this.checkedSelectedItem;
    roleOperation.status = roleOperation.status ? 1 : 0;
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.update;
    this.systemAdmin.systemUserRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Updated";
        this.saveRoleModalButton.nativeElement.click();
      }
    });
  }
  onCancelUserRoleActiveDeactiveCahnge() {
    this.onRoleSelection(this.checkedSelectedItem);
  }
  AddNewUserToRole() {
    let roleOperation = new src_app_core_models_adminstration_RoleOperation__WEBPACK_IMPORTED_MODULE_4__.userRoleOperation();
    roleOperation = this.usersNotInRoleForm?.value;
    roleOperation.status = this.usersNotInRoleForm?.value.status ? 1 : 0;
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert;
    roleOperation.roleId = this.SelectedRoleId;
    this.systemAdmin.systemUserRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Created";
        this.saveRoleModalButton.nativeElement.click();
        this.loadRoleUsers();
        this.loadUsersNotInRole();
      }
    });
  }
  AddNewEntityToRole() {
    let roleOperation = new src_app_core_models_adminstration_entityRoleOperations__WEBPACK_IMPORTED_MODULE_5__.entityRoleOperations();
    roleOperation = this.entitiesNotInRoleForm?.value;
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType.insert;
    roleOperation.roleId = this.SelectedRoleId;
    this.systemAdmin.systemEntityRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Created";
        this.saveRoleModalButton.nativeElement.click();
        this.loadEntitiesNotInRole();
        this.loadRoleEntities();
      }
    });
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
    this.CheckUserRoleActiveDeactiveModalBtn.nativeElement.click();
  }
  onRoleUserStatusChange(change) {
    const JsonPropName = change.JsonPropName;
    const value = change.value;
    const selectedItem = change.selectedItem;
  }
  onRoleEntityStatusChange(change) {
    const JsonPropName = change.JsonPropName;
    const value = change.value;
    const selectedItem = change.selectedItem;
  }
  AddNewRole() {
    this.router.navigate(['system-admin/roles/new']);
  }
  checkDeleteRoleEntity(item) {
    this.checkMessage = `Are you sure you want to delete this?`;
    this.CheckUserRoleActiveDeactiveModalBtn.nativeElement.click();
    this.deleteSelectedItem = item;
  }
  deleteRoleEntity() {
    let roleOperation = new src_app_core_models_adminstration_entityRoleOperations__WEBPACK_IMPORTED_MODULE_5__.entityRoleOperations();
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType["delete"];
    roleOperation.roleId = this.deleteSelectedItem.roleId;
    roleOperation.entityId = this.deleteSelectedItem.entityId;
    this.systemAdmin.systemEntityRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Deleted";
        this.saveRoleModalButton.nativeElement.click();
        this.loadEntitiesNotInRole();
        this.loadRoleEntities();
      }
    });
  }
  updateSelectedRole(item) {
    this.router.navigate(['system-admin/roles/edit', item.roleId]);
  }
  setActiveTab(tab) {
    this.activeTab = tab;
  }
  onValueChange(item) {
    this.selectedUserId = item.userId;
    // this.systemAdmin.getUsersNotInRole({containsText:item., roleId:this.SelectedRoleId})
    //   .subscribe(result=>{
    //     this.usersNotInRole = result.items
    //   })
  }
  static #_ = this.ɵfac = function RolesComponent_Factory(t) {
    return new (t || RolesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_6__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_11__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormBuilder));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({
    type: RolesComponent,
    selectors: [["app-roles"]],
    viewQuery: function RolesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵloadQuery"]()) && (ctx.saveRoleModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵloadQuery"]()) && (ctx.CheckRoleActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵloadQuery"]()) && (ctx.CheckUserRoleActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 230,
    vars: 36,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], ["for", "search"], ["type", "text", "id", "search", "formControlName", "roleName", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "selectedRow", "updateItemEvent", "updatetemEvent", "selectItemEvent", "checkboxEvent"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#v-details", "type", "button", "role", "tab", "aria-controls", "v-details", "aria-selected", "true", 1, "nav-link", "active", 3, "click"], ["id", "home-tab", "data-bs-toggle", "tab", "data-bs-target", "#instructions", "type", "button", "role", "tab", "aria-controls", "instructions", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "inspection-tab-content"], ["id", "myTabContent", 1, "tab-content"], ["id", "v-details", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#addUserRoleModel", 1, "btn", "btn-orange", "btn-block"], ["for", "username"], ["type", "text", "id", "username", "formControlName", "username", 1, "form-control", "searchBox"], ["for", "name"], ["type", "text", "id", "name", "formControlName", "name", 1, "form-control", "searchBox"], [1, "col-md-6"], [3, "tblHeaders", "tblValues", "isUpdateOperationEnabled", "isDeleteOperationEnabled", "checkboxEvent"], ["id", "instructions", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], ["id", "accordionExample3", 1, "accordion", "section", "accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#addEntityRoleModel", 1, "btn", "btn-orange"], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "isUpdateOperationEnabled", "deleteItemEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveRoleModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#roleConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckRoleActiveDeactiveModalBtn", ""], ["id", "roleConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#userRoleConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckUserRoleActiveDeactiveModalBtn", ""], ["id", "userRoleConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#checkDeleteUserEntity", 1, "btn", "btn-orange", 2, "display", "none"], ["checkDeleteUserEntityBtn", ""], ["id", "checkDeleteUserEntity", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["id", "addUserRoleModel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "col-md-4"], ["formControlName", "userId", "placeholder", "Select User", 3, "list", "displayMember", "idMember", "valueChanged"], ["type", "checkbox", "id", "search", "formControlName", "status"], ["class", "error-message", 4, "ngIf"], [1, "row", "justify-content-end"], [1, "col-6"], ["type", "button", 1, "btn", "btn-orange", "col-md-3", 3, "disabled", "click"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-light", "col-md-3"], ["id", "addEntityRoleModel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["formControlName", "entityId", "placeholder", "Select Entity", 3, "list", "displayMember", "idMember", "valueChanged"], ["type", "button", 1, "btn", "btn-orange", "col-md-3", 3, "click"], [1, "error-message"]],
    template: function RolesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](8, " System Roles ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "div", 0)(13, "div", 11)(14, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_14_listener() {
          return ctx.AddNewRole();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](15, " Add Role ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](16, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](17, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](18, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](19, "form", 15)(20, "div", 16)(21, "div", 11)(22, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](23, "Role Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](24, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](25, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](26, "app-data-table-viewer", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("updateItemEvent", function RolesComponent_Template_app_data_table_viewer_updateItemEvent_26_listener($event) {
          return ctx.updateSelectedRole($event);
        })("updatetemEvent", function RolesComponent_Template_app_data_table_viewer_updatetemEvent_26_listener($event) {
          return ctx.updateSelectedRole($event);
        })("selectItemEvent", function RolesComponent_Template_app_data_table_viewer_selectItemEvent_26_listener($event) {
          return ctx.onRoleSelection($event);
        })("checkboxEvent", function RolesComponent_Template_app_data_table_viewer_checkboxEvent_26_listener($event) {
          return ctx.onRoleStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](27, "div", 0)(28, "div", 1)(29, "div", 2)(30, "div", 3)(31, "div", 4)(32, "div", 5)(33, "div", 1)(34, "div", 20)(35, "ul", 21)(36, "li", 22)(37, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_37_listener() {
          return ctx.setActiveTab("details");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](38, " Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](39, "li", 22)(40, "button", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_40_listener() {
          return ctx.setActiveTab("inst");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](41, " Entities ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](42, "div", 25)(43, "div", 0)(44, "div", 1)(45, "div", 26)(46, "div", 27)(47, "div", 0)(48, "div", 1)(49, "div", 2)(50, "div", 3)(51, "div", 28)(52, "div", 5)(53, "h2", 29)(54, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](55);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](56, "div", 31)(57, "div", 9)(58, "div", 10)(59, "div", 0)(60, "div", 11)(61, "button", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](62, " Assign User ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](63, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](64, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](65, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](66, "form", 15)(67, "div", 16)(68, "div", 11)(69, "label", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](70, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](71, "input", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](72, "div", 11)(73, "label", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](74, "Full Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](75, "input", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](76, "div", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](77, "app-data-table-viewer", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("checkboxEvent", function RolesComponent_Template_app_data_table_viewer_checkboxEvent_77_listener($event) {
          return ctx.onUserRoleStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](78, "div", 39)(79, "div", 0)(80, "div", 1)(81, "div", 2)(82, "div", 3)(83, "div", 40)(84, "div", 5)(85, "h2", 41)(86, "button", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](87);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](88, "div", 43)(89, "div", 9)(90, "div", 10)(91, "div", 0)(92, "div", 11)(93, "button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](94, " Assign entity ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](95, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](96, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](97, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](98, "form", 15)(99, "div", 16)(100, "div", 11)(101, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](102, "Entity Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](103, "input", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](104, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](105, "app-data-table-viewer", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("deleteItemEvent", function RolesComponent_Template_app_data_table_viewer_deleteItemEvent_105_listener($event) {
          return ctx.checkDeleteRoleEntity($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](106, "button", 47, 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](108, "div", 49)(109, "div", 50)(110, "div", 51)(111, "div", 52)(112, "h1", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](113, "img", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](114);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](115, "button", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](116, "button", 56, 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](118, "div", 58)(119, "div", 59)(120, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](121, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](122, "div", 60)(123, "div", 0)(124, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](125, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](126, "div", 1)(127, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](128);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](129, "br")(130, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](131, "button", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_131_listener() {
          return ctx.onCancelRoleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](132, "img", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](133, "button", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_133_listener() {
          return ctx.onConfirmRoleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](134, "img", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](135, "button", 65, 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](137, "div", 67)(138, "div", 59)(139, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](140, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](141, "div", 60)(142, "div", 0)(143, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](144, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](145, "div", 1)(146, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](147);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](148, "br")(149, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](150, "button", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_150_listener() {
          return ctx.onCancelUserRoleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](151, "img", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](152, "button", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_152_listener() {
          return ctx.onConfirmUserRoleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](153, "img", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](154, "button", 68, 69);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](156, "div", 70)(157, "div", 59)(158, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](159, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](160, "div", 60)(161, "div", 0)(162, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](163, "img", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](164, "div", 1)(165, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](166);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](167, "br")(168, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](169, "button", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_169_listener() {
          return ctx.deleteRoleEntity();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](170, "img", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](171, "button", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](172, "img", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](173, "div", 72)(174, "div", 59)(175, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](176, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](177, "div", 60)(178, "div", 0)(179, "div", 1)(180, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](181);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](182, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](183, "div", 1)(184, "form", 15)(185, "div", 0)(186, "div", 73)(187, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](188, "User Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](189, "app-select-dropdown", 74);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("valueChanged", function RolesComponent_Template_app_select_dropdown_valueChanged_189_listener($event) {
          return ctx.onValueChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](190, "div", 11)(191, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](192, " Status ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](193, "input", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](194, RolesComponent_div_194_Template, 2, 0, "div", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](195, "div", 77)(196, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](197, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](198, "div", 78)(199, "div", 0)(200, "button", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_200_listener() {
          return ctx.AddNewUserToRole();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](201, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](202, "button", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](203, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](204, "div", 81)(205, "div", 59)(206, "div", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](207, "div", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](208, "div", 60)(209, "div", 0)(210, "div", 1)(211, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](212);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](213, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](214, "div", 1)(215, "form", 15)(216, "div", 0)(217, "div", 73)(218, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](219, "Entity Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](220, "app-select-dropdown", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("valueChanged", function RolesComponent_Template_app_select_dropdown_valueChanged_220_listener($event) {
          return ctx.onValueChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](221, "div", 77)(222, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](223, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](224, "div", 78)(225, "div", 0)(226, "button", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("click", function RolesComponent_Template_button_click_226_listener() {
          return ctx.AddNewEntityToRole();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](227, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](228, "button", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](229, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("formGroup", ctx.RolesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("tblHeaders", ctx.roleHeaders)("tblValues", ctx.roles)("isDeleteOperationEnabled", false)("selectedRow", ctx.seletedRole);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx.UserTitleName, " Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("formGroup", ctx.RoleUsersSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("tblHeaders", ctx.usersHeaders)("tblValues", ctx.users)("isUpdateOperationEnabled", false)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx.UserTitleName, " Entities ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("formGroup", ctx.RoleEntitiesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("tblHeaders", ctx.entitiesHeaders)("tblValues", ctx.entities)("isUpdateOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" Add User To ", ctx.UserTitleName, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("formGroup", ctx.usersNotInRoleForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("list", ctx.usersNotInRole)("displayMember", "userFullName")("idMember", "userId");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.usersNotInRoleForm.get("status").hasError("required") && ctx.usersNotInRoleForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("disabled", !ctx.usersNotInRoleForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtextInterpolate1"](" Add Entity To ", ctx.UserTitleName, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("formGroup", ctx.entitiesNotInRoleForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("list", ctx.entitiesNotInRole)("displayMember", "entityEdesc")("idMember", "entityId");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_7__.DataTableViewerComponent, _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_8__.SelectDropdownComponent],
    styles: [".inspection-tab-menu[_ngcontent-%COMP%]{\r\n    width: 1230px;\r\n    margin-left: 15px;\r\n    margin-top: 1%;\r\n }\r\n\r\n @media (max-width: 768px) {\r\n    .inspection-tab-menu[_ngcontent-%COMP%] {\r\n        margin-left: 0;\r\n        padding: 0 15px;\r\n    }\r\n}\r\n\r\n\r\n\r\n.outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9yb2xlcy9yb2xlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJDQUFDO0lBQ0csYUFBYTtJQUNiLGlCQUFpQjtJQUNqQixjQUFjO0NBQ2pCOztDQUVBO0lBQ0c7UUFDSSxjQUFjO1FBQ2QsZUFBZTtJQUNuQjtBQUNKOzs7O0FBSUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiIC5pbnNwZWN0aW9uLXRhYi1tZW51e1xyXG4gICAgd2lkdGg6IDEyMzBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogMSU7XHJcbiB9XHJcblxyXG4gQG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XHJcbiAgICAuaW5zcGVjdGlvbi10YWItbWVudSB7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgICAgICAgcGFkZGluZzogMCAxNXB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5cclxuXHJcbi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 37859:
/*!*************************************************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/system-messages/system-messages-operation/system-messages-operation.component.ts ***!
  \*************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemMessagesOperationComponent": () => (/* binding */ SystemMessagesOperationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_MessageOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/MessageOperation */ 88940);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveMessageModalButton"];
function SystemMessagesOperationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function SystemMessagesOperationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function SystemMessagesOperationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function SystemMessagesOperationComponent_button_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SystemMessagesOperationComponent_button_29_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.createUpdateMessage());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r3.messageForm.valid);
  }
}
class SystemMessagesOperationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createMessageForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.messageId = +params['messageId'];
      if (this.messageId > 0) {
        this.loadMessage();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadMessage() {
    this.systemAdminService.getSystemMessages({
      messageId: this.messageId
    }).subscribe(result => {
      this.messageForm.patchValue(result.items[0]);
    });
  }
  createMessageForm() {
    this.messageForm = this.fb.group({
      messagePrefix: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      messageAname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      messageEname: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required]
    });
  }
  createUpdateMessage() {
    let messageOper = new src_app_core_models_adminstration_MessageOperation__WEBPACK_IMPORTED_MODULE_0__.MessageOperation();
    messageOper = this.messageForm?.value;
    messageOper.operationType = this.operation;
    if (this.messageId > 0) messageOper.messageId = this.messageId;
    this.systemAdminService.systemMessagesOperations(messageOper).subscribe(result => {
      if (result.items > 0) this.saveMessageModalButton.nativeElement.click();
    });
  }
  backToMessagesList() {
    this.router.navigate(['system-admin/messages']);
  }
  static #_ = this.ɵfac = function SystemMessagesOperationComponent_Factory(t) {
    return new (t || SystemMessagesOperationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: SystemMessagesOperationComponent,
    selectors: [["app-system-messages-operation"]],
    viewQuery: function SystemMessagesOperationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveMessageModalButton = _t.first);
      }
    },
    decls: 44,
    vars: 7,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "messagePrefix", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "messageEname", 1, "form-control"], ["type", "text", "formControlName", "messageAname", 1, "form-control"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveMessageModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function SystemMessagesOperationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Prefix * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, SystemMessagesOperationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Message *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, SystemMessagesOperationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "Arabic Message");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, SystemMessagesOperationComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](29, SystemMessagesOperationComponent_button_29_Template, 2, 1, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "div", 19)(31, "button", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SystemMessagesOperationComponent_Template_button_click_31_listener() {
          return ctx.backToMessagesList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](32, "i", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](33, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](34, "button", 22, 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](36, "div", 24)(37, "div", 25)(38, "div", 26)(39, "div", 27)(40, "h1", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](41, "img", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](42);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](43, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.messageForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " System Message ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.messageForm.get("messagePrefix").hasError("required") && ctx.messageForm.get("messagePrefix").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.messageForm.get("messageEname").hasError("required") && ctx.messageForm.get("messageEname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.messageForm.get("messageAname").hasError("required") && ctx.messageForm.get("messageAname").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9zeXN0ZW0tbWVzc2FnZXMvc3lzdGVtLW1lc3NhZ2VzLW9wZXJhdGlvbi9zeXN0ZW0tbWVzc2FnZXMtb3BlcmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 85919:
/*!*************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/system-messages/system-messages.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemMessagesComponent": () => (/* binding */ SystemMessagesComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_models_adminstration_MessageOperation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/adminstration/MessageOperation */ 88940);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);









const _c0 = ["deleteMessageModalButton"];
const _c1 = ["CheckDeleteModalBtn"];
class SystemMessagesComponent {
  constructor(systemAdmin, router) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.messages = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.messageHeaders = [{
      JsonPropName: 'messagePrefix',
      showName: 'Prefix'
    }, {
      JsonPropName: 'messageEname',
      showName: 'Message'
    }, {
      JsonPropName: 'messageAname',
      showName: 'Arabic Message'
    }];
  }
  ngOnInit() {
    this.messagesSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl(null)
    });
    this.bindChange();
    this.loadMessages();
  }
  loadMessages() {
    this.systemAdmin.getSystemMessages({}).subscribe(result => {
      this.messages.data = result.items;
    });
  }
  bindChange() {
    this.messagesSearchForm.controls.searchField?.valueChanges.subscribe(change => {
      this.searchMessages(change);
    });
  }
  updateSelectedMessage(item) {
    this.router.navigate(['system-admin/messages/edit', item.messageId]);
  }
  deleteSystemMessage() {
    let messageOper = new src_app_core_models_adminstration_MessageOperation__WEBPACK_IMPORTED_MODULE_1__.MessageOperation();
    messageOper = this.selectedDeleteItem;
    messageOper.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_2__.operationType["delete"];
    this.systemAdmin.systemMessagesOperations(messageOper).subscribe(result => {
      if (result.items > 0) {
        this.deleteMessageModalButton.nativeElement.click();
        this.loadMessages();
      }
    });
  }
  searchMessages(searchValue) {
    this.systemAdmin.getSystemMessages({
      containsText: searchValue
    }).subscribe(result => {
      this.messages.data = result.items;
    });
  }
  onDeleteSysMessage(item) {
    this.selectedDeleteItem = item;
    this.CheckDeleteModalBtn.nativeElement.click();
  }
  AddNewMessage() {
    this.router.navigate(['system-admin/messages/new']);
  }
  static #_ = this.ɵfac = function SystemMessagesComponent_Factory(t) {
    return new (t || SystemMessagesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_3__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: SystemMessagesComponent,
    selectors: [["app-system-messages"]],
    viewQuery: function SystemMessagesComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.deleteMessageModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.CheckDeleteModalBtn = _t.first);
      }
    },
    decls: 61,
    vars: 4,
    consts: [[1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], ["for", ""], ["type", "text", "id", "search", "formControlName", "searchField", 1, "form-control", "searchBox"], [3, "tblHeaders", "tblValues", "selectedRow", "updateItemEvent", "deleteItemEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["deleteMessageModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#deleteConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckDeleteModalBtn", ""], ["id", "deleteConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"]],
    template: function SystemMessagesComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "div", 2)(3, "div", 1)(4, "div", 2)(5, "div", 1)(6, "div", 3)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "h2", 8)(12, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](13, " System Messages ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "div", 10)(15, "div", 11)(16, "div", 12)(17, "div", 1)(18, "div", 13)(19, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function SystemMessagesComponent_Template_button_click_19_listener() {
          return ctx.AddNewMessage();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20, " Add Message ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](21, "i", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](22, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](23, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](24, "form", 17)(25, "div", 1)(26, "div", 16)(27, "label", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](28, "Message Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](29, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](30, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "app-data-table-viewer", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("updateItemEvent", function SystemMessagesComponent_Template_app_data_table_viewer_updateItemEvent_31_listener($event) {
          return ctx.updateSelectedMessage($event);
        })("deleteItemEvent", function SystemMessagesComponent_Template_app_data_table_viewer_deleteItemEvent_31_listener($event) {
          return ctx.onDeleteSysMessage($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](32, "button", 21, 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "div", 23)(35, "div", 24)(36, "div", 25)(37, "div", 26)(38, "h1", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](39, "img", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](40, " Deleted Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](41, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](42, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "div", 32)(45, "div", 33)(46, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](47, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "div", 34)(49, "div", 1)(50, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](51, "img", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](52, "div", 3)(53, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](54, " Are you sure you want to delete this message ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](55, "br")(56, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](57, "button", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](58, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](59, "button", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function SystemMessagesComponent_Template_button_click_59_listener() {
          return ctx.deleteSystemMessage();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](60, "img", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.messagesSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("tblHeaders", ctx.messageHeaders)("tblValues", ctx.messages)("selectedRow", ctx.selectedMessage);
      }
    },
    dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_4__.DataTableViewerComponent],
    styles: [".searchBox[_ngcontent-%COMP%]{\r\n    width: 25%; \r\n    margin-bottom: 1%; \r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi9zeXN0ZW0tbWVzc2FnZXMvc3lzdGVtLW1lc3NhZ2VzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxVQUFVO0lBQ1YsaUJBQWlCO0FBQ3JCIiwic291cmNlc0NvbnRlbnQiOlsiLnNlYXJjaEJveHtcclxuICAgIHdpZHRoOiAyNSU7IFxyXG4gICAgbWFyZ2luLWJvdHRvbTogMSU7IFxyXG59IFxyXG4gXHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 14357:
/*!*******************************************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/users/user-opertation/user-opertation.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserOpertationComponent": () => (/* binding */ UserOpertationComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_adminstration_userOperation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/adminstration/userOperation */ 45987);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);








const _c0 = ["saveUserModalButton"];
function UserOpertationComponent_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_div_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_div_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_div_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function UserOpertationComponent_button_55_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UserOpertationComponent_button_55_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r9.createUpdateUser());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r7.userForm.valid);
  }
}
class UserOpertationComponent {
  constructor(fb, route, systemAdminService, router) {
    this.fb = fb;
    this.route = route;
    this.systemAdminService = systemAdminService;
    this.router = router;
    this.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType;
    this.validationEnabled = false;
  }
  ngOnInit() {
    this.checkViewInsertUpdateMode();
    this.createUserForm();
  }
  checkViewInsertUpdateMode() {
    this.route.url.subscribe(segments => {
      const lastSegment = segments[segments.length - 2].path;
      this.operation = lastSegment === 'view' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view : lastSegment === 'edit' ? src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update : src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update || this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.view) this.route.params.subscribe(params => {
      this.userId = +params['id'];
      if (this.userId > 0) {
        this.loadUser();
      }
    });
    if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update) {
      this.title = "Update";
      this.action = "Updated";
    } else if (this.operation == src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert) {
      this.title = "Create New";
      this.action = "Created";
    }
  }
  loadUser() {
    this.systemAdminService.getUsers({
      searchUserId: this.userId
    }).subscribe(result => {
      this.userForm.patchValue(result.items.users[0]);
    });
  }
  createUserForm() {
    this.userForm = this.fb.group({
      status: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      username: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      userFullName: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      userFullNameAr: [null],
      mail: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      phone: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      rfid: [null],
      softDeleted: [null]
    });
  }
  createUpdateUser() {
    let userOper = new src_app_core_models_adminstration_userOperation__WEBPACK_IMPORTED_MODULE_0__.userOperation();
    userOper = this.userForm?.value;
    userOper.status = this.userForm?.value.status ? 1 : 0;
    userOper.softDeleted = this.userForm?.value.softDeleted ? 1 : 0;
    userOper.operationType = this.operation;
    if (this.userId > 0) userOper.userId = this.userId;
    this.systemAdminService.userOpration(userOper).subscribe(result => {
      if (result.items > 0) this.saveUserModalButton.nativeElement.click();
    });
  }
  backToUsersList() {
    this.router.navigate(['system-admin/users']);
  }
  static #_ = this.ɵfac = function UserOpertationComponent_Factory(t) {
    return new (t || UserOpertationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_2__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: UserOpertationComponent,
    selectors: [["app-user-opertation"]],
    viewQuery: function UserOpertationComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.saveUserModalButton = _t.first);
      }
    },
    decls: 70,
    vars: 11,
    consts: [[1, "col-md-12"], [1, "row"], [3, "formGroup"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-3", "col-lg-3"], ["type", "text", "formControlName", "username", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "userFullName", 1, "form-control"], ["type", "text", "formControlName", "userFullNameAr", 1, "form-control"], ["type", "text", "formControlName", "mail", 1, "form-control"], ["type", "text", "formControlName", "phone", 1, "form-control"], ["type", "text", "formControlName", "rfid", 1, "form-control"], [1, "col-md-2", "col-lg-3"], [1, "form-check"], ["type", "checkbox", "formControlName", "status", 1, "form-check-input"], ["for", "flexCheckDefault", 1, "form-check-label"], ["type", "checkbox", "formControlName", "softDeleted", 1, "form-check-input"], [1, "modal-footer", "text-center"], ["type", "button", "class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-arrow-left"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveUserModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], [1, "error-message"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function UserOpertationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "form", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "div", 6)(7, "h2", 7)(8, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 9)(11, "div", 10)(12, "div", 11)(13, "div", 12)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Username * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, UserOpertationComponent_div_17_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 12)(19, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Full Name *");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](21, "input", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, UserOpertationComponent_div_22_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 12)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](25, "Arabic Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](26, "input", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](27, UserOpertationComponent_div_27_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "div", 12)(29, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](30, "Email * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](31, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](32, UserOpertationComponent_div_32_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "div", 12)(34, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](35, "Phone No. * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](36, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](37, UserOpertationComponent_div_37_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](38, "div", 12)(39, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](40, "RFID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](41, "input", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](42, UserOpertationComponent_div_42_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](43, "div", 20)(44, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](45, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](47, " Active * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](48, UserOpertationComponent_div_48_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "div", 20)(50, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](51, "input", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](52, "label", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](53, " Deleted ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](54, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](55, UserOpertationComponent_button_55_Template, 2, 1, "button", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](56, "div", 27)(57, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UserOpertationComponent_Template_button_click_57_listener() {
          return ctx.backToUsersList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](58, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](59, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](60, "button", 30, 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](62, "div", 32)(63, "div", 33)(64, "div", 34)(65, "div", 35)(66, "h1", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](67, "img", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](68);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](69, "button", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.userForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.title, " User ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("username").hasError("required") && ctx.userForm.get("username").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("userFullName").hasError("required") && ctx.userForm.get("userFullName").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("userFullNameAr").hasError("required") && ctx.userForm.get("userFullNameAr").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("mail").hasError("required") && ctx.userForm.get("mail").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("phone").hasError("required") && ctx.userForm.get("phone").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("rfid").hasError("required") && ctx.userForm.get("rfid").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.userForm.get("status").hasError("required") && ctx.userForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.operation != ctx.operationType.view);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi91c2Vycy91c2VyLW9wZXJ0YXRpb24vdXNlci1vcGVydGF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsZUFBZTtBQUNuQjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiLm91dGxpbmUtcmFkaW8tY29udGFpbmVyOmhvdmVyIC5iaSB7XHJcbiAgICBjb2xvcjogI2ZiOGQwZDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmJ0bi1vcmFuZ2U6ZGlzYWJsZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICAgIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 81391:
/*!*****************************************************************************!*\
  !*** ./src/app/modules/administration/systemAdmin/users/users.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsersComponent": () => (/* binding */ UsersComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/tableData */ 5058);
/* harmony import */ var src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/operation-type.enum */ 25190);
/* harmony import */ var src_app_core_models_adminstration_systemUserRoleOperation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/adminstration/systemUserRoleOperation */ 17671);
/* harmony import */ var src_app_core_models_adminstration_RoleOperation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/adminstration/RoleOperation */ 86171);
/* harmony import */ var src_app_core_models_adminstration_userOperation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/models/adminstration/userOperation */ 45987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/system-admin.service */ 990);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components/data-table-viewer/data-table-viewer.component */ 75984);
/* harmony import */ var _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components/select-dropdown-component/select-dropdown.component */ 55306);













const _c0 = ["saveRoleModalButton"];
const _c1 = ["CheckUserActiveDeactiveModalBtn"];
const _c2 = ["CheckUserRoleActiveDeactiveModalBtn"];
function UsersComponent_div_120_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
  }
}
class UsersComponent {
  constructor(systemAdmin, router, formBuilder) {
    this.systemAdmin = systemAdmin;
    this.router = router;
    this.formBuilder = formBuilder;
    this.roles = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.users = new src_app_core_models_tableData__WEBPACK_IMPORTED_MODULE_0__.tableData();
    this.roleHeaders = [{
      JsonPropName: 'roleEname',
      showName: 'Role Name'
    }, {
      JsonPropName: 'roleAname',
      showName: 'Role Arabic Name'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.userHeaders = [{
      JsonPropName: 'username',
      showName: 'Username'
    }, {
      JsonPropName: 'userFullName',
      showName: 'Full Name'
    }, {
      JsonPropName: 'mail',
      showName: 'Email'
    }, {
      JsonPropName: 'phone',
      showName: 'Phone'
    }, {
      JsonPropName: 'status',
      showName: 'Active',
      ShowInCheckBox: true
    }];
    this.rolesNotWithUser = [];
  }
  ngOnInit() {
    this.createUserForms();
    this.bindChange();
    this.loadUsers();
  }
  createUserForms() {
    this.usersSearchForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroup({
      username: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      name: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null)
    });
    this.rolesNotAssignToUserForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroup({
      searchField: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null),
      status: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required),
      roleId: new _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControl(null, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required)
    });
  }
  loadUsers() {
    this.systemAdmin.getUsers({}).subscribe(result => {
      this.users.data = result.items.users;
      this.users.totalPages = result.items.pageCount;
      this.onUserSelection(this.users.data[0]);
    });
  }
  bindChange() {
    this.usersSearchForm.controls.username.valueChanges.subscribe(change => {
      this.systemAdmin.getUsers({
        searchUsername: change
      }).subscribe(result => {
        this.users.data = result.items.users;
        this.users.totalPages = result.items.pageCount;
      });
    });
    this.usersSearchForm.controls.name.valueChanges.subscribe(change => {
      this.systemAdmin.getUsers({
        searchUserFullName: change
      }).subscribe(result => {
        this.users.data = result.items.users;
        this.users.totalPages = result.items.pageCount;
      });
    });
  }
  searchRoles(searchValue) {
    this.systemAdmin.getSystemRoles({
      searchRoleName: searchValue
    }).subscribe(result => {
      this.roles.data = result.items;
    });
  }
  onUserSelection(item) {
    this.UserTitleName = item.username;
    this.selectedUserId = item.userId;
    this.loadUserRoles();
    this.loadrolesNotWithUser();
  }
  loadrolesNotWithUser() {
    this.systemAdmin.getrolesNotWithUser({
      userId: this.selectedUserId
    }).subscribe(result => {
      this.rolesNotWithUser = result.items;
    });
  }
  loadUserRoles() {
    this.systemAdmin.getUserRoles({
      userId: this.selectedUserId
    }).subscribe(result => {
      this.roles.data = result.items;
    });
  }
  onUserStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "user");
    this.CheckUserActiveDeactiveModalBtn.nativeElement.click();
  }
  onUserRoleStatusChange(change) {
    this.checkedJsonPropName = change.JsonPropName;
    this.checkedValue = change.value;
    this.checkedSelectedItem = change.selectedItem;
    this.checkctiveDeactiveOperation(this.checkedValue, "user role");
    this.CheckUserRoleActiveDeactiveModalBtn.nativeElement.click();
  }
  onConfirmUserActiveDeactiveChange() {
    let userOper = new src_app_core_models_adminstration_userOperation__WEBPACK_IMPORTED_MODULE_4__.userOperation();
    userOper = this.checkedSelectedItem;
    userOper.status = userOper.status ? 1 : 0;
    userOper.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    userOper.softDeleted == null ? 0 : userOper.softDeleted;
    this.systemAdmin.userOpration(userOper).subscribe(result => {
      if (result.items > 0) {
        this.action = "Updated";
        this.saveRoleModalButton.nativeElement.click();
      }
    });
  }
  onCancelUserActiveDeactiveChange() {
    this.loadUsers();
  }
  onConfirmUserRoleActiveDeactiveCahnge() {
    let roleOperation = new src_app_core_models_adminstration_systemUserRoleOperation__WEBPACK_IMPORTED_MODULE_2__.systemUserRoleOperation();
    roleOperation.userId = this.selectedUserId;
    roleOperation.status = this.checkedSelectedItem.status ? 1 : 0;
    roleOperation.roleId = this.checkedSelectedItem.roleId;
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.update;
    this.systemAdmin.systemUserRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Updated";
        this.saveRoleModalButton.nativeElement.click();
      }
    });
  }
  onCancelUserRoleActiveDeactiveCahnge() {
    this.loadUserRoles();
  }
  AddNewRoleToUSer() {
    let roleOperation = new src_app_core_models_adminstration_RoleOperation__WEBPACK_IMPORTED_MODULE_3__.userRoleOperation();
    roleOperation = this.rolesNotAssignToUserForm?.value;
    roleOperation.status = this.rolesNotAssignToUserForm?.value.status ? 1 : 0;
    roleOperation.operationType = src_app_core_utilities_enums_operation_type_enum__WEBPACK_IMPORTED_MODULE_1__.operationType.insert;
    roleOperation.userId = this.selectedUserId;
    this.systemAdmin.systemUserRolesOperations(roleOperation).subscribe(result => {
      if (result.items > 0) {
        this.action = "Created";
        this.saveRoleModalButton.nativeElement.click();
        this.loadUserRoles();
        this.loadrolesNotWithUser();
      }
    });
  }
  checkctiveDeactiveOperation(value, item) {
    if (value == 1) this.checkMessage = `Are you sure you want to activate this ${item} ?`;else this.checkMessage = `Are you sure you want to deactivate this ${item}?`;
  }
  AddNewUser() {
    this.router.navigate(['system-admin/users/new']);
  }
  updateSelectedUser(item) {
    this.router.navigate(['system-admin/users/edit', item.userId]);
  }
  onChangePage(change) {
    this.systemAdmin.getUsers({
      pageNumber: change.pageIndex
    }).subscribe(result => {
      this.users.data = result.items.users;
      this.users.totalPages = result.items.pageCount;
      this.onUserSelection(this.users.data[0]);
    });
  }
  onChangeOrder(change) {
    this.systemAdmin.getUsers({
      orderBy: change.orderBy,
      sortOrder: change.sortOrder
    }).subscribe(result => {
      this.users.data = result.items.users;
      this.users.totalPages = result.items.pageCount;
      this.onUserSelection(this.users.data[0]);
    });
  }
  static #_ = this.ɵfac = function UsersComponent_Factory(t) {
    return new (t || UsersComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_system_admin_service__WEBPACK_IMPORTED_MODULE_5__.SystemAdminService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_10__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: UsersComponent,
    selectors: [["app-users"]],
    viewQuery: function UsersComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c1, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵviewQuery"](_c2, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.saveRoleModalButton = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.CheckUserActiveDeactiveModalBtn = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵloadQuery"]()) && (ctx.CheckUserRoleActiveDeactiveModalBtn = _t.first);
      }
    },
    decls: 130,
    vars: 22,
    consts: [[1, "row"], [1, "col-12"], [1, "card"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section", "accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search1", 1, "accordion-button"], ["id", "act-search1", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "container", "mt-4"], [1, "col-md-3"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], [1, "bi", "bi-plus"], [1, "col-md-9"], [3, "formGroup"], [1, "row", "justify-content-between", "mb-2"], ["for", "username"], ["type", "text", "id", "username", "formControlName", "username", 1, "form-control", "searchBox"], ["for", "name"], ["type", "text", "id", "name", "formControlName", "name", 1, "form-control", "searchBox"], [1, "col-md-6"], [3, "tblHeaders", "tblValues", "isDeleteOperationEnabled", "backendOrdering", "backendPagination", "selectedRow", "updateItemEvent", "selectItemEvent", "paginationEvent", "orderingEvent", "checkboxEvent"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#addUserRoleModel", 1, "btn", "btn-orange", "btn-block"], [3, "tblHeaders", "tblValues", "isUpdateOperationEnabled", "isDeleteOperationEnabled", "checkboxEvent"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#success", 1, "btn", "btn-orange", 2, "display", "none"], ["saveRoleModalButton", ""], ["id", "success", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#userConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckUserActiveDeactiveModalBtn", ""], ["id", "userConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["src", "./assets/img/Check circle.svg"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#userRoleConfirmationModal", 1, "btn", "btn-orange", 2, "display", "none"], ["CheckUserRoleActiveDeactiveModalBtn", ""], ["id", "userRoleConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["id", "addUserRoleModel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "col-md-4"], ["for", "search"], ["formControlName", "roleId", "placeholder", "Select Role", 3, "list", "displayMember", "idMember"], ["type", "checkbox", "id", "search", "formControlName", "status"], ["class", "error-message", 4, "ngIf"], [1, "row", "justify-content-end"], [1, "col-6"], ["type", "button", 1, "btn", "btn-orange", "col-md-3", 3, "disabled", "click"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-light", "col-md-3"], [1, "error-message"]],
    template: function UsersComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "h2", 6)(7, "button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](8, " System Users ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](9, "div", 8)(10, "div", 9)(11, "div", 10)(12, "div", 0)(13, "div", 11)(14, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function UsersComponent_Template_button_click_14_listener() {
          return ctx.AddNewUser();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](15, " Add User ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](16, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](17, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](18, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](19, "form", 15)(20, "div", 16)(21, "div", 11)(22, "label", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](23, "Username");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](24, "input", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](25, "div", 11)(26, "label", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](27, "Full Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](28, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](29, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](30, "app-data-table-viewer", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("updateItemEvent", function UsersComponent_Template_app_data_table_viewer_updateItemEvent_30_listener($event) {
          return ctx.updateSelectedUser($event);
        })("selectItemEvent", function UsersComponent_Template_app_data_table_viewer_selectItemEvent_30_listener($event) {
          return ctx.onUserSelection($event);
        })("paginationEvent", function UsersComponent_Template_app_data_table_viewer_paginationEvent_30_listener($event) {
          return ctx.onChangePage($event);
        })("orderingEvent", function UsersComponent_Template_app_data_table_viewer_orderingEvent_30_listener($event) {
          return ctx.onChangeOrder($event);
        })("checkboxEvent", function UsersComponent_Template_app_data_table_viewer_checkboxEvent_30_listener($event) {
          return ctx.onUserStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](31, "div", 0)(32, "div", 1)(33, "div", 2)(34, "div", 3)(35, "div", 23)(36, "div", 5)(37, "h2", 24)(38, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](39);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](40, "div", 26)(41, "div", 9)(42, "div", 10)(43, "div", 0)(44, "div", 11)(45, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](46, " Assign Role ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](47, "i", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](48, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](49, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](50, "app-data-table-viewer", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("checkboxEvent", function UsersComponent_Template_app_data_table_viewer_checkboxEvent_50_listener($event) {
          return ctx.onUserRoleStatusChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](51, "button", 29, 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](53, "div", 31)(54, "div", 32)(55, "div", 33)(56, "div", 34)(57, "h1", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](58, "img", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](59);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](60, "button", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](61, "button", 38, 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](63, "div", 40)(64, "div", 41)(65, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](66, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](67, "div", 42)(68, "div", 0)(69, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](70, "img", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](71, "div", 1)(72, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](73);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](74, "br")(75, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](76, "button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function UsersComponent_Template_button_click_76_listener() {
          return ctx.onCancelUserActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](77, "img", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](78, "button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function UsersComponent_Template_button_click_78_listener() {
          return ctx.onConfirmUserActiveDeactiveChange();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](79, "img", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](80, "button", 47, 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](82, "div", 49)(83, "div", 41)(84, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](85, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](86, "div", 42)(87, "div", 0)(88, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](89, "img", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](90, "div", 1)(91, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](92);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](93, "br")(94, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](95, "button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function UsersComponent_Template_button_click_95_listener() {
          return ctx.onCancelUserRoleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](96, "img", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](97, "button", 44);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function UsersComponent_Template_button_click_97_listener() {
          return ctx.onConfirmUserRoleActiveDeactiveCahnge();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](98, "img", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](99, "div", 50)(100, "div", 41)(101, "div", 33);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](102, "div", 34);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](103, "div", 42)(104, "div", 0)(105, "div", 1)(106, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](107);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](108, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](109, "div", 1)(110, "form", 15)(111, "div", 0)(112, "div", 51)(113, "label", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](114, "Role");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](115, "app-select-dropdown", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](116, "div", 11)(117, "label", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](118, " Status ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](119, "input", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](120, UsersComponent_div_120_Template, 2, 0, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](121, "div", 56)(122, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](123, "div", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](124, "div", 57)(125, "div", 0)(126, "button", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function UsersComponent_Template_button_click_126_listener() {
          return ctx.AddNewRoleToUSer();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](127, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](128, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](129, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.usersSearchForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("tblHeaders", ctx.userHeaders)("tblValues", ctx.users)("isDeleteOperationEnabled", false)("backendOrdering", true)("backendPagination", true)("selectedRow", ctx.users.data[0]);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx.UserTitleName, " Roles ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("tblHeaders", ctx.roleHeaders)("tblValues", ctx.roles)("isUpdateOperationEnabled", false)("isDeleteOperationEnabled", false);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx.action, " Successfully ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](19);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" ", ctx.checkMessage, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate1"](" Add Role To ", ctx.UserTitleName, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("formGroup", ctx.rolesNotAssignToUserForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("list", ctx.rolesNotWithUser)("displayMember", "roleEname")("idMember", "roleId");
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.rolesNotAssignToUserForm.get("status").hasError("required") && ctx.rolesNotAssignToUserForm.get("status").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("disabled", !ctx.rolesNotAssignToUserForm.valid);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormControlName, _components_data_table_viewer_data_table_viewer_component__WEBPACK_IMPORTED_MODULE_6__.DataTableViewerComponent, _components_select_dropdown_component_select_dropdown_component__WEBPACK_IMPORTED_MODULE_7__.SelectDropdownComponent],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hZG1pbmlzdHJhdGlvbi9zeXN0ZW1BZG1pbi91c2Vycy91c2Vycy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIi5vdXRsaW5lLXJhZGlvLWNvbnRhaW5lcjpob3ZlciAuYmkge1xyXG4gICAgY29sb3I6ICNmYjhkMGQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNlZjljM2Q7XHJcbiAgICBjb2xvcjogI2ZmZmY7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ })

}]);
//# sourceMappingURL=740.fd6bea2c31898a4d.js.map