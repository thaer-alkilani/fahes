"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[116],{

/***/ 81745:
/*!*********************************************************!*\
  !*** ./src/app/core/services/authentication.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationService": () => (/* binding */ AuthenticationService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);





class AuthenticationService {
  constructor(fahesApiService, httpClient) {
    this.fahesApiService = fahesApiService;
    this.httpClient = httpClient;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Authentication/v1';
  }
  azureAuthentication(username, password) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/AzureAuthentication`, {
      username,
      password
    });
  }
  authenticate(username) {
    const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
      'Content-Type': 'application/json'
    });
    const requestOptions = {
      headers: headers
    };
    return this.httpClient.post(`${this.baseUrl}/${this.apiUrl}/authenticate`, {
      username
    }, requestOptions);
  }
  RFIDauthenticate(rfid) {
    const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({
      'Content-Type': 'application/json'
    });
    const requestOptions = {
      headers: headers
    };
    return this.httpClient.post(`${this.baseUrl}/${this.apiUrl}/RFIDauthenticate`, {
      rfid
    }, requestOptions);
  }
  static #_ = this.ɵfac = function AuthenticationService_Factory(t) {
    return new (t || AuthenticationService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: AuthenticationService,
    factory: AuthenticationService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 34005:
/*!********************************************************************!*\
  !*** ./src/app/modules/authentication/authentication.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationComponent": () => (/* binding */ AuthenticationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 60124);


class AuthenticationComponent {
  static #_ = this.ɵfac = function AuthenticationComponent_Factory(t) {
    return new (t || AuthenticationComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: AuthenticationComponent,
    selectors: [["app-authentication"]],
    decls: 1,
    vars: 0,
    template: function AuthenticationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    encapsulation: 2
  });
}

/***/ }),

/***/ 44116:
/*!*****************************************************************!*\
  !*** ./src/app/modules/authentication/authentication.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthenticationModule": () => (/* binding */ AuthenticationModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _authentication_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authentication.component */ 34005);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login/login.component */ 62504);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);









const routes = [{
  path: '',
  redirectTo: 'login',
  pathMatch: 'full'
}, {
  path: '',
  component: _authentication_component__WEBPACK_IMPORTED_MODULE_0__.AuthenticationComponent,
  children: [{
    path: 'login',
    component: _login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent
  }]
}];
class AuthenticationModule {
  static #_ = this.ɵfac = function AuthenticationModule_Factory(t) {
    return new (t || AuthenticationModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: AuthenticationModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes), _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AuthenticationModule, {
    declarations: [_authentication_component__WEBPACK_IMPORTED_MODULE_0__.AuthenticationComponent, _login_login_component__WEBPACK_IMPORTED_MODULE_1__.LoginComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule]
  });
})();

/***/ }),

/***/ 62504:
/*!*****************************************************************!*\
  !*** ./src/app/modules/authentication/login/login.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jwt-decode */ 84738);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _azure_msal_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @azure/msal-angular */ 51107);
/* harmony import */ var src_app_core_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/authentication.service */ 81745);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_authentication_service_ts_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/authentication-service.ts.service */ 21022);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 94666);













const _c0 = ["rfidValue"];
function LoginComponent_div_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 29)(1, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](2, " Incorrect Credentials ");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
  }
}
function LoginComponent_a_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "a", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function LoginComponent_a_23_Template_a_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r3.getRfidCode());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](1, " Login By RFID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
  }
}
class LoginComponent {
  constructor(router, msal, fb, authServ, globalService, authService, sharedData, el, renderer, sidenav) {
    this.router = router;
    this.msal = msal;
    this.fb = fb;
    this.authServ = authServ;
    this.globalService = globalService;
    this.authService = authService;
    this.sharedData = sharedData;
    this.el = el;
    this.renderer = renderer;
    this.sidenav = sidenav;
    this.notAuth = false;
    this.isEnableAD = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.login.enableADLogin;
    this.isEnableRfid = src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.login.enableRfid;
    this.loginForm = this.fb.group({
      username: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required],
      rfidCode: ['']
    });
  }
  ngAfterViewInit() {
    if (this.authService.getAccessToken() == null && this.authService.getLoginHint() != null) {
      localStorage.clear();
    }
  }
  ngOnInit() {
    this.loadUserIPaddress();
    if (!this.loginForm.get('rfidCode').value) {
      console.log("azure");
      this.msal.handleRedirectObservable().subscribe({
        next: result => {
          if (result != null) {
            if (result.accessToken) {
              //Setting up the authentication tokens :
              localStorage.setItem("login_hint", result.idTokenClaims.login_hint);
              this.authService.setAccessToken(result.accessToken);
              this.decodedToken = (0,jwt_decode__WEBPACK_IMPORTED_MODULE_0__.jwtDecode)(result.accessToken);
              this.authServ.authenticate(this.decodedToken.unique_name).subscribe(response => {
                if (response.items != null) {
                  this.user = response.items;
                  this.sharedData.setUserId(this.user.userId);
                  this.sharedData.setStationId(this.user.userAssignPosition.stationId);
                  this.sharedData.setStationName(this.user.userAssignPosition.stationName);
                  this.sharedData.setStationClassification(this.user.userAssignPosition.stationClassification);
                  this.sharedData.setStationSettings(this.user.userAssignPosition.stationSettings);
                  this.sharedData.setInsSection(this.user.userAssignPosition.sectionId);
                  this.sharedData.setSectionName(this.user.userAssignPosition.sectionName);
                  this.sharedData.setBooth(this.user.userAssignPosition.boothId);
                  this.sharedData.setLaneId(this.user.userAssignPosition.laneId);
                  this.sharedData.setLaneName(this.user.userAssignPosition.laneName);
                  this.authService.setAccessToken(result.accessToken);
                  //const encSt = CryptoJS.AES.encrypt(this.user.userAssignPosition.stationName, 'secret_key').toString();
                  localStorage.setItem("station", this.user.userAssignPosition.stationName);
                  localStorage.setItem("stationId", this.user.userAssignPosition.stationId.toString());
                  localStorage.setItem("booth", this.user.userAssignPosition.boothId.toString());
                  localStorage.setItem("boothDesc", this.user.userAssignPosition.boothName);
                  localStorage.setItem("stationClassification", this.user.userAssignPosition.stationClassification.toString());
                  localStorage.setItem("userName", this.user.userFullName);
                  localStorage.setItem("sectionId", this.user.userAssignPosition.sectionId.toString());
                  localStorage.setItem("sectionName", this.user.userAssignPosition.sectionName);
                  localStorage.setItem("userId", this.user.userId.toString());
                  localStorage.setItem("laneId", this.user.userAssignPosition.laneId.toString());
                  localStorage.setItem("laneName", this.user.userAssignPosition.laneName);
                  this.sidenav.getSideMenu(this.user.userId).subscribe(data => {
                    for (let i = 0; i < data.items.length; i++) {
                      if (data.items[i].moduleId === 3) {
                        this.router.navigate(['/inspection/landing-inspection']);
                        break;
                      } else {
                        this.router.navigate(['/registration']);
                      }
                    }
                  });
                } else {
                  this.errorMessageAuth = response.errorMessage;
                }
              }, error => {
                this.errorMessageAuth = error.error.errorMessage;
              });
            }
          }
        },
        error: error => {}
      });
    } else {
      this.sharedData.setRfid(true);
    }
    if (this.isEnableRfid) {
      //  const modalElement = document.getElementById('rfidModal');
      const rfidModal = this.el.nativeElement.querySelector('#rfidModal');
      this.renderer.addClass(rfidModal, 'show');
      this.renderer.setStyle(rfidModal, 'display', 'block');
    }
  }
  closeRfid() {
    const rfidModal = this.el.nativeElement.querySelector('#rfidModal');
    this.renderer.removeClass(rfidModal, 'show');
    this.renderer.setStyle(rfidModal, 'display', 'none');
    document.body.style.overflow = 'auto';
  }
  loadUserIPaddress() {
    this.globalService.getUserIpAddress().subscribe(res => {
      this.ipAddress = res.items;
    });
  }
  loginAzure() {
    this.msal.loginRedirect({
      scopes: src_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.msalConfig.auth.scopes
    }).subscribe();
  }
  LogIn() {
    this.authServ.azureAuthentication(this.loginForm.get('username').value, this.loginForm.get('password').value).subscribe(response => {
      const items = response.items;
      if (items) {
        this.authService.setAccessToken(items);
        this.router.navigate(['/registration']);
      } else {
        this.notAuth = true;
      }
    });
  }
  getRfidCode() {
    console.log("testt");
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#rfidValue');
      if (myInput) {
        myInput.focus();
      }
    }, 200);
  }
  onRfidCodeInput(event) {
    const barcodeValue = event.target.value;
    this.sharedData.setRfid(true);
    localStorage.setItem('rfid', barcodeValue);
    this.loginForm.get('rfidCode').setValue(barcodeValue);
    console.log(barcodeValue);
    this.isRfidScanned = true;
    this.readRFIDCode();
  }
  readRFIDCode() {
    this.authServ.RFIDauthenticate(this.loginForm.get("rfidCode").value).subscribe(res => {
      if (res.items) {
        this.user = res.items;
        this.sharedData.setUserId(this.user.userId);
        this.sharedData.setStationId(this.user.userAssignPosition.stationId);
        this.sharedData.setStationName(this.user.userAssignPosition.stationName);
        this.sharedData.setStationClassification(this.user.userAssignPosition.stationClassification);
        this.sharedData.setStationSettings(this.user.userAssignPosition.stationSettings);
        this.sharedData.setInsSection(this.user.userAssignPosition.sectionId);
        this.sharedData.setSectionName(this.user.userAssignPosition.sectionName);
        this.sharedData.setBooth(this.user.userAssignPosition.boothId);
        this.sharedData.setLaneId(this.user.userAssignPosition.laneId);
        this.sharedData.setLaneName(this.user.userAssignPosition.laneName);
        //    this.authService.setAccessToken("eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlhSdmtvOFA3QTNVYVdTblU3Yk05blQwTWpoQSIsImtpZCI6IlhSdmtvOFA3QTNVYVdTblU3Yk05blQwTWpoQSJ9.eyJhdWQiOiJhcGk6Ly9lN2FiNDczZC00YWEzLTQ0ZjMtYWQzNS1hY2I2YTBiM2JiOTYiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82YmNlMWViMy04ZDZkLTRjZmQtYjZlZS05MTJmMTUyZDYwYzMvIiwiaWF0IjoxNzEwNjkzODU0LCJuYmYiOjE3MTA2OTM4NTQsImV4cCI6MTcxMDY5Nzc4NCwiYWNyIjoiMSIsImFpbyI6IkFWUUFxLzhXQUFBQXh6ZE9ESUdGQWN4YkppZkFUVFJaS0VBY1ZGa3hWTWkyYk0vQm52WmpjZWtzMTRLZzZIVVhWNGp6SW5lMnBNM3VuQm81YWNZamEyQWF0QzRjQTBoREFiT0RGMU5UUitZU0pxdXpLeFc1UzBBPSIsImFtciI6WyJwd2QiLCJtZmEiXSwiYXBwaWQiOiJkMDg1YmJiNC0xZmRlLTQ4OTgtOTJjNS1iM2M5YWEzYTc1ODkiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IlVzZXIxIiwiZ2l2ZW5fbmFtZSI6IkRpeWFyIiwiaXBhZGRyIjoiMTg1LjIwNi4yMDAuMjI0IiwibmFtZSI6IkRpeWFyIFVzZXIxIiwib2lkIjoiZTcxZmFjMDktMzk4Ni00ZTA4LWIzMmEtOTA1NTM3OWI4MjY2IiwicmgiOiIwLkFYb0FzeDdPYTIyTl9VeTI3cEV2RlMxZ3d6MUhxLWVqU3ZORXJUV3N0cUN6dTVaNkFGOC4iLCJzY3AiOiJVc2VyLkluZm8iLCJzdWIiOiJRZWhsWWtjT0RtazVEWk1fSEhYYkVob245VXYxS2swSzVxVExPQVJlMDVjIiwidGlkIjoiNmJjZTFlYjMtOGQ2ZC00Y2ZkLWI2ZWUtOTEyZjE1MmQ2MGMzIiwidW5pcXVlX25hbWUiOiJkaXlhcnVzZXIxQHdvcW9kLm9ubWljcm9zb2Z0LmNvbSIsInVwbiI6ImRpeWFydXNlcjFAd29xb2Qub25taWNyb3NvZnQuY29tIiwidXRpIjoiYXBvdE9VRDc5RUN4OTV5M0lNTmVBQSIsInZlciI6IjEuMCJ9.EXaZKM3XSQYqPLHLlvw9ZLwsv2OZRu40z1x58cITjnMrnSMCLXG0D6cJh0ujHt5gArmjAcShly2KugAqL3CgwnocMexT-32_bZ9udfbVCgF6n4aDNQNHQKVly1t4ZOn7nAx7e9T6ieK-E61U-MmyK1NS61bg3JwKVneu-vHtO_Bm5km4vSrhwjgpCtJOrKDxadrOziwZptbnR1XCKJWj34ceU1mCN3857ruA1tkXyEXGLkSuFIyhUoB4I3l_qzpG0gDPUahJmGe8UgKDKYEBhm-tZ4hqqx6GmVWbz5WNMSc5s3aE6D3BzMcDGfenLi2BXFL4OQ7cRh9nx1_a666tTw");
        //const encSt = CryptoJS.AES.encrypt(this.user.userAssignPosition.stationName, 'secret_key').toString();
        localStorage.setItem("station", this.user.userAssignPosition.stationName);
        localStorage.setItem("stationId", this.user.userAssignPosition.stationId.toString());
        localStorage.setItem("booth", this.user.userAssignPosition.boothId.toString());
        localStorage.setItem("boothDesc", this.user.userAssignPosition.boothName);
        localStorage.setItem("stationClassification", this.user.userAssignPosition.stationClassification.toString());
        localStorage.setItem("userName", this.user.userFullName);
        localStorage.setItem("sectionId", this.user.userAssignPosition.sectionId.toString());
        localStorage.setItem("sectionName", this.user.userAssignPosition.sectionName);
        localStorage.setItem("userId", this.user.userId.toString());
        localStorage.setItem("laneId", this.user.userAssignPosition.laneId.toString());
        localStorage.setItem("laneName", this.user.userAssignPosition.laneName);
        this.authService.setAccessToken(res.items.rfidSessionDetails.token);
        this.sidenav.getSideMenu(this.user.userId).subscribe(data => {
          for (let i = 0; i < data.items.length; i++) {
            if (data.items[i].moduleId === 3) {
              this.router.navigate(['/inspection/landing-inspection']);
              break;
            } else {
              this.router.navigate(['/registration']);
            }
          }
        });
      } else {
        console.log(res.errorMessage);
        const modalElement = document.getElementById('rfid');
        if (modalElement) {
          modalElement.classList.remove('show');
          modalElement.style.display = 'none';
          document.body.classList.remove('modal-open');
          const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
          if (modalBackdrop) {
            modalBackdrop.remove();
          }
          document.body.style.overflow = 'auto';
        }
        this.errorMessageAuth = res.errorMessage;
      }
    }, error => {
      console.log(error);
      this.errorMessageAuth = error.error.errorMessage;
      const modalElement = document.getElementById('rfid');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    });
    const modalElement = document.getElementById('rfid');
    if (modalElement) {
      modalElement.classList.remove('show');
      modalElement.style.display = 'none';
      document.body.classList.remove('modal-open');
      const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
      if (modalBackdrop) {
        modalBackdrop.remove();
      }
      document.body.style.overflow = 'auto';
    }
  }
  static #_ = this.ɵfac = function LoginComponent_Factory(t) {
    return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_azure_msal_angular__WEBPACK_IMPORTED_MODULE_10__.MsalService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__.AuthenticationService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_3__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_authentication_service_ts_service__WEBPACK_IMPORTED_MODULE_4__.AuthenticationServiceTsService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_5__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_7__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_7__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_6__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({
    type: LoginComponent,
    selectors: [["app-login"]],
    viewQuery: function LoginComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.rfidValue = _t.first);
      }
    },
    decls: 42,
    vars: 7,
    consts: [["lang", "en"], [3, "formGroup"], [1, "login-wrap"], [1, "login-sec"], ["src", "./assets/img/logo.png", 1, "login-logo"], [1, "row"], [1, "col-12"], [1, "form-group"], [1, "iwi"], ["type", "text", "placeholder", "Username", "formControlName", "username", 1, "form-control", 3, "disabled"], ["src", "./assets/img/icon _person.svg"], ["type", "password", "placeholder", "Password", "formControlName", "password", 1, "form-control", 3, "disabled"], ["src", "./assets/img/icon _lock.svg"], ["class", "col-12", "id", "incorrectCred", 4, "ngIf"], [1, "col-12", "end-btns"], ["id", "azureLink", 3, "click"], ["id", "rfid", "data-bs-toggle", "modal", "data-bs-target", "#rfidModal", 3, "click", 4, "ngIf"], ["type", "button", "disabled", "", 1, "btn", "btn-login", 3, "click"], [1, "error-message"], ["id", "rfidModal", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["src", "./assets/img/scan.svg", "width", "50px"], ["type", "button", 1, "btn-close", 3, "click"], [1, "modal-body"], ["type", "password", "id", "rfidValue", "formControlName", "rfidCode", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["rfidValue", ""], ["id", "incorrectCred", 1, "col-12"], ["id", "rfid", "data-bs-toggle", "modal", "data-bs-target", "#rfidModal", 3, "click"]],
    template: function LoginComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "html", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "body")(3, "form", 1)(4, "div", 2)(5, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](6, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "div", 5)(8, "div", 6)(9, "div", 7)(10, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](11, "input", 9)(12, "img", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](13, "div", 6)(14, "div", 7)(15, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](16, "input", 11)(17, "img", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](18, LoginComponent_div_18_Template, 3, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](19, "div", 5)(20, "div", 14)(21, "a", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function LoginComponent_Template_a_click_21_listener() {
          return ctx.loginAzure();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](22, " Login Using Azure ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](23, LoginComponent_a_23_Template, 2, 0, "a", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](24, "div", 6)(25, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_25_listener() {
          return ctx.LogIn();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](26, "Log In");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](27, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](29, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](30);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](31, "div", 19)(32, "div", 20)(33, "div", 21)(34, "div", 22)(35, "h1", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](36, "img", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](37, " RFID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](38, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("click", function LoginComponent_Template_button_click_38_listener() {
          return ctx.closeRfid();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](39, "div", 26)(40, "input", 27, 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("keyup.enter", function LoginComponent_Template_input_keyup_enter_40_listener($event) {
          return ctx.onRfidCodeInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("formGroup", ctx.loginForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("disabled", !ctx.isEnableAD);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("disabled", !ctx.isEnableAD);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.notAuth);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.isEnableRfid);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.errorMessageAuth, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtextInterpolate1"](" ", ctx.ipAddress, " ");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlName],
    styles: ["#incorrectCred[_ngcontent-%COMP%] {\r\n    color: red;\r\n}\r\n\r\n#azureLink[_ngcontent-%COMP%] {\r\n    float: left;\r\n}\r\n\r\n#rfid[_ngcontent-%COMP%] {\r\n    float: right;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9hdXRoZW50aWNhdGlvbi9sb2dpbi9sb2dpbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksVUFBVTtBQUNkOztBQUVBO0lBQ0ksV0FBVztBQUNmOztBQUVBO0lBQ0ksWUFBWTtBQUNoQiIsInNvdXJjZXNDb250ZW50IjpbIiNpbmNvcnJlY3RDcmVkIHtcclxuICAgIGNvbG9yOiByZWQ7XHJcbn1cclxuXHJcbiNhenVyZUxpbmsge1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcbn1cclxuXHJcbiNyZmlkIHtcclxuICAgIGZsb2F0OiByaWdodDtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 84738:
/*!****************************************************!*\
  !*** ./node_modules/jwt-decode/build/esm/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvalidTokenError": () => (/* binding */ InvalidTokenError),
/* harmony export */   "jwtDecode": () => (/* binding */ jwtDecode)
/* harmony export */ });
class InvalidTokenError extends Error {}
InvalidTokenError.prototype.name = "InvalidTokenError";
function b64DecodeUnicode(str) {
  return decodeURIComponent(atob(str).replace(/(.)/g, (m, p) => {
    let code = p.charCodeAt(0).toString(16).toUpperCase();
    if (code.length < 2) {
      code = "0" + code;
    }
    return "%" + code;
  }));
}
function base64UrlDecode(str) {
  let output = str.replace(/-/g, "+").replace(/_/g, "/");
  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += "==";
      break;
    case 3:
      output += "=";
      break;
    default:
      throw new Error("base64 string is not of the correct length");
  }
  try {
    return b64DecodeUnicode(output);
  } catch (err) {
    return atob(output);
  }
}
function jwtDecode(token, options) {
  if (typeof token !== "string") {
    throw new InvalidTokenError("Invalid token specified: must be a string");
  }
  options || (options = {});
  const pos = options.header === true ? 0 : 1;
  const part = token.split(".")[pos];
  if (typeof part !== "string") {
    throw new InvalidTokenError(`Invalid token specified: missing part #${pos + 1}`);
  }
  let decoded;
  try {
    decoded = base64UrlDecode(part);
  } catch (e) {
    throw new InvalidTokenError(`Invalid token specified: invalid base64 for part #${pos + 1} (${e.message})`);
  }
  try {
    return JSON.parse(decoded);
  } catch (e) {
    throw new InvalidTokenError(`Invalid token specified: invalid json for part #${pos + 1} (${e.message})`);
  }
}

/***/ })

}]);
//# sourceMappingURL=116.09de0b1fd8cd064a.js.map