"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[313],{

/***/ 9059:
/*!*******************************************************!*\
  !*** ./src/app/core/enums/defect-evaluations.enum.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DEFECT_EVALUATIONS": () => (/* binding */ DEFECT_EVALUATIONS)
/* harmony export */ });
var DEFECT_EVALUATIONS;
(function (DEFECT_EVALUATIONS) {
  DEFECT_EVALUATIONS[DEFECT_EVALUATIONS["LET_THE_INSPECTOR_DECIDE"] = 1] = "LET_THE_INSPECTOR_DECIDE";
  DEFECT_EVALUATIONS[DEFECT_EVALUATIONS["OK_COMMENT"] = 2] = "OK_COMMENT";
  DEFECT_EVALUATIONS[DEFECT_EVALUATIONS["MAJOR"] = 3] = "MAJOR";
  DEFECT_EVALUATIONS[DEFECT_EVALUATIONS["MINOR"] = 4] = "MINOR";
})(DEFECT_EVALUATIONS || (DEFECT_EVALUATIONS = {}));

/***/ }),

/***/ 5706:
/*!**************************************************!*\
  !*** ./src/app/core/enums/defect-source.enum.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DEFECT_SOURCE": () => (/* binding */ DEFECT_SOURCE)
/* harmony export */ });
var DEFECT_SOURCE;
(function (DEFECT_SOURCE) {
  DEFECT_SOURCE[DEFECT_SOURCE["INSPECTOR"] = 1] = "INSPECTOR";
})(DEFECT_SOURCE || (DEFECT_SOURCE = {}));

/***/ }),

/***/ 3165:
/*!****************************************************!*\
  !*** ./src/app/core/enums/inspection.tabs.enum.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "INSPECTION_TABS": () => (/* binding */ INSPECTION_TABS)
/* harmony export */ });
var INSPECTION_TABS;
(function (INSPECTION_TABS) {
  INSPECTION_TABS[INSPECTION_TABS["ALL"] = -2] = "ALL";
  INSPECTION_TABS[INSPECTION_TABS["EXCLUDED"] = -1] = "EXCLUDED";
  INSPECTION_TABS[INSPECTION_TABS["LEGAL"] = 1] = "LEGAL";
  INSPECTION_TABS[INSPECTION_TABS["TECHNICAL"] = 2] = "TECHNICAL";
  INSPECTION_TABS[INSPECTION_TABS["OK_COMMENT"] = 3] = "OK_COMMENT";
  INSPECTION_TABS[INSPECTION_TABS["MINOR"] = 4] = "MINOR";
  INSPECTION_TABS[INSPECTION_TABS["HISTORY"] = 5] = "HISTORY";
})(INSPECTION_TABS || (INSPECTION_TABS = {}));

/***/ }),

/***/ 2444:
/*!*******************************************************************!*\
  !*** ./src/app/core/guards/confirm-on-component-changes.guard.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanExitGuard": () => (/* binding */ CanExitGuard)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/api */ 4356);


class CanExitGuard {
  constructor(confirmationService) {
    this.confirmationService = confirmationService;
  }
  canDeactivate(component) {
    if (component.canDeactivate) {
      return component.canDeactivate();
    }
    return true;
  }
  static #_ = this.ɵfac = function CanExitGuard_Factory(t) {
    return new (t || CanExitGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](primeng_api__WEBPACK_IMPORTED_MODULE_1__.ConfirmationService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
    token: CanExitGuard,
    factory: CanExitGuard.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 5220:
/*!*****************************************************!*\
  !*** ./src/app/core/models/inspection.interface.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchInspection": () => (/* binding */ SearchInspection)
/* harmony export */ });
/* harmony import */ var _enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../enums/vehicle-search-types.enum */ 1114);

class SearchInspection {
  constructor(query, searchType = _enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__.VEHICLE_SEARCH_TYPES.PLATE_NO) {
    this.searchType = 2;
    this.serviceType = 1;
    this.sectionId = 1;
    this.searchText = query;
    this.searchType = +searchType;
  }
}

/***/ }),

/***/ 4354:
/*!***************************************************************************!*\
  !*** ./src/app/core/resolvers/inspection/get-vehicle-details.resolver.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetVehicleDetailsResolver": () => (/* binding */ GetVehicleDetailsResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 9337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 3158);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_inspection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../services/inspection.service */ 7875);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);




class GetVehicleDetailsResolver {
  constructor(_service, _router) {
    this._service = _service;
    this._router = _router;
  }
  resolve(route, state) {
    const query = route.queryParams['query'];
    const searchType = route.queryParams['searchType'];
    if (!query) return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    return this._service.search(query, searchType).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.tap)(x => {
      if (!x) this._router.navigate(['/portal/inspection'], {});
      return x;
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(_ => {
      // this._router.navigate(['/error'], {});
      return rxjs__WEBPACK_IMPORTED_MODULE_1__.EMPTY;
    }));
  }
  static #_ = this.ɵfac = function GetVehicleDetailsResolver_Factory(t) {
    return new (t || GetVehicleDetailsResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_services_inspection_service__WEBPACK_IMPORTED_MODULE_0__.InspectionService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: GetVehicleDetailsResolver,
    factory: GetVehicleDetailsResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 7875:
/*!*****************************************************!*\
  !*** ./src/app/core/services/inspection.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionService": () => (/* binding */ InspectionService)
/* harmony export */ });
/* harmony import */ var _utilities_apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utilities/apis */ 1603);
/* harmony import */ var _models_inspection_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../models/inspection.interface */ 5220);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var _enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../enums/defect-evaluations.enum */ 9059);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fahes.api.service */ 5159);






class InspectionService {
  constructor(_baseService) {
    this._baseService = _baseService;
  }
  search(payload, searchType) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.SearchInpsectionRequestDetails, new _models_inspection_interface__WEBPACK_IMPORTED_MODULE_1__.SearchInspection(payload, searchType)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(x => {
      return {
        ...x,
        selectedDefects: this.mapDefects(x.selectedDefects, !x.isEditableIspection),
        excludedDefects: this.mapDefects(x.excludedDefects),
        plateTypeName: {
          NameEn: x.plateTypeName,
          NameAr: x.plateTypeNameAr
        },
        vehicleCategoryValueLocalized: {
          NameEn: x.vehicleCategoryValue,
          NameAr: x.vehicleCategoryValueAr
        }
      };
    }));
  }
  mapDefects(defects, hideIcon = false) {
    return defects.map(x => {
      return {
        ...x,
        showAttachments: x.hasFiles > 0,
        commentTypeName: _enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS[x.commentType],
        hideIcon: hideIcon
      };
    });
  }
  GetMainVisualDefects(requestId) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.GetMainVisualDefects, {
      requestId
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(x => x.map(y => {
      return {
        Id: y.mainDefectId,
        NameEn: y.defectNameEn,
        NameAr: y.defectNameAr
      };
    })));
  }
  GetSubVisualDefects(mainDefectId) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.GetSubVisualDefects, {
      mainDefectId
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(x => x.map(y => {
      return {
        Id: y.subDefectId,
        NameEn: y.descriptionEn,
        NameAr: y.descriptionAr
      };
    })));
  }
  GetSubVisualDefectComments(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.GetSubVisualDefectComments, payload).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(x => x.map(y => {
      return {
        Id: y.defCommentId,
        NameEn: y.descriptionEn,
        NameAr: y.descriptionAr,
        extra: y
      };
    })));
  }
  createDefects(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.CreateInspectionResult, payload);
  }
  deleteDefects(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.DeleteInspectionDefectList, payload);
  }
  getDefectAttachments(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.GlobalConfigs.GetDefectAttachments, payload);
  }
  getInspectionResultDetails(requestId) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Inspection.GetInspectionResultDetails, {
      requestId
    });
  }
  static #_ = this.ɵfac = function InspectionService_Factory(t) {
    return new (t || InspectionService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_3__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
    token: InspectionService,
    factory: InspectionService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 9739:
/*!************************************************************************************************************************!*\
  !*** ./src/app/features/inspection/current-inspection-vehicle-details/current-inspection-vehicle-details.component.ts ***!
  \************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CurrentInspectionVehicleDetailsComponent": () => (/* binding */ CurrentInspectionVehicleDetailsComponent)
/* harmony export */ });
/* harmony import */ var C_Users_thkil_MOI_MOI_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/api */ 4356);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _inspection_vehicle_details_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../inspection-vehicle-details/inspection-vehicle-details.component */ 5047);







class CurrentInspectionVehicleDetailsComponent {
  constructor(_route, confirmationService, _translate) {
    this._route = _route;
    this.confirmationService = confirmationService;
    this._translate = _translate;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription();
    this.hasChanges = false;
  }
  ngOnInit() {
    this.getResolved();
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_3__.map)(el => el['data'])).subscribe(res => {
      if (res) {
        res.station = {
          NameEn: res.stationNameEn,
          NameAr: res.stationNameAr
        };
        if (typeof res.plateTypeName == 'string') {
          res.plateTypeName = {
            NameEn: res.plateTypeName,
            NameAr: res.plateTypeName
          };
        }
        this.items = res;
      }
    });
    this.subscription.add(sub);
  }
  canExit(hasChanges) {
    this.hasChanges = hasChanges;
  }
  canDeactivate() {
    var _this = this;
    return (0,C_Users_thkil_MOI_MOI_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // return false
      if (_this.hasChanges) {
        if (yield _this.confirm()) {
          return true;
        } else {
          return false;
        }
      } else {
        return true;
      }
    })();
  }
  confirmLeaveWithoutSave() {
    return this.confirmationService.confirm({
      message: `${this._translate.instant('canExit')}`,
      header: `${this._translate.instant('Confirmation')}`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: `${this._translate.instant('Confirm')}`,
      rejectLabel: `${this._translate.instant('Cancel')}`,
      accept: () => {
        return true;
      },
      reject: () => {
        return false;
      }
    });
  }
  confirm({
    message = `${this._translate.instant('canExitMessage')}`,
    header = `${this._translate.instant('Confirmation')}`,
    icon = "pi pi-exclamation-triangle",
    acceptLabel = `${this._translate.instant('Confirm')}`,
    rejectLabel = `${this._translate.instant('Cancel')}`
  } = {}) {
    return new Promise(resolve => {
      console.log(this.confirmationService.confirm({
        message,
        header,
        icon,
        acceptLabel,
        rejectLabel,
        accept: () => {
          resolve(true);
        },
        reject: () => {
          resolve(false);
        }
      }));
    });
  }
  static #_ = this.ɵfac = function CurrentInspectionVehicleDetailsComponent_Factory(t) {
    return new (t || CurrentInspectionVehicleDetailsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_6__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslateService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: CurrentInspectionVehicleDetailsComponent,
    selectors: [["app-current-inspection-vehicle-details"]],
    decls: 1,
    vars: 1,
    consts: [[3, "items", "hasChanges"]],
    template: function CurrentInspectionVehicleDetailsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-inspection-vehicle-details", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("hasChanges", function CurrentInspectionVehicleDetailsComponent_Template_app_inspection_vehicle_details_hasChanges_0_listener($event) {
          return ctx.canExit($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("items", ctx.items);
      }
    },
    dependencies: [_inspection_vehicle_details_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_1__.InspectionVehicleDetailsComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 1704:
/*!********************************************************************!*\
  !*** ./src/app/features/inspection/inspection-handlers.service.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionHandlersService": () => (/* binding */ InspectionHandlersService)
/* harmony export */ });
/* harmony import */ var src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/defect-evaluations.enum */ 9059);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 8699);



class InspectionHandlersService {
  constructor(_translate) {
    this._translate = _translate;
  }
  mapSelectedDefects(arr) {
    return arr.map(x => this.AddNewDefects(x));
  }
  AddNewDefects(defect) {
    return {
      defCommentCode: defect.defCommentCode,
      description: {
        NameEn: `${defect?.defectCommentDescriptionEn ? defect?.defectCommentDescriptionEn : defect.defectCommentEn}`,
        NameAr: `${defect?.defectCommentDescriptionAr ? defect?.defectCommentDescriptionAr : defect.defectCommentAr}`
      },
      mainCatrgoryDefectDescription: {
        NameEn: `${defect?.mainCatrgoryDefectDescriptionEn}`,
        NameAr: `${defect?.mainCatrgoryDefectDescriptionAR}`
      },
      subCatrgoryDefectDescription: {
        NameEn: `${defect?.subCatrgoryDefectDescriptionEn}`,
        NameAr: `${defect?.subCatrgoryDefectDescriptionAr}`
      },
      descriptionEn: `${defect?.descriptionEn} - ${defect.selectedDefectLocation}`,
      descriptionAr: `${defect?.descriptionAr} - ${defect.selectedDefectLocation}`,
      remarks: [defect?.remarks],
      item: defect,
      commentTypeName: src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_0__.DEFECT_EVALUATIONS[defect.commentType]
    };
  }
  mapToExcluded(excludedDefects) {
    return excludedDefects.map(x => {
      return {
        ...x,
        descriptionEn: x.descriptionEn || x.defectCommentEn,
        descriptionAr: x.descriptionAr || x.defectCommentAr,
        hideIcon: true
      };
    });
  }
  static #_ = this.ɵfac = function InspectionHandlersService_Factory(t) {
    return new (t || InspectionHandlersService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslateService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
    token: InspectionHandlersService,
    factory: InspectionHandlersService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 4951:
/*!******************************************************************!*\
  !*** ./src/app/features/inspection/inspection-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionRoutingModule": () => (/* binding */ InspectionRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _vehicle_inspection_audit_form_vehicle_inspection_audit_form_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vehicle-inspection-audit-form/vehicle-inspection-audit-form.component */ 3947);
/* harmony import */ var src_app_core_resolvers_inspection_get_vehicle_details_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/resolvers/inspection/get-vehicle-details.resolver */ 4354);
/* harmony import */ var _current_inspection_vehicle_details_current_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./current-inspection-vehicle-details/current-inspection-vehicle-details.component */ 9739);
/* harmony import */ var src_app_core_guards_confirm_on_component_changes_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/guards/confirm-on-component-changes.guard */ 2444);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);







const routes = [{
  path: '',
  component: _vehicle_inspection_audit_form_vehicle_inspection_audit_form_component__WEBPACK_IMPORTED_MODULE_0__.VehicleInspectionAuditFormComponent,
  data: {
    title: "VehicleInspectionAuditSystem"
  }
}, {
  path: 'vehicle-details',
  component: _current_inspection_vehicle_details_current_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_2__.CurrentInspectionVehicleDetailsComponent,
  canDeactivate: [src_app_core_guards_confirm_on_component_changes_guard__WEBPACK_IMPORTED_MODULE_3__.CanExitGuard],
  data: {
    title: "VehicleDetails"
  },
  resolve: {
    data: src_app_core_resolvers_inspection_get_vehicle_details_resolver__WEBPACK_IMPORTED_MODULE_1__.GetVehicleDetailsResolver
  }
}
// {
//   path: 'vehicle-history-details',
//   component: InspectionVehicleDetailsComponent,
//   data: {title: "VehicleHistoryDetails"},
//   resolve: {data: GetVehicleHistoryDetailsResolver}
// }
];

class InspectionRoutingModule {
  static #_ = this.ɵfac = function InspectionRoutingModule_Factory(t) {
    return new (t || InspectionRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: InspectionRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](InspectionRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterModule]
  });
})();

/***/ }),

/***/ 4960:
/*!***********************************************************************************************************************************************!*\
  !*** ./src/app/features/inspection/inspection-vehicle-details/inspection-vehicle-details-body/add-defects-form/add-defects-form.component.ts ***!
  \***********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddDefectsFormComponent": () => (/* binding */ AddDefectsFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 1640);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 8977);
/* harmony import */ var src_app_core_enums_Lookups_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/Lookups.enum */ 7741);
/* harmony import */ var src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/enums/defect-evaluations.enum */ 9059);
/* harmony import */ var src_app_core_enums_defect_source_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/enums/defect-source.enum */ 5706);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var src_app_shared_inputs_multi_check_input_multi_check_input_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/inputs/multi-check-input/multi-check-input.component */ 3454);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);
/* harmony import */ var src_app_core_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/inspection.service */ 7875);
/* harmony import */ var src_app_core_services_lookups_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/lookups.service */ 3846);
/* harmony import */ var _shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 8699);














class AddDefectsFormComponent {
  constructor(_fb, _dialogService, _inspections, ref, _lockups) {
    this._fb = _fb;
    this._dialogService = _dialogService;
    this._inspections = _inspections;
    this.ref = ref;
    this._lockups = _lockups;
    this.submitted = false;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_8__.Subscription();
    this.controls = [{
      label: 'Main',
      name: 'main',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__.INPUTS_TYPES.LIST,
      required: true,
      width: 'col-md-6',
      filter: true,
      list: []
    }, {
      label: 'Sub',
      name: 'sub',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__.INPUTS_TYPES.LIST,
      required: true,
      width: 'col-md-6',
      filter: true,
      list: []
    }, {
      label: 'Comment',
      name: 'defectsCommentId',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__.INPUTS_TYPES.LIST,
      required: true,
      width: 'col-md-12',
      filter: true,
      list: []
    }, {
      label: 'remarks',
      name: 'remarks',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__.INPUTS_TYPES.TEXT_AREA,
      required: false,
      width: 'col-md-12'
    }];
    this.evaluations = [];
  }
  ngOnInit() {
    this.initForm();
    this.getData();
  }
  initForm() {
    this.form = this._fb.group({
      requestId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      sectionId: [1, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      inspectionStepId: [null],
      inspectionReqId: [null],
      inspectionServiceId: [null],
      defectMode: [null],
      defectsCommentId: [{
        value: null,
        disabled: true
      }, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      defectClassification: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      remarks: [null],
      status: [1],
      defectSource: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      evalutionId: [null],
      locations: [[]],
      axle: [{
        value: 0,
        disabled: true
      }],
      // TODO
      createdBy: [4, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      main: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      sub: [{
        value: null,
        disabled: true
      }, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required],
      selectedComment: [null]
    });
  }
  getData() {
    this.dialogData = this._dialogService.data;
    this.form.patchValue({
      requestId: this.dialogData.data.requestId,
      inspectionStepId: this.dialogData.data.inspectionStepId,
      inspectionReqId: this.dialogData.data.inspectionReqId,
      inspectionServiceId: this.dialogData.data.inspectionServiceId,
      defectSource: src_app_core_enums_defect_source_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_SOURCE.INSPECTOR
    });
    this.getMainVisualDefects();
  }
  getMainVisualDefects() {
    (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.forkJoin)({
      evaluations: this._lockups.getLookup(src_app_core_enums_Lookups_enum__WEBPACK_IMPORTED_MODULE_0__.LOOKUPS.EVALUATIONS),
      defects: this._inspections.GetMainVisualDefects(1)
    }).subscribe(({
      defects,
      evaluations
    }) => {
      this.controls.find(x => x.name === 'main').list = defects;
      this.evaluations = evaluations.map(x => {
        return {
          id: x.lkCodeValue,
          value: x.lkValueEname,
          // value: {NameEn: x.lkValueEname, NameAr: x.lkValueAname},
          isLocalized: true
        };
      });
    });
    this.onMainDefectsChange();
    this.onSubDefectsChange();
    this.onCommentChange();
  }
  onMainDefectsChange() {
    const sub = this.form.controls['main'].valueChanges.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.distinctUntilChanged)()).subscribe(input => {
      if (input) {
        this.form.controls['sub'].patchValue(null);
        this.form.controls['sub'].enable();
        this.form.controls['defectsCommentId'].patchValue(null);
        this.form.controls['defectsCommentId'].disable();
        this._inspections.GetSubVisualDefects(input).subscribe(res => {
          this.controls.find(x => x.name === 'sub').list = res;
        });
      } else {
        this.form.controls['sub'].patchValue(null);
        this.form.controls['sub'].disable();
        this.form.controls['defectsCommentId'].patchValue(null);
        this.form.controls['defectsCommentId'].disable();
      }
    });
    this.subscription.add(sub);
  }
  onSubDefectsChange() {
    const sub = this.form.controls['sub'].valueChanges.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.distinctUntilChanged)()).subscribe(input => {
      if (input) {
        const payload = {
          mainDefectId: this.form.getRawValue().main,
          subDefectId: this.form.getRawValue().sub
        };
        this.form.controls['defectsCommentId'].patchValue(null);
        this.form.controls['defectsCommentId'].enable();
        this._inspections.GetSubVisualDefectComments(payload).subscribe(res => {
          this.dialogData.selectedDefects.forEach(x => {
            const input = res.find(y => y.extra.defCommentId === x.defCommentId);
            // ?.disabled = true
            if (input) {
              input.disabled = true;
            }
          });
          this.controls.find(x => x.name === 'defectsCommentId').list = res;
        });
      } else {
        this.form.controls['defectsCommentId'].patchValue(null);
        this.form.controls['defectsCommentId'].disable();
      }
    });
    this.subscription.add(sub);
  }
  onCommentChange() {
    const sub = this.form.controls['defectsCommentId'].valueChanges.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_11__.distinctUntilChanged)()).subscribe(input => {
      if (input) {
        const inputList = this.controls.find(x => x.name === 'defectsCommentId')?.list;
        const c = inputList?.find(y => y.Id === input)?.extra;
        this.form.controls['defectClassification'].patchValue(c.defectClassification);
        this.form.controls['defectMode'].patchValue(c.mode);
        this.form.controls['selectedComment'].patchValue(c);
        this.handleLocations(c);
        this.handleEvaluations(c);
        this.handleRemarks(c.isRemarkRequired);
      } else {
        this.handleEvaluations(null);
      }
    });
    this.subscription.add(sub);
  }
  handleRemarks(isRemarkRequired = false) {
    const control = this.controls.find(x => x.name === 'remarks');
    const remarks = this.form.controls['remarks'];
    if (isRemarkRequired) {
      remarks.addValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required);
      control && (control.required = true);
      console.log('remarks', isRemarkRequired, remarks);
    } else {
      remarks.removeValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required);
      control && (control.required = false);
    }
    remarks.updateValueAndValidity();
    this.form.updateValueAndValidity();
  }
  handleLocations(comment) {
    const obj = {
      ...comment.defectLocation
    };
    const activeProps = Object.keys(obj).filter(prop => obj[prop] === true);
    const control = this.controls.find(x => x.name === 'locations');
    if (activeProps.length) {
      this.form.controls['locations'].addValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required);
      if (control) {
        control.options = [...this.mapActiveLocations(activeProps)];
      } else {
        const toInsert = {
          label: 'Locations',
          name: 'locations',
          type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__.INPUTS_TYPES.MULTI_CHECK_BOX,
          required: true,
          width: 'col-md-12',
          viewAs: src_app_shared_inputs_multi_check_input_multi_check_input_component__WEBPACK_IMPORTED_MODULE_4__.VIEW_AS.squre,
          isMulti: true,
          options: [...this.mapActiveLocations(activeProps)]
        };
        this.controls?.splice(3, 0, toInsert).join();
      }
    } else {
      this.resetLocations(control);
    }
  }
  resetLocations(control) {
    this.form.controls['locations'].removeValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required);
    if (control) {
      this.controls = this.controls.filter(x => x.name !== 'locations');
    }
  }
  handleEvaluations(comment) {
    const control = this.controls.find(x => x.name === 'evalutionId');
    if (comment) {
      if (control) {
        const values = this.calculateEvaluationsIds(comment.commentType, this.evaluations);
        control.options = [...values];
      } else {
        const toInsert = {
          label: 'Evalution',
          name: 'evalutionId',
          type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_3__.INPUTS_TYPES.MULTI_CHECK_BOX,
          required: true,
          width: 'col-md-12',
          viewAs: src_app_shared_inputs_multi_check_input_multi_check_input_component__WEBPACK_IMPORTED_MODULE_4__.VIEW_AS.line,
          isMulti: false,
          options: this.calculateEvaluationsIds(comment.commentType, this.evaluations)
        };
        this.controls?.splice(3, 0, toInsert).join();
      }
      this.form.controls['evalutionId'].addValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required);
    } else {
      if (control) {
        this.controls = this.controls.filter(x => x.name !== 'evalutionId');
        this.form.controls['evalutionId'].removeValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_9__.Validators.required);
      }
    }
  }
  calculateEvaluationsIds(id, lookup) {
    let values = [];
    this.form.controls['evalutionId'].patchValue(null);
    this.form.controls['evalutionId'].enable();
    switch (id) {
      case src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.LET_THE_INSPECTOR_DECIDE:
        values = lookup.filter(x => x.id !== src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.LET_THE_INSPECTOR_DECIDE);
        break;
      case src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.OK_COMMENT:
        values = lookup.filter(x => x.id == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.OK_COMMENT);
        this.form.controls['evalutionId'].patchValue(id);
        this.form.controls['evalutionId'].disable();
        break;
      case src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.MAJOR || src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.MINOR:
        values = lookup.filter(x => x.id !== (src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.LET_THE_INSPECTOR_DECIDE || src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.OK_COMMENT));
        this.form.controls['evalutionId'].patchValue(id);
        this.form.controls['evalutionId'].disable();
        break;
      default:
        values = lookup.filter(x => x.id !== src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_1__.DEFECT_EVALUATIONS.LET_THE_INSPECTOR_DECIDE);
        break;
    }
    return values;
  }
  mapActiveLocations(arr) {
    return arr.map(x => {
      return {
        id: x,
        value: x.toUpperCase()
      };
    });
  }
  cancel() {
    this.form.reset();
    this.submitted = false;
    this.ref.close(null);
  }
  submit() {
    this.submitted = true;
    if (!this.form.valid) return;
    const sc = this.form.controls['selectedComment'];
    sc.patchValue({
      ...this.mapSelectedComment(sc.value),
      commentType: this.form.controls['evalutionId'].value
    });
    this.ref.close(this.form.getRawValue());
  }
  mapSelectedComment(comment) {
    const main = this.controls.find(x => x.name == 'main')?.list?.find(y => y.Id == this.form.getRawValue().main);
    const sub = this.controls.find(x => x.name == 'sub')?.list?.find(y => y.Id == this.form.getRawValue().sub);
    return comment = {
      ...comment,
      defectCommentDescriptionEn: comment.descriptionEn,
      defectCommentDescriptionAr: comment.descriptionAr,
      mainCatrgoryDefectDescriptionEn: main?.NameEn,
      mainCatrgoryDefectDescriptionAR: main?.NameAr,
      subCatrgoryDefectDescriptionEn: sub?.NameEn,
      subCatrgoryDefectDescriptionAr: sub?.NameAr,
      remarks: this.form.getRawValue().remarks
    };
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function AddDefectsFormComponent_Factory(t) {
    return new (t || AddDefectsFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_13__.DynamicDialogConfig), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_core_services_inspection_service__WEBPACK_IMPORTED_MODULE_5__.InspectionService), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_13__.DynamicDialogRef), _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdirectiveInject"](src_app_core_services_lookups_service__WEBPACK_IMPORTED_MODULE_6__.LookupsService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineComponent"]({
    type: AddDefectsFormComponent,
    selectors: [["app-add-defects-form"]],
    decls: 11,
    vars: 9,
    consts: [[1, "d-flex", "flex-column", "justify-content-between", "h-100"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "row"], [1, "col-12", "ab-ri", "mb-0"], ["type", "button", 1, "btn", "btn-outline", 3, "click"], ["type", "button", 1, "btn", "btn-purple", 3, "click"]],
    template: function AddDefectsFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](0, "div", 0)(1, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelement"](2, "app-f-form", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](3, "div", 2)(4, "div", 3)(5, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function AddDefectsFormComponent_Template_button_click_5_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](7, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementStart"](8, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵlistener"]("click", function AddDefectsFormComponent_Template_button_click_8_listener() {
          return ctx.submit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtext"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵproperty"]("controls", ctx.controls)("formGroup", ctx.form)("submitted", ctx.submitted);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](7, 5, "Cancel"));
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵpipeBind1"](10, 7, "Confirm"));
      }
    },
    dependencies: [_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_7__.FFormComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 8460:
/*!*****************************************************************************************************************************************************!*\
  !*** ./src/app/features/inspection/inspection-vehicle-details/inspection-vehicle-details-body/delete-defect-modal/delete-defect-modal.component.ts ***!
  \*****************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteDefectModalComponent": () => (/* binding */ DeleteDefectModalComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/button */ 6328);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 8699);









function DeleteDefectModalComponent_p_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 1, "deleteConfirmationMessage"));
  }
}
const _c0 = function (a0) {
  return {
    v1: a0
  };
};
function DeleteDefectModalComponent_p_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](2, 1, "deleteAllConfirmationMessage", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](4, _c0, ctx_r1.dialogData)));
  }
}
class DeleteDefectModalComponent {
  constructor(ref, _dialogService) {
    this.ref = ref;
    this._dialogService = _dialogService;
    this.submitted = false;
    this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
      moiRemark: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null)
    });
    this.controls = [{
      label: 'remarks',
      name: 'moiRemark',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__.INPUTS_TYPES.TEXT_AREA,
      required: false,
      width: 'col-md-12'
    }];
  }
  ngOnInit() {
    this.getData();
  }
  getData() {
    this.dialogData = this._dialogService.data.data;
  }
  cancel() {
    this.ref.close(false);
  }
  confirm() {
    this.submitted = true;
    this.ref.close(this.form.getRawValue());
  }
  static #_ = this.ɵfac = function DeleteDefectModalComponent_Factory(t) {
    return new (t || DeleteDefectModalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_4__.DynamicDialogRef), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_4__.DynamicDialogConfig));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: DeleteDefectModalComponent,
    selectors: [["app-delete-defect-modal"]],
    decls: 12,
    vars: 11,
    consts: [[1, "text-center"], [4, "ngIf"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "d-flex", "align-items-center", "justify-content-end"], ["styleClass", "p-button-secondary px-4", 1, "px-3", 3, "click"], ["styleClass", "px-4", 3, "click"]],
    template: function DeleteDefectModalComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, DeleteDefectModalComponent_p_1_Template, 3, 3, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, DeleteDefectModalComponent_p_2_Template, 3, 6, "p", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "app-f-form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 3)(6, "p-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function DeleteDefectModalComponent_Template_p_button_click_6_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "p-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function DeleteDefectModalComponent_Template_p_button_click_9_listener() {
          return ctx.confirm();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](11, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.dialogData == 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.dialogData > 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("controls", ctx.controls)("formGroup", ctx.form)("submitted", ctx.submitted);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](8, 7, "Cancel"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](11, 9, "Confirm"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_1__.FFormComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, primeng_button__WEBPACK_IMPORTED_MODULE_6__.Button, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 248:
/*!*********************************************************************************************************************************************!*\
  !*** ./src/app/features/inspection/inspection-vehicle-details/inspection-vehicle-details-body/inspection-vehicle-details-body.component.ts ***!
  \*********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionVehicleDetailsBodyComponent": () => (/* binding */ InspectionVehicleDetailsBodyComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/inspection.tabs.enum */ 3165);
/* harmony import */ var _add_defects_form_add_defects_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add-defects-form/add-defects-form.component */ 4960);
/* harmony import */ var src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/enums/defect-evaluations.enum */ 9059);
/* harmony import */ var src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/enums/table.enum */ 6592);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var src_app_core_helper_arrays_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/helper/arrays.helper */ 1634);
/* harmony import */ var _previous_inspection_vehicle_details_previous_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../previous-inspection-vehicle-details/previous-inspection-vehicle-details.component */ 6967);
/* harmony import */ var src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/enums/vehicle-search-types.enum */ 1114);
/* harmony import */ var _delete_defect_modal_delete_defect_modal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./delete-defect-modal/delete-defect-modal.component */ 8460);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _inspection_handlers_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../inspection-handlers.service */ 1704);
/* harmony import */ var src_app_core_services_inspection_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/inspection.service */ 7875);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/api */ 4356);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../shared/components/f-table/f-table.component */ 2812);
/* harmony import */ var primeng_tabmenu__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/tabmenu */ 7077);
/* harmony import */ var primeng_galleria__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/galleria */ 806);




















function InspectionVehicleDetailsBodyComponent_div_0_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](1, "translate");
  }
  if (rf & 2) {
    const item_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](1, 1, item_r5.label), " ");
  }
}
function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "app-f-table", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onDeleteAll", function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_1_Template_app_f_table_onDeleteAll_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r12.deleteAll($event));
    })("onAction", function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_1_Template_app_f_table_onAction_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r13);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r14.handleAction($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("multiSelect", ctx_r9.activeItem.id != ctx_r9.INSPECTION_TABS.EXCLUDED.toString() && !ctx_r9.dialogMode && ctx_r9.items[0].isEditableIspection)("cols", ctx_r9.tabsCols)("items", ctx_r9.activeTabData)("actions", ctx_r9.actions)("trackBy", "defCommentId");
  }
}
function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "app-f-table", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onAction", function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_2_Template_app_f_table_onAction_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r16);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r15.viewHistoryById($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("cols", ctx_r10.historyTabsCols)("items", ctx_r10.history)("actions", ctx_r10.historyActions)("multiSelect", false);
  }
}
function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 14)(1, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_div_3_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r17.addDefect());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpipeBind1"](3, 1, "AddDefect"));
  }
}
function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_1_Template, 1, 5, "app-f-table", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_app_f_table_2_Template, 1, 4, "app-f-table", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_div_3_Template, 4, 3, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r8.activeItem.id != ctx_r8.INSPECTION_TABS.HISTORY.toString());
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r8.activeItem.id == ctx_r8.INSPECTION_TABS.HISTORY.toString() && !ctx_r8.hideActions);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r8.items.length && !ctx_r8.hideActions && ctx_r8.activeItem.id != ctx_r8.INSPECTION_TABS.EXCLUDED.toString() && ctx_r8.items[0].isEditableIspection);
  }
}
function InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](1, InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_div_1_Template, 4, 3, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const tab_r7 = ctx.$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r4.activeItem.id == tab_r7.id);
  }
}
function InspectionVehicleDetailsBodyComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 4)(1, "p-tabMenu", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("activeItemChange", function InspectionVehicleDetailsBodyComponent_div_0_Template_p_tabMenu_activeItemChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r20);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵresetView"](ctx_r19.activeItemChange($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](2, InspectionVehicleDetailsBodyComponent_div_0_ng_template_2_Template, 2, 3, "ng-template", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](4, InspectionVehicleDetailsBodyComponent_div_0_ng_container_4_Template, 2, 1, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵclassProp"]("shadow-none", ctx_r0.dialogMode);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("model", ctx_r0.tabs)("activeItem", ctx_r0.activeItem)("scrollable", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngSwitch", ctx_r0.activeItem.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngForOf", ctx_r0.tabs);
  }
}
function InspectionVehicleDetailsBodyComponent_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "img", 16);
  }
  if (rf & 2) {
    const item_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", item_r21.itemImageSrc, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
  }
}
function InspectionVehicleDetailsBodyComponent_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "img", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r22 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("src", item_r22.thumbnailImageSrc, _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsanitizeUrl"]);
  }
}
const _c0 = function () {
  return {
    "max-width": "50%"
  };
};
class InspectionVehicleDetailsBodyComponent {
  constructor(dialogService, _translate, _inspectionHandlerService, _inspectionService, confirmationService, _datePipe) {
    this.dialogService = dialogService;
    this._translate = _translate;
    this._inspectionHandlerService = _inspectionHandlerService;
    this._inspectionService = _inspectionService;
    this.confirmationService = confirmationService;
    this._datePipe = _datePipe;
    this.onCreate = new _angular_core__WEBPACK_IMPORTED_MODULE_11__.EventEmitter();
    this.dialogMode = false;
    this.cols = [{
      title: '',
      col: 'vinSeqId'
    }, {
      title: '',
      col: 'category',
      isLocalized: true
    }, {
      title: '',
      col: 'lastIssuedVin'
    }, {
      title: '',
      col: 'seq',
      isNumber: true
    }, {
      title: '',
      col: 'availableSeqCount',
      isNumber: true
    }
    // { title: '', col: 'actions' },
    ];

    this.tabs = [{
      label: 'All',
      id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.ALL.toString()
    }, {
      label: 'ExcludedDefects',
      id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.EXCLUDED.toString()
    }, {
      label: 'LegalDefects',
      id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.LEGAL.toString()
    }, {
      label: 'MajorTechnicalDefects',
      id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL.toString()
    }, {
      label: 'MinorTechnicalDefects',
      id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.MINOR.toString()
    }, {
      label: 'OK/Comment',
      id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.OK_COMMENT.toString()
    }];
    this.activeTabData = [];
    this.selectedDefects = [];
    this.excludedDefects = [];
    this.excludedDefectsInit = [];
    this.CreatedDefects = [];
    this.history = [];
    this.hideActions = false;
    this.responsiveOptions = [{
      breakpoint: '1500px',
      numVisible: 5
    }, {
      breakpoint: '1024px',
      numVisible: 3
    }, {
      breakpoint: '768px',
      numVisible: 2
    }, {
      breakpoint: '560px',
      numVisible: 1
    }];
    this.hasChanges = false;
    this.tabsCols = [{
      title: 'CommentCode',
      col: 'defCommentCode'
    }, {
      title: 'description',
      col: 'description',
      isCustomInspectionDesc: true
    }, {
      title: 'MainCategory',
      col: 'mainCatrgoryDefectDescription',
      isLocalized: true
    }, {
      title: 'SubCategory',
      col: 'subCatrgoryDefectDescription',
      isLocalized: true
    }, {
      title: 'remarks',
      col: 'remarks',
      isList: true
    }];
    this.historyTabsCols = [{
      title: 'inspectionType',
      col: 'inspectionTypeValue'
    }, {
      title: 'Date',
      col: 'createdDate',
      isDate: true
    }, {
      title: 'remarks',
      col: 'remarks',
      isList: true
    }, {
      title: 'Status',
      col: 'finalResult',
      isPassFail: true
    }, {
      title: 'actions',
      col: 'actions'
    }];
    this.actions = [{
      name: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES_Names.ATTACHMENT,
      icon: 'attach_file',
      colorClass: 'text-info',
      type: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES.ICON
    }, {
      name: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES_Names.DELETE,
      icon: 'delete',
      colorClass: 'text-danger',
      type: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES.ICON
    }];
    this.historyActions = [{
      name: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES_Names.VIEW,
      icon: 'visibility',
      colorClass: 'text-success',
      type: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES.ICON
    }];
    this.images = [];
    this.showGalleria = false;
  }
  get INSPECTION_TABS() {
    return src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS;
  }
  ngOnInit() {
    this.items[0] && (this.excludedDefects = [...this.items[0].excludedDefects]);
    this.items[0] && (this.excludedDefectsInit = [...this.items[0].excludedDefects]);
    this.activeItem = this.tabs[0];
    this.selectedDefects = this.items[0] ? this.items[0].selectedDefects : [];
    this.history = this.items[0] ? this.items[0].inspectionsHistory : [];
    // this.items[0].isEditableIspection = true;
    this.handleHistoryActions();
    this.activeItemChange(this.activeItem);
  }
  handleHistoryActions() {
    this.items[0] && (this.hideActions = this.items[0].hideActions);
    // this.dialogMode && (this.hideActions = true);
    if (!this.hideActions) {
      this.tabs.push({
        label: 'History',
        id: src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.HISTORY.toString()
      });
      this.tabsCols.push({
        title: 'actions',
        col: 'actions'
      });
    } else {
      this.actions = [];
    }
  }
  activeItemChange(e) {
    this.activeItem = e;
    this.handleLegalTabTable();
    switch (this.activeItem.id) {
      case src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.ALL.toString():
        this.activeTabData = [...this._inspectionHandlerService.mapSelectedDefects(this.selectedDefects), ...this._inspectionHandlerService.mapSelectedDefects(this.CreatedDefects)];
        break;
      case src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.EXCLUDED.toString():
        this.activeTabData = [...this._inspectionHandlerService.mapSelectedDefects(this._inspectionHandlerService.mapToExcluded(this.excludedDefects))];
        break;
      case src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.OK_COMMENT.toString():
        this.activeTabData = [...this._inspectionHandlerService.mapSelectedDefects(this.selectedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.OK_COMMENT || x.commentType == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS.OK_COMMENT)), ...this._inspectionHandlerService.mapSelectedDefects(this.CreatedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL && x.commentType == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS.OK_COMMENT))];
        break;
      case src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.LEGAL.toString():
        this.activeTabData = [...this._inspectionHandlerService.mapSelectedDefects(this.selectedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.LEGAL)), ...this._inspectionHandlerService.mapSelectedDefects(this.CreatedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.LEGAL))];
        break;
      case src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL.toString():
        this.activeTabData = [...this._inspectionHandlerService.mapSelectedDefects(this.selectedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL && x.commentType == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS.MAJOR)), ...this._inspectionHandlerService.mapSelectedDefects(this.CreatedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL && x.commentType == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS.MAJOR))];
        break;
      case src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.MINOR.toString():
        this.activeTabData = [...this._inspectionHandlerService.mapSelectedDefects(this.selectedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL && x.commentType == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS.MINOR)), ...this._inspectionHandlerService.mapSelectedDefects(this.CreatedDefects.filter(x => x.defectClassification == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.TECHNICAL && x.commentType == src_app_core_enums_defect_evaluations_enum__WEBPACK_IMPORTED_MODULE_2__.DEFECT_EVALUATIONS.MINOR))];
        break;
      default:
        this.activeTabData = [];
        break;
    }
  }
  handleLegalTabTable() {
    const row = {
      title: 'Type',
      col: 'commentTypeName',
      isCustomLocalized: true
    };
    const isExist = this.tabsCols.find(x => x.col == row.col);
    if (this.activeItem.id == src_app_core_enums_inspection_tabs_enum__WEBPACK_IMPORTED_MODULE_0__.INSPECTION_TABS.LEGAL.toString()) {
      // add row
      !isExist && this.tabsCols.splice(1, 0, row);
    } else {
      // remove row
      this.tabsCols = this.tabsCols.filter(x => x.col !== row.col);
    }
  }
  addDefect() {
    if (!this.items[0].isEditableIspection) return;
    this.ref = this.dialogService.open(_add_defects_form_add_defects_form_component__WEBPACK_IMPORTED_MODULE_1__.AddDefectsFormComponent, {
      header: this._translate.instant('AddDefect'),
      width: '70%',
      contentStyle: {
        overflow: 'auto'
      },
      baseZIndex: 10000,
      maximizable: true,
      data: {
        data: this.items[0],
        selectedDefects: [...this.CreatedDefects, ...this.selectedDefects]
      }
    });
    this.ref.onClose.subscribe(x => {
      if (x) {
        this.hasChanges = true;
        x = {
          ...x,
          ...x.selectedComment
        };
        this.CreatedDefects.push(x);
        this.handleOnCreate();
        this.activeItemChange(this.activeItem);
      }
    });
    this.ref.onMaximize.subscribe(() => {});
  }
  handleAction(event) {
    switch (event.action) {
      case src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES_Names.DELETE:
        this.handleDelete(event);
        break;
      case src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_3__.TABLE_ACTIONS_TYPES_Names.VIEW:
        this.getDefectAttachments(event.item.item.defCommentId);
        break;
    }
  }
  getDefectAttachments(defectId) {
    this._inspectionService.getDefectAttachments({
      defectId,
      requestId: this.items[0].requestId
    }).subscribe(res => {
      if (res.length) {
        const mimeType = 'image/png'; // Assuming the image is a PNG based on file name
        this.showGalleria = true;
        this.images = res.map(x => {
          return {
            itemImageSrc: `data:${mimeType};base64,${x?.file}`,
            thumbnailImageSrc: `data:${mimeType};base64,${x?.file}`
          };
        });
      }
    });
  }
  viewHistoryById(event) {
    this.getHistoryByRequestId(event.item.requestId, event.item.createdDate);
  }
  openHistoryDialog(hostoryItems, header) {
    this.ref = this.dialogService.open(_previous_inspection_vehicle_details_previous_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_5__.PreviousInspectionVehicleDetailsComponent, {
      header: this._datePipe.transform(header, 'dd/MM/yyyy'),
      width: '70%',
      contentStyle: {
        overflow: 'auto'
      },
      baseZIndex: 10000,
      maximizable: true,
      data: {
        data: hostoryItems
      }
    });
    this.ref.onClose.subscribe(() => {});
    this.ref.onMaximize.subscribe(() => {});
  }
  getHistoryByRequestId(requestId, header) {
    this._inspectionService.search(requestId.toString(), src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_6__.VEHICLE_SEARCH_TYPES.REQUEST_ID).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_12__.map)(x => {
      return {
        ...x,
        hideActions: true
      };
    })).subscribe(res => {
      if (res) {
        this.openHistoryDialog(res, header);
      }
    });
  }
  handleDelete(event) {
    if (!this.items[0].isEditableIspection) return;
    if (this.CreatedDefects.length && this.CreatedDefects.some(x => x.defCommentId == event.item.item.defCommentId)) {
      this.handleDeleteCreatedDefects(event);
    } else {
      this.handleDeleteSelectedDefect(event);
    }
    this.hasChanges = true;
  }
  handleOnActionHandled() {
    this.activeItemChange(this.activeItem);
    this.handleOnCreate();
  }
  handleOnCreate() {
    this.onCreate.emit({
      createdDefects: this.CreatedDefects,
      excludedDefects: (0,src_app_core_helper_arrays_helper__WEBPACK_IMPORTED_MODULE_4__.getArraysDifference)(this.excludedDefectsInit, this.excludedDefects, 'defectCommentId'),
      hasChanges: this.hasChanges
    });
  }
  handleDeleteCreatedDefects(event) {
    this.confirmationService.confirm({
      message: `${this._translate.instant('deleteConfirmationMessage')}`,
      header: `${this._translate.instant('Confirmation')}`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: `${this._translate.instant('Confirm')}`,
      rejectLabel: `${this._translate.instant('Cancel')}`,
      accept: () => {
        this.CreatedDefects.length && (this.CreatedDefects = [...this.CreatedDefects.filter(x => x?.defCommentId !== event.item.item.defCommentId)]);
        this.handleOnActionHandled();
      },
      reject: () => {}
    });
  }
  openDeteleDialog(length) {
    this.ref = this.dialogService.open(_delete_defect_modal_delete_defect_modal_component__WEBPACK_IMPORTED_MODULE_7__.DeleteDefectModalComponent, {
      header: `${this._translate.instant('Confirmation')}`,
      width: '50%',
      contentStyle: {
        overflow: 'auto'
      },
      baseZIndex: 10000,
      maximizable: false,
      data: {
        data: length
      }
    });
  }
  handleDeleteSelectedDefect(event) {
    this.openDeteleDialog(1);
    this.ref.onClose.subscribe(x => {
      if (x) {
        if (this.selectedDefects.length) {
          this.selectedDefects = [...this.selectedDefects.filter(x => x?.defCommentId !== event.item.item.defCommentId)];
          event.item.item.remarks = x.moiRemark;
        }
        this.excludedDefects.push(event.item.item);
        this.handleOnActionHandled();
      }
    });
    this.ref.onMaximize.subscribe(() => {});
  }
  deleteAll(event) {
    if (!this.items[0].isEditableIspection) return;
    this.openDeteleDialog(event.length);
    this.ref.onClose.subscribe(x => {
      if (x) {
        if (this.CreatedDefects.length) {
          event.forEach(x => {
            this.CreatedDefects = this.CreatedDefects.filter(y => y.defCommentId != x.item.defCommentId);
            console.log('test', this.CreatedDefects.filter(y => y.defCommentId == x.item.defCommentId));
          });
        }
        if (this.selectedDefects.length || this.CreatedDefects.length) {
          event.forEach(el => {
            el.item.remarks = x.moiRemark;
          });
          const unselected = [...this.selectedDefects.filter(y => {
            if (!event.some(x => x.item.defCommentId == y.defCommentId)) return y;
          })];
          const deleted = [...this.selectedDefects.filter(y => {
            if (event.some(x => x.item.defCommentId == y.defCommentId)) return y;
          })];
          this.excludedDefects = [...this.excludedDefects, ...deleted];
          this.selectedDefects = [...unselected];
        }
        console.log(this.CreatedDefects, event);
        this.handleOnActionHandled();
      }
    });
    this.ref.onMaximize.subscribe(() => {});
  }
  undoChanges() {
    this.selectedDefects = [...this.items[0].selectedDefects];
    this.excludedDefects = [...this.excludedDefectsInit];
    this.CreatedDefects = [];
    this.handleOnActionHandled();
  }
  static #_ = this.ɵfac = function InspectionVehicleDetailsBodyComponent_Factory(t) {
    return new (t || InspectionVehicleDetailsBodyComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_13__.DialogService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_inspection_handlers_service__WEBPACK_IMPORTED_MODULE_8__.InspectionHandlersService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_inspection_service__WEBPACK_IMPORTED_MODULE_9__.InspectionService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_15__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_16__.DatePipe));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
    type: InspectionVehicleDetailsBodyComponent,
    selectors: [["app-inspection-vehicle-details-body"]],
    inputs: {
      items: "items",
      dialogMode: "dialogMode"
    },
    outputs: {
      onCreate: "onCreate"
    },
    decls: 5,
    vars: 10,
    consts: [["class", "white-block", 3, "shadow-none", 4, "ngIf"], [3, "value", "visible", "responsiveOptions", "containerStyle", "numVisible", "circular", "fullScreen", "showItemNavigators", "visibleChange"], ["pTemplate", "item"], ["pTemplate", "thumbnail"], [1, "white-block"], [3, "model", "activeItem", "scrollable", "activeItemChange"], [3, "ngSwitch"], [4, "ngFor", "ngForOf"], [4, "ngIf"], [3, "multiSelect", "cols", "items", "actions", "trackBy", "onDeleteAll", "onAction", 4, "ngIf"], [3, "cols", "items", "actions", "multiSelect", "onAction", 4, "ngIf"], ["class", "mt-4 text-center", 4, "ngIf"], [3, "multiSelect", "cols", "items", "actions", "trackBy", "onDeleteAll", "onAction"], [3, "cols", "items", "actions", "multiSelect", "onAction"], [1, "mt-4", "text-center"], ["type", "button", 1, "btn", "btn-purple", "px-5", 3, "click"], [2, "width", "100%", "min-width", "50vw", "display", "block", 3, "src"], [1, "grid", "grid-nogutter", "justify-content-center"], [2, "display", "block", 3, "src"]],
    template: function InspectionVehicleDetailsBodyComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](0, InspectionVehicleDetailsBodyComponent_div_0_Template, 5, 7, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "p-galleria", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("visibleChange", function InspectionVehicleDetailsBodyComponent_Template_p_galleria_visibleChange_2_listener($event) {
          return ctx.showGalleria = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, InspectionVehicleDetailsBodyComponent_ng_template_3_Template, 1, 1, "ng-template", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](4, InspectionVehicleDetailsBodyComponent_ng_template_4_Template, 2, 1, "ng-template", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.activeItem);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx.images)("visible", ctx.showGalleria)("responsiveOptions", ctx.responsiveOptions)("containerStyle", _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵpureFunction0"](9, _c0))("numVisible", 9)("circular", true)("fullScreen", true)("showItemNavigators", true);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_16__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgSwitch, _shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_10__.FTableComponent, primeng_tabmenu__WEBPACK_IMPORTED_MODULE_17__.TabMenu, primeng_api__WEBPACK_IMPORTED_MODULE_15__.PrimeTemplate, primeng_galleria__WEBPACK_IMPORTED_MODULE_18__.Galleria, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 5047:
/*!********************************************************************************************************!*\
  !*** ./src/app/features/inspection/inspection-vehicle-details/inspection-vehicle-details.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionVehicleDetailsComponent": () => (/* binding */ InspectionVehicleDetailsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 1640);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/api */ 4356);
/* harmony import */ var src_app_core_services_inspection_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/inspection.service */ 7875);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/toastr.service */ 8996);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/components/business/vehicle-details-header/vehicle-details-header.component */ 5425);
/* harmony import */ var _inspection_vehicle_details_body_inspection_vehicle_details_body_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./inspection-vehicle-details-body/inspection-vehicle-details-body.component */ 248);











const _c0 = ["body"];
function InspectionVehicleDetailsComponent_div_3_div_1_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionVehicleDetailsComponent_div_3_div_1_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.undoChanges());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, "undoChanges"));
  }
}
function InspectionVehicleDetailsComponent_div_3_div_1_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionVehicleDetailsComponent_div_3_div_1_button_5_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.submit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, "Confirm"));
  }
}
function InspectionVehicleDetailsComponent_div_3_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, InspectionVehicleDetailsComponent_div_3_div_1_button_1_Template, 3, 3, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionVehicleDetailsComponent_div_3_div_1_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r10.cancel());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, InspectionVehicleDetailsComponent_div_3_div_1_button_5_Template, 3, 3, "button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r3.defects == null ? null : ctx_r3.defects.createdDefects == null ? null : ctx_r3.defects.createdDefects.length) || (ctx_r3.defects == null ? null : ctx_r3.defects.excludedDefects == null ? null : ctx_r3.defects.excludedDefects.length));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 3, "Cancel"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (ctx_r3.defects == null ? null : ctx_r3.defects.createdDefects == null ? null : ctx_r3.defects.createdDefects.length) || (ctx_r3.defects == null ? null : ctx_r3.defects.excludedDefects == null ? null : ctx_r3.defects.excludedDefects.length));
  }
}
function InspectionVehicleDetailsComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, InspectionVehicleDetailsComponent_div_3_div_1_Template, 6, 5, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.items);
  }
}
function InspectionVehicleDetailsComponent_div_4_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 6)(1, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function InspectionVehicleDetailsComponent_div_4_div_1_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r13.back());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 1, "Back"));
  }
}
function InspectionVehicleDetailsComponent_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, InspectionVehicleDetailsComponent_div_4_div_1_Template, 4, 3, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r2.items);
  }
}
const _c1 = function (a0) {
  return [a0];
};
const _c2 = function () {
  return [];
};
class InspectionVehicleDetailsComponent {
  constructor(_route, confirmationService, _inspections, _translate, _toastr, _router, _location) {
    this._route = _route;
    this.confirmationService = confirmationService;
    this._inspections = _inspections;
    this._translate = _translate;
    this._toastr = _toastr;
    this._router = _router;
    this._location = _location;
    this.dialogMode = false;
    this.hasChanges = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subscription();
    this.extraCols = [{
      title: 'Station',
      col: 'station',
      isLocalized: true
    }];
    this.hideActions = false;
  }
  ngOnInit() {
    this.items && (this.hideActions = this.items.hideActions);
    this.getInspectionResultDetails();
  }
  cancel() {
    this.defects?.createdDefects?.length || this.defects?.excludedDefects?.length ? this.undoChanges(true) : this._router.navigate(['..'], {
      relativeTo: this._route
    });
  }
  undoChanges(route = false) {
    this.confirmationService.confirm({
      message: `${this._translate.instant('undoMessage')}`,
      header: `${this._translate.instant('Confirmation')}`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: `${this._translate.instant('Confirm')}`,
      rejectLabel: `${this._translate.instant('Cancel')}`,
      accept: () => {
        this.bodyComponent.undoChanges();
        if (route) this._router.navigate(['..'], {
          relativeTo: this._route
        });
      },
      reject: type => {}
    });
  }
  submit() {
    this.confirmationService.confirm({
      message: `${this._translate.instant('DoYouWantToProceedMessage')}`,
      header: `${this._translate.instant('Confirmation')}`,
      icon: 'pi pi-exclamation-triangle',
      acceptLabel: `${this._translate.instant('Confirm')}`,
      rejectLabel: `${this._translate.instant('Cancel')}`,
      accept: () => {
        this.submitCompination();
      },
      reject: type => {}
    });
  }
  createDefects() {
    if (!this.defects.createdDefects.length) return;
    const defects = this.defects.createdDefects.map(x => {
      return {
        axle: 0,
        defectClassification: x.defectClassification,
        defectMode: x.mode,
        defectsCommentId: x.defCommentId,
        defectSource: x.defectSource,
        evalutionId: x.evalutionId,
        inspectionReqId: this.items.inspectionReqId,
        inspectionServiceId: this.items.inspectionServiceId,
        inspectionStepId: this.items.inspectionStepId,
        locations: x.locations,
        remarks: x.remarks,
        requestId: this.items.requestId,
        sectionId: this.items.sectionId,
        status: x.status,
        createdBy: 1
      };
    });
    return defects;
  }
  deleteDefects() {
    if (!this.defects.excludedDefects.length) return;
    const defects = this.defects.excludedDefects.map(x => {
      return {
        inspectionReqId: this.items.inspectionReqId,
        defectsCommentId: x.defCommentId,
        moiRemark: x.remarks
      };
    });
    return defects;
  }
  submitCompination() {
    // debugger
    const createDefects = this.createDefects();
    const excludedDefects = this.deleteDefects();
    let endpoints;
    if (createDefects && createDefects?.length && excludedDefects && excludedDefects?.length) {
      endpoints = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.forkJoin)({
        create: this._inspections.createDefects(createDefects),
        delete: this._inspections.deleteDefects(excludedDefects)
      });
    } else if (createDefects && createDefects?.length && !excludedDefects) {
      endpoints = this._inspections.createDefects(createDefects);
    } else if (excludedDefects && excludedDefects?.length && !createDefects) {
      endpoints = this._inspections.deleteDefects(excludedDefects);
    }
    endpoints?.subscribe({
      next: res => {
        this._toastr.showSuccess(this._translate.instant('Submitted successfully'));
        this.hasChanges.emit(false);
        this._router.navigate(['portal/inspection']);
      }
    });
  }
  create(event) {
    this.defects = event;
    this.hasChanges.emit(event.hasChanges);
  }
  getInspectionResultDetails() {
    this._inspections.getInspectionResultDetails(this.items.requestId).subscribe(res => {
      this.inspectionResultDetails = res;
    });
  }
  back() {
    this._router.navigated ? this._location.back() : this._router.navigate(['portal/inspection']);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function InspectionVehicleDetailsComponent_Factory(t) {
    return new (t || InspectionVehicleDetailsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_8__.ConfirmationService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_inspection_service__WEBPACK_IMPORTED_MODULE_0__.InspectionService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_1__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_10__.Location));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: InspectionVehicleDetailsComponent,
    selectors: [["app-inspection-vehicle-details"]],
    viewQuery: function InspectionVehicleDetailsComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.bodyComponent = _t.first);
      }
    },
    inputs: {
      items: "items",
      dialogMode: "dialogMode"
    },
    outputs: {
      hasChanges: "hasChanges"
    },
    decls: 5,
    vars: 14,
    consts: [[3, "extraCols", "items", "inspectionResultDetails", "dialogMode"], [3, "items", "dialogMode", "onCreate"], ["body", ""], ["class", "row", 4, "ngIf"], [1, "row"], ["class", "col-12 ab-ri", 4, "ngIf"], [1, "col-12", "ab-ri"], ["type", "button", "class", "btn btn-outline", 3, "click", 4, "ngIf"], ["type", "button", 1, "btn", "btn-outline", 3, "click"], ["type", "button", "class", "btn btn-purple", 3, "click", 4, "ngIf"], ["type", "button", 1, "btn", "btn-purple", 3, "click"]],
    template: function InspectionVehicleDetailsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-vehicle-details-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "app-inspection-vehicle-details-body", 1, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onCreate", function InspectionVehicleDetailsComponent_Template_app_inspection_vehicle_details_body_onCreate_1_listener($event) {
          return ctx.create($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, InspectionVehicleDetailsComponent_div_3_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, InspectionVehicleDetailsComponent_div_4_Template, 2, 1, "div", 3);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("extraCols", ctx.extraCols)("items", ctx.items ? _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](8, _c1, ctx.items) : _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](10, _c2))("inspectionResultDetails", ctx.inspectionResultDetails)("dialogMode", ctx.dialogMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("items", ctx.items ? _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](11, _c1, ctx.items) : _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](13, _c2))("dialogMode", ctx.dialogMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.hideActions);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.hideActions && !ctx.dialogMode);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_2__.VehicleDetailsHeaderComponent, _inspection_vehicle_details_body_inspection_vehicle_details_body_component__WEBPACK_IMPORTED_MODULE_3__.InspectionVehicleDetailsBodyComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3313:
/*!**********************************************************!*\
  !*** ./src/app/features/inspection/inspection.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionModule": () => (/* binding */ InspectionModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _inspection_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./inspection-routing.module */ 4951);
/* harmony import */ var _vehicle_inspection_audit_form_vehicle_inspection_audit_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vehicle-inspection-audit-form/vehicle-inspection-audit-form.component */ 3947);
/* harmony import */ var _inspection_vehicle_details_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./inspection-vehicle-details/inspection-vehicle-details.component */ 5047);
/* harmony import */ var _inspection_vehicle_details_inspection_vehicle_details_body_inspection_vehicle_details_body_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./inspection-vehicle-details/inspection-vehicle-details-body/inspection-vehicle-details-body.component */ 248);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/f-table/f-table.component */ 2812);
/* harmony import */ var primeng_tabmenu__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! primeng/tabmenu */ 7077);
/* harmony import */ var _inspection_vehicle_details_inspection_vehicle_details_body_add_defects_form_add_defects_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./inspection-vehicle-details/inspection-vehicle-details-body/add-defects-form/add-defects-form.component */ 4960);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);
/* harmony import */ var src_app_shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/business/vehicle-details-header/vehicle-details-header.component */ 5425);
/* harmony import */ var src_app_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/components/business/vehicle-search-container/vehicle-search-container.component */ 4070);
/* harmony import */ var primeng_galleria__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/galleria */ 806);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _current_inspection_vehicle_details_current_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./current-inspection-vehicle-details/current-inspection-vehicle-details.component */ 9739);
/* harmony import */ var _previous_inspection_vehicle_details_previous_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./previous-inspection-vehicle-details/previous-inspection-vehicle-details.component */ 6967);
/* harmony import */ var _inspection_vehicle_details_inspection_vehicle_details_body_delete_defect_modal_delete_defect_modal_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./inspection-vehicle-details/inspection-vehicle-details-body/delete-defect-modal/delete-defect-modal.component */ 8460);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/button */ 6328);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 2560);






















class InspectionModule {
  static #_ = this.ɵfac = function InspectionModule_Factory(t) {
    return new (t || InspectionModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineNgModule"]({
    type: InspectionModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _inspection_routing_module__WEBPACK_IMPORTED_MODULE_0__.InspectionRoutingModule, src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_4__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateModule, src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_5__.FTableComponent, primeng_tabmenu__WEBPACK_IMPORTED_MODULE_15__.TabMenuModule, primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_16__.DynamicDialogModule, src_app_shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_7__.VehicleDetailsHeaderComponent, src_app_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_8__.VehicleSearchContainerComponent, primeng_galleria__WEBPACK_IMPORTED_MODULE_17__.GalleriaModule, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_19__.ButtonModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵsetNgModuleScope"](InspectionModule, {
    declarations: [_vehicle_inspection_audit_form_vehicle_inspection_audit_form_component__WEBPACK_IMPORTED_MODULE_1__.VehicleInspectionAuditFormComponent, _inspection_vehicle_details_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_2__.InspectionVehicleDetailsComponent, _inspection_vehicle_details_inspection_vehicle_details_body_inspection_vehicle_details_body_component__WEBPACK_IMPORTED_MODULE_3__.InspectionVehicleDetailsBodyComponent, _inspection_vehicle_details_inspection_vehicle_details_body_add_defects_form_add_defects_form_component__WEBPACK_IMPORTED_MODULE_6__.AddDefectsFormComponent, _current_inspection_vehicle_details_current_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_9__.CurrentInspectionVehicleDetailsComponent, _previous_inspection_vehicle_details_previous_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_10__.PreviousInspectionVehicleDetailsComponent, _inspection_vehicle_details_inspection_vehicle_details_body_delete_defect_modal_delete_defect_modal_component__WEBPACK_IMPORTED_MODULE_11__.DeleteDefectModalComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _inspection_routing_module__WEBPACK_IMPORTED_MODULE_0__.InspectionRoutingModule, src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_4__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslateModule, src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_5__.FTableComponent, primeng_tabmenu__WEBPACK_IMPORTED_MODULE_15__.TabMenuModule, primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_16__.DynamicDialogModule, src_app_shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_7__.VehicleDetailsHeaderComponent, src_app_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_8__.VehicleSearchContainerComponent, primeng_galleria__WEBPACK_IMPORTED_MODULE_17__.GalleriaModule, _angular_forms__WEBPACK_IMPORTED_MODULE_18__.FormsModule, primeng_button__WEBPACK_IMPORTED_MODULE_19__.ButtonModule]
  });
})();
_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵsetComponentScope"](_previous_inspection_vehicle_details_previous_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_10__.PreviousInspectionVehicleDetailsComponent, [_angular_common__WEBPACK_IMPORTED_MODULE_13__.NgIf, _inspection_vehicle_details_inspection_vehicle_details_component__WEBPACK_IMPORTED_MODULE_2__.InspectionVehicleDetailsComponent], [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__.TranslatePipe]);

/***/ }),

/***/ 6967:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/features/inspection/previous-inspection-vehicle-details/previous-inspection-vehicle-details.component.ts ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PreviousInspectionVehicleDetailsComponent": () => (/* binding */ PreviousInspectionVehicleDetailsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);


function PreviousInspectionVehicleDetailsComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "app-inspection-vehicle-details", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2)(3, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function PreviousInspectionVehicleDetailsComponent_ng_container_0_Template_button_click_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r2);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.back());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipe"](5, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("items", ctx_r0.dialogData)("dialogMode", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpipeBind1"](5, 3, "Back"));
  }
}
class PreviousInspectionVehicleDetailsComponent {
  constructor(ref, _dialogService) {
    this.ref = ref;
    this._dialogService = _dialogService;
  }
  ngOnInit() {
    this.getData();
  }
  getData() {
    this.dialogData = this._dialogService.data.data;
  }
  back() {
    this.ref.close();
  }
  static #_ = this.ɵfac = function PreviousInspectionVehicleDetailsComponent_Factory(t) {
    return new (t || PreviousInspectionVehicleDetailsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_1__.DynamicDialogRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_1__.DynamicDialogConfig));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: PreviousInspectionVehicleDetailsComponent,
    selectors: [["app-previous-inspection-vehicle-details"]],
    decls: 1,
    vars: 1,
    consts: [[4, "ngIf"], [3, "items", "dialogMode"], [1, "col-12", "ab-ri"], ["type", "button", 1, "btn", "btn-outline", 3, "click"]],
    template: function PreviousInspectionVehicleDetailsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, PreviousInspectionVehicleDetailsComponent_ng_container_0_Template, 6, 5, "ng-container", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.dialogData);
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3947:
/*!**************************************************************************************************************!*\
  !*** ./src/app/features/inspection/vehicle-inspection-audit-form/vehicle-inspection-audit-form.component.ts ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleInspectionAuditFormComponent": () => (/* binding */ VehicleInspectionAuditFormComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/vehicle-search-types.enum */ 1114);
/* harmony import */ var src_app_core_helper_create_inspection_search_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/helper/create-inspection-search.helper */ 3893);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/components/business/vehicle-search-container/vehicle-search-container.component */ 4070);





class VehicleInspectionAuditFormComponent {
  constructor(_router, _route) {
    this._router = _router;
    this._route = _route;
  }
  submit(event) {
    const {
      searchText,
      searchType,
      ...toConcat
    } = event;
    this._router.navigate(["vehicle-details"], {
      relativeTo: this._route,
      queryParams: {
        query: event.searchType == src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__.VEHICLE_SEARCH_TYPES.PLATE_NO ? event.plateType ? (0,src_app_core_helper_create_inspection_search_helper__WEBPACK_IMPORTED_MODULE_1__.concatinate)(toConcat) : event.searchText : event.searchText,
        searchType: event.searchType
      }
    });
  }
  static #_ = this.ɵfac = function VehicleInspectionAuditFormComponent_Factory(t) {
    return new (t || VehicleInspectionAuditFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: VehicleInspectionAuditFormComponent,
    selectors: [["app-vehicle-inspection-audit-form"]],
    decls: 1,
    vars: 0,
    consts: [[3, "onSearch"]],
    template: function VehicleInspectionAuditFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "app-vehicle-search-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("onSearch", function VehicleInspectionAuditFormComponent_Template_app_vehicle_search_container_onSearch_0_listener($event) {
          return ctx.submit($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      }
    },
    dependencies: [_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_2__.VehicleSearchContainerComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 806:
/*!************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-galleria.mjs ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Galleria": () => (/* binding */ Galleria),
/* harmony export */   "GalleriaContent": () => (/* binding */ GalleriaContent),
/* harmony export */   "GalleriaItem": () => (/* binding */ GalleriaItem),
/* harmony export */   "GalleriaItemSlot": () => (/* binding */ GalleriaItemSlot),
/* harmony export */   "GalleriaModule": () => (/* binding */ GalleriaModule),
/* harmony export */   "GalleriaThumbnails": () => (/* binding */ GalleriaThumbnails)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 4356);
/* harmony import */ var primeng_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/utils */ 8549);
/* harmony import */ var primeng_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/dom */ 1420);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/ripple */ 4538);
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/animations */ 4851);
/* harmony import */ var primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/icons/chevronright */ 4890);
/* harmony import */ var primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/icons/chevronleft */ 6168);
/* harmony import */ var primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/icons/times */ 9696);
/* harmony import */ var primeng_icons_windowmaximize__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primeng/icons/windowmaximize */ 6780);
/* harmony import */ var primeng_icons_windowminimize__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! primeng/icons/windowminimize */ 9881);
















const _c0 = ["mask"];
const _c1 = function (a0, a1) {
  return {
    showTransitionParams: a0,
    hideTransitionParams: a1
  };
};
const _c2 = function (a1) {
  return {
    value: "visible",
    params: a1
  };
};
function Galleria_div_0_div_1_p_galleriaContent_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p-galleriaContent", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("@animation.start", function Galleria_div_0_div_1_p_galleriaContent_2_Template_p_galleriaContent_animation_animation_start_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r6.onAnimationStart($event));
    })("@animation.done", function Galleria_div_0_div_1_p_galleriaContent_2_Template_p_galleriaContent_animation_animation_done_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r8.onAnimationEnd($event));
    })("maskHide", function Galleria_div_0_div_1_p_galleriaContent_2_Template_p_galleriaContent_maskHide_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r9.onMaskHide());
    })("activeItemChange", function Galleria_div_0_div_1_p_galleriaContent_2_Template_p_galleriaContent_activeItemChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r10.onActiveItemChange($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("@animation", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](8, _c2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](5, _c1, ctx_r5.showTransitionOptions, ctx_r5.hideTransitionOptions)))("value", ctx_r5.value)("activeIndex", ctx_r5.activeIndex)("numVisible", ctx_r5.numVisible)("ngStyle", ctx_r5.containerStyle);
  }
}
const _c3 = function (a1) {
  return {
    "p-galleria-mask p-component-overlay p-component-overlay-enter": true,
    "p-galleria-visible": a1
  };
};
function Galleria_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3, 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, Galleria_div_0_div_1_p_galleriaContent_2_Template, 1, 10, "p-galleriaContent", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r3.maskClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c3, ctx_r3.visible));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r3.visible);
  }
}
function Galleria_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, Galleria_div_0_div_1_Template, 3, 6, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.maskVisible);
  }
}
function Galleria_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p-galleriaContent", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("activeItemChange", function Galleria_ng_template_1_Template_p_galleriaContent_activeItemChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r11.onActiveItemChange($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r2.value)("activeIndex", ctx_r2.activeIndex)("numVisible", ctx_r2.numVisible);
  }
}
function GalleriaContent_div_0_button_1_TimesIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "TimesIcon", 11);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("styleClass", "p-galleria-close-icon");
  }
}
function GalleriaContent_div_0_button_1_2_ng_template_0_Template(rf, ctx) {}
function GalleriaContent_div_0_button_1_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaContent_div_0_button_1_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function GalleriaContent_div_0_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaContent_div_0_button_1_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r8.maskHide.emit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaContent_div_0_button_1_TimesIcon_1_Template, 1, 1, "TimesIcon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaContent_div_0_button_1_2_Template, 1, 0, null, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r1.galleria.closeIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.galleria.closeIconTemplate);
  }
}
function GalleriaContent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "p-galleriaItemSlot", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("templates", ctx_r2.galleria.templates);
  }
}
function GalleriaContent_div_0_p_galleriaThumbnails_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "p-galleriaThumbnails", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("onActiveIndexChange", function GalleriaContent_div_0_p_galleriaThumbnails_5_Template_p_galleriaThumbnails_onActiveIndexChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r10.onActiveIndexChange($event));
    })("stopSlideShow", function GalleriaContent_div_0_p_galleriaThumbnails_5_Template_p_galleriaThumbnails_stopSlideShow_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r12.stopSlideShow());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("containerId", ctx_r3.id)("value", ctx_r3.value)("activeIndex", ctx_r3.activeIndex)("templates", ctx_r3.galleria.templates)("numVisible", ctx_r3.numVisible)("responsiveOptions", ctx_r3.galleria.responsiveOptions)("circular", ctx_r3.galleria.circular)("isVertical", ctx_r3.isVertical())("contentHeight", ctx_r3.galleria.verticalThumbnailViewPortHeight)("showThumbnailNavigators", ctx_r3.galleria.showThumbnailNavigators)("slideShowActive", ctx_r3.slideShowActive);
  }
}
function GalleriaContent_div_0_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "p-galleriaItemSlot", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("templates", ctx_r4.galleria.templates);
  }
}
const _c4 = function (a1, a2, a3) {
  return {
    "p-galleria p-component": true,
    "p-galleria-fullscreen": a1,
    "p-galleria-indicator-onitem": a2,
    "p-galleria-item-nav-onhover": a3
  };
};
const _c5 = function () {
  return {};
};
function GalleriaContent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaContent_div_0_button_1_Template, 3, 2, "button", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaContent_div_0_div_2_Template, 2, 1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 4)(4, "p-galleriaItem", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("onActiveIndexChange", function GalleriaContent_div_0_Template_p_galleriaItem_onActiveIndexChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r13.onActiveIndexChange($event));
    })("startSlideShow", function GalleriaContent_div_0_Template_p_galleriaItem_startSlideShow_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r15.startSlideShow());
    })("stopSlideShow", function GalleriaContent_div_0_Template_p_galleriaItem_stopSlideShow_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r16.stopSlideShow());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GalleriaContent_div_0_p_galleriaThumbnails_5_Template, 1, 11, "p-galleriaThumbnails", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, GalleriaContent_div_0_div_6_Template, 2, 1, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r0.galleriaClass());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](20, _c4, ctx_r0.galleria.fullScreen, ctx_r0.galleria.showIndicatorsOnItem, ctx_r0.galleria.showItemNavigatorsOnHover && !ctx_r0.galleria.fullScreen))("ngStyle", !ctx_r0.galleria.fullScreen ? ctx_r0.galleria.containerStyle : _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](24, _c5));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("id", ctx_r0.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.galleria.fullScreen);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.galleria.templates && ctx_r0.galleria.headerFacet);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", ctx_r0.value)("activeIndex", ctx_r0.activeIndex)("circular", ctx_r0.galleria.circular)("templates", ctx_r0.galleria.templates)("showIndicators", ctx_r0.galleria.showIndicators)("changeItemOnIndicatorHover", ctx_r0.galleria.changeItemOnIndicatorHover)("indicatorFacet", ctx_r0.galleria.indicatorFacet)("captionFacet", ctx_r0.galleria.captionFacet)("showItemNavigators", ctx_r0.galleria.showItemNavigators)("autoPlay", ctx_r0.galleria.autoPlay)("slideShowActive", ctx_r0.slideShowActive);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.galleria.showThumbnails);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.galleria.templates && ctx_r0.galleria.footerFacet);
  }
}
function GalleriaItemSlot_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function GalleriaItemSlot_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaItemSlot_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.contentTemplate)("ngTemplateOutletContext", ctx_r0.context);
  }
}
function GalleriaItem_button_2_ChevronLeftIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronLeftIcon", 9);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("styleClass", "p-galleria-item-prev-icon");
  }
}
function GalleriaItem_button_2_2_ng_template_0_Template(rf, ctx) {}
function GalleriaItem_button_2_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaItem_button_2_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
const _c6 = function (a1) {
  return {
    "p-galleria-item-prev p-galleria-item-nav p-link": true,
    "p-disabled": a1
  };
};
function GalleriaItem_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaItem_button_2_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r7.navBackward($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaItem_button_2_ChevronLeftIcon_1_Template, 1, 1, "ChevronLeftIcon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaItem_button_2_2_Template, 1, 0, null, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c6, ctx_r0.isNavBackwardDisabled()))("disabled", ctx_r0.isNavBackwardDisabled());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.galleria.itemPreviousIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.galleria.itemPreviousIconTemplate);
  }
}
function GalleriaItem_button_4_ChevronRightIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronRightIcon", 9);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("styleClass", "p-galleria-item-next-icon");
  }
}
function GalleriaItem_button_4_2_ng_template_0_Template(rf, ctx) {}
function GalleriaItem_button_4_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaItem_button_4_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
const _c7 = function (a1) {
  return {
    "p-galleria-item-next p-galleria-item-nav p-link": true,
    "p-disabled": a1
  };
};
function GalleriaItem_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaItem_button_4_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r12.navForward($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaItem_button_4_ChevronRightIcon_1_Template, 1, 1, "ChevronRightIcon", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaItem_button_4_2_Template, 1, 0, null, 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c7, ctx_r1.isNavForwardDisabled()))("disabled", ctx_r1.isNavForwardDisabled());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r1.galleria.itemNextIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r1.galleria.itemNextIconTemplate);
  }
}
function GalleriaItem_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "p-galleriaItemSlot", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("item", ctx_r2.activeItem)("templates", ctx_r2.templates);
  }
}
function GalleriaItem_ul_6_li_1_button_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "button", 17);
  }
}
const _c8 = function (a1) {
  return {
    "p-galleria-indicator": true,
    "p-highlight": a1
  };
};
function GalleriaItem_ul_6_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaItem_ul_6_li_1_Template_li_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);
      const index_r16 = restoredCtx.index;
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r18.onIndicatorClick(index_r16));
    })("mouseenter", function GalleriaItem_ul_6_li_1_Template_li_mouseenter_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);
      const index_r16 = restoredCtx.index;
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r20.onIndicatorMouseEnter(index_r16));
    })("keydown.enter", function GalleriaItem_ul_6_li_1_Template_li_keydown_enter_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19);
      const index_r16 = restoredCtx.index;
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r21.onIndicatorKeyDown(index_r16));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaItem_ul_6_li_1_button_1_Template, 1, 0, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "p-galleriaItemSlot", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const index_r16 = ctx.index;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c8, ctx_r14.isIndicatorItemActive(index_r16)));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r14.indicatorFacet);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("index", index_r16)("templates", ctx_r14.templates);
  }
}
function GalleriaItem_ul_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaItem_ul_6_li_1_Template, 3, 6, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r3.value);
  }
}
const _c9 = ["itemsContainer"];
function GalleriaThumbnails_button_2_ng_container_1_ChevronLeftIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronLeftIcon", 11);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("styleClass", "p-galleria-thumbnail-prev-icon");
  }
}
function GalleriaThumbnails_button_2_ng_container_1_ChevronUpIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronUpIcon", 11);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("styleClass", "p-galleria-thumbnail-prev-icon");
  }
}
function GalleriaThumbnails_button_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaThumbnails_button_2_ng_container_1_ChevronLeftIcon_1_Template, 1, 1, "ChevronLeftIcon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaThumbnails_button_2_ng_container_1_ChevronUpIcon_2_Template, 1, 1, "ChevronUpIcon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r4.isVertical);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r4.isVertical);
  }
}
function GalleriaThumbnails_button_2_2_ng_template_0_Template(rf, ctx) {}
function GalleriaThumbnails_button_2_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaThumbnails_button_2_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
const _c10 = function (a1) {
  return {
    "p-galleria-thumbnail-prev p-link": true,
    "p-disabled": a1
  };
};
function GalleriaThumbnails_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaThumbnails_button_2_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r9.navBackward($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaThumbnails_button_2_ng_container_1_Template, 3, 2, "ng-container", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaThumbnails_button_2_2_Template, 1, 0, null, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c10, ctx_r0.isNavBackwardDisabled()))("disabled", ctx_r0.isNavBackwardDisabled());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.galleria.previousThumbnailIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.galleria.previousThumbnailIconTemplate);
  }
}
const _c11 = function (a1, a2, a3, a4) {
  return {
    "p-galleria-thumbnail-item": true,
    "p-galleria-thumbnail-item-current": a1,
    "p-galleria-thumbnail-item-active": a2,
    "p-galleria-thumbnail-item-start": a3,
    "p-galleria-thumbnail-item-end": a4
  };
};
function GalleriaThumbnails_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 12)(1, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaThumbnails_div_6_Template_div_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const index_r12 = restoredCtx.index;
      const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r13.onItemClick(index_r12));
    })("keydown.enter", function GalleriaThumbnails_div_6_Template_div_keydown_enter_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r14);
      const index_r12 = restoredCtx.index;
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r15.onItemClick(index_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "p-galleriaItemSlot", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r11 = ctx.$implicit;
    const index_r12 = ctx.index;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction4"](4, _c11, ctx_r2.activeIndex === index_r12, ctx_r2.isItemActive(index_r12), ctx_r2.firstItemAciveIndex() === index_r12, ctx_r2.lastItemActiveIndex() === index_r12));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("tabindex", ctx_r2.getTabIndex(index_r12));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("item", item_r11)("templates", ctx_r2.templates);
  }
}
function GalleriaThumbnails_button_7_ng_container_1_ChevronRightIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronRightIcon", 12);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "p-galleria-thumbnail-next-icon");
  }
}
function GalleriaThumbnails_button_7_ng_container_1_ChevronDownIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronDownIcon", 12);
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", "p-galleria-thumbnail-next-icon");
  }
}
function GalleriaThumbnails_button_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaThumbnails_button_7_ng_container_1_ChevronRightIcon_1_Template, 1, 1, "ChevronRightIcon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaThumbnails_button_7_ng_container_1_ChevronDownIcon_2_Template, 1, 1, "ChevronDownIcon", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r16.isVertical);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r16.isVertical);
  }
}
function GalleriaThumbnails_button_7_2_ng_template_0_Template(rf, ctx) {}
function GalleriaThumbnails_button_7_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaThumbnails_button_7_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
const _c12 = function (a1) {
  return {
    "p-galleria-thumbnail-next p-link": true,
    "p-disabled": a1
  };
};
function GalleriaThumbnails_button_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function GalleriaThumbnails_button_7_Template_button_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r22);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r21.navForward($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, GalleriaThumbnails_button_7_ng_container_1_Template, 3, 2, "ng-container", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaThumbnails_button_7_2_Template, 1, 0, null, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c12, ctx_r3.isNavForwardDisabled()))("disabled", ctx_r3.isNavForwardDisabled());
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r3.galleria.nextThumbnailIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r3.galleria.nextThumbnailIconTemplate);
  }
}
const _c13 = function (a0) {
  return {
    height: a0
  };
};
class Galleria {
  constructor(document, element, cd, config) {
    this.document = document;
    this.element = element;
    this.cd = cd;
    this.config = config;
    this.fullScreen = false;
    this.numVisible = 3;
    this.showItemNavigators = false;
    this.showThumbnailNavigators = true;
    this.showItemNavigatorsOnHover = false;
    this.changeItemOnIndicatorHover = false;
    this.circular = false;
    this.autoPlay = false;
    this.transitionInterval = 4000;
    this.showThumbnails = true;
    this.thumbnailsPosition = 'bottom';
    this.verticalThumbnailViewPortHeight = '300px';
    this.showIndicators = false;
    this.showIndicatorsOnItem = false;
    this.indicatorsPosition = 'bottom';
    this.baseZIndex = 0;
    this.showTransitionOptions = '150ms cubic-bezier(0, 0, 0.2, 1)';
    this.hideTransitionOptions = '150ms cubic-bezier(0, 0, 0.2, 1)';
    this.activeIndexChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this._visible = false;
    this._activeIndex = 0;
    this.maskVisible = false;
  }
  get activeIndex() {
    return this._activeIndex;
  }
  set activeIndex(activeIndex) {
    this._activeIndex = activeIndex;
  }
  get visible() {
    return this._visible;
  }
  set visible(visible) {
    this._visible = visible;
    if (this._visible && !this.maskVisible) {
      this.maskVisible = true;
    }
  }
  ngAfterContentInit() {
    this.templates.forEach(item => {
      switch (item.getType()) {
        case 'header':
          this.headerFacet = item.template;
          break;
        case 'footer':
          this.footerFacet = item.template;
          break;
        case 'indicator':
          this.indicatorFacet = item.template;
          break;
        case 'closeicon':
          this.closeIconTemplate = item.template;
          break;
        case 'itemnexticon':
          this.itemNextIconTemplate = item.template;
          break;
        case 'itempreviousicon':
          this.itemPreviousIconTemplate = item.template;
          break;
        case 'previousthumbnailicon':
          this.previousThumbnailIconTemplate = item.template;
          break;
        case 'nextthumbnailicon':
          this.nextThumbnailIconTemplate = item.template;
          break;
        case 'caption':
          this.captionFacet = item.template;
          break;
      }
    });
  }
  ngOnChanges(simpleChanges) {
    if (simpleChanges.value && simpleChanges.value.currentValue?.length < this.numVisible) {
      this.numVisible = simpleChanges.value.currentValue.length;
    }
  }
  onMaskHide() {
    this.visible = false;
    this.visibleChange.emit(false);
  }
  onActiveItemChange(index) {
    if (this.activeIndex !== index) {
      this.activeIndex = index;
      this.activeIndexChange.emit(index);
    }
  }
  onAnimationStart(event) {
    switch (event.toState) {
      case 'visible':
        this.enableModality();
        break;
      case 'void':
        primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.addClass(this.mask.nativeElement, 'p-component-overlay-leave');
        break;
    }
  }
  onAnimationEnd(event) {
    switch (event.toState) {
      case 'void':
        this.disableModality();
        break;
    }
  }
  enableModality() {
    primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.addClass(this.document.body, 'p-overflow-hidden');
    this.cd.markForCheck();
    if (this.mask) {
      primeng_utils__WEBPACK_IMPORTED_MODULE_2__.ZIndexUtils.set('modal', this.mask.nativeElement, this.baseZIndex || this.config.zIndex.modal);
    }
  }
  disableModality() {
    primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.removeClass(this.document.body, 'p-overflow-hidden');
    this.maskVisible = false;
    this.cd.markForCheck();
    if (this.mask) {
      primeng_utils__WEBPACK_IMPORTED_MODULE_2__.ZIndexUtils.clear(this.mask.nativeElement);
    }
  }
  ngOnDestroy() {
    if (this.fullScreen) {
      primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.removeClass(this.document.body, 'p-overflow-hidden');
    }
    if (this.mask) {
      this.disableModality();
    }
  }
}
Galleria.ɵfac = function Galleria_Factory(t) {
  return new (t || Galleria)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeNGConfig));
};
Galleria.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: Galleria,
  selectors: [["p-galleria"]],
  contentQueries: function Galleria_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Galleria_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.mask = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    activeIndex: "activeIndex",
    fullScreen: "fullScreen",
    id: "id",
    value: "value",
    numVisible: "numVisible",
    responsiveOptions: "responsiveOptions",
    showItemNavigators: "showItemNavigators",
    showThumbnailNavigators: "showThumbnailNavigators",
    showItemNavigatorsOnHover: "showItemNavigatorsOnHover",
    changeItemOnIndicatorHover: "changeItemOnIndicatorHover",
    circular: "circular",
    autoPlay: "autoPlay",
    transitionInterval: "transitionInterval",
    showThumbnails: "showThumbnails",
    thumbnailsPosition: "thumbnailsPosition",
    verticalThumbnailViewPortHeight: "verticalThumbnailViewPortHeight",
    showIndicators: "showIndicators",
    showIndicatorsOnItem: "showIndicatorsOnItem",
    indicatorsPosition: "indicatorsPosition",
    baseZIndex: "baseZIndex",
    maskClass: "maskClass",
    containerClass: "containerClass",
    containerStyle: "containerStyle",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    visible: "visible"
  },
  outputs: {
    activeIndexChange: "activeIndexChange",
    visibleChange: "visibleChange"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
  decls: 3,
  vars: 2,
  consts: [[4, "ngIf", "ngIfElse"], ["windowed", ""], [3, "ngClass", "class", 4, "ngIf"], [3, "ngClass"], ["mask", ""], [3, "value", "activeIndex", "numVisible", "ngStyle", "maskHide", "activeItemChange", 4, "ngIf"], [3, "value", "activeIndex", "numVisible", "ngStyle", "maskHide", "activeItemChange"], [3, "value", "activeIndex", "numVisible", "activeItemChange"]],
  template: function Galleria_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, Galleria_div_0_Template, 2, 1, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, Galleria_ng_template_1_Template, 1, 3, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    }
    if (rf & 2) {
      const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.fullScreen)("ngIfElse", _r1);
    }
  },
  dependencies: function () {
    return [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle, GalleriaContent];
  },
  styles: [".p-galleria-content{display:flex;flex-direction:column}.p-galleria-item-wrapper{display:flex;flex-direction:column;position:relative}.p-galleria-item-container{position:relative;display:flex;height:100%}.p-galleria-item-nav{position:absolute;top:50%;margin-top:-.5rem;display:inline-flex;justify-content:center;align-items:center;overflow:hidden}.p-galleria-item-prev{left:0;border-top-left-radius:0;border-bottom-left-radius:0}.p-galleria-item-next{right:0;border-top-right-radius:0;border-bottom-right-radius:0}.p-galleria-item{display:flex;justify-content:center;align-items:center;height:100%;width:100%}.p-galleria-item-nav-onhover .p-galleria-item-nav{pointer-events:none;opacity:0;transition:opacity .2s ease-in-out}.p-galleria-item-nav-onhover .p-galleria-item-wrapper:hover .p-galleria-item-nav{pointer-events:all;opacity:1}.p-galleria-item-nav-onhover .p-galleria-item-wrapper:hover .p-galleria-item-nav.p-disabled{pointer-events:none}.p-galleria-caption{position:absolute;bottom:0;left:0;width:100%}.p-galleria-thumbnail-wrapper{display:flex;flex-direction:column;overflow:auto;flex-shrink:0}.p-galleria-thumbnail-prev,.p-galleria-thumbnail-next{align-self:center;flex:0 0 auto;display:flex;justify-content:center;align-items:center;overflow:hidden;position:relative}.p-galleria-thumbnail-prev span,.p-galleria-thumbnail-next span{display:flex;justify-content:center;align-items:center}.p-galleria-thumbnail-container{display:flex;flex-direction:row}.p-galleria-thumbnail-items-container{overflow:hidden;width:100%}.p-galleria-thumbnail-items{display:flex}.p-galleria-thumbnail-item{overflow:auto;display:flex;align-items:center;justify-content:center;cursor:pointer;opacity:.5}.p-galleria-thumbnail-item:hover{opacity:1;transition:opacity .3s}.p-galleria-thumbnail-item-current{opacity:1}.p-galleria-thumbnails-left .p-galleria-content,.p-galleria-thumbnails-right .p-galleria-content,.p-galleria-thumbnails-left .p-galleria-item-wrapper,.p-galleria-thumbnails-right .p-galleria-item-wrapper{flex-direction:row}.p-galleria-thumbnails-left p-galleriaitem,.p-galleria-thumbnails-top p-galleriaitem{order:2}.p-galleria-thumbnails-left p-galleriathumbnails,.p-galleria-thumbnails-top p-galleriathumbnails{order:1}.p-galleria-thumbnails-left .p-galleria-thumbnail-container,.p-galleria-thumbnails-right .p-galleria-thumbnail-container{flex-direction:column;flex-grow:1}.p-galleria-thumbnails-left .p-galleria-thumbnail-items,.p-galleria-thumbnails-right .p-galleria-thumbnail-items{flex-direction:column;height:100%}.p-galleria-thumbnails-left .p-galleria-thumbnail-wrapper,.p-galleria-thumbnails-right .p-galleria-thumbnail-wrapper{height:100%}.p-galleria-indicators{display:flex;align-items:center;justify-content:center}.p-galleria-indicator>button{display:inline-flex;align-items:center}.p-galleria-indicators-left .p-galleria-item-wrapper,.p-galleria-indicators-right .p-galleria-item-wrapper{flex-direction:row;align-items:center}.p-galleria-indicators-left .p-galleria-item-container,.p-galleria-indicators-top .p-galleria-item-container{order:2}.p-galleria-indicators-left .p-galleria-indicators,.p-galleria-indicators-top .p-galleria-indicators{order:1}.p-galleria-indicators-left .p-galleria-indicators,.p-galleria-indicators-right .p-galleria-indicators{flex-direction:column}.p-galleria-indicator-onitem .p-galleria-indicators{position:absolute;display:flex;z-index:1}.p-galleria-indicator-onitem.p-galleria-indicators-top .p-galleria-indicators{top:0;left:0;width:100%;align-items:flex-start}.p-galleria-indicator-onitem.p-galleria-indicators-right .p-galleria-indicators{right:0;top:0;height:100%;align-items:flex-end}.p-galleria-indicator-onitem.p-galleria-indicators-bottom .p-galleria-indicators{bottom:0;left:0;width:100%;align-items:flex-end}.p-galleria-indicator-onitem.p-galleria-indicators-left .p-galleria-indicators{left:0;top:0;height:100%;align-items:flex-start}.p-galleria-mask{position:fixed;top:0;left:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background-color:transparent;transition-property:background-color}.p-galleria-close{position:absolute;top:0;right:0;display:flex;justify-content:center;align-items:center;overflow:hidden}.p-galleria-mask .p-galleria-item-nav{position:fixed;top:50%;margin-top:-.5rem}.p-galleria-mask.p-galleria-mask-leave{background-color:transparent}.p-items-hidden .p-galleria-thumbnail-item{visibility:hidden}.p-items-hidden .p-galleria-thumbnail-item.p-galleria-thumbnail-item-active{visibility:visible}\n"],
  encapsulation: 2,
  data: {
    animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.trigger)('animation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.transition)('void => visible', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.style)({
      transform: 'scale(0.7)',
      opacity: 0
    }), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.animate)('{{showTransitionParams}}')]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.transition)('visible => void', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.animate)('{{hideTransitionParams}}', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.style)({
      transform: 'scale(0.7)',
      opacity: 0
    }))])])]
  },
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Galleria, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-galleria',
      template: `
        <div *ngIf="fullScreen; else windowed">
            <div *ngIf="maskVisible" #mask [ngClass]="{ 'p-galleria-mask p-component-overlay p-component-overlay-enter': true, 'p-galleria-visible': this.visible }" [class]="maskClass">
                <p-galleriaContent
                    *ngIf="visible"
                    [@animation]="{ value: 'visible', params: { showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }"
                    (@animation.start)="onAnimationStart($event)"
                    (@animation.done)="onAnimationEnd($event)"
                    [value]="value"
                    [activeIndex]="activeIndex"
                    [numVisible]="numVisible"
                    (maskHide)="onMaskHide()"
                    (activeItemChange)="onActiveItemChange($event)"
                    [ngStyle]="containerStyle"
                ></p-galleriaContent>
            </div>
        </div>

        <ng-template #windowed>
            <p-galleriaContent [value]="value" [activeIndex]="activeIndex" [numVisible]="numVisible" (activeItemChange)="onActiveItemChange($event)"></p-galleriaContent>
        </ng-template>
    `,
      animations: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.trigger)('animation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.transition)('void => visible', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.style)({
        transform: 'scale(0.7)',
        opacity: 0
      }), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.animate)('{{showTransitionParams}}')]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.transition)('visible => void', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.animate)('{{hideTransitionParams}}', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_5__.style)({
        transform: 'scale(0.7)',
        opacity: 0
      }))])])],
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-galleria-content{display:flex;flex-direction:column}.p-galleria-item-wrapper{display:flex;flex-direction:column;position:relative}.p-galleria-item-container{position:relative;display:flex;height:100%}.p-galleria-item-nav{position:absolute;top:50%;margin-top:-.5rem;display:inline-flex;justify-content:center;align-items:center;overflow:hidden}.p-galleria-item-prev{left:0;border-top-left-radius:0;border-bottom-left-radius:0}.p-galleria-item-next{right:0;border-top-right-radius:0;border-bottom-right-radius:0}.p-galleria-item{display:flex;justify-content:center;align-items:center;height:100%;width:100%}.p-galleria-item-nav-onhover .p-galleria-item-nav{pointer-events:none;opacity:0;transition:opacity .2s ease-in-out}.p-galleria-item-nav-onhover .p-galleria-item-wrapper:hover .p-galleria-item-nav{pointer-events:all;opacity:1}.p-galleria-item-nav-onhover .p-galleria-item-wrapper:hover .p-galleria-item-nav.p-disabled{pointer-events:none}.p-galleria-caption{position:absolute;bottom:0;left:0;width:100%}.p-galleria-thumbnail-wrapper{display:flex;flex-direction:column;overflow:auto;flex-shrink:0}.p-galleria-thumbnail-prev,.p-galleria-thumbnail-next{align-self:center;flex:0 0 auto;display:flex;justify-content:center;align-items:center;overflow:hidden;position:relative}.p-galleria-thumbnail-prev span,.p-galleria-thumbnail-next span{display:flex;justify-content:center;align-items:center}.p-galleria-thumbnail-container{display:flex;flex-direction:row}.p-galleria-thumbnail-items-container{overflow:hidden;width:100%}.p-galleria-thumbnail-items{display:flex}.p-galleria-thumbnail-item{overflow:auto;display:flex;align-items:center;justify-content:center;cursor:pointer;opacity:.5}.p-galleria-thumbnail-item:hover{opacity:1;transition:opacity .3s}.p-galleria-thumbnail-item-current{opacity:1}.p-galleria-thumbnails-left .p-galleria-content,.p-galleria-thumbnails-right .p-galleria-content,.p-galleria-thumbnails-left .p-galleria-item-wrapper,.p-galleria-thumbnails-right .p-galleria-item-wrapper{flex-direction:row}.p-galleria-thumbnails-left p-galleriaitem,.p-galleria-thumbnails-top p-galleriaitem{order:2}.p-galleria-thumbnails-left p-galleriathumbnails,.p-galleria-thumbnails-top p-galleriathumbnails{order:1}.p-galleria-thumbnails-left .p-galleria-thumbnail-container,.p-galleria-thumbnails-right .p-galleria-thumbnail-container{flex-direction:column;flex-grow:1}.p-galleria-thumbnails-left .p-galleria-thumbnail-items,.p-galleria-thumbnails-right .p-galleria-thumbnail-items{flex-direction:column;height:100%}.p-galleria-thumbnails-left .p-galleria-thumbnail-wrapper,.p-galleria-thumbnails-right .p-galleria-thumbnail-wrapper{height:100%}.p-galleria-indicators{display:flex;align-items:center;justify-content:center}.p-galleria-indicator>button{display:inline-flex;align-items:center}.p-galleria-indicators-left .p-galleria-item-wrapper,.p-galleria-indicators-right .p-galleria-item-wrapper{flex-direction:row;align-items:center}.p-galleria-indicators-left .p-galleria-item-container,.p-galleria-indicators-top .p-galleria-item-container{order:2}.p-galleria-indicators-left .p-galleria-indicators,.p-galleria-indicators-top .p-galleria-indicators{order:1}.p-galleria-indicators-left .p-galleria-indicators,.p-galleria-indicators-right .p-galleria-indicators{flex-direction:column}.p-galleria-indicator-onitem .p-galleria-indicators{position:absolute;display:flex;z-index:1}.p-galleria-indicator-onitem.p-galleria-indicators-top .p-galleria-indicators{top:0;left:0;width:100%;align-items:flex-start}.p-galleria-indicator-onitem.p-galleria-indicators-right .p-galleria-indicators{right:0;top:0;height:100%;align-items:flex-end}.p-galleria-indicator-onitem.p-galleria-indicators-bottom .p-galleria-indicators{bottom:0;left:0;width:100%;align-items:flex-end}.p-galleria-indicator-onitem.p-galleria-indicators-left .p-galleria-indicators{left:0;top:0;height:100%;align-items:flex-start}.p-galleria-mask{position:fixed;top:0;left:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background-color:transparent;transition-property:background-color}.p-galleria-close{position:absolute;top:0;right:0;display:flex;justify-content:center;align-items:center;overflow:hidden}.p-galleria-mask .p-galleria-item-nav{position:fixed;top:50%;margin-top:-.5rem}.p-galleria-mask.p-galleria-mask-leave{background-color:transparent}.p-items-hidden .p-galleria-thumbnail-item{visibility:hidden}.p-items-hidden .p-galleria-thumbnail-item.p-galleria-thumbnail-item-active{visibility:visible}\n"]
    }]
  }], function () {
    return [{
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }, {
      type: primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeNGConfig
    }];
  }, {
    activeIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    fullScreen: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    id: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    numVisible: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    responsiveOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showItemNavigators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showThumbnailNavigators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showItemNavigatorsOnHover: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    changeItemOnIndicatorHover: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    circular: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    autoPlay: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    transitionInterval: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showThumbnails: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    thumbnailsPosition: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    verticalThumbnailViewPortHeight: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showIndicators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showIndicatorsOnItem: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    indicatorsPosition: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    baseZIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    maskClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    containerClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    containerStyle: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    hideTransitionOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    mask: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['mask']
    }],
    visible: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    activeIndexChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    visibleChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate]
    }]
  });
})();
class GalleriaContent {
  constructor(galleria, cd, differs) {
    this.galleria = galleria;
    this.cd = cd;
    this.differs = differs;
    this.value = [];
    this.maskHide = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.activeItemChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.id = this.galleria.id || (0,primeng_utils__WEBPACK_IMPORTED_MODULE_2__.UniqueComponentId)();
    this._activeIndex = 0;
    this.slideShowActive = true;
    this.differ = this.differs.find(this.galleria).create();
  }
  get activeIndex() {
    return this._activeIndex;
  }
  set activeIndex(activeIndex) {
    this._activeIndex = activeIndex;
  }
  ngDoCheck() {
    const changes = this.differ.diff(this.galleria);
    if (changes?.forEachItem.length > 0) {
      // Because we change the properties of the parent component,
      // and the children take our entity from the injector.
      // We can tell the children to redraw themselves when we change the properties of the parent component.
      // Since we have an onPush strategy
      this.cd.markForCheck();
    }
  }
  galleriaClass() {
    const thumbnailsPosClass = this.galleria.showThumbnails && this.getPositionClass('p-galleria-thumbnails', this.galleria.thumbnailsPosition);
    const indicatorPosClass = this.galleria.showIndicators && this.getPositionClass('p-galleria-indicators', this.galleria.indicatorsPosition);
    return (this.galleria.containerClass ? this.galleria.containerClass + ' ' : '') + (thumbnailsPosClass ? thumbnailsPosClass + ' ' : '') + (indicatorPosClass ? indicatorPosClass + ' ' : '');
  }
  startSlideShow() {
    this.interval = setInterval(() => {
      let activeIndex = this.galleria.circular && this.value.length - 1 === this.activeIndex ? 0 : this.activeIndex + 1;
      this.onActiveIndexChange(activeIndex);
      this.activeIndex = activeIndex;
    }, this.galleria.transitionInterval);
    this.slideShowActive = true;
  }
  stopSlideShow() {
    if (this.interval) {
      clearInterval(this.interval);
    }
    this.slideShowActive = false;
  }
  getPositionClass(preClassName, position) {
    const positions = ['top', 'left', 'bottom', 'right'];
    const pos = positions.find(item => item === position);
    return pos ? `${preClassName}-${pos}` : '';
  }
  isVertical() {
    return this.galleria.thumbnailsPosition === 'left' || this.galleria.thumbnailsPosition === 'right';
  }
  onActiveIndexChange(index) {
    if (this.activeIndex !== index) {
      this.activeIndex = index;
      this.activeItemChange.emit(this.activeIndex);
    }
  }
}
GalleriaContent.ɵfac = function GalleriaContent_Factory(t) {
  return new (t || GalleriaContent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](Galleria), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.KeyValueDiffers));
};
GalleriaContent.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: GalleriaContent,
  selectors: [["p-galleriaContent"]],
  inputs: {
    activeIndex: "activeIndex",
    value: "value",
    numVisible: "numVisible"
  },
  outputs: {
    maskHide: "maskHide",
    activeItemChange: "activeItemChange"
  },
  decls: 1,
  vars: 1,
  consts: [[3, "ngClass", "ngStyle", "class", 4, "ngIf"], [3, "ngClass", "ngStyle"], ["type", "button", "class", "p-galleria-close p-link", "pRipple", "", 3, "click", 4, "ngIf"], ["class", "p-galleria-header", 4, "ngIf"], [1, "p-galleria-content"], [3, "value", "activeIndex", "circular", "templates", "showIndicators", "changeItemOnIndicatorHover", "indicatorFacet", "captionFacet", "showItemNavigators", "autoPlay", "slideShowActive", "onActiveIndexChange", "startSlideShow", "stopSlideShow"], [3, "containerId", "value", "activeIndex", "templates", "numVisible", "responsiveOptions", "circular", "isVertical", "contentHeight", "showThumbnailNavigators", "slideShowActive", "onActiveIndexChange", "stopSlideShow", 4, "ngIf"], ["class", "p-galleria-footer", 4, "ngIf"], ["type", "button", "pRipple", "", 1, "p-galleria-close", "p-link", 3, "click"], [3, "styleClass", 4, "ngIf"], [4, "ngTemplateOutlet"], [3, "styleClass"], [1, "p-galleria-header"], ["type", "header", 3, "templates"], [3, "containerId", "value", "activeIndex", "templates", "numVisible", "responsiveOptions", "circular", "isVertical", "contentHeight", "showThumbnailNavigators", "slideShowActive", "onActiveIndexChange", "stopSlideShow"], [1, "p-galleria-footer"], ["type", "footer", 3, "templates"]],
  template: function GalleriaContent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaContent_div_0_Template, 7, 25, "div", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.value && ctx.value.length > 0);
    }
  },
  dependencies: function () {
    return [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle, primeng_ripple__WEBPACK_IMPORTED_MODULE_6__.Ripple, primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__.TimesIcon, GalleriaItemSlot, GalleriaItem, GalleriaThumbnails];
  },
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GalleriaContent, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-galleriaContent',
      template: `
        <div
            [attr.id]="id"
            *ngIf="value && value.length > 0"
            [ngClass]="{
                'p-galleria p-component': true,
                'p-galleria-fullscreen': this.galleria.fullScreen,
                'p-galleria-indicator-onitem': this.galleria.showIndicatorsOnItem,
                'p-galleria-item-nav-onhover': this.galleria.showItemNavigatorsOnHover && !this.galleria.fullScreen
            }"
            [ngStyle]="!galleria.fullScreen ? galleria.containerStyle : {}"
            [class]="galleriaClass()"
        >
            <button *ngIf="galleria.fullScreen" type="button" class="p-galleria-close p-link" (click)="maskHide.emit()" pRipple>
                <TimesIcon *ngIf="!galleria.closeIconTemplate" [styleClass]="'p-galleria-close-icon'"/>
                <ng-template *ngTemplateOutlet="galleria.closeIconTemplate"></ng-template>
            </button>
            <div *ngIf="galleria.templates && galleria.headerFacet" class="p-galleria-header">
                <p-galleriaItemSlot type="header" [templates]="galleria.templates"></p-galleriaItemSlot>
            </div>
            <div class="p-galleria-content">
                <p-galleriaItem
                    [value]="value"
                    [activeIndex]="activeIndex"
                    [circular]="galleria.circular"
                    [templates]="galleria.templates"
                    (onActiveIndexChange)="onActiveIndexChange($event)"
                    [showIndicators]="galleria.showIndicators"
                    [changeItemOnIndicatorHover]="galleria.changeItemOnIndicatorHover"
                    [indicatorFacet]="galleria.indicatorFacet"
                    [captionFacet]="galleria.captionFacet"
                    [showItemNavigators]="galleria.showItemNavigators"
                    [autoPlay]="galleria.autoPlay"
                    [slideShowActive]="slideShowActive"
                    (startSlideShow)="startSlideShow()"
                    (stopSlideShow)="stopSlideShow()"
                ></p-galleriaItem>

                <p-galleriaThumbnails
                    *ngIf="galleria.showThumbnails"
                    [containerId]="id"
                    [value]="value"
                    (onActiveIndexChange)="onActiveIndexChange($event)"
                    [activeIndex]="activeIndex"
                    [templates]="galleria.templates"
                    [numVisible]="numVisible"
                    [responsiveOptions]="galleria.responsiveOptions"
                    [circular]="galleria.circular"
                    [isVertical]="isVertical()"
                    [contentHeight]="galleria.verticalThumbnailViewPortHeight"
                    [showThumbnailNavigators]="galleria.showThumbnailNavigators"
                    [slideShowActive]="slideShowActive"
                    (stopSlideShow)="stopSlideShow()"
                ></p-galleriaThumbnails>
            </div>
            <div *ngIf="galleria.templates && galleria.footerFacet" class="p-galleria-footer">
                <p-galleriaItemSlot type="footer" [templates]="galleria.templates"></p-galleriaItemSlot>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush
    }]
  }], function () {
    return [{
      type: Galleria
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.KeyValueDiffers
    }];
  }, {
    activeIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    numVisible: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    maskHide: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    activeItemChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }]
  });
})();
class GalleriaItemSlot {
  get item() {
    return this._item;
  }
  set item(item) {
    this._item = item;
    if (this.templates) {
      this.templates.forEach(item => {
        if (item.getType() === this.type) {
          switch (this.type) {
            case 'item':
            case 'caption':
            case 'thumbnail':
              this.context = {
                $implicit: this.item
              };
              this.contentTemplate = item.template;
              break;
          }
        }
      });
    }
  }
  ngAfterContentInit() {
    this.templates.forEach(item => {
      if (item.getType() === this.type) {
        switch (this.type) {
          case 'item':
          case 'caption':
          case 'thumbnail':
            this.context = {
              $implicit: this.item
            };
            this.contentTemplate = item.template;
            break;
          case 'indicator':
            this.context = {
              $implicit: this.index
            };
            this.contentTemplate = item.template;
            break;
          default:
            this.context = {};
            this.contentTemplate = item.template;
            break;
        }
      }
    });
  }
}
GalleriaItemSlot.ɵfac = function GalleriaItemSlot_Factory(t) {
  return new (t || GalleriaItemSlot)();
};
GalleriaItemSlot.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: GalleriaItemSlot,
  selectors: [["p-galleriaItemSlot"]],
  inputs: {
    templates: "templates",
    index: "index",
    item: "item",
    type: "type"
  },
  decls: 1,
  vars: 1,
  consts: [[4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function GalleriaItemSlot_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, GalleriaItemSlot_ng_container_0_Template, 2, 2, "ng-container", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.contentTemplate);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgTemplateOutlet],
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GalleriaItemSlot, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-galleriaItemSlot',
      template: `
        <ng-container *ngIf="contentTemplate">
            <ng-container *ngTemplateOutlet="contentTemplate; context: context"></ng-container>
        </ng-container>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush
    }]
  }], null, {
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    index: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    item: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    type: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class GalleriaItem {
  constructor(galleria) {
    this.galleria = galleria;
    this.circular = false;
    this.showItemNavigators = false;
    this.showIndicators = true;
    this.slideShowActive = true;
    this.changeItemOnIndicatorHover = true;
    this.autoPlay = false;
    this.startSlideShow = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.stopSlideShow = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.onActiveIndexChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this._activeIndex = 0;
  }
  get activeIndex() {
    return this._activeIndex;
  }
  set activeIndex(activeIndex) {
    this._activeIndex = activeIndex;
  }
  get activeItem() {
    return this.value[this._activeIndex];
  }
  ngOnChanges({
    autoPlay
  }) {
    if (autoPlay?.currentValue) {
      this.startSlideShow.emit();
    }
    if (autoPlay && autoPlay.currentValue === false) {
      this.stopTheSlideShow();
    }
  }
  next() {
    let nextItemIndex = this.activeIndex + 1;
    let activeIndex = this.circular && this.value.length - 1 === this.activeIndex ? 0 : nextItemIndex;
    this.onActiveIndexChange.emit(activeIndex);
  }
  prev() {
    let prevItemIndex = this.activeIndex !== 0 ? this.activeIndex - 1 : 0;
    let activeIndex = this.circular && this.activeIndex === 0 ? this.value.length - 1 : prevItemIndex;
    this.onActiveIndexChange.emit(activeIndex);
  }
  stopTheSlideShow() {
    if (this.slideShowActive && this.stopSlideShow) {
      this.stopSlideShow.emit();
    }
  }
  navForward(e) {
    this.stopTheSlideShow();
    this.next();
    if (e && e.cancelable) {
      e.preventDefault();
    }
  }
  navBackward(e) {
    this.stopTheSlideShow();
    this.prev();
    if (e && e.cancelable) {
      e.preventDefault();
    }
  }
  onIndicatorClick(index) {
    this.stopTheSlideShow();
    this.onActiveIndexChange.emit(index);
  }
  onIndicatorMouseEnter(index) {
    if (this.changeItemOnIndicatorHover) {
      this.stopTheSlideShow();
      this.onActiveIndexChange.emit(index);
    }
  }
  onIndicatorKeyDown(index) {
    this.stopTheSlideShow();
    this.onActiveIndexChange.emit(index);
  }
  isNavForwardDisabled() {
    return !this.circular && this.activeIndex === this.value.length - 1;
  }
  isNavBackwardDisabled() {
    return !this.circular && this.activeIndex === 0;
  }
  isIndicatorItemActive(index) {
    return this.activeIndex === index;
  }
}
GalleriaItem.ɵfac = function GalleriaItem_Factory(t) {
  return new (t || GalleriaItem)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](Galleria));
};
GalleriaItem.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: GalleriaItem,
  selectors: [["p-galleriaItem"]],
  inputs: {
    circular: "circular",
    value: "value",
    showItemNavigators: "showItemNavigators",
    showIndicators: "showIndicators",
    slideShowActive: "slideShowActive",
    changeItemOnIndicatorHover: "changeItemOnIndicatorHover",
    autoPlay: "autoPlay",
    templates: "templates",
    indicatorFacet: "indicatorFacet",
    captionFacet: "captionFacet",
    activeIndex: "activeIndex"
  },
  outputs: {
    startSlideShow: "startSlideShow",
    stopSlideShow: "stopSlideShow",
    onActiveIndexChange: "onActiveIndexChange"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]],
  decls: 7,
  vars: 6,
  consts: [[1, "p-galleria-item-wrapper"], [1, "p-galleria-item-container"], ["type", "button", "pRipple", "", 3, "ngClass", "disabled", "click", 4, "ngIf"], ["type", "item", 1, "p-galleria-item", 3, "item", "templates"], ["class", "p-galleria-caption", 4, "ngIf"], ["class", "p-galleria-indicators p-reset", 4, "ngIf"], ["type", "button", "pRipple", "", 3, "ngClass", "disabled", "click"], [3, "styleClass", 4, "ngIf"], [4, "ngTemplateOutlet"], [3, "styleClass"], [1, "p-galleria-caption"], ["type", "caption", 3, "item", "templates"], [1, "p-galleria-indicators", "p-reset"], ["tabindex", "0", 3, "ngClass", "click", "mouseenter", "keydown.enter", 4, "ngFor", "ngForOf"], ["tabindex", "0", 3, "ngClass", "click", "mouseenter", "keydown.enter"], ["type", "button", "tabIndex", "-1", "class", "p-link", 4, "ngIf"], ["type", "indicator", 3, "index", "templates"], ["type", "button", "tabIndex", "-1", 1, "p-link"]],
  template: function GalleriaItem_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaItem_button_2_Template, 3, 6, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "p-galleriaItemSlot", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, GalleriaItem_button_4_Template, 3, 6, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, GalleriaItem_div_5_Template, 2, 2, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, GalleriaItem_ul_6_Template, 2, 1, "ul", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showItemNavigators);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("item", ctx.activeItem)("templates", ctx.templates);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showItemNavigators);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.captionFacet);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showIndicators);
    }
  },
  dependencies: function () {
    return [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgTemplateOutlet, primeng_ripple__WEBPACK_IMPORTED_MODULE_6__.Ripple, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_9__.ChevronLeftIcon, GalleriaItemSlot];
  },
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GalleriaItem, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-galleriaItem',
      template: `
        <div class="p-galleria-item-wrapper">
            <div class="p-galleria-item-container">
                <button
                    *ngIf="showItemNavigators"
                    type="button"
                    [ngClass]="{ 'p-galleria-item-prev p-galleria-item-nav p-link': true, 'p-disabled': this.isNavBackwardDisabled() }"
                    (click)="navBackward($event)"
                    [disabled]="isNavBackwardDisabled()"
                    pRipple
                >
                    <ChevronLeftIcon *ngIf="!galleria.itemPreviousIconTemplate" [styleClass]="'p-galleria-item-prev-icon'"/>
                    <ng-template *ngTemplateOutlet="galleria.itemPreviousIconTemplate"></ng-template>
                </button>
                <p-galleriaItemSlot type="item" [item]="activeItem" [templates]="templates" class="p-galleria-item"></p-galleriaItemSlot>
                <button
                    *ngIf="showItemNavigators"
                    type="button"
                    [ngClass]="{ 'p-galleria-item-next p-galleria-item-nav p-link': true, 'p-disabled': this.isNavForwardDisabled() }"
                    (click)="navForward($event)"
                    [disabled]="isNavForwardDisabled()"
                    pRipple
                >
                    <ChevronRightIcon *ngIf="!galleria.itemNextIconTemplate" [styleClass]="'p-galleria-item-next-icon'"/>
                    <ng-template *ngTemplateOutlet="galleria.itemNextIconTemplate"></ng-template>
                </button>
                <div class="p-galleria-caption" *ngIf="captionFacet">
                    <p-galleriaItemSlot type="caption" [item]="activeItem" [templates]="templates"></p-galleriaItemSlot>
                </div>
            </div>
            <ul *ngIf="showIndicators" class="p-galleria-indicators p-reset">
                <li
                    *ngFor="let item of value; let index = index"
                    tabindex="0"
                    (click)="onIndicatorClick(index)"
                    (mouseenter)="onIndicatorMouseEnter(index)"
                    (keydown.enter)="onIndicatorKeyDown(index)"
                    [ngClass]="{ 'p-galleria-indicator': true, 'p-highlight': isIndicatorItemActive(index) }"
                >
                    <button type="button" tabIndex="-1" class="p-link" *ngIf="!indicatorFacet"></button>
                    <p-galleriaItemSlot type="indicator" [index]="index" [templates]="templates"></p-galleriaItemSlot>
                </li>
            </ul>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush
    }]
  }], function () {
    return [{
      type: Galleria
    }];
  }, {
    circular: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showItemNavigators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showIndicators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    slideShowActive: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    changeItemOnIndicatorHover: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    autoPlay: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    indicatorFacet: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    captionFacet: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    startSlideShow: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    stopSlideShow: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    onActiveIndexChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    activeIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class GalleriaThumbnails {
  constructor(galleria, document, platformId, renderer, cd) {
    this.galleria = galleria;
    this.document = document;
    this.platformId = platformId;
    this.renderer = renderer;
    this.cd = cd;
    this.isVertical = false;
    this.slideShowActive = false;
    this.circular = false;
    this.contentHeight = '300px';
    this.showThumbnailNavigators = true;
    this.onActiveIndexChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.stopSlideShow = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.startPos = null;
    this.thumbnailsStyle = null;
    this.sortedResponsiveOptions = null;
    this.totalShiftedItems = 0;
    this.page = 0;
    this._numVisible = 0;
    this.d_numVisible = 0;
    this._oldNumVisible = 0;
    this._activeIndex = 0;
    this._oldactiveIndex = 0;
  }
  get numVisible() {
    return this._numVisible;
  }
  set numVisible(numVisible) {
    this._numVisible = numVisible;
    this._oldNumVisible = this.d_numVisible;
    this.d_numVisible = numVisible;
  }
  get activeIndex() {
    return this._activeIndex;
  }
  set activeIndex(activeIndex) {
    this._oldactiveIndex = this._activeIndex;
    this._activeIndex = activeIndex;
  }
  ngOnInit() {
    this.createStyle();
    if (this.responsiveOptions) {
      this.bindDocumentListeners();
    }
  }
  ngAfterContentChecked() {
    let totalShiftedItems = this.totalShiftedItems;
    if ((this._oldNumVisible !== this.d_numVisible || this._oldactiveIndex !== this._activeIndex) && this.itemsContainer) {
      if (this._activeIndex <= this.getMedianItemIndex()) {
        totalShiftedItems = 0;
      } else if (this.value.length - this.d_numVisible + this.getMedianItemIndex() < this._activeIndex) {
        totalShiftedItems = this.d_numVisible - this.value.length;
      } else if (this.value.length - this.d_numVisible < this._activeIndex && this.d_numVisible % 2 === 0) {
        totalShiftedItems = this._activeIndex * -1 + this.getMedianItemIndex() + 1;
      } else {
        totalShiftedItems = this._activeIndex * -1 + this.getMedianItemIndex();
      }
      if (totalShiftedItems !== this.totalShiftedItems) {
        this.totalShiftedItems = totalShiftedItems;
      }
      if (this.itemsContainer && this.itemsContainer.nativeElement) {
        this.itemsContainer.nativeElement.style.transform = this.isVertical ? `translate3d(0, ${totalShiftedItems * (100 / this.d_numVisible)}%, 0)` : `translate3d(${totalShiftedItems * (100 / this.d_numVisible)}%, 0, 0)`;
      }
      if (this._oldactiveIndex !== this._activeIndex) {
        primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.removeClass(this.itemsContainer.nativeElement, 'p-items-hidden');
        this.itemsContainer.nativeElement.style.transition = 'transform 500ms ease 0s';
      }
      this._oldactiveIndex = this._activeIndex;
      this._oldNumVisible = this.d_numVisible;
    }
  }
  ngAfterViewInit() {
    this.calculatePosition();
  }
  createStyle() {
    if (!this.thumbnailsStyle) {
      this.thumbnailsStyle = this.document.createElement('style');
      this.thumbnailsStyle.type = 'text/css';
      this.document.body.appendChild(this.thumbnailsStyle);
    }
    let innerHTML = `
            #${this.containerId} .p-galleria-thumbnail-item {
                flex: 1 0 ${100 / this.d_numVisible}%
            }
        `;
    if (this.responsiveOptions) {
      this.sortedResponsiveOptions = [...this.responsiveOptions];
      this.sortedResponsiveOptions.sort((data1, data2) => {
        const value1 = data1.breakpoint;
        const value2 = data2.breakpoint;
        let result = null;
        if (value1 == null && value2 != null) result = -1;else if (value1 != null && value2 == null) result = 1;else if (value1 == null && value2 == null) result = 0;else if (typeof value1 === 'string' && typeof value2 === 'string') result = value1.localeCompare(value2, undefined, {
          numeric: true
        });else result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
        return -1 * result;
      });
      for (let i = 0; i < this.sortedResponsiveOptions.length; i++) {
        let res = this.sortedResponsiveOptions[i];
        innerHTML += `
                    @media screen and (max-width: ${res.breakpoint}) {
                        #${this.containerId} .p-galleria-thumbnail-item {
                            flex: 1 0 ${100 / res.numVisible}%
                        }
                    }
                `;
      }
    }
    this.thumbnailsStyle.innerHTML = innerHTML;
  }
  calculatePosition() {
    if (this.itemsContainer && this.sortedResponsiveOptions) {
      let windowWidth = window.innerWidth;
      let matchedResponsiveData = {
        numVisible: this._numVisible
      };
      for (let i = 0; i < this.sortedResponsiveOptions.length; i++) {
        let res = this.sortedResponsiveOptions[i];
        if (parseInt(res.breakpoint, 10) >= windowWidth) {
          matchedResponsiveData = res;
        }
      }
      if (this.d_numVisible !== matchedResponsiveData.numVisible) {
        this.d_numVisible = matchedResponsiveData.numVisible;
        this.cd.markForCheck();
      }
    }
  }
  getTabIndex(index) {
    return this.isItemActive(index) ? 0 : null;
  }
  navForward(e) {
    this.stopTheSlideShow();
    let nextItemIndex = this._activeIndex + 1;
    if (nextItemIndex + this.totalShiftedItems > this.getMedianItemIndex() && (-1 * this.totalShiftedItems < this.getTotalPageNumber() - 1 || this.circular)) {
      this.step(-1);
    }
    let activeIndex = this.circular && this.value.length - 1 === this._activeIndex ? 0 : nextItemIndex;
    this.onActiveIndexChange.emit(activeIndex);
    if (e.cancelable) {
      e.preventDefault();
    }
  }
  navBackward(e) {
    this.stopTheSlideShow();
    let prevItemIndex = this._activeIndex !== 0 ? this._activeIndex - 1 : 0;
    let diff = prevItemIndex + this.totalShiftedItems;
    if (this.d_numVisible - diff - 1 > this.getMedianItemIndex() && (-1 * this.totalShiftedItems !== 0 || this.circular)) {
      this.step(1);
    }
    let activeIndex = this.circular && this._activeIndex === 0 ? this.value.length - 1 : prevItemIndex;
    this.onActiveIndexChange.emit(activeIndex);
    if (e.cancelable) {
      e.preventDefault();
    }
  }
  onItemClick(index) {
    this.stopTheSlideShow();
    let selectedItemIndex = index;
    if (selectedItemIndex !== this._activeIndex) {
      const diff = selectedItemIndex + this.totalShiftedItems;
      let dir = 0;
      if (selectedItemIndex < this._activeIndex) {
        dir = this.d_numVisible - diff - 1 - this.getMedianItemIndex();
        if (dir > 0 && -1 * this.totalShiftedItems !== 0) {
          this.step(dir);
        }
      } else {
        dir = this.getMedianItemIndex() - diff;
        if (dir < 0 && -1 * this.totalShiftedItems < this.getTotalPageNumber() - 1) {
          this.step(dir);
        }
      }
      this.activeIndex = selectedItemIndex;
      this.onActiveIndexChange.emit(this.activeIndex);
    }
  }
  step(dir) {
    let totalShiftedItems = this.totalShiftedItems + dir;
    if (dir < 0 && -1 * totalShiftedItems + this.d_numVisible > this.value.length - 1) {
      totalShiftedItems = this.d_numVisible - this.value.length;
    } else if (dir > 0 && totalShiftedItems > 0) {
      totalShiftedItems = 0;
    }
    if (this.circular) {
      if (dir < 0 && this.value.length - 1 === this._activeIndex) {
        totalShiftedItems = 0;
      } else if (dir > 0 && this._activeIndex === 0) {
        totalShiftedItems = this.d_numVisible - this.value.length;
      }
    }
    if (this.itemsContainer) {
      primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.removeClass(this.itemsContainer.nativeElement, 'p-items-hidden');
      this.itemsContainer.nativeElement.style.transform = this.isVertical ? `translate3d(0, ${totalShiftedItems * (100 / this.d_numVisible)}%, 0)` : `translate3d(${totalShiftedItems * (100 / this.d_numVisible)}%, 0, 0)`;
      this.itemsContainer.nativeElement.style.transition = 'transform 500ms ease 0s';
    }
    this.totalShiftedItems = totalShiftedItems;
  }
  stopTheSlideShow() {
    if (this.slideShowActive && this.stopSlideShow) {
      this.stopSlideShow.emit();
    }
  }
  changePageOnTouch(e, diff) {
    if (diff < 0) {
      // left
      this.navForward(e);
    } else {
      // right
      this.navBackward(e);
    }
  }
  getTotalPageNumber() {
    return this.value.length > this.d_numVisible ? this.value.length - this.d_numVisible + 1 : 0;
  }
  getMedianItemIndex() {
    let index = Math.floor(this.d_numVisible / 2);
    return this.d_numVisible % 2 ? index : index - 1;
  }
  onTransitionEnd() {
    if (this.itemsContainer && this.itemsContainer.nativeElement) {
      primeng_dom__WEBPACK_IMPORTED_MODULE_1__.DomHandler.addClass(this.itemsContainer.nativeElement, 'p-items-hidden');
      this.itemsContainer.nativeElement.style.transition = '';
    }
  }
  onTouchEnd(e) {
    let touchobj = e.changedTouches[0];
    if (this.isVertical) {
      this.changePageOnTouch(e, touchobj.pageY - this.startPos.y);
    } else {
      this.changePageOnTouch(e, touchobj.pageX - this.startPos.x);
    }
  }
  onTouchMove(e) {
    if (e.cancelable) {
      e.preventDefault();
    }
  }
  onTouchStart(e) {
    let touchobj = e.changedTouches[0];
    this.startPos = {
      x: touchobj.pageX,
      y: touchobj.pageY
    };
  }
  isNavBackwardDisabled() {
    return !this.circular && this._activeIndex === 0 || this.value.length <= this.d_numVisible;
  }
  isNavForwardDisabled() {
    return !this.circular && this._activeIndex === this.value.length - 1 || this.value.length <= this.d_numVisible;
  }
  firstItemAciveIndex() {
    return this.totalShiftedItems * -1;
  }
  lastItemActiveIndex() {
    return this.firstItemAciveIndex() + this.d_numVisible - 1;
  }
  isItemActive(index) {
    return this.firstItemAciveIndex() <= index && this.lastItemActiveIndex() >= index;
  }
  bindDocumentListeners() {
    if ((0,_angular_common__WEBPACK_IMPORTED_MODULE_3__.isPlatformBrowser)(this.platformId)) {
      const window = this.document.defaultView || 'window';
      this.documentResizeListener = this.renderer.listen(window, 'resize', () => {
        this.calculatePosition();
      });
    }
  }
  unbindDocumentListeners() {
    if (this.documentResizeListener) {
      this.documentResizeListener();
      this.documentResizeListener = null;
    }
  }
  ngOnDestroy() {
    if (this.responsiveOptions) {
      this.unbindDocumentListeners();
    }
    if (this.thumbnailsStyle) {
      this.thumbnailsStyle.parentNode.removeChild(this.thumbnailsStyle);
    }
  }
}
GalleriaThumbnails.ɵfac = function GalleriaThumbnails_Factory(t) {
  return new (t || GalleriaThumbnails)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](Galleria), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.PLATFORM_ID), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
};
GalleriaThumbnails.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: GalleriaThumbnails,
  selectors: [["p-galleriaThumbnails"]],
  viewQuery: function GalleriaThumbnails_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c9, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.itemsContainer = _t.first);
    }
  },
  inputs: {
    containerId: "containerId",
    value: "value",
    isVertical: "isVertical",
    slideShowActive: "slideShowActive",
    circular: "circular",
    responsiveOptions: "responsiveOptions",
    contentHeight: "contentHeight",
    showThumbnailNavigators: "showThumbnailNavigators",
    templates: "templates",
    numVisible: "numVisible",
    activeIndex: "activeIndex"
  },
  outputs: {
    onActiveIndexChange: "onActiveIndexChange",
    stopSlideShow: "stopSlideShow"
  },
  decls: 8,
  vars: 6,
  consts: [[1, "p-galleria-thumbnail-wrapper"], [1, "p-galleria-thumbnail-container"], ["type", "button", "pRipple", "", 3, "ngClass", "disabled", "click", 4, "ngIf"], [1, "p-galleria-thumbnail-items-container", 3, "ngStyle"], [1, "p-galleria-thumbnail-items", 3, "transitionend", "touchstart", "touchmove", "touchend"], ["itemsContainer", ""], [3, "ngClass", 4, "ngFor", "ngForOf"], ["type", "button", "pRipple", "", 3, "ngClass", "disabled", "click"], [4, "ngIf"], [4, "ngTemplateOutlet"], [3, "styleClass", 4, "ngIf"], [3, "styleClass"], [3, "ngClass"], [1, "p-galleria-thumbnail-item-content", 3, "click", "keydown.enter"], ["type", "thumbnail", 3, "item", "templates"], [3, "ngClass", 4, "ngIf"]],
  template: function GalleriaThumbnails_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, GalleriaThumbnails_button_2_Template, 3, 6, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3)(4, "div", 4, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("transitionend", function GalleriaThumbnails_Template_div_transitionend_4_listener() {
        return ctx.onTransitionEnd();
      })("touchstart", function GalleriaThumbnails_Template_div_touchstart_4_listener($event) {
        return ctx.onTouchStart($event);
      })("touchmove", function GalleriaThumbnails_Template_div_touchmove_4_listener($event) {
        return ctx.onTouchMove($event);
      })("touchend", function GalleriaThumbnails_Template_div_touchend_4_listener($event) {
        return ctx.onTouchEnd($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, GalleriaThumbnails_div_6_Template, 3, 9, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, GalleriaThumbnails_button_7_Template, 3, 6, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showThumbnailNavigators);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](4, _c13, ctx.isVertical ? ctx.contentHeight : ""));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.value);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.showThumbnailNavigators);
    }
  },
  dependencies: function () {
    return [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle, primeng_ripple__WEBPACK_IMPORTED_MODULE_6__.Ripple, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_9__.ChevronLeftIcon, GalleriaItemSlot];
  },
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GalleriaThumbnails, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-galleriaThumbnails',
      template: `
        <div class="p-galleria-thumbnail-wrapper">
            <div class="p-galleria-thumbnail-container">
                <button *ngIf="showThumbnailNavigators" type="button" [ngClass]="{ 'p-galleria-thumbnail-prev p-link': true, 'p-disabled': this.isNavBackwardDisabled() }" (click)="navBackward($event)" [disabled]="isNavBackwardDisabled()" pRipple>
                    <ng-container *ngIf="!galleria.previousThumbnailIconTemplate">
                        <ChevronLeftIcon *ngIf="!isVertical" [styleClass]="'p-galleria-thumbnail-prev-icon'"/>
                        <ChevronUpIcon *ngIf="isVertical" [styleClass]="'p-galleria-thumbnail-prev-icon'"/>
                    </ng-container>
                    <ng-template *ngTemplateOutlet="galleria.previousThumbnailIconTemplate"></ng-template>
                </button>
                <div class="p-galleria-thumbnail-items-container" [ngStyle]="{ height: isVertical ? contentHeight : '' }">
                    <div #itemsContainer class="p-galleria-thumbnail-items" (transitionend)="onTransitionEnd()" (touchstart)="onTouchStart($event)" (touchmove)="onTouchMove($event)" (touchend)="onTouchEnd($event)">
                        <div
                            *ngFor="let item of value; let index = index"
                            [ngClass]="{
                                'p-galleria-thumbnail-item': true,
                                'p-galleria-thumbnail-item-current': activeIndex === index,
                                'p-galleria-thumbnail-item-active': isItemActive(index),
                                'p-galleria-thumbnail-item-start': firstItemAciveIndex() === index,
                                'p-galleria-thumbnail-item-end': lastItemActiveIndex() === index
                            }"
                        >
                            <div class="p-galleria-thumbnail-item-content" [attr.tabindex]="getTabIndex(index)" (click)="onItemClick(index)" (keydown.enter)="onItemClick(index)">
                                <p-galleriaItemSlot type="thumbnail" [item]="item" [templates]="templates"></p-galleriaItemSlot>
                            </div>
                        </div>
                    </div>
                </div>
                <button *ngIf="showThumbnailNavigators" type="button" [ngClass]="{ 'p-galleria-thumbnail-next p-link': true, 'p-disabled': this.isNavForwardDisabled() }" (click)="navForward($event)" [disabled]="isNavForwardDisabled()" pRipple>
                    <ng-container *ngIf="!galleria.nextThumbnailIconTemplate">
                        <ChevronRightIcon *ngIf="!isVertical" [ngClass]="'p-galleria-thumbnail-next-icon'"/>
                        <ChevronDownIcon *ngIf="isVertical" [ngClass]="'p-galleria-thumbnail-next-icon'"/>
                    </ng-container>
                    <ng-template *ngTemplateOutlet="galleria.nextThumbnailIconTemplate"></ng-template>
                </button>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush
    }]
  }], function () {
    return [{
      type: Galleria
    }, {
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT]
      }]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__.PLATFORM_ID]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }];
  }, {
    containerId: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    isVertical: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    slideShowActive: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    circular: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    responsiveOptions: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    contentHeight: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showThumbnailNavigators: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    onActiveIndexChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    stopSlideShow: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    itemsContainer: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['itemsContainer']
    }],
    numVisible: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    activeIndex: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class GalleriaModule {}
GalleriaModule.ɵfac = function GalleriaModule_Factory(t) {
  return new (t || GalleriaModule)();
};
GalleriaModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: GalleriaModule
});
GalleriaModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_6__.RippleModule, primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__.TimesIcon, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_9__.ChevronLeftIcon, primeng_icons_windowmaximize__WEBPACK_IMPORTED_MODULE_10__.WindowMaximizeIcon, primeng_icons_windowminimize__WEBPACK_IMPORTED_MODULE_11__.WindowMinimizeIcon, _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](GalleriaModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_6__.RippleModule, primeng_icons_times__WEBPACK_IMPORTED_MODULE_7__.TimesIcon, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_9__.ChevronLeftIcon, primeng_icons_windowmaximize__WEBPACK_IMPORTED_MODULE_10__.WindowMaximizeIcon, primeng_icons_windowminimize__WEBPACK_IMPORTED_MODULE_11__.WindowMinimizeIcon],
      exports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, Galleria, GalleriaContent, GalleriaItemSlot, GalleriaItem, GalleriaThumbnails, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule],
      declarations: [Galleria, GalleriaContent, GalleriaItemSlot, GalleriaItem, GalleriaThumbnails]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-galleria.mjs.map

/***/ }),

/***/ 7077:
/*!***********************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-tabmenu.mjs ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabMenu": () => (/* binding */ TabMenu),
/* harmony export */   "TabMenuModule": () => (/* binding */ TabMenuModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 4356);
/* harmony import */ var primeng_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/dom */ 1420);
/* harmony import */ var primeng_ripple__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/ripple */ 4538);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/tooltip */ 4329);
/* harmony import */ var primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/icons/chevronleft */ 6168);
/* harmony import */ var primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/icons/chevronright */ 4890);














const _c0 = ["content"];
const _c1 = ["navbar"];
const _c2 = ["inkbar"];
const _c3 = ["prevBtn"];
const _c4 = ["nextBtn"];
function TabMenu_button_2_ChevronLeftIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronLeftIcon");
  }
}
function TabMenu_button_2_3_ng_template_0_Template(rf, ctx) {}
function TabMenu_button_2_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, TabMenu_button_2_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function TabMenu_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 11, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TabMenu_button_2_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r10.navBackward());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_button_2_ChevronLeftIcon_2_Template, 1, 0, "ChevronLeftIcon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, TabMenu_button_2_3_Template, 1, 0, null, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r0.previousIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r0.previousIconTemplate);
  }
}
function TabMenu_li_7_a_1_ng_container_1_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 24);
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r12.icon)("ngStyle", item_r12.iconStyle);
  }
}
function TabMenu_li_7_a_1_ng_container_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r12.label);
  }
}
function TabMenu_li_7_a_1_ng_container_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", item_r12.label, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
  }
}
function TabMenu_li_7_a_1_ng_container_1_span_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r12.badgeStyleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r12.badge);
  }
}
function TabMenu_li_7_a_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, TabMenu_li_7_a_1_ng_container_1_span_1_Template, 1, 2, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_li_7_a_1_ng_container_1_span_2_Template, 2, 1, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, TabMenu_li_7_a_1_ng_container_1_ng_template_3_Template, 1, 1, "ng-template", null, 22, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, TabMenu_li_7_a_1_ng_container_1_span_5_Template, 2, 2, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.escape !== false)("ngIfElse", _r20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.badge);
  }
}
function TabMenu_li_7_a_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
const _c5 = function (a0, a1) {
  return {
    $implicit: a0,
    index: a1
  };
};
function TabMenu_li_7_a_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TabMenu_li_7_a_1_Template_a_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r30);
      const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r28.itemClick($event, item_r12));
    })("keydown.enter", function TabMenu_li_7_a_1_Template_a_keydown_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r30);
      const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r31.itemClick($event, item_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, TabMenu_li_7_a_1_ng_container_1_Template, 6, 4, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_li_7_a_1_ng_container_2_Template, 1, 0, "ng-container", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const item_r12 = ctx_r33.$implicit;
    const i_r13 = ctx_r33.index;
    const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("target", item_r12.target);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("href", item_r12.url, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("tabindex", item_r12.disabled ? null : "0")("title", item_r12.title)("id", item_r12.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r14.itemTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r14.itemTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](8, _c5, item_r12, i_r13));
  }
}
function TabMenu_li_7_a_2_ng_container_1_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 24);
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r12.icon)("ngStyle", item_r12.iconStyle);
  }
}
function TabMenu_li_7_a_2_ng_container_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r12.label);
  }
}
function TabMenu_li_7_a_2_ng_container_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "span", 26);
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("innerHTML", item_r12.label, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeHtml"]);
  }
}
function TabMenu_li_7_a_2_ng_container_1_span_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", item_r12.badgeStyleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](item_r12.badge);
  }
}
function TabMenu_li_7_a_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, TabMenu_li_7_a_2_ng_container_1_span_1_Template, 1, 2, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_li_7_a_2_ng_container_1_span_2_Template, 2, 1, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, TabMenu_li_7_a_2_ng_container_1_ng_template_3_Template, 1, 1, "ng-template", null, 29, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, TabMenu_li_7_a_2_ng_container_1_span_5_Template, 2, 2, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](4);
    const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.escape !== false)("ngIfElse", _r38);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.badge);
  }
}
function TabMenu_li_7_a_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
const _c6 = function () {
  return {
    exact: false
  };
};
function TabMenu_li_7_a_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TabMenu_li_7_a_2_Template_a_click_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48);
      const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r46.itemClick($event, item_r12));
    })("keydown.enter", function TabMenu_li_7_a_2_Template_a_keydown_enter_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r48);
      const item_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r49.itemClick($event, item_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, TabMenu_li_7_a_2_ng_container_1_Template, 6, 4, "ng-container", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_li_7_a_2_ng_container_2_Template, 1, 0, "ng-container", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const item_r12 = ctx_r51.$implicit;
    const i_r13 = ctx_r51.index;
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("routerLink", item_r12.routerLink)("queryParams", item_r12.queryParams)("routerLinkActive", "p-menuitem-link-active")("routerLinkActiveOptions", item_r12.routerLinkActiveOptions || _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction0"](17, _c6))("target", item_r12.target)("fragment", item_r12.fragment)("queryParamsHandling", item_r12.queryParamsHandling)("preserveFragment", item_r12.preserveFragment)("skipLocationChange", item_r12.skipLocationChange)("replaceUrl", item_r12.replaceUrl)("state", item_r12.state);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("tabindex", item_r12.disabled ? null : "0")("title", item_r12.title)("id", item_r12.id);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r15.itemTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r15.itemTemplate)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](18, _c5, item_r12, i_r13));
  }
}
const _c7 = function (a1, a2, a3) {
  return {
    "p-tabmenuitem": true,
    "p-disabled": a1,
    "p-highlight": a2,
    "p-hidden": a3
  };
};
function TabMenu_li_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, TabMenu_li_7_a_1_Template, 3, 11, "a", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_li_7_a_2_Template, 3, 21, "a", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r12 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](item_r12.styleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", item_r12.style)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction3"](9, _c7, item_r12.disabled, ctx_r3.isActive(item_r12), item_r12.visible === false))("tooltipOptions", item_r12.tooltipOptions);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-selected", ctx_r3.isActive(item_r12))("aria-expanded", ctx_r3.isActive(item_r12));
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !item_r12.routerLink);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", item_r12.routerLink);
  }
}
function TabMenu_button_10_ChevronRightIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "ChevronRightIcon");
  }
}
function TabMenu_button_10_3_ng_template_0_Template(rf, ctx) {}
function TabMenu_button_10_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, TabMenu_button_10_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function TabMenu_button_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r57 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "button", 30, 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function TabMenu_button_10_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r57);
      const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r56.navForward());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_button_10_ChevronRightIcon_2_Template, 1, 0, "ChevronRightIcon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, TabMenu_button_10_3_Template, 1, 0, null, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx_r5.previousIconTemplate);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", ctx_r5.nextIconTemplate);
  }
}
const _c8 = function (a1) {
  return {
    "p-tabmenu p-component": true,
    "p-tabmenu-scrollable": a1
  };
};
class TabMenu {
  constructor(platformId, router, route, cd) {
    this.platformId = platformId;
    this.router = router;
    this.route = route;
    this.cd = cd;
    this.activeItemChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.backwardIsDisabled = true;
    this.forwardIsDisabled = false;
    this.timerIdForInitialAutoScroll = null;
  }
  ngAfterContentInit() {
    this.templates.forEach(item => {
      switch (item.getType()) {
        case 'item':
          this.itemTemplate = item.template;
          break;
        case 'nexticon':
          this.nextIconTemplate = item.template;
          break;
        case 'previousicon':
          this.previousIconTemplate = item.template;
          break;
        default:
          this.itemTemplate = item.template;
          break;
      }
    });
  }
  ngAfterViewInit() {
    if ((0,_angular_common__WEBPACK_IMPORTED_MODULE_1__.isPlatformBrowser)(this.platformId)) {
      this.updateInkBar();
      this.initAutoScrollForActiveItem();
      this.initButtonState();
    }
  }
  ngAfterViewChecked() {
    if (this.tabChanged) {
      this.updateInkBar();
      this.tabChanged = false;
    }
  }
  ngOnDestroy() {
    this.clearAutoScrollHandler();
  }
  isActive(item) {
    if (item.routerLink) {
      const routerLink = Array.isArray(item.routerLink) ? item.routerLink : [item.routerLink];
      return this.router.isActive(this.router.createUrlTree(routerLink, {
        relativeTo: this.route
      }).toString(), item.routerLinkActiveOptions?.exact ?? item.routerLinkActiveOptions ?? false);
    }
    return item === this.activeItem;
  }
  itemClick(event, item) {
    if (item.disabled) {
      event.preventDefault();
      return;
    }
    if (!item.url && !item.routerLink) {
      event.preventDefault();
    }
    if (item.command) {
      item.command({
        originalEvent: event,
        item: item
      });
    }
    this.activeItem = item;
    this.activeItemChange.emit(item);
    this.tabChanged = true;
  }
  updateInkBar() {
    const tabHeader = primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.findSingle(this.navbar.nativeElement, 'li.p-highlight');
    if (tabHeader) {
      this.inkbar.nativeElement.style.width = primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getWidth(tabHeader) + 'px';
      this.inkbar.nativeElement.style.left = primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getOffset(tabHeader).left - primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getOffset(this.navbar.nativeElement).left + 'px';
    }
  }
  getVisibleButtonWidths() {
    return [this.prevBtn?.nativeElement, this.nextBtn?.nativeElement].reduce((acc, el) => el ? acc + primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getWidth(el) : acc, 0);
  }
  updateButtonState() {
    const content = this.content.nativeElement;
    const {
      scrollLeft,
      scrollWidth
    } = content;
    const width = primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getWidth(content);
    this.backwardIsDisabled = scrollLeft === 0;
    this.forwardIsDisabled = parseInt(scrollLeft) === scrollWidth - width;
  }
  updateScrollBar(index) {
    const tabHeader = this.navbar.nativeElement.children[index];
    if (!tabHeader) {
      return;
    }
    tabHeader.scrollIntoView({
      block: 'nearest',
      inline: 'center'
    });
  }
  onScroll(event) {
    this.scrollable && this.updateButtonState();
    event.preventDefault();
  }
  navBackward() {
    const content = this.content.nativeElement;
    const width = primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getWidth(content) - this.getVisibleButtonWidths();
    const pos = content.scrollLeft - width;
    content.scrollLeft = pos <= 0 ? 0 : pos;
  }
  navForward() {
    const content = this.content.nativeElement;
    const width = primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.getWidth(content) - this.getVisibleButtonWidths();
    const pos = content.scrollLeft + width;
    const lastPos = content.scrollWidth - width;
    content.scrollLeft = pos >= lastPos ? lastPos : pos;
  }
  initAutoScrollForActiveItem() {
    if (!this.scrollable) {
      return;
    }
    this.clearAutoScrollHandler();
    // We have to wait for the rendering and then can scroll to element.
    this.timerIdForInitialAutoScroll = setTimeout(() => {
      const activeItem = this.model.findIndex(menuItem => this.isActive(menuItem));
      if (activeItem !== -1) {
        this.updateScrollBar(activeItem);
      }
    });
  }
  clearAutoScrollHandler() {
    if (this.timerIdForInitialAutoScroll) {
      clearTimeout(this.timerIdForInitialAutoScroll);
      this.timerIdForInitialAutoScroll = null;
    }
  }
  initButtonState() {
    if (this.scrollable) {
      // We have to wait for the rendering and then retrieve the actual size element from the DOM.
      // in future `Promise.resolve` can be changed to `queueMicrotask` (if ie11 support will be dropped)
      Promise.resolve().then(() => {
        this.updateButtonState();
        this.cd.markForCheck();
      });
    }
  }
}
TabMenu.ɵfac = function TabMenu_Factory(t) {
  return new (t || TabMenu)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.PLATFORM_ID), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef));
};
TabMenu.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: TabMenu,
  selectors: [["p-tabMenu"]],
  contentQueries: function TabMenu_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵcontentQuery"](dirIndex, primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.templates = _t);
    }
  },
  viewQuery: function TabMenu_Query(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c1, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c2, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c3, 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c4, 5);
    }
    if (rf & 2) {
      let _t;
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.navbar = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.inkbar = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.prevBtn = _t.first);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.nextBtn = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    model: "model",
    activeItem: "activeItem",
    scrollable: "scrollable",
    popup: "popup",
    style: "style",
    styleClass: "styleClass"
  },
  outputs: {
    activeItemChange: "activeItemChange"
  },
  decls: 11,
  vars: 9,
  consts: [[3, "ngClass", "ngStyle"], [1, "p-tabmenu-nav-container"], ["class", "p-tabmenu-nav-prev p-tabmenu-nav-btn p-link", "type", "button", "pRipple", "", 3, "click", 4, "ngIf"], [1, "p-tabmenu-nav-content", 3, "scroll"], ["content", ""], ["role", "tablist", 1, "p-tabmenu-nav", "p-reset"], ["navbar", ""], ["role", "tab", "pTooltip", "", 3, "ngStyle", "class", "ngClass", "tooltipOptions", 4, "ngFor", "ngForOf"], [1, "p-tabmenu-ink-bar"], ["inkbar", ""], ["class", "p-tabmenu-nav-next p-tabmenu-nav-btn p-link", "type", "button", "pRipple", "", 3, "click", 4, "ngIf"], ["type", "button", "pRipple", "", 1, "p-tabmenu-nav-prev", "p-tabmenu-nav-btn", "p-link", 3, "click"], ["prevBtn", ""], [4, "ngIf"], [4, "ngTemplateOutlet"], ["role", "tab", "pTooltip", "", 3, "ngStyle", "ngClass", "tooltipOptions"], ["class", "p-menuitem-link", "role", "presentation", "pRipple", "", 3, "target", "click", "keydown.enter", 4, "ngIf"], ["role", "presentation", "class", "p-menuitem-link", "pRipple", "", 3, "routerLink", "queryParams", "routerLinkActive", "routerLinkActiveOptions", "target", "fragment", "queryParamsHandling", "preserveFragment", "skipLocationChange", "replaceUrl", "state", "click", "keydown.enter", 4, "ngIf"], ["role", "presentation", "pRipple", "", 1, "p-menuitem-link", 3, "target", "click", "keydown.enter"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["class", "p-menuitem-icon", 3, "ngClass", "ngStyle", 4, "ngIf"], ["class", "p-menuitem-text", 4, "ngIf", "ngIfElse"], ["htmlLabel", ""], ["class", "p-menuitem-badge", 3, "ngClass", 4, "ngIf"], [1, "p-menuitem-icon", 3, "ngClass", "ngStyle"], [1, "p-menuitem-text"], [1, "p-menuitem-text", 3, "innerHTML"], [1, "p-menuitem-badge", 3, "ngClass"], ["role", "presentation", "pRipple", "", 1, "p-menuitem-link", 3, "routerLink", "queryParams", "routerLinkActive", "routerLinkActiveOptions", "target", "fragment", "queryParamsHandling", "preserveFragment", "skipLocationChange", "replaceUrl", "state", "click", "keydown.enter"], ["htmlRouteLabel", ""], ["type", "button", "pRipple", "", 1, "p-tabmenu-nav-next", "p-tabmenu-nav-btn", "p-link", 3, "click"], ["nextBtn", ""]],
  template: function TabMenu_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, TabMenu_button_2_Template, 4, 2, "button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3, 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("scroll", function TabMenu_Template_div_scroll_3_listener($event) {
        return ctx.onScroll($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "ul", 5, 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](7, TabMenu_li_7_Template, 3, 13, "li", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "li", 8, 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, TabMenu_button_10_Template, 4, 2, "button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.styleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](7, _c8, ctx.scrollable))("ngStyle", ctx.style);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.scrollable && !ctx.backwardIsDisabled);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.model);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.scrollable && !ctx.forwardIsDisabled);
    }
  },
  dependencies: function () {
    return [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgTemplateOutlet, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLinkActive, primeng_ripple__WEBPACK_IMPORTED_MODULE_5__.Ripple, primeng_tooltip__WEBPACK_IMPORTED_MODULE_6__.Tooltip, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_7__.ChevronLeftIcon, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon];
  },
  styles: [".p-tabmenu-nav-container{position:relative}.p-tabmenu-scrollable .p-tabmenu-nav-container{overflow:hidden}.p-tabmenu-nav-content{overflow-x:auto;overflow-y:hidden;scroll-behavior:smooth;scrollbar-width:none;overscroll-behavior:contain auto}.p-tabmenu-nav-btn{position:absolute;top:0;z-index:2;height:100%;display:flex;align-items:center;justify-content:center}.p-tabmenu-nav-prev{left:0}.p-tabmenu-nav-next{right:0}.p-tabview-nav-content::-webkit-scrollbar{display:none}.p-tabmenu-nav{display:flex;margin:0;padding:0;list-style-type:none;flex-wrap:nowrap}.p-tabmenu-nav a{cursor:pointer;-webkit-user-select:none;user-select:none;display:flex;align-items:center;position:relative;text-decoration:none;overflow:hidden}.p-tabmenu-nav a:focus{z-index:1}.p-tabmenu-nav .p-menuitem-text{line-height:1;white-space:nowrap}.p-tabmenu-ink-bar{display:none;z-index:1}.p-tabmenu-nav-content::-webkit-scrollbar{display:none}.p-tabmenuitem:not(.p-hidden){display:flex}\n"],
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](TabMenu, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-tabMenu',
      template: `
        <div [ngClass]="{ 'p-tabmenu p-component': true, 'p-tabmenu-scrollable': scrollable }" [ngStyle]="style" [class]="styleClass">
            <div class="p-tabmenu-nav-container">
                <button *ngIf="scrollable && !backwardIsDisabled" #prevBtn class="p-tabmenu-nav-prev p-tabmenu-nav-btn p-link" (click)="navBackward()" type="button" pRipple>
                    <ChevronLeftIcon *ngIf="!previousIconTemplate"/>
                    <ng-template *ngTemplateOutlet="previousIconTemplate"></ng-template>
                </button>
                <div #content class="p-tabmenu-nav-content" (scroll)="onScroll($event)">
                    <ul #navbar class="p-tabmenu-nav p-reset" role="tablist">
                        <li
                            *ngFor="let item of model; let i = index"
                            role="tab"
                            [ngStyle]="item.style"
                            [class]="item.styleClass"
                            [attr.aria-selected]="isActive(item)"
                            [attr.aria-expanded]="isActive(item)"
                            [ngClass]="{ 'p-tabmenuitem': true, 'p-disabled': item.disabled, 'p-highlight': isActive(item), 'p-hidden': item.visible === false }"
                            pTooltip
                            [tooltipOptions]="item.tooltipOptions"
                        >
                            <a
                                *ngIf="!item.routerLink"
                                [attr.href]="item.url"
                                class="p-menuitem-link"
                                role="presentation"
                                (click)="itemClick($event, item)"
                                (keydown.enter)="itemClick($event, item)"
                                [attr.tabindex]="item.disabled ? null : '0'"
                                [target]="item.target"
                                [attr.title]="item.title"
                                [attr.id]="item.id"
                                pRipple
                            >
                                <ng-container *ngIf="!itemTemplate">
                                    <span class="p-menuitem-icon" [ngClass]="item.icon" *ngIf="item.icon" [ngStyle]="item.iconStyle"></span>
                                    <span class="p-menuitem-text" *ngIf="item.escape !== false; else htmlLabel">{{ item.label }}</span>
                                    <ng-template #htmlLabel><span class="p-menuitem-text" [innerHTML]="item.label"></span></ng-template>
                                    <span class="p-menuitem-badge" *ngIf="item.badge" [ngClass]="item.badgeStyleClass">{{ item.badge }}</span>
                                </ng-container>
                                <ng-container *ngTemplateOutlet="itemTemplate; context: { $implicit: item, index: i }"></ng-container>
                            </a>
                            <a
                                *ngIf="item.routerLink"
                                [routerLink]="item.routerLink"
                                [queryParams]="item.queryParams"
                                [routerLinkActive]="'p-menuitem-link-active'"
                                [routerLinkActiveOptions]="item.routerLinkActiveOptions || { exact: false }"
                                role="presentation"
                                class="p-menuitem-link"
                                (click)="itemClick($event, item)"
                                (keydown.enter)="itemClick($event, item)"
                                [attr.tabindex]="item.disabled ? null : '0'"
                                [target]="item.target"
                                [attr.title]="item.title"
                                [attr.id]="item.id"
                                [fragment]="item.fragment"
                                [queryParamsHandling]="item.queryParamsHandling"
                                [preserveFragment]="item.preserveFragment"
                                [skipLocationChange]="item.skipLocationChange"
                                [replaceUrl]="item.replaceUrl"
                                [state]="item.state"
                                pRipple
                            >
                                <ng-container *ngIf="!itemTemplate">
                                    <span class="p-menuitem-icon" [ngClass]="item.icon" *ngIf="item.icon" [ngStyle]="item.iconStyle"></span>
                                    <span class="p-menuitem-text" *ngIf="item.escape !== false; else htmlRouteLabel">{{ item.label }}</span>
                                    <ng-template #htmlRouteLabel><span class="p-menuitem-text" [innerHTML]="item.label"></span></ng-template>
                                    <span class="p-menuitem-badge" *ngIf="item.badge" [ngClass]="item.badgeStyleClass">{{ item.badge }}</span>
                                </ng-container>
                                <ng-container *ngTemplateOutlet="itemTemplate; context: { $implicit: item, index: i }"></ng-container>
                            </a>
                        </li>
                        <li #inkbar class="p-tabmenu-ink-bar"></li>
                    </ul>
                </div>
                <button *ngIf="scrollable && !forwardIsDisabled" #nextBtn class="p-tabmenu-nav-next p-tabmenu-nav-btn p-link" (click)="navForward()" type="button" pRipple>
                    <ChevronRightIcon *ngIf="!previousIconTemplate"/>
                    <ng-template *ngTemplateOutlet="nextIconTemplate"></ng-template>
                </button>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-tabmenu-nav-container{position:relative}.p-tabmenu-scrollable .p-tabmenu-nav-container{overflow:hidden}.p-tabmenu-nav-content{overflow-x:auto;overflow-y:hidden;scroll-behavior:smooth;scrollbar-width:none;overscroll-behavior:contain auto}.p-tabmenu-nav-btn{position:absolute;top:0;z-index:2;height:100%;display:flex;align-items:center;justify-content:center}.p-tabmenu-nav-prev{left:0}.p-tabmenu-nav-next{right:0}.p-tabview-nav-content::-webkit-scrollbar{display:none}.p-tabmenu-nav{display:flex;margin:0;padding:0;list-style-type:none;flex-wrap:nowrap}.p-tabmenu-nav a{cursor:pointer;-webkit-user-select:none;user-select:none;display:flex;align-items:center;position:relative;text-decoration:none;overflow:hidden}.p-tabmenu-nav a:focus{z-index:1}.p-tabmenu-nav .p-menuitem-text{line-height:1;white-space:nowrap}.p-tabmenu-ink-bar{display:none;z-index:1}.p-tabmenu-nav-content::-webkit-scrollbar{display:none}.p-tabmenuitem:not(.p-hidden){display:flex}\n"]
    }]
  }], function () {
    return [{
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_core__WEBPACK_IMPORTED_MODULE_0__.PLATFORM_ID]
      }]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectorRef
    }];
  }, {
    model: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    activeItem: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    activeItemChange: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    scrollable: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    popup: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    content: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['content']
    }],
    navbar: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['navbar']
    }],
    inkbar: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['inkbar']
    }],
    prevBtn: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['prevBtn']
    }],
    nextBtn: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewChild,
      args: ['nextBtn']
    }],
    templates: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ContentChildren,
      args: [primeng_api__WEBPACK_IMPORTED_MODULE_4__.PrimeTemplate]
    }]
  });
})();
class TabMenuModule {}
TabMenuModule.ɵfac = function TabMenuModule_Factory(t) {
  return new (t || TabMenuModule)();
};
TabMenuModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: TabMenuModule
});
TabMenuModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_5__.RippleModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_6__.TooltipModule, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_7__.ChevronLeftIcon, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_6__.TooltipModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](TabMenuModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule, primeng_ripple__WEBPACK_IMPORTED_MODULE_5__.RippleModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_6__.TooltipModule, primeng_icons_chevronleft__WEBPACK_IMPORTED_MODULE_7__.ChevronLeftIcon, primeng_icons_chevronright__WEBPACK_IMPORTED_MODULE_8__.ChevronRightIcon],
      exports: [TabMenu, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_6__.TooltipModule],
      declarations: [TabMenu]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-tabmenu.mjs.map

/***/ })

}]);
//# sourceMappingURL=313.60ee98e6910927a7.js.map