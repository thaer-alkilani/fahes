"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[741],{

/***/ 9162:
/*!*****************************************************!*\
  !*** ./src/app/core/models/pagination.interface.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IPaginationControls": () => (/* binding */ IPaginationControls),
/* harmony export */   "IPaginationIndexing": () => (/* binding */ IPaginationIndexing)
/* harmony export */ });
class IPaginationControls {
  constructor(Id, TotalCount, PageIndex = 1, PageSize = 10) {
    this.Id = Id;
    this.TotalCount = TotalCount;
    this.PageIndex = PageIndex;
    this.PageSize = PageSize;
  }
}
class IPaginationIndexing {
  constructor(PageIndex = 1, PageSize = 10) {
    this.PageIndex = PageIndex;
    this.PageSize = PageSize;
  }
}

/***/ }),

/***/ 3975:
/*!**********************************************************!*\
  !*** ./src/app/core/models/user-management.interface.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GetMOIUsersFilterDto": () => (/* binding */ GetMOIUsersFilterDto),
/* harmony export */   "GetMOIUsersSearchingForm": () => (/* binding */ GetMOIUsersSearchingForm),
/* harmony export */   "UpdateUserStatus": () => (/* binding */ UpdateUserStatus)
/* harmony export */ });
class GetMOIUsersSearchingForm {
  constructor(searchUsername, searchUserFullName) {
    this.orderBy = '';
    this.sortOrder = '';
    this.searchUsername = searchUsername;
    this.searchUserFullName = searchUserFullName;
  }
}
class GetMOIUsersFilterDto extends GetMOIUsersSearchingForm {
  constructor(searchUsername, searchUserFullName, pageNumber = 1, pageSize = 10) {
    super(searchUsername, searchUserFullName);
    this.pageNumber = pageNumber;
    this.pageSize = pageSize;
  }
}
class UpdateUserStatus {
  constructor(status, roleId, userId) {
    this.operationType = "UPDATE";
    this.createdBy = 0;
    this.updatedBy = 0;
    this.status = status;
    this.roleId = roleId;
    this.userId = userId;
  }
}

/***/ }),

/***/ 4915:
/*!*********************************************************************************!*\
  !*** ./src/app/core/resolvers/user-management/user-management-list.resolver.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserManagementListResolver": () => (/* binding */ UserManagementListResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 3158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 591);
/* harmony import */ var _models_user_management_interface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/user-management.interface */ 3975);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_user_management_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/user-management.service */ 6383);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);





class UserManagementListResolver {
  constructor(_service, _router) {
    this._service = _service;
    this._router = _router;
  }
  resolve(route, state) {
    const page = route.queryParams['page'] || 1;
    const pageSize = route.queryParams['pageSize'] || 10;
    const searchUserFullName = route.queryParams['searchUserFullName'] || "";
    const searchUsername = route.queryParams['searchUsername'] || "";
    return this._service.getMoiUsers(new _models_user_management_interface__WEBPACK_IMPORTED_MODULE_0__.GetMOIUsersFilterDto(searchUsername, searchUserFullName, page, pageSize)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.catchError)(err => {
      return rxjs__WEBPACK_IMPORTED_MODULE_3__.EMPTY;
    }));
  }
  static #_ = this.ɵfac = function UserManagementListResolver_Factory(t) {
    return new (t || UserManagementListResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_services_user_management_service__WEBPACK_IMPORTED_MODULE_1__.UserManagementService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({
    token: UserManagementListResolver,
    factory: UserManagementListResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 6383:
/*!**********************************************************!*\
  !*** ./src/app/core/services/user-management.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserManagementService": () => (/* binding */ UserManagementService)
/* harmony export */ });
/* harmony import */ var _utilities_apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utilities/apis */ 1603);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 5159);



class UserManagementService {
  constructor(_baseService) {
    this._baseService = _baseService;
  }
  getMoiUsers(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.UserManagement.GetMoiUsers, payload);
  }
  userRoleOperations(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.UserManagement.UserRoleOperations, payload);
  }
  static #_ = this.ɵfac = function UserManagementService_Factory(t) {
    return new (t || UserManagementService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: UserManagementService,
    factory: UserManagementService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 7914:
/*!****************************************************************************!*\
  !*** ./src/app/features/user-management/user-management-routing.module.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserManagementRoutingModule": () => (/* binding */ UserManagementRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _users_management_list_users_management_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./users-management-list/users-management-list.component */ 4007);
/* harmony import */ var src_app_core_resolvers_user_management_user_management_list_resolver__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/resolvers/user-management/user-management-list.resolver */ 4915);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);





const routes = [{
  path: '',
  component: _users_management_list_users_management_list_component__WEBPACK_IMPORTED_MODULE_0__.UsersManagementListComponent,
  data: {
    title: "UsersList"
  },
  resolve: {
    data: src_app_core_resolvers_user_management_user_management_list_resolver__WEBPACK_IMPORTED_MODULE_1__.UserManagementListResolver
  }
}];
class UserManagementRoutingModule {
  static #_ = this.ɵfac = function UserManagementRoutingModule_Factory(t) {
    return new (t || UserManagementRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
    type: UserManagementRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](UserManagementRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
})();

/***/ }),

/***/ 6809:
/*!*********************************************************************************************************************!*\
  !*** ./src/app/features/user-management/user-management-searching-form/user-management-searching-form.component.ts ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserManagementSearchingFormComponent": () => (/* binding */ UserManagementSearchingFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 8699);






class UserManagementSearchingFormComponent {
  constructor(_fb) {
    this._fb = _fb;
    this.search = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    this.submitted = false;
    this.controls = [{
      label: 'FullName',
      name: 'searchUserFullName',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__.INPUTS_TYPES.TEXT,
      required: true,
      width: 'col-lg-6'
    }, {
      label: 'Username',
      name: 'searchUsername',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__.INPUTS_TYPES.TEXT,
      required: true,
      width: 'col-lg-6'
    }];
  }
  ngOnInit() {
    this.initForm();
  }
  initForm() {
    this.form = this._fb.group({
      searchUserFullName: [null],
      searchUsername: [null]
    });
  }
  emitForm() {
    this.search.emit(this.form.value);
  }
  onSearch() {
    this.emitForm();
  }
  reset() {
    this.form.reset();
    this.emitForm();
  }
  static #_ = this.ɵfac = function UserManagementSearchingFormComponent_Factory(t) {
    return new (t || UserManagementSearchingFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: UserManagementSearchingFormComponent,
    selectors: [["app-user-management-searching-form"]],
    outputs: {
      search: "search"
    },
    decls: 9,
    vars: 9,
    consts: [[1, "form-block"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "mt-3", "text-end"], ["type", "button", 1, "btn", "btn-outline", "me-3", 3, "click"], ["type", "button", 1, "btn", "btn-purple", 3, "click"]],
    template: function UserManagementSearchingFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "app-f-form", 1)(2, "div", 2)(3, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UserManagementSearchingFormComponent_Template_button_click_3_listener() {
          return ctx.reset();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](5, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function UserManagementSearchingFormComponent_Template_button_click_6_listener() {
          return ctx.onSearch();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("controls", ctx.controls)("formGroup", ctx.form)("submitted", ctx.submitted);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](5, 5, "Reset"));
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](8, 7, "Search"));
      }
    },
    dependencies: [_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_1__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 2741:
/*!********************************************************************!*\
  !*** ./src/app/features/user-management/user-management.module.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UserManagementModule": () => (/* binding */ UserManagementModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _user_management_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./user-management-routing.module */ 7914);
/* harmony import */ var _users_management_list_users_management_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./users-management-list/users-management-list.component */ 4007);
/* harmony import */ var _user_management_searching_form_user_management_searching_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-management-searching-form/user-management-searching-form.component */ 6809);
/* harmony import */ var src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/components/f-table/f-table.component */ 2812);
/* harmony import */ var src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var src_app_shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/pagination/pagination.component */ 3556);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);









class UserManagementModule {
  static #_ = this.ɵfac = function UserManagementModule_Factory(t) {
    return new (t || UserManagementModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: UserManagementModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _user_management_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserManagementRoutingModule, src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_3__.FTableComponent, src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_4__.FFormComponent, src_app_shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__.PaginationComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](UserManagementModule, {
    declarations: [_users_management_list_users_management_list_component__WEBPACK_IMPORTED_MODULE_1__.UsersManagementListComponent, _user_management_searching_form_user_management_searching_form_component__WEBPACK_IMPORTED_MODULE_2__.UserManagementSearchingFormComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _user_management_routing_module__WEBPACK_IMPORTED_MODULE_0__.UserManagementRoutingModule, src_app_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_3__.FTableComponent, src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_4__.FFormComponent, src_app_shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_5__.PaginationComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule]
  });
})();

/***/ }),

/***/ 4007:
/*!***************************************************************************************************!*\
  !*** ./src/app/features/user-management/users-management-list/users-management-list.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsersManagementListComponent": () => (/* binding */ UsersManagementListComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var src_app_core_enums_is_enabled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/is-enabled */ 9684);
/* harmony import */ var src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/enums/table.enum */ 6592);
/* harmony import */ var src_app_core_models_pagination_interface__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/pagination.interface */ 9162);
/* harmony import */ var src_app_core_models_user_management_interface__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/user-management.interface */ 3975);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_core_services_user_management_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/user-management.service */ 6383);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/toastr.service */ 8996);
/* harmony import */ var _shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/f-table/f-table.component */ 2812);
/* harmony import */ var _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/pagination/pagination.component */ 3556);
/* harmony import */ var _user_management_searching_form_user_management_searching_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../user-management-searching-form/user-management-searching-form.component */ 6809);













class UsersManagementListComponent {
  constructor(_route, _router, _service, _translate, _toastr) {
    this._route = _route;
    this._router = _router;
    this._service = _service;
    this._translate = _translate;
    this._toastr = _toastr;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subscription();
    this.filter = new src_app_core_models_user_management_interface__WEBPACK_IMPORTED_MODULE_3__.GetMOIUsersFilterDto();
    this.cols = [{
      title: 'FullName',
      col: 'userFullName'
    }, {
      title: 'username',
      col: 'username'
    }, {
      title: 'mail',
      col: 'mail'
    }, {
      title: 'phone',
      col: 'phone'
    }, {
      title: 'Roles',
      col: 'roleName',
      isLocalized: true
    }, {
      title: 'actions',
      col: 'actions'
    }];
    this.actions = [{
      name: '',
      type: src_app_core_enums_table_enum__WEBPACK_IMPORTED_MODULE_1__.TABLE_ACTIONS_TYPES.SWITCH,
      message: 'enable/disable'
    }];
  }
  ngOnInit() {
    this.getResolved();
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.map)(el => el['data'])).subscribe(res => {
      if (res) {
        this.items = this.mapUsers(res.users);
        this.paginationControls = new src_app_core_models_pagination_interface__WEBPACK_IMPORTED_MODULE_2__.IPaginationControls('UsersManagementList', res.pageCount);
      }
    });
    this.subscription.add(sub);
  }
  mapUsers(arr) {
    return arr.map(x => {
      return {
        ...x,
        IsEnabled: x.status == 1 ? true : false,
        roleName: {
          NameEn: x.roleNameE,
          NameAr: x.roleNameA
        }
      };
    });
  }
  onPaginate(event) {
    this.filter.pageNumber = event;
    this.getDataFromService();
  }
  toggleState(event) {
    this._service.userRoleOperations(new src_app_core_models_user_management_interface__WEBPACK_IMPORTED_MODULE_3__.UpdateUserStatus(event.value, event.item.roleId, event.item.userId)).subscribe({
      next: res => {
        this._toastr.showSuccess(event.value === src_app_core_enums_is_enabled__WEBPACK_IMPORTED_MODULE_0__.IS_ENABLED.ENABLED ? this._translate.instant('UserEnabledSuccessfully') : this._translate.instant('UserDisabledSuccessfully'));
      },
      error: err => {
        this._toastr.showError(event.value === src_app_core_enums_is_enabled__WEBPACK_IMPORTED_MODULE_0__.IS_ENABLED.ENABLED ? this._translate.instant('FailedToEnableUser') : this._translate.instant('FailedToDisableUser'));
        const arr = JSON.stringify(this.items);
        this.items = JSON.parse(arr);
      }
    });
  }
  getDataFromService() {
    this._service.getMoiUsers(this.filter).subscribe({
      next: res => {
        this.items = this.mapUsers(res.users);
        this.paginationControls = new src_app_core_models_pagination_interface__WEBPACK_IMPORTED_MODULE_2__.IPaginationControls('UsersManagementList', res.pageCount, this.filter.pageNumber);
        this._router.navigate([], {
          queryParams: {
            page: this.filter.pageNumber,
            pageSize: this.paginationControls.PageSize,
            searchUsername: this.filter.searchUsername,
            searchUserFullName: this.filter.searchUserFullName
          },
          queryParamsHandling: 'merge'
        });
      }
    });
  }
  search(event) {
    this.filter.searchUserFullName = event.searchUserFullName;
    this.filter.searchUsername = event.searchUsername;
    this.filter.pageNumber = 1;
    this.getDataFromService();
  }
  static #_ = this.ɵfac = function UsersManagementListComponent_Factory(t) {
    return new (t || UsersManagementListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_user_management_service__WEBPACK_IMPORTED_MODULE_4__.UserManagementService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_5__.ToastrService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({
    type: UsersManagementListComponent,
    selectors: [["app-users-management-list"]],
    decls: 5,
    vars: 6,
    consts: [[3, "search"], [1, "white-block"], [3, "paginationControls", "cols", "items", "actions", "trackBy", "onAction"], [1, "mt-3", "border", "rounded-4", "p-2"], [3, "paginationControls", "pageChanged"]],
    template: function UsersManagementListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "app-user-management-searching-form", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("search", function UsersManagementListComponent_Template_app_user_management_searching_form_search_0_listener($event) {
          return ctx.search($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "div", 1)(2, "app-f-table", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("onAction", function UsersManagementListComponent_Template_app_f_table_onAction_2_listener($event) {
          return ctx.toggleState($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "div", 3)(4, "app-pagination", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("pageChanged", function UsersManagementListComponent_Template_app_pagination_pageChanged_4_listener($event) {
          return ctx.onPaginate($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("paginationControls", ctx.paginationControls)("cols", ctx.cols)("items", ctx.items)("actions", ctx.actions)("trackBy", "userId");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("paginationControls", ctx.paginationControls);
      }
    },
    dependencies: [_shared_components_f_table_f_table_component__WEBPACK_IMPORTED_MODULE_6__.FTableComponent, _shared_components_pagination_pagination_component__WEBPACK_IMPORTED_MODULE_7__.PaginationComponent, _user_management_searching_form_user_management_searching_form_component__WEBPACK_IMPORTED_MODULE_8__.UserManagementSearchingFormComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3556:
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/pagination/pagination.component.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaginationComponent": () => (/* binding */ PaginationComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-pagination */ 2302);
/* harmony import */ var src_app_core_models_pagination_interface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/pagination.interface */ 9162);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);











const _c0 = function (a0) {
  return {
    "hidden": a0
  };
};
class PaginationComponent {
  constructor(_router) {
    this._router = _router;
    this.pageChanged = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    this.loading = false;
    this.paginationControls = new src_app_core_models_pagination_interface__WEBPACK_IMPORTED_MODULE_0__.IPaginationControls('', 0, 1, 10);
  }
  // toggleBtn() : void {
  //   this.rotate = !this.rotate;
  //   this.status = this.rotate ? "ON" : "OFF";
  // }
  onPageChaned(event) {
    this.pageChanged.emit(event);
  }
  static #_ = this.ɵfac = function PaginationComponent_Factory(t) {
    return new (t || PaginationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: PaginationComponent,
    selectors: [["app-pagination"]],
    inputs: {
      loading: "loading",
      paginationControls: "paginationControls"
    },
    outputs: {
      pageChanged: "pageChanged"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵStandaloneFeature"]],
    decls: 16,
    vars: 29,
    consts: [[1, "accordion-table-pagination", "has-text-centered", "custom-validation", "d-flex", "justify-content-between", "align-items-center", "px-2", "py-1"], [3, "nextLabel", "previousLabel", "id", "pageChange"], [1, "spinner", 3, "ngClass"], [1, "paging-info"], [1, "mb-0"]],
    template: function PaginationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "pagination-controls", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("pageChange", function PaginationComponent_Template_pagination_controls_pageChange_1_listener($event) {
          return ctx.onPageChaned($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](2, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](3, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 3)(6, "p", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](9, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](10, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](11, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](15, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("nextLabel", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](2, 13, "Next"))("previousLabel", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](3, 15, "Previous"))("id", ctx.paginationControls.Id);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](27, _c0, !ctx.loading));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate7"]("", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 17, "SHOWING"), " ", ctx.paginationControls.TotalCount > 0 ? (ctx.paginationControls.PageIndex - 1) * ctx.paginationControls.PageSize + 1 : ctx.paginationControls.TotalCount, " ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](9, 19, "TO"), " ", ctx.paginationControls.PageSize * ctx.paginationControls.PageIndex <= ctx.paginationControls.TotalCount ? ctx.paginationControls.PageSize * ctx.paginationControls.PageIndex : ctx.paginationControls.TotalCount, " ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](10, 21, "OF"), " ", ctx.paginationControls.TotalCount, " ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](11, 23, "ROWS"), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.paginationControls.PageSize, "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](15, 25, "ROWS PER PAGE"), "");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, ngx_pagination__WEBPACK_IMPORTED_MODULE_4__.NgxPaginationModule, ngx_pagination__WEBPACK_IMPORTED_MODULE_4__.PaginationControlsComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: ["@media (max-width: 539px) {\n  .custom-validation[_ngcontent-%COMP%] {\n    flex-direction: column;\n  }\n}\n\n  .custom-validation .ngx-pagination {\n  margin: 0;\n  padding: 0;\n}\n\n  .accordion-table-pagination .ngx-pagination a,   .accordion-table-pagination .ngx-pagination button {\n  text-decoration: none !important;\n}\n  .accordion-table-pagination .ngx-pagination .current {\n  background: var(--main-blue);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvcGFnaW5hdGlvbi9wYWdpbmF0aW9uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBREY7SUFFSSxzQkFBQTtFQUNGO0FBQ0Y7O0FBQ0E7RUFDRSxTQUFBO0VBQ0EsVUFBQTtBQUVGOztBQUdJO0VBQ0UsZ0NBQUE7QUFBTjtBQUVJO0VBQ0UsNEJBQUE7QUFBTiIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tdmFsaWRhdGlvbntcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTM5cHgpe1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB9XHJcbn1cclxuOjpuZy1kZWVwIC5jdXN0b20tdmFsaWRhdGlvbiAubmd4LXBhZ2luYXRpb257XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbjo6bmctZGVlcHtcclxuICAuYWNjb3JkaW9uLXRhYmxlLXBhZ2luYXRpb257XHJcbiAgICAubmd4LXBhZ2luYXRpb24gYSwgLm5neC1wYWdpbmF0aW9uIGJ1dHRvbntcclxuICAgICAgdGV4dC1kZWNvcmF0aW9uOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAubmd4LXBhZ2luYXRpb24gLmN1cnJlbnR7XHJcbiAgICAgIGJhY2tncm91bmQ6IHZhcigtLW1haW4tYmx1ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ })

}]);
//# sourceMappingURL=741.909d8417fa9a15f4.js.map