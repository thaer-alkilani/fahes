"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[919],{

/***/ 5674:
/*!**************************************************!*\
  !*** ./src/app/core/helper/map-lookup.helper.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mapLookup": () => (/* binding */ mapLookup)
/* harmony export */ });
function mapLookup(list) {
  return list.map(x => {
    return {
      NameEn: x.reasonEname,
      NameAr: x.reasonAname,
      Id: x.reasonValue
    };
  });
}

/***/ }),

/***/ 760:
/*!**************************************************!*\
  !*** ./src/app/core/models/vehicle.interface.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchVehiclePayload": () => (/* binding */ SearchVehiclePayload)
/* harmony export */ });
class SearchVehiclePayload {
  // stationId: number = 1
  constructor(plateNo, plateType) {
    this.plateNo = +plateNo;
    this.plateType = +plateType;
  }
}

/***/ }),

/***/ 9292:
/*!**********************************************************************!*\
  !*** ./src/app/core/resolvers/exemption/vehicle-details.resolver.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleDetailsResolver": () => (/* binding */ VehicleDetailsResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 9337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 3158);
/* harmony import */ var _models_vehicle_interface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/vehicle.interface */ 760);
/* harmony import */ var _helper_create_inspection_search_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../helper/create-inspection-search.helper */ 3893);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_exemption_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/exemption.service */ 8706);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);






class VehicleDetailsResolver {
  constructor(_service, _router) {
    this._service = _service;
    this._router = _router;
  }
  resolve(route, state) {
    const plateType = route.queryParams['plateType'];
    const plateNo = route.queryParams['plateNo'];
    const searchText = route.queryParams['searchText'];
    const searchType = route.queryParams['searchType'];
    // Declare query as optional to handle potential undefined cases
    let query;
    if (!searchText) {
      if (!(plateNo && plateType)) return rxjs__WEBPACK_IMPORTED_MODULE_3__.EMPTY;
      query = new _models_vehicle_interface__WEBPACK_IMPORTED_MODULE_0__.SearchVehiclePayload(plateNo, (0,_helper_create_inspection_search_helper__WEBPACK_IMPORTED_MODULE_1__.calcType)(plateType));
    } else if (searchText) {
      if (!searchText) return rxjs__WEBPACK_IMPORTED_MODULE_3__.EMPTY;
      const istimara = searchText.split(' ').join('').split(/(?<=^.{2})/);
      query = new _models_vehicle_interface__WEBPACK_IMPORTED_MODULE_0__.SearchVehiclePayload(istimara[1], istimara[0]);
    }
    // Ensure query is assigned before using it
    if (query) {
      return this._service.search(query).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.tap)(x => {
        if (!x) this._router.navigate(['/portal/exemption'], {});
        return x;
      }), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.catchError)(_ => {
        // this._router.navigate(['/error'], {});
        return rxjs__WEBPACK_IMPORTED_MODULE_3__.EMPTY;
      }));
    } else {
      // Handle the case where query is not assigned
      return rxjs__WEBPACK_IMPORTED_MODULE_3__.EMPTY; // Or handle the error differently
    }
  }
  static #_ = this.ɵfac = function VehicleDetailsResolver_Factory(t) {
    return new (t || VehicleDetailsResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_services_exemption_service__WEBPACK_IMPORTED_MODULE_2__.ExemptionService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjectable"]({
    token: VehicleDetailsResolver,
    factory: VehicleDetailsResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 8706:
/*!****************************************************!*\
  !*** ./src/app/core/services/exemption.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptionService": () => (/* binding */ ExemptionService)
/* harmony export */ });
/* harmony import */ var _utilities_apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utilities/apis */ 1603);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 5159);



class ExemptionService {
  constructor(_baseService) {
    this._baseService = _baseService;
  }
  insert(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Exemption.insertExemptedVehicles, payload);
  }
  search(payload) {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.GlobalConfigs.GetVehicleDetails, payload);
  }
  getResons() {
    return this._baseService.post(_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Exemption.GetExemptedReasons, null);
  }
  static #_ = this.ɵfac = function ExemptionService_Factory(t) {
    return new (t || ExemptionService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: ExemptionService,
    factory: ExemptionService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 9603:
/*!*******************************************************************************!*\
  !*** ./src/app/features/exemption/exemption-form/exemption-form.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptionFormComponent": () => (/* binding */ ExemptionFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 1640);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var src_app_core_helper_create_inspection_search_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/helper/create-inspection-search.helper */ 3893);
/* harmony import */ var src_app_core_helper_map_lookup_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/helper/map-lookup.helper */ 5674);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_app_core_services_lookups_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookups.service */ 3846);
/* harmony import */ var src_app_core_services_exemption_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/exemption.service */ 8706);
/* harmony import */ var src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/toastr.service */ 8996);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var _shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../shared/components/business/vehicle-details-header/vehicle-details-header.component */ 5425);















function ExemptionFormComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "app-f-form", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 4)(4, "div", 5)(5, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ExemptionFormComponent_ng_container_1_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r1.cancel());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](8, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("click", function ExemptionFormComponent_ng_container_1_Template_button_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r2);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r3.submit());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("controls", ctx_r0.controls)("formGroup", ctx_r0.form)("submitted", ctx_r0.submitted);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](7, 5, "Cancel"));
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpipeBind1"](10, 7, "Confirm"));
  }
}
const _c0 = function (a0) {
  return [a0];
};
const _c1 = function () {
  return [];
};
class ExemptionFormComponent {
  constructor(_fb, _lookups, _exemption, _toastr, _translateService, _route, _router) {
    this._fb = _fb;
    this._lookups = _lookups;
    this._exemption = _exemption;
    this._toastr = _toastr;
    this._translateService = _translateService;
    this._route = _route;
    this._router = _router;
    this.submitted = false;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_9__.Subscription();
    this.controls = [
    // {
    //   label: 'LicenseNo',
    //   name: 'plateNo',
    //   type: INPUTS_TYPES.NUMBER,
    //   required: true,
    //   width: 'col-md-4',
    // },
    // {
    //   label: 'LicenseType',
    //   name: 'plateType',
    //   type: INPUTS_TYPES.LIST,
    //   required: true,
    //   width: 'col-md-4',
    //   list: <ILookup[]>[],
    // },
    {
      label: 'Reason',
      name: 'exemptedReason',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__.INPUTS_TYPES.LIST,
      list: [],
      required: true,
      width: 'col-md-6'
    }, {
      label: 'remarks',
      name: 'remarks',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_0__.INPUTS_TYPES.TEXT_AREA,
      required: true,
      width: 'col-md-6'
    }];
  }
  ngOnInit() {
    this.getResolved();
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_10__.map)(el => el['data'])).subscribe(res => {
      if (res) {
        res.station = {
          NameEn: res.stationNameEn,
          NameAr: res.stationNameAr
        };
        res.plateTypeName = {
          NameEn: res.plateTypeEname,
          NameAr: res.plateTypeAname
        };
        this.items = res;
        this.initForm();
      }
    });
    this.subscription.add(sub);
  }
  initForm() {
    this.form = this._fb.group({
      plateNo: [this.items.plateNo, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.Validators.required],
      plateType: [this.items.plateType, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.Validators.required],
      exemptedReason: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.Validators.required],
      remarks: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.Validators.required],
      // TODO
      createdBy: [4, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.Validators.required]
    });
    this.getLookups();
  }
  getLookups() {
    (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.forkJoin)({
      resons: this._exemption.getResons()
    }).subscribe(({
      resons
    }) => {
      this.controls.find(x => x.name === 'exemptedReason').list = (0,src_app_core_helper_map_lookup_helper__WEBPACK_IMPORTED_MODULE_2__.mapLookup)(resons);
    });
  }
  get plateTypeInput() {
    return this.form.controls['plateType'];
  }
  cancel() {
    this.form.reset();
    this.submitted = false;
    this._router.navigate(['..'], {
      relativeTo: this._route
    });
  }
  submit() {
    this.submitted = true;
    if (!this.form.valid) return;
    const value = this.form.getRawValue();
    value.plateType = (0,src_app_core_helper_create_inspection_search_helper__WEBPACK_IMPORTED_MODULE_1__.calcType)(value.plateType.toString());
    this._exemption.insert(value).subscribe(x => {
      if (x) {
        this.cancel();
        this._toastr.showSuccess(this._translateService.instant('Added successfully'));
      }
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function ExemptionFormComponent_Factory(t) {
    return new (t || ExemptionFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_lookups_service__WEBPACK_IMPORTED_MODULE_3__.LookupsService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_exemption_service__WEBPACK_IMPORTED_MODULE_4__.ExemptionService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](src_app_core_services_toastr_service__WEBPACK_IMPORTED_MODULE_5__.ToastrService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({
    type: ExemptionFormComponent,
    selectors: [["app-exemption-form"]],
    decls: 2,
    vars: 5,
    consts: [[3, "items"], [4, "ngIf"], [1, "form-block"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "row"], [1, "col-12", "ab-ri"], ["type", "button", 1, "btn", "btn-outline", 3, "click"], ["type", "button", 1, "btn", "btn-purple", 3, "click"]],
    template: function ExemptionFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](0, "app-vehicle-details-header", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](1, ExemptionFormComponent_ng_container_1_Template, 11, 9, "ng-container", 1);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("items", ctx.items ? _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction1"](2, _c0, ctx.items) : _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵpureFunction0"](4, _c1));
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.items);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_6__.FFormComponent, _shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_7__.VehicleDetailsHeaderComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 9856:
/*!****************************************************************!*\
  !*** ./src/app/features/exemption/exemption-routing.module.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptionRoutingModule": () => (/* binding */ ExemptionRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _exemption_form_exemption_form_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./exemption-form/exemption-form.component */ 9603);
/* harmony import */ var _exemption_search_form_exemption_search_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./exemption-search-form/exemption-search-form.component */ 7828);
/* harmony import */ var src_app_core_resolvers_exemption_vehicle_details_resolver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/resolvers/exemption/vehicle-details.resolver */ 9292);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);






const routes = [{
  path: '',
  component: _exemption_search_form_exemption_search_form_component__WEBPACK_IMPORTED_MODULE_1__.ExemptionSearchFormComponent,
  data: {
    title: "Exemption"
  }
}, {
  path: 'vehicle-details',
  component: _exemption_form_exemption_form_component__WEBPACK_IMPORTED_MODULE_0__.ExemptionFormComponent,
  data: {
    title: "Exemption"
  },
  resolve: {
    data: src_app_core_resolvers_exemption_vehicle_details_resolver__WEBPACK_IMPORTED_MODULE_2__.VehicleDetailsResolver
  }
}];
class ExemptionRoutingModule {
  static #_ = this.ɵfac = function ExemptionRoutingModule_Factory(t) {
    return new (t || ExemptionRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: ExemptionRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ExemptionRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 7828:
/*!*********************************************************************************************!*\
  !*** ./src/app/features/exemption/exemption-search-form/exemption-search-form.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptionSearchFormComponent": () => (/* binding */ ExemptionSearchFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../shared/components/business/vehicle-search-container/vehicle-search-container.component */ 4070);



class ExemptionSearchFormComponent {
  constructor(_router, _route) {
    this._router = _router;
    this._route = _route;
  }
  submit(event) {
    const {
      plateNo,
      plateType,
      ...rest
    } = event;
    this._router.navigate(["vehicle-details"], {
      relativeTo: this._route,
      queryParams: event.searchText ? rest : event
    });
  }
  static #_ = this.ɵfac = function ExemptionSearchFormComponent_Factory(t) {
    return new (t || ExemptionSearchFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: ExemptionSearchFormComponent,
    selectors: [["app-exemption-search-form"]],
    decls: 1,
    vars: 1,
    consts: [[3, "showReceipt", "onSearch"]],
    template: function ExemptionSearchFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "app-vehicle-search-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("onSearch", function ExemptionSearchFormComponent_Template_app_vehicle_search_container_onSearch_0_listener($event) {
          return ctx.submit($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("showReceipt", false);
      }
    },
    dependencies: [_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_0__.VehicleSearchContainerComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3919:
/*!********************************************************!*\
  !*** ./src/app/features/exemption/exemption.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExemptionModule": () => (/* binding */ ExemptionModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _exemption_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./exemption-routing.module */ 9856);
/* harmony import */ var _exemption_form_exemption_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./exemption-form/exemption-form.component */ 9603);
/* harmony import */ var src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/shared/components/f-form/f-form.component */ 1293);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _exemption_search_form_exemption_search_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./exemption-search-form/exemption-search-form.component */ 7828);
/* harmony import */ var src_app_shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/components/business/vehicle-details-header/vehicle-details-header.component */ 5425);
/* harmony import */ var src_app_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/components/business/vehicle-search-container/vehicle-search-container.component */ 4070);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);









class ExemptionModule {
  static #_ = this.ɵfac = function ExemptionModule_Factory(t) {
    return new (t || ExemptionModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({
    type: ExemptionModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _exemption_routing_module__WEBPACK_IMPORTED_MODULE_0__.ExemptionRoutingModule, src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule, src_app_shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_4__.VehicleDetailsHeaderComponent, src_app_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_5__.VehicleSearchContainerComponent]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](ExemptionModule, {
    declarations: [_exemption_form_exemption_form_component__WEBPACK_IMPORTED_MODULE_1__.ExemptionFormComponent, _exemption_search_form_exemption_search_form_component__WEBPACK_IMPORTED_MODULE_3__.ExemptionSearchFormComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _exemption_routing_module__WEBPACK_IMPORTED_MODULE_0__.ExemptionRoutingModule, src_app_shared_components_f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__.TranslateModule, src_app_shared_components_business_vehicle_details_header_vehicle_details_header_component__WEBPACK_IMPORTED_MODULE_4__.VehicleDetailsHeaderComponent, src_app_shared_components_business_vehicle_search_container_vehicle_search_container_component__WEBPACK_IMPORTED_MODULE_5__.VehicleSearchContainerComponent]
  });
})();

/***/ })

}]);
//# sourceMappingURL=919.429378e09fbd1430.js.map