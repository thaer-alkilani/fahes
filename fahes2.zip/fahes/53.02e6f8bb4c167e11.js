"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[53],{

/***/ 7741:
/*!********************************************!*\
  !*** ./src/app/core/enums/Lookups.enum.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LOOKUPS": () => (/* binding */ LOOKUPS)
/* harmony export */ });
var LOOKUPS;
(function (LOOKUPS) {
  LOOKUPS[LOOKUPS["EXEMPTED_REASON"] = 60] = "EXEMPTED_REASON";
  LOOKUPS[LOOKUPS["PLATE_TYPE"] = 40] = "PLATE_TYPE";
  LOOKUPS[LOOKUPS["EVALUATIONS"] = 29] = "EVALUATIONS";
})(LOOKUPS || (LOOKUPS = {}));

/***/ }),

/***/ 1114:
/*!*********************************************************!*\
  !*** ./src/app/core/enums/vehicle-search-types.enum.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VEHICLE_SEARCH_TYPES": () => (/* binding */ VEHICLE_SEARCH_TYPES),
/* harmony export */   "VEHICLE_SEARCH_TYPES_Buttons": () => (/* binding */ VEHICLE_SEARCH_TYPES_Buttons)
/* harmony export */ });
var VEHICLE_SEARCH_TYPES;
(function (VEHICLE_SEARCH_TYPES) {
  VEHICLE_SEARCH_TYPES[VEHICLE_SEARCH_TYPES["PLATE_NO"] = 2] = "PLATE_NO";
  VEHICLE_SEARCH_TYPES[VEHICLE_SEARCH_TYPES["SCAN"] = 3] = "SCAN";
  VEHICLE_SEARCH_TYPES[VEHICLE_SEARCH_TYPES["REQUEST_ID"] = 4] = "REQUEST_ID";
})(VEHICLE_SEARCH_TYPES || (VEHICLE_SEARCH_TYPES = {}));
var VEHICLE_SEARCH_TYPES_Buttons;
(function (VEHICLE_SEARCH_TYPES_Buttons) {
  VEHICLE_SEARCH_TYPES_Buttons[VEHICLE_SEARCH_TYPES_Buttons["PLATE_NO"] = 1] = "PLATE_NO";
  VEHICLE_SEARCH_TYPES_Buttons[VEHICLE_SEARCH_TYPES_Buttons["ISTIMARA"] = 2] = "ISTIMARA";
  VEHICLE_SEARCH_TYPES_Buttons[VEHICLE_SEARCH_TYPES_Buttons["RECEIPT"] = 3] = "RECEIPT";
})(VEHICLE_SEARCH_TYPES_Buttons || (VEHICLE_SEARCH_TYPES_Buttons = {}));

/***/ }),

/***/ 3893:
/*!****************************************************************!*\
  !*** ./src/app/core/helper/create-inspection-search.helper.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "calcType": () => (/* binding */ calcType),
/* harmony export */   "concatinate": () => (/* binding */ concatinate)
/* harmony export */ });
function concatinate(payload) {
  return calcType(payload.plateType.toString()) + payload.plateNo.toString();
}
function calcType(licenseType) {
  if (licenseType.length == 1) {
    return '0' + licenseType;
  } else {
    return licenseType;
  }
}

/***/ }),

/***/ 3846:
/*!**************************************************!*\
  !*** ./src/app/core/services/lookups.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LookupsService": () => (/* binding */ LookupsService)
/* harmony export */ });
/* harmony import */ var _utilities_apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utilities/apis */ 1603);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 5159);



class LookupsService {
  constructor(_baseService) {
    this._baseService = _baseService;
  }
  getLookup(code) {
    const url = `${_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Lookups}?${this._baseService.toQueryString({
      LookupCode: code
    })}`;
    return this._baseService.post(url, null);
  }
  static #_ = this.ɵfac = function LookupsService_Factory(t) {
    return new (t || LookupsService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: LookupsService,
    factory: LookupsService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 4321:
/*!*************************************************************************************!*\
  !*** ./src/app/shared/components/business/scan-istimara/scan-istimara.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ScanIstimaraComponent": () => (/* binding */ ScanIstimaraComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/vehicle-search-types.enum */ 1114);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var _f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../f-form/f-form.component */ 1293);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);











function ScanIstimaraComponent_h5_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "h5", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 3, ctx_r0.label)));
  }
}
class ScanIstimaraComponent {
  constructor(_fb) {
    this._fb = _fb;
    this.onSearch = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    this.submitted = false;
    this.controls = [{
      label: 'BarCode',
      name: 'searchText',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__.INPUTS_TYPES.TEXT_NUM,
      required: true,
      width: 'col-lg-12 col-md-6'
    }];
  }
  ngOnInit() {
    this.initForm();
  }
  initForm() {
    this.form = this._fb.group({
      searchText: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.maxLength(8)]],
      searchType: [src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__.VEHICLE_SEARCH_TYPES.PLATE_NO]
    });
  }
  cancel() {
    this.form.reset();
    this.submitted = false;
  }
  submit() {
    this.submitted = true;
    if (!this.form.valid) return;
    this.onSearch.emit(this.form.getRawValue());
  }
  static #_ = this.ɵfac = function ScanIstimaraComponent_Factory(t) {
    return new (t || ScanIstimaraComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ScanIstimaraComponent,
    selectors: [["app-scan-istimara"]],
    inputs: {
      label: "label"
    },
    outputs: {
      onSearch: "onSearch"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵStandaloneFeature"]],
    decls: 8,
    vars: 7,
    consts: [[1, "form-block", "row", "justify-content-between", "align-items-center", "p-3", "mx-0", "h-100"], ["class", "fw-bold mb-0", 4, "ngIf"], [1, "col-lg-10", "col-md-12"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "col"], ["type", "button", 1, "btn", "btn-purple", "w-100", 3, "click"], [1, "fw-bold", "mb-0"]],
    template: function ScanIstimaraComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ScanIstimaraComponent_h5_1_Template, 4, 5, "h5", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "app-f-form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4)(5, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ScanIstimaraComponent_Template_button_click_5_listener() {
          return ctx.submit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("controls", ctx.controls)("formGroup", ctx.form)("submitted", ctx.submitted);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 5, "Search"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.TitleCasePipe, _f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 2085:
/*!*************************************************************************************************!*\
  !*** ./src/app/shared/components/business/seaching-receipt-no/seaching-receipt-no.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchingReceiptNoComponent": () => (/* binding */ SearchingReceiptNoComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/vehicle-search-types.enum */ 1114);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var _f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../f-form/f-form.component */ 1293);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);











function SearchingReceiptNoComponent_h5_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "h5", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 3, ctx_r0.label)));
  }
}
class SearchingReceiptNoComponent {
  constructor(_fb) {
    this._fb = _fb;
    this.onSearch = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    this.submitted = false;
    this.controls = [{
      label: 'ReceiptNo',
      name: 'searchText',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__.INPUTS_TYPES.TEXT_NUM,
      required: true,
      width: 'col-lg-12 col-md-6'
    }];
  }
  ngOnInit() {
    this.initForm();
  }
  initForm() {
    this.form = this._fb.group({
      searchText: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required],
      searchType: [src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_0__.VEHICLE_SEARCH_TYPES.SCAN]
    });
  }
  cancel() {
    this.form.reset();
    this.submitted = false;
  }
  submit() {
    this.submitted = true;
    if (!this.form.valid) return;
    this.onSearch.emit(this.form.getRawValue());
  }
  static #_ = this.ɵfac = function SearchingReceiptNoComponent_Factory(t) {
    return new (t || SearchingReceiptNoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: SearchingReceiptNoComponent,
    selectors: [["app-seaching-receipt-no"]],
    inputs: {
      label: "label"
    },
    outputs: {
      onSearch: "onSearch"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵStandaloneFeature"]],
    decls: 8,
    vars: 7,
    consts: [[1, "form-block", "row", "justify-content-between", "align-items-center", "p-3", "mx-0", "h-100"], ["class", "fw-bold mb-0", 4, "ngIf"], [1, "col-lg-10", "col-md-12"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "col"], ["type", "button", 1, "btn", "btn-purple", "w-100", 3, "click"], [1, "fw-bold", "mb-0"]],
    template: function SearchingReceiptNoComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, SearchingReceiptNoComponent_h5_1_Template, 4, 5, "h5", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "app-f-form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4)(5, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SearchingReceiptNoComponent_Template_button_click_5_listener() {
          return ctx.submit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("controls", ctx.controls)("formGroup", ctx.form)("submitted", ctx.submitted);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 5, "Search"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.TitleCasePipe, _f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__.FFormComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 3886:
/*!***************************************************************************************************!*\
  !*** ./src/app/shared/components/business/searching-plate-form/searching-plate-form.component.ts ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchingPlateFormComponent": () => (/* binding */ SearchingPlateFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var src_app_core_enums_Lookups_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/enums/Lookups.enum */ 7741);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/enums/inputs-types */ 7000);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../f-form/f-form.component */ 1293);
/* harmony import */ var src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/enums/vehicle-search-types.enum */ 1114);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_core_services_lookups_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/lookups.service */ 3846);














function SearchingPlateFormComponent_h5_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "h5", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 1, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](3, 3, ctx_r0.label)));
  }
}
class SearchingPlateFormComponent {
  constructor(_fb, _router, _route, _lookups) {
    this._fb = _fb;
    this._router = _router;
    this._route = _route;
    this._lookups = _lookups;
    this.onSearch = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
    this.submitted = false;
    this.controls = [{
      label: 'LicenseNo',
      name: 'plateNo',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__.INPUTS_TYPES.TEXT_NUM,
      required: true,
      width: 'col-lg-6'
    }, {
      label: 'LicenseType',
      name: 'plateType',
      type: src_app_core_enums_inputs_types__WEBPACK_IMPORTED_MODULE_1__.INPUTS_TYPES.LIST,
      required: true,
      width: 'col-lg-6',
      list: []
    }];
  }
  ngOnInit() {
    this.initForm();
  }
  initForm() {
    this.form = this._fb.group({
      plateNo: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(6)]],
      plateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      searchType: [src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_3__.VEHICLE_SEARCH_TYPES.PLATE_NO]
    });
    this.getLookups();
  }
  getLookups() {
    this._lookups.getLookup(src_app_core_enums_Lookups_enum__WEBPACK_IMPORTED_MODULE_0__.LOOKUPS.PLATE_TYPE).subscribe(res => {
      const control = this.controls?.find(x => x.name === 'plateType');
      if (control) {
        control.list = res.map(x => {
          return {
            NameEn: x.lkValueEname,
            NameAr: x.lkValueAname,
            Id: x.lkCodeValue
          };
        });
      }
    });
  }
  cancel() {
    this.form.reset();
    this.submitted = false;
  }
  submit() {
    this.submitted = true;
    if (!this.form.valid) return;
    this.onSearch.emit(this.form.getRawValue());
  }
  static #_ = this.ɵfac = function SearchingPlateFormComponent_Factory(t) {
    return new (t || SearchingPlateFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookups_service__WEBPACK_IMPORTED_MODULE_4__.LookupsService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: SearchingPlateFormComponent,
    selectors: [["app-searching-plate-form"]],
    inputs: {
      label: "label"
    },
    outputs: {
      onSearch: "onSearch"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵStandaloneFeature"]],
    decls: 8,
    vars: 7,
    consts: [[1, "form-block", "row", "justify-content-between", "align-items-center", "p-3", "mx-0", "h-100"], ["class", "fw-bold mb-0", 4, "ngIf"], [1, "col-lg-10"], [1, "w-100", 3, "controls", "formGroup", "submitted"], [1, "col"], ["type", "button", 1, "btn", "btn-purple", "w-100", 3, "click"], [1, "fw-bold", "mb-0"]],
    template: function SearchingPlateFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, SearchingPlateFormComponent_h5_1_Template, 4, 5, "h5", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "app-f-form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 4)(5, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function SearchingPlateFormComponent_Template_button_click_5_listener() {
          return ctx.submit();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](7, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("controls", ctx.controls)("formGroup", ctx.form)("submitted", ctx.submitted);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](7, 5, "Search"));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.TitleCasePipe, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormGroupDirective, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe, _f_form_f_form_component__WEBPACK_IMPORTED_MODULE_2__.FFormComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 5425:
/*!*******************************************************************************************************!*\
  !*** ./src/app/shared/components/business/vehicle-details-header/vehicle-details-header.component.ts ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleDetailsHeaderComponent": () => (/* binding */ VehicleDetailsHeaderComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _f_table_f_table_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../f-table/f-table.component */ 2812);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _f_pass_fail_f_pass_fail_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../f-pass-fail/f-pass-fail.component */ 9708);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);






function VehicleDetailsHeaderComponent_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 5)(1, "h6");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "app-f-pass-fail", 6)(3, "app-f-pass-fail", 7)(4, "app-f-pass-fail", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("finalResult", ctx_r0.inspectionResultDetails.isTechnichalPassed);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("finalResult", ctx_r0.inspectionResultDetails.isLegalPassed);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("finalResult", ctx_r0.items[0].finalResult == 1 ? true : ctx_r0.items[0].finalResult == 2 ? false : null);
  }
}
class VehicleDetailsHeaderComponent {
  constructor() {
    this.dialogMode = false;
    this.cols = [{
      title: 'OwnerPID',
      col: 'ownerPID'
    }, {
      title: 'OwnerName',
      col: 'ownerName'
    }, {
      title: 'LicensePlateNo',
      col: 'plateNo',
      isNumber: true
    }, {
      title: 'LicensePlateType',
      col: 'plateTypeName',
      isLocalized: true
    }, {
      title: 'VINNo',
      col: 'vinNo'
    }, {
      title: 'category',
      col: 'vehicleCategoryValueLocalized',
      isLocalized: true
    }];
  }
  ngOnInit() {
    if (this.extraCols?.length) {
      this.cols = [...this.cols, ...this.extraCols];
    }
  }
  static #_ = this.ɵfac = function VehicleDetailsHeaderComponent_Factory(t) {
    return new (t || VehicleDetailsHeaderComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: VehicleDetailsHeaderComponent,
    selectors: [["app-vehicle-details-header"]],
    inputs: {
      items: "items",
      extraCols: "extraCols",
      dialogMode: "dialogMode",
      inspectionResultDetails: "inspectionResultDetails"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵStandaloneFeature"]],
    decls: 5,
    vars: 8,
    consts: [[1, "form-block", "position-relative"], ["class", "v-status", 4, "ngIf"], [1, "row", "w-100"], [1, "col-12", "table-responsive"], [3, "coloredHeader", "showBorders", "cols", "items", "trackBy"], [1, "v-status"], ["label", "Technichal", 1, "me-3", 3, "finalResult"], ["label", "Legal", 1, "me-3", 3, "finalResult"], ["label", "FinalResult", 1, "me-3", 3, "finalResult"]],
    template: function VehicleDetailsHeaderComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, VehicleDetailsHeaderComponent_span_1_Template, 5, 3, "span", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 2)(3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](4, "app-f-table", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("shadow-none", ctx.dialogMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.inspectionResultDetails);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("coloredHeader", false)("showBorders", false)("cols", ctx.cols)("items", ctx.items)("trackBy", "OwnerPID");
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _f_table_f_table_component__WEBPACK_IMPORTED_MODULE_0__.FTableComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslateModule, _f_pass_fail_f_pass_fail_component__WEBPACK_IMPORTED_MODULE_1__.FPassFailComponent],
    styles: [".v-status[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 15px;\n}\n\n  .rtl .v-status {\n  left: 15px;\n  right: auto !important;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvYnVzaW5lc3MvdmVoaWNsZS1kZXRhaWxzLWhlYWRlci92ZWhpY2xlLWRldGFpbHMtaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtBQUNGOztBQUdFO0VBQ0UsVUFBQTtFQUNBLHNCQUFBO0FBQUoiLCJzb3VyY2VzQ29udGVudCI6WyIudi1zdGF0dXMge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDEwcHg7XHJcbiAgcmlnaHQ6IDE1cHg7XHJcbn1cclxuXHJcbjo6bmctZGVlcCAucnRse1xyXG4gIC52LXN0YXR1cyB7XHJcbiAgICBsZWZ0OiAxNXB4O1xyXG4gICAgcmlnaHQ6IGF1dG8gIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 4070:
/*!***********************************************************************************************************!*\
  !*** ./src/app/shared/components/business/vehicle-search-container/vehicle-search-container.component.ts ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleSearchContainerComponent": () => (/* binding */ VehicleSearchContainerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _scan_istimara_scan_istimara_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../scan-istimara/scan-istimara.component */ 4321);
/* harmony import */ var _searching_plate_form_searching_plate_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../searching-plate-form/searching-plate-form.component */ 3886);
/* harmony import */ var src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/enums/vehicle-search-types.enum */ 1114);
/* harmony import */ var _seaching_receipt_no_seaching_receipt_no_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../seaching-receipt-no/seaching-receipt-no.component */ 2085);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);








const _c0 = ["form"];
class VehicleSearchContainerComponent {
  constructor() {
    this.showReceipt = true;
    this.onSearch = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.currentOption = src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_2__.VEHICLE_SEARCH_TYPES_Buttons.RECEIPT;
    this.timeOuts = [];
  }
  get VEHICLE_SEARCH_TYPES_Buttons() {
    return src_app_core_enums_vehicle_search_types_enum__WEBPACK_IMPORTED_MODULE_2__.VEHICLE_SEARCH_TYPES_Buttons;
  }
  ngAfterViewInit() {
    this.autoFocusFirstInput();
  }
  autoFocusFirstInput() {
    const time = setTimeout(() => {
      this.clearTimeouts();
      const input = this.form.nativeElement.querySelector('.p-element.ng-pristine');
      input.focus();
    }, 0);
    this.timeOuts.push(time);
  }
  clearTimeouts() {
    if (this.timeOuts.length) {
      this.timeOuts.forEach(x => clearTimeout(x));
      this.timeOuts = [];
    }
  }
  toggle(value) {
    this.currentOption = value;
    this.autoFocusFirstInput();
  }
  submit(event) {
    this.onSearch.emit(event);
  }
  ngOnDestroy() {
    this.clearTimeouts();
  }
  static #_ = this.ɵfac = function VehicleSearchContainerComponent_Factory(t) {
    return new (t || VehicleSearchContainerComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: VehicleSearchContainerComponent,
    selectors: [["app-vehicle-search-container"]],
    viewQuery: function VehicleSearchContainerComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.form = _t.first);
      }
    },
    inputs: {
      showReceipt: "showReceipt"
    },
    outputs: {
      onSearch: "onSearch"
    },
    standalone: true,
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵStandaloneFeature"]],
    decls: 11,
    vars: 0,
    consts: [[1, "vehicle-toggler-container"], ["id", "formRefId", 1, "row"], ["form", ""], [1, "col-lg-6", "mb-3"], [1, "h-100"], ["label", "SearchReceipt", 3, "onSearch"], ["label", "ScanIstimara", 3, "onSearch"], [1, "col-lg-12", "mb-3"], ["label", "SearchPlate", 3, "onSearch"]],
    template: function VehicleSearchContainerComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0)(1, "div", 1, 2)(3, "div", 3)(4, "div", 4)(5, "app-seaching-receipt-no", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSearch", function VehicleSearchContainerComponent_Template_app_seaching_receipt_no_onSearch_5_listener($event) {
          return ctx.submit($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 3)(7, "div", 4)(8, "app-scan-istimara", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSearch", function VehicleSearchContainerComponent_Template_app_scan_istimara_onSearch_8_listener($event) {
          return ctx.submit($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 7)(10, "app-searching-plate-form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("onSearch", function VehicleSearchContainerComponent_Template_app_searching_plate_form_onSearch_10_listener($event) {
          return ctx.submit($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _searching_plate_form_searching_plate_form_component__WEBPACK_IMPORTED_MODULE_1__.SearchingPlateFormComponent, _scan_istimara_scan_istimara_component__WEBPACK_IMPORTED_MODULE_0__.ScanIstimaraComponent, _seaching_receipt_no_seaching_receipt_no_component__WEBPACK_IMPORTED_MODULE_3__.SearchingReceiptNoComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ })

}]);
//# sourceMappingURL=53.02e6f8bb4c167e11.js.map