"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[759],{

/***/ 3759:
/*!***************************************************************************************!*\
  !*** ./node_modules/@azure/msal-browser/dist/controllers/NestedAppAuthController.mjs ***!
  \***************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NestedAppAuthController": () => (/* binding */ NestedAppAuthController)
/* harmony export */ });
/* harmony import */ var D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @azure/msal-common */ 3758);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @azure/msal-common */ 193);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @azure/msal-common */ 8174);
/* harmony import */ var _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/BrowserConstants.mjs */ 495);
/* harmony import */ var _crypto_CryptoOps_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../crypto/CryptoOps.mjs */ 3589);
/* harmony import */ var _naa_mapping_NestedAppAuthAdapter_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../naa/mapping/NestedAppAuthAdapter.mjs */ 6488);
/* harmony import */ var _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../error/NestedAppAuthError.mjs */ 415);
/* harmony import */ var _event_EventHandler_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../event/EventHandler.mjs */ 1262);
/* harmony import */ var _event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../event/EventType.mjs */ 1241);
/*! @azure/msal-browser v3.13.0 2024-04-11 */











/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class NestedAppAuthController {
  constructor(operatingContext) {
    this.operatingContext = operatingContext;
    const proxy = this.operatingContext.getBridgeProxy();
    if (proxy !== undefined) {
      this.bridgeProxy = proxy;
    } else {
      throw new Error("unexpected: bridgeProxy is undefined");
    }
    // Set the configuration.
    this.config = operatingContext.getConfig();
    // Initialize logger
    this.logger = this.operatingContext.getLogger();
    // Initialize performance client
    this.performanceClient = this.config.telemetry.client;
    // Initialize the crypto class.
    this.browserCrypto = operatingContext.isBrowserEnvironment() ? new _crypto_CryptoOps_mjs__WEBPACK_IMPORTED_MODULE_1__.CryptoOps(this.logger, this.performanceClient) : _azure_msal_common__WEBPACK_IMPORTED_MODULE_2__.DEFAULT_CRYPTO_IMPLEMENTATION;
    this.eventHandler = new _event_EventHandler_mjs__WEBPACK_IMPORTED_MODULE_3__.EventHandler(this.logger, this.browserCrypto);
    this.nestedAppAuthAdapter = new _naa_mapping_NestedAppAuthAdapter_mjs__WEBPACK_IMPORTED_MODULE_4__.NestedAppAuthAdapter(this.config.auth.clientId, this.config.auth.clientCapabilities, this.browserCrypto, this.logger);
  }
  getBrowserStorage() {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  getEventHandler() {
    return this.eventHandler;
  }
  static createController(operatingContext) {
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const controller = new NestedAppAuthController(operatingContext);
      return Promise.resolve(controller);
    })();
  }
  initialize() {
    // do nothing not required by this controller
    return Promise.resolve();
  }
  ensureValidRequest(request) {
    if (request?.correlationId) {
      return request;
    }
    return {
      ...request,
      correlationId: this.browserCrypto.createNewGuid()
    };
  }
  acquireTokenInteractive(request) {
    var _this = this;
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const validRequest = _this.ensureValidRequest(request);
      _this.eventHandler.emitEvent(_event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__.EventType.ACQUIRE_TOKEN_START, _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.InteractionType.Popup, validRequest);
      const atPopupMeasurement = _this.performanceClient.startMeasurement(_azure_msal_common__WEBPACK_IMPORTED_MODULE_8__.PerformanceEvents.AcquireTokenPopup, validRequest.correlationId);
      atPopupMeasurement?.add({
        nestedAppAuthRequest: true
      });
      try {
        const naaRequest = _this.nestedAppAuthAdapter.toNaaTokenRequest(validRequest);
        const reqTimestamp = _azure_msal_common__WEBPACK_IMPORTED_MODULE_9__.nowSeconds();
        const response = yield _this.bridgeProxy.getTokenInteractive(naaRequest);
        const result = _this.nestedAppAuthAdapter.fromNaaTokenResponse(naaRequest, response, reqTimestamp);
        _this.operatingContext.setActiveAccount(result.account);
        _this.eventHandler.emitEvent(_event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__.EventType.ACQUIRE_TOKEN_SUCCESS, _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.InteractionType.Popup, result);
        atPopupMeasurement.add({
          accessTokenSize: result.accessToken.length,
          idTokenSize: result.idToken.length
        });
        atPopupMeasurement.end({
          success: true,
          requestId: result.requestId
        });
        return result;
      } catch (e) {
        const error = _this.nestedAppAuthAdapter.fromBridgeError(e);
        _this.eventHandler.emitEvent(_event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__.EventType.ACQUIRE_TOKEN_FAILURE, _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.InteractionType.Popup, null, e);
        atPopupMeasurement.end({
          success: false
        }, e);
        throw error;
      }
    })();
  }
  acquireTokenSilentInternal(request) {
    var _this2 = this;
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const validRequest = _this2.ensureValidRequest(request);
      _this2.eventHandler.emitEvent(_event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__.EventType.ACQUIRE_TOKEN_START, _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.InteractionType.Silent, validRequest);
      const ssoSilentMeasurement = _this2.performanceClient.startMeasurement(_azure_msal_common__WEBPACK_IMPORTED_MODULE_8__.PerformanceEvents.SsoSilent, validRequest.correlationId);
      ssoSilentMeasurement?.increment({
        visibilityChangeCount: 0
      });
      ssoSilentMeasurement?.add({
        nestedAppAuthRequest: true
      });
      try {
        const naaRequest = _this2.nestedAppAuthAdapter.toNaaTokenRequest(validRequest);
        const reqTimestamp = _azure_msal_common__WEBPACK_IMPORTED_MODULE_9__.nowSeconds();
        const response = yield _this2.bridgeProxy.getTokenSilent(naaRequest);
        const result = _this2.nestedAppAuthAdapter.fromNaaTokenResponse(naaRequest, response, reqTimestamp);
        _this2.operatingContext.setActiveAccount(result.account);
        _this2.eventHandler.emitEvent(_event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__.EventType.ACQUIRE_TOKEN_SUCCESS, _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.InteractionType.Silent, result);
        ssoSilentMeasurement?.add({
          accessTokenSize: result.accessToken.length,
          idTokenSize: result.idToken.length
        });
        ssoSilentMeasurement?.end({
          success: true,
          requestId: result.requestId
        });
        return result;
      } catch (e) {
        const error = _this2.nestedAppAuthAdapter.fromBridgeError(e);
        _this2.eventHandler.emitEvent(_event_EventType_mjs__WEBPACK_IMPORTED_MODULE_6__.EventType.ACQUIRE_TOKEN_FAILURE, _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.InteractionType.Silent, null, e);
        ssoSilentMeasurement?.end({
          success: false
        }, e);
        throw error;
      }
    })();
  }
  acquireTokenPopup(request) {
    var _this3 = this;
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this3.acquireTokenInteractive(request);
    })();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  acquireTokenRedirect(request) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  acquireTokenSilent(silentRequest) {
    var _this4 = this;
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this4.acquireTokenSilentInternal(silentRequest);
    })();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  acquireTokenByCode(request // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  acquireTokenNative(request, apiId,
  // eslint-disable-line @typescript-eslint/no-unused-vars
  accountId // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  acquireTokenByRefreshToken(commonRequest,
  // eslint-disable-line @typescript-eslint/no-unused-vars
  silentRequest // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  /**
   * Adds event callbacks to array
   * @param callback
   */
  addEventCallback(callback) {
    return this.eventHandler.addEventCallback(callback);
  }
  /**
   * Removes callback with provided id from callback array
   * @param callbackId
   */
  removeEventCallback(callbackId) {
    this.eventHandler.removeEventCallback(callbackId);
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  addPerformanceCallback(callback) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  removePerformanceCallback(callbackId) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  enableAccountStorageEvents() {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  disableAccountStorageEvents() {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  getAccount(accountFilter) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
    // TODO: Look at standard implementation
  }

  getAccountByHomeId(homeAccountId) {
    const currentAccount = this.operatingContext.getActiveAccount();
    if (currentAccount !== undefined) {
      if (currentAccount.homeAccountId === homeAccountId) {
        return this.nestedAppAuthAdapter.fromNaaAccountInfo(currentAccount);
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  getAccountByLocalId(localId) {
    const currentAccount = this.operatingContext.getActiveAccount();
    if (currentAccount !== undefined) {
      if (currentAccount.localAccountId === localId) {
        return this.nestedAppAuthAdapter.fromNaaAccountInfo(currentAccount);
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  getAccountByUsername(userName) {
    const currentAccount = this.operatingContext.getActiveAccount();
    if (currentAccount !== undefined) {
      if (currentAccount.username === userName) {
        return this.nestedAppAuthAdapter.fromNaaAccountInfo(currentAccount);
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  getAllAccounts() {
    const currentAccount = this.operatingContext.getActiveAccount();
    if (currentAccount !== undefined) {
      return [this.nestedAppAuthAdapter.fromNaaAccountInfo(currentAccount)];
    } else {
      return [];
    }
  }
  handleRedirectPromise(hash // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    return Promise.resolve(null);
  }
  loginPopup(request // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    return this.acquireTokenInteractive(request || _utils_BrowserConstants_mjs__WEBPACK_IMPORTED_MODULE_7__.DEFAULT_REQUEST);
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  loginRedirect(request) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  logout(logoutRequest) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  logoutRedirect(logoutRequest // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  logoutPopup(logoutRequest // eslint-disable-line @typescript-eslint/no-unused-vars
  ) {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  ssoSilent(
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  request) {
    return this.acquireTokenSilentInternal(request);
  }
  getTokenCache() {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  /**
   * Returns the logger instance
   */
  getLogger() {
    return this.logger;
  }
  /**
   * Replaces the default logger set in configurations with new Logger with new configurations
   * @param logger Logger instance
   */
  setLogger(logger) {
    this.logger = logger;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  setActiveAccount(account) {
    /*
     * StandardController uses this to allow the developer to set the active account
     * in the nested app auth scenario the active account is controlled by the app hosting the nested app
     */
    this.logger.warning("nestedAppAuth does not support setActiveAccount");
    return;
  }
  getActiveAccount() {
    const currentAccount = this.operatingContext.getActiveAccount();
    if (currentAccount !== undefined) {
      return this.nestedAppAuthAdapter.fromNaaAccountInfo(currentAccount);
    } else {
      return null;
    }
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  initializeWrapperLibrary(sku, version) {
    /*
     * Standard controller uses this to set the sku and version of the wrapper library in the storage
     * we do nothing here
     */
    return;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  setNavigationClient(navigationClient) {
    this.logger.warning("setNavigationClient is not supported in nested app auth");
  }
  getConfiguration() {
    return this.config;
  }
  isBrowserEnv() {
    return this.operatingContext.isBrowserEnvironment();
  }
  getBrowserCrypto() {
    return this.browserCrypto;
  }
  getPerformanceClient() {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  getRedirectResponse() {
    throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  clearCache(logoutRequest) {
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
    })();
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  hydrateCache(
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  result,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  request) {
    return (0,D_Diyar_fahes_fahes_frontend_FAHES_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      throw _error_NestedAppAuthError_mjs__WEBPACK_IMPORTED_MODULE_5__.NestedAppAuthError.createUnsupportedError();
    })();
  }
}


/***/ }),

/***/ 415:
/*!****************************************************************************!*\
  !*** ./node_modules/@azure/msal-browser/dist/error/NestedAppAuthError.mjs ***!
  \****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NestedAppAuthError": () => (/* binding */ NestedAppAuthError),
/* harmony export */   "NestedAppAuthErrorMessage": () => (/* binding */ NestedAppAuthErrorMessage)
/* harmony export */ });
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @azure/msal-common */ 5031);
/*! @azure/msal-browser v3.13.0 2024-04-11 */




/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
/**
 * NestedAppAuthErrorMessage class containing string constants used by error codes and messages.
 */
const NestedAppAuthErrorMessage = {
  unsupportedMethod: {
    code: "unsupported_method",
    desc: "The PKCE code challenge and verifier could not be generated."
  }
};
class NestedAppAuthError extends _azure_msal_common__WEBPACK_IMPORTED_MODULE_0__.AuthError {
  constructor(errorCode, errorMessage) {
    super(errorCode, errorMessage);
    Object.setPrototypeOf(this, NestedAppAuthError.prototype);
    this.name = "NestedAppAuthError";
  }
  static createUnsupportedError() {
    return new NestedAppAuthError(NestedAppAuthErrorMessage.unsupportedMethod.code, NestedAppAuthErrorMessage.unsupportedMethod.desc);
  }
}


/***/ }),

/***/ 9207:
/*!*******************************************************************!*\
  !*** ./node_modules/@azure/msal-browser/dist/naa/BridgeError.mjs ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isBridgeError": () => (/* binding */ isBridgeError)
/* harmony export */ });
/*! @azure/msal-browser v3.13.0 2024-04-11 */


/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
function isBridgeError(error) {
  return error.status !== undefined;
}


/***/ }),

/***/ 6488:
/*!************************************************************************************!*\
  !*** ./node_modules/@azure/msal-browser/dist/naa/mapping/NestedAppAuthAdapter.mjs ***!
  \************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NestedAppAuthAdapter": () => (/* binding */ NestedAppAuthAdapter)
/* harmony export */ });
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @azure/msal-common */ 4551);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @azure/msal-common */ 6725);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @azure/msal-common */ 838);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @azure/msal-common */ 1902);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @azure/msal-common */ 8909);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @azure/msal-common */ 2129);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @azure/msal-common */ 7609);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @azure/msal-common */ 1435);
/* harmony import */ var _azure_msal_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @azure/msal-common */ 5031);
/* harmony import */ var _BridgeError_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../BridgeError.mjs */ 9207);
/* harmony import */ var _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../BridgeStatusCode.mjs */ 679);
/*! @azure/msal-browser v3.13.0 2024-04-11 */






/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */
class NestedAppAuthAdapter {
  constructor(clientId, clientCapabilities, crypto, logger) {
    this.clientId = clientId;
    this.clientCapabilities = clientCapabilities;
    this.crypto = crypto;
    this.logger = logger;
  }
  toNaaTokenRequest(request) {
    let extraParams;
    if (request.extraQueryParameters === undefined) {
      extraParams = new Map();
    } else {
      extraParams = new Map(Object.entries(request.extraQueryParameters));
    }
    const requestBuilder = new _azure_msal_common__WEBPACK_IMPORTED_MODULE_0__.RequestParameterBuilder();
    const claims = requestBuilder.addClientCapabilitiesToClaims(request.claims, this.clientCapabilities);
    const scopes = request.scopes || _azure_msal_common__WEBPACK_IMPORTED_MODULE_1__.OIDC_DEFAULT_SCOPES;
    const tokenRequest = {
      platformBrokerId: request.account?.homeAccountId,
      clientId: this.clientId,
      authority: request.authority,
      scope: scopes.join(" "),
      correlationId: request.correlationId !== undefined ? request.correlationId : this.crypto.createNewGuid(),
      claims: !_azure_msal_common__WEBPACK_IMPORTED_MODULE_2__.StringUtils.isEmptyObj(claims) ? claims : undefined,
      state: request.state,
      authenticationScheme: request.authenticationScheme || _azure_msal_common__WEBPACK_IMPORTED_MODULE_1__.AuthenticationScheme.BEARER,
      extraParameters: extraParams
    };
    return tokenRequest;
  }
  fromNaaTokenResponse(request, response, reqTimestamp) {
    if (!response.token.id_token || !response.token.access_token) {
      throw (0,_azure_msal_common__WEBPACK_IMPORTED_MODULE_3__.createClientAuthError)(_azure_msal_common__WEBPACK_IMPORTED_MODULE_4__.nullOrEmptyToken);
    }
    const expiresOn = new Date((reqTimestamp + (response.token.expires_in || 0)) * 1000);
    const idTokenClaims = _azure_msal_common__WEBPACK_IMPORTED_MODULE_5__.extractTokenClaims(response.token.id_token, this.crypto.base64Decode);
    const account = this.fromNaaAccountInfo(response.account, idTokenClaims);
    const scopes = response.token.scope || request.scope;
    const authenticationResult = {
      authority: response.token.authority || account.environment,
      uniqueId: account.localAccountId,
      tenantId: account.tenantId,
      scopes: scopes.split(" "),
      account,
      idToken: response.token.id_token,
      idTokenClaims,
      accessToken: response.token.access_token,
      fromCache: true,
      expiresOn: expiresOn,
      tokenType: request.authenticationScheme || _azure_msal_common__WEBPACK_IMPORTED_MODULE_1__.AuthenticationScheme.BEARER,
      correlationId: request.correlationId,
      extExpiresOn: expiresOn,
      state: request.state
    };
    return authenticationResult;
  }
  /*
   *  export type AccountInfo = {
   *     homeAccountId: string;
   *     environment: string;
   *     tenantId: string;
   *     username: string;
   *     localAccountId: string;
   *     name?: string;
   *     idToken?: string;
   *     idTokenClaims?: TokenClaims & {
   *         [key: string]:
   *             | string
   *             | number
   *             | string[]
   *             | object
   *             | undefined
   *             | unknown;
   *     };
   *     nativeAccountId?: string;
   *     authorityType?: string;
   * };
   */
  fromNaaAccountInfo(fromAccount, idTokenClaims) {
    const effectiveIdTokenClaims = idTokenClaims || fromAccount.idTokenClaims;
    const localAccountId = fromAccount.localAccountId || effectiveIdTokenClaims?.oid || effectiveIdTokenClaims?.sub || "";
    const tenantId = fromAccount.tenantId || effectiveIdTokenClaims?.tid || "";
    const homeAccountId = fromAccount.homeAccountId || `${localAccountId}.${tenantId}`;
    const username = fromAccount.username || effectiveIdTokenClaims?.preferred_username || "";
    const name = fromAccount.name || effectiveIdTokenClaims?.name;
    const account = {
      homeAccountId,
      environment: fromAccount.environment,
      tenantId,
      username,
      localAccountId,
      name,
      idToken: fromAccount.idToken,
      idTokenClaims: effectiveIdTokenClaims
    };
    return account;
  }
  /**
   *
   * @param error BridgeError
   * @returns AuthError, ClientAuthError, ClientConfigurationError, ServerError, InteractionRequiredError
   */
  fromBridgeError(error) {
    if ((0,_BridgeError_mjs__WEBPACK_IMPORTED_MODULE_6__.isBridgeError)(error)) {
      switch (error.status) {
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.UserCancel:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_3__.ClientAuthError(_azure_msal_common__WEBPACK_IMPORTED_MODULE_4__.userCanceled);
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.NoNetwork:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_3__.ClientAuthError(_azure_msal_common__WEBPACK_IMPORTED_MODULE_4__.noNetworkConnectivity);
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.AccountUnavailable:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_3__.ClientAuthError(_azure_msal_common__WEBPACK_IMPORTED_MODULE_4__.noAccountFound);
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.Disabled:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_3__.ClientAuthError(_azure_msal_common__WEBPACK_IMPORTED_MODULE_4__.nestedAppAuthBridgeDisabled);
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.NestedAppAuthUnavailable:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_3__.ClientAuthError(error.code || _azure_msal_common__WEBPACK_IMPORTED_MODULE_4__.nestedAppAuthBridgeDisabled, error.description);
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.TransientError:
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.PersistentError:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_8__.ServerError(error.code, error.description);
        case _BridgeStatusCode_mjs__WEBPACK_IMPORTED_MODULE_7__.BridgeStatusCode.UserInteractionRequired:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_9__.InteractionRequiredAuthError(error.code, error.description);
        default:
          return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_10__.AuthError(error.code, error.description);
      }
    } else {
      return new _azure_msal_common__WEBPACK_IMPORTED_MODULE_10__.AuthError("unknown_error", "An unknown error occurred");
    }
  }
}


/***/ })

}]);
//# sourceMappingURL=759.3bba9d01c6d1d84c.js.map