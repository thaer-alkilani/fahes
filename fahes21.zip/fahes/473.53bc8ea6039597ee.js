"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[473],{

/***/ 39553:
/*!**************************************************!*\
  !*** ./src/app/core/models/device-input-code.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInputCode": () => (/* binding */ DeviceInputCode)
/* harmony export */ });
class DeviceInputCode {
  constructor(codeOperation, codeValues) {
    this.codeOperation = codeOperation;
    this.codeValues = codeValues;
  }
}

/***/ }),

/***/ 17238:
/*!***************************************************!*\
  !*** ./src/app/core/models/device-results-dto.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInspectionProcessDto": () => (/* binding */ DeviceInspectionProcessDto),
/* harmony export */   "DeviceResultsDto": () => (/* binding */ DeviceResultsDto),
/* harmony export */   "DeviceSectionInspectionDto": () => (/* binding */ DeviceSectionInspectionDto)
/* harmony export */ });
class DeviceResultsDto {}
class DeviceInspectionProcessDto {}
class DeviceSectionInspectionDto {}

/***/ }),

/***/ 36591:
/*!***************************************************!*\
  !*** ./src/app/core/models/inspection-request.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionRequest": () => (/* binding */ InspectionRequest)
/* harmony export */ });
class InspectionRequest {
  constructor(details) {
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 46587:
/*!****************************************************************!*\
  !*** ./src/app/core/models/visual-defects/save-sub-defects.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SaveSubDefectComments": () => (/* binding */ SaveSubDefectComments)
/* harmony export */ });
class SaveSubDefectComments {
  constructor(details) {
    Object.assign(this, details);
  }
}

/***/ }),

/***/ 11428:
/*!*************************************************************!*\
  !*** ./src/app/core/services/inspection-service.service.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionServiceService": () => (/* binding */ InspectionServiceService)
/* harmony export */ });
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 85159);



class InspectionServiceService {
  constructor(fahesApiService) {
    this.fahesApiService = fahesApiService;
    this.baseUrl = `${src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.serviceUrl}`;
    this.apiUrl = 'Inspection/v1';
  }
  searchInpsectionRequestDetails(searchType, searchText, serviceType) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/SearchInpsectionRequestDetails`, {
      searchType,
      searchText,
      serviceType
    });
  }
  getInspectionDetailsByPlateNoAndPlateType(plateNo, plateType) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByPlateNoAndPlateType`, {
      plateNo,
      plateType
    });
  }
  getInspectionDetailsByVinNo(vinNo) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByVinNoDTO`, {
      vinNo
    });
  }
  getInspectionDetailsByRequestId(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionDetailsByRequestId`, {
      requestId
    });
  }
  getInspectionDetailsByReceiptNo(receiptNo) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDetailsByReceiptNo`, {
      receiptNo
    });
  }
  createInspectionRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionRequest`, body);
  }
  getInspectionInstructionsByRequestId(inspectionId, sectionId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/GetInspectionInstructionsByRequestId`, {
      inspectionId,
      sectionId
    });
  }
  getInspectionDefects(inspectionRequest) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionDefects`, {
      inspectionReqId: inspectionRequest
    });
  }
  deleteInspectionDefect(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/deleteInspectionDefect`, body);
  }
  getExternalInspectionRequests(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getExternalInspectionRequests`, body);
  }
  createInspectionStep(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/createInspectionStep`, body);
  }
  submitTankerCertificateRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitTankerCertificateRequest`, body);
  }
  getQatarVinNumbersDetails(categoryId, requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getQatarVinNumbersDetails`, {
      categoryId,
      requestId
    });
  }
  submitVinStampingRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitVinStampingRequest`, body);
  }
  submitInspectionRequest(requestId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/submitInspectionRequest`, {
      requestId
    });
  }
  getInspectedVehicleReportDetails(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectedVehicleReportDetails`, body);
  }
  getSubServices(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getSubServices`, body);
  }
  insertInspectionResultsReportLog(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/insertInspectionResultsReportLog`, body);
  }
  fillInspectionTankValues(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/fillInspectionTankValues`, body);
  }
  finishInspectionStep(inspectionStepId) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/finishInspectionStep`, {
      inspectionStepId
    });
  }
  getFinalInspectionDeviceResult(deviceInspectionProcessDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getFinalInspectionDeviceResult`, deviceInspectionProcessDto);
  }
  getDeviceInspectionReads(deviceSectionInspectionDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getDeviceInspectionReads`, deviceSectionInspectionDto);
  }
  getInspectionResultDetails(baseInspectionRequestDto) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionResultDetails`, baseInspectionRequestDto);
  }
  getVINSequences(body) {
    return this.fahesApiService.post(`${this.baseUrl}/MOI/v1/getVINSequences`, body);
  }
  calculateTankerCertificateVolume(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/calculateTankerCertificateVolume`, body);
  }
  startExternalInspectionRequest(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/startExternalInspectionRequest`, body);
  }
  getInspectionRegisterVehicle(body) {
    return this.fahesApiService.post(`${this.baseUrl}/${this.apiUrl}/getInspectionRegisterVehicle`, body);
  }
  static #_ = this.ɵfac = function InspectionServiceService_Factory(t) {
    return new (t || InspectionServiceService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
    token: InspectionServiceService,
    factory: InspectionServiceService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 84187:
/*!*******************************************************************!*\
  !*** ./src/app/core/utilities/enums/defect-comments-sort-type.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectCommentSortType": () => (/* binding */ DefectCommentSortType)
/* harmony export */ });
var DefectCommentSortType;
(function (DefectCommentSortType) {
  DefectCommentSortType["Ascending"] = "ASC";
  DefectCommentSortType["Descending"] = "DESC";
})(DefectCommentSortType || (DefectCommentSortType = {}));

/***/ }),

/***/ 81295:
/*!**********************************************************!*\
  !*** ./src/app/core/utilities/enums/defect-selection.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DefectSelectionMode": () => (/* binding */ DefectSelectionMode)
/* harmony export */ });
var DefectSelectionMode;
(function (DefectSelectionMode) {
  DefectSelectionMode[DefectSelectionMode["Main"] = 1] = "Main";
  DefectSelectionMode[DefectSelectionMode["Sub"] = 2] = "Sub";
  DefectSelectionMode[DefectSelectionMode["Comments"] = 3] = "Comments";
})(DefectSelectionMode || (DefectSelectionMode = {}));

/***/ }),

/***/ 74676:
/*!***********************************************************************!*\
  !*** ./src/app/core/utilities/enums/device-inspection-status.enum.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceInspectionStatus": () => (/* binding */ DeviceInspectionStatus)
/* harmony export */ });
var DeviceInspectionStatus;
(function (DeviceInspectionStatus) {
  DeviceInspectionStatus[DeviceInspectionStatus["InProgress"] = 1] = "InProgress";
  DeviceInspectionStatus[DeviceInspectionStatus["Complete"] = 2] = "Complete";
})(DeviceInspectionStatus || (DeviceInspectionStatus = {}));

/***/ }),

/***/ 33219:
/*!********************************************************************!*\
  !*** ./src/app/core/utilities/enums/external-inspection-status.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExternalInpsectionStatus": () => (/* binding */ ExternalInpsectionStatus)
/* harmony export */ });
var ExternalInpsectionStatus;
(function (ExternalInpsectionStatus) {
  ExternalInpsectionStatus[ExternalInpsectionStatus["InProgress"] = 1] = "InProgress";
  ExternalInpsectionStatus[ExternalInpsectionStatus["Hold"] = 2] = "Hold";
})(ExternalInpsectionStatus || (ExternalInpsectionStatus = {}));

/***/ }),

/***/ 40681:
/*!***************************************************************************!*\
  !*** ./src/app/core/utilities/enums/inspection-save-action-types.enum.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionSaveActionTypes": () => (/* binding */ InspectionSaveActionTypes)
/* harmony export */ });
var InspectionSaveActionTypes;
(function (InspectionSaveActionTypes) {
  InspectionSaveActionTypes[InspectionSaveActionTypes["Save"] = 1] = "Save";
  InspectionSaveActionTypes[InspectionSaveActionTypes["SaveAndUpdate"] = 2] = "SaveAndUpdate";
})(InspectionSaveActionTypes || (InspectionSaveActionTypes = {}));

/***/ }),

/***/ 54733:
/*!******************************************************!*\
  !*** ./src/app/core/utilities/enums/main-defects.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainDefectEnum": () => (/* binding */ MainDefectEnum)
/* harmony export */ });
var MainDefectEnum;
(function (MainDefectEnum) {
  MainDefectEnum[MainDefectEnum["BrakeSystem"] = 2100] = "BrakeSystem";
  MainDefectEnum[MainDefectEnum["SteeringSystem"] = 2200] = "SteeringSystem";
  MainDefectEnum[MainDefectEnum["Visibility"] = 2300] = "Visibility";
  MainDefectEnum[MainDefectEnum["LightingSystem"] = 2400] = "LightingSystem";
  MainDefectEnum[MainDefectEnum["AxlesSuspensionWheelsTires"] = 2500] = "AxlesSuspensionWheelsTires";
  MainDefectEnum[MainDefectEnum["ChassisAndBody"] = 2600] = "ChassisAndBody";
  MainDefectEnum[MainDefectEnum["EngineAndGearbox"] = 2700] = "EngineAndGearbox";
  MainDefectEnum[MainDefectEnum["OtherEquipments"] = 2800] = "OtherEquipments";
  MainDefectEnum[MainDefectEnum["Environment"] = 2900] = "Environment";
  MainDefectEnum[MainDefectEnum["PublicTransport"] = 3000] = "PublicTransport";
  MainDefectEnum[MainDefectEnum["LegalRequirements"] = 3100] = "LegalRequirements";
  MainDefectEnum[MainDefectEnum["WaterTanker"] = 4100] = "WaterTanker";
})(MainDefectEnum || (MainDefectEnum = {}));

/***/ }),

/***/ 53805:
/*!*******************************************************************!*\
  !*** ./src/app/core/utilities/enums/system-lookup-value-codes.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemLookupValueCodes": () => (/* binding */ SystemLookupValueCodes)
/* harmony export */ });
var SystemLookupValueCodes;
(function (SystemLookupValueCodes) {
  //Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["Inspection"] = 1] = "Inspection";
  SystemLookupValueCodes[SystemLookupValueCodes["VINStamping"] = 2] = "VINStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["TankerCertificate"] = 3] = "TankerCertificate";
  SystemLookupValueCodes[SystemLookupValueCodes["Exempted"] = 4] = "Exempted";
  SystemLookupValueCodes[SystemLookupValueCodes["MobileInspection"] = 4] = "MobileInspection";
  //Registration Resource :
  SystemLookupValueCodes[SystemLookupValueCodes["MoblieApplication"] = 1] = "MoblieApplication";
  SystemLookupValueCodes[SystemLookupValueCodes["Booth"] = 2] = "Booth";
  SystemLookupValueCodes[SystemLookupValueCodes["BackOffice"] = 3] = "BackOffice";
  SystemLookupValueCodes[SystemLookupValueCodes["SupportDocuments"] = 1] = "SupportDocuments";
  SystemLookupValueCodes[SystemLookupValueCodes["InspectionImages"] = 2] = "InspectionImages";
  // Vin Service Types :
  SystemLookupValueCodes[SystemLookupValueCodes["NewStamping"] = 1] = "NewStamping";
  SystemLookupValueCodes[SystemLookupValueCodes["ReStamping"] = 2] = "ReStamping";
})(SystemLookupValueCodes || (SystemLookupValueCodes = {}));

/***/ }),

/***/ 12452:
/*!********************************************************!*\
  !*** ./src/app/core/utilities/object-value-checker.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ObjectValueChecker": () => (/* binding */ ObjectValueChecker)
/* harmony export */ });
class ObjectValueChecker {
  static isNullOrEmpty(value) {
    if (value != null && value != '') return true;else return false;
  }
}

/***/ }),

/***/ 82412:
/*!******************************************************************************************!*\
  !*** ./src/app/modules/inspection/components/delete-confirm/delete-confirm.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeleteConfirmComponent": () => (/* binding */ DeleteConfirmComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class DeleteConfirmComponent {
  ngOnInit() {}
  confirmDelete() {}
  static #_ = this.ɵfac = function DeleteConfirmComponent_Factory(t) {
    return new (t || DeleteConfirmComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: DeleteConfirmComponent,
    selectors: [["app-delete-confirm"]],
    decls: 16,
    vars: 0,
    consts: [[1, "modal-content"], [1, "modal-header"], [1, "modal-body"], [1, "row"], [1, "col-12"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"]],
    template: function DeleteConfirmComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2)(3, "div", 3)(4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](5, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, " Are you sure you want to delete the defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](10, "br")(11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](13, "img", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DeleteConfirmComponent_Template_button_click_14_listener() {
          return ctx.confirmDelete();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
      }
    },
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 16564:
/*!**************************************************************************************!*\
  !*** ./src/app/modules/inspection/components/landing-page/landing-page.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingPageComponent": () => (/* binding */ LandingPageComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);











const _c0 = ["barCodeId"];
const _c1 = ["barCodeId2"];
function LandingPageComponent_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_54_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 34)(1, "label", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Istimara Bar Code * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "input", 36, 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("keyup.enter", function LandingPageComponent_div_54_Template_input_keyup_enter_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r11.onIstimaraInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, LandingPageComponent_div_54_div_5_Template, 2, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r3.landingForm.get("istimaraCode").hasError("pattern"));
  }
}
function LandingPageComponent_div_55_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 24)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Vin No * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "input", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_56_option_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Inspection Service ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_56_option_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " VIN Stamping ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_56_option_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Tanker Certificate ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 24)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Service Type * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "select", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, LandingPageComponent_div_56_option_4_Template, 2, 0, "option", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, LandingPageComponent_div_56_option_5_Template, 2, 0, "option", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, LandingPageComponent_div_56_option_6_Template, 2, 0, "option", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.activeIns);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.activeVin);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r5.activeTank);
  }
}
function LandingPageComponent_div_57_div_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_57_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 24)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Receipt Number * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "input", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, LandingPageComponent_div_57_div_4_Template, 2, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r6.landingForm.get("inputReqNo").invalid && ctx_r6.landingForm.get("inputReqNo").touched);
  }
}
function LandingPageComponent_div_59_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 47)(1, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_div_59_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r18);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r17.manualEntry());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, " Inspect ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", ctx_r7.activeButton == 1 && (!ctx_r7.landingForm.get("istimaraCode").value || !ctx_r7.landingForm.get("selectServiceType").value) || ctx_r7.activeButton == 2 && (!ctx_r7.landingForm.get("inputVinNo").value || !ctx_r7.landingForm.get("selectServiceType").value) || ctx_r7.activeButton == 3 && !ctx_r7.landingForm.get("inputReqNo").value);
  }
}
function LandingPageComponent_div_60_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Enter all fields ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
const _c2 = function (a0) {
  return {
    "active": a0
  };
};
class LandingPageComponent {
  constructor(formBuilder, router, sharedDataService, lookupServ, sideNav, sharedLookup, el, renderer, vehicleService, insService) {
    this.formBuilder = formBuilder;
    this.router = router;
    this.sharedDataService = sharedDataService;
    this.lookupServ = lookupServ;
    this.sideNav = sideNav;
    this.sharedLookup = sharedLookup;
    this.el = el;
    this.renderer = renderer;
    this.vehicleService = vehicleService;
    this.insService = insService;
    this.submitted = false;
    this.fillFields = false;
    this.isBarCodeScanned = false;
    this.isModalOpen = false;
    this.registeredVehicles = [];
    this.offers = [];
    this.landingForm = formBuilder.group({
      // inputPlateType: [null, Validators.required],
      // inputPlateNo: [null, Validators.required],
      inputVinNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      inputReqNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      selectServiceType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required],
      plateTypes: [[]],
      isPlate: [false],
      isVin: [false],
      isReq: [false],
      // displayBarCode: ['', [Validators.required, Validators.pattern(/^.{3,8}$/)]],
      displayBarCode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required]],
      istimaraCode: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.pattern(/^.{3,8}$/)]]
    });
  }
  ngOnInit() {
    this.sideNav.setHeaderValue(true, false);
    this.sideNav.setActiveEnt(3, 36);
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.landingForm.get('plateTypes').setValue(data);
    });
    //   const carImagePopModal = this.el.nativeElement.querySelector('#receiptNo');
    //  this.renderer.addClass(carImagePopModal, 'show');
    // this.renderer.setStyle(carImagePopModal, 'display', 'block');
    this.insService.getInspectionRegisterVehicle({
      stationId: this.stationId,
      pageSize: 1000,
      pageNumber: 1
    }).subscribe(response => {
      response.items.map(item => {
        const plateType = ('0' + item.plateType).slice(-2);
        const plateNo = ('000000' + item.plateNo).slice(-6);
        this.registeredVehicles.push(plateType + plateNo);
      });
    });
    this.landingForm.get('istimaraCode').valueChanges.subscribe(value => {
      let serviceCalled = false;
      if (this.landingForm.get('istimaraCode').value.length > 3) {
        for (let rg of this.registeredVehicles) {
          if (rg == this.landingForm.get('istimaraCode').value && !serviceCalled) {
            this.checkServices();
            serviceCalled = true;
          }
        }
      }
    });
    const receiptModal = this.el.nativeElement.querySelector('#receiptNo');
    this.renderer.addClass(receiptModal, 'show');
    this.renderer.setStyle(receiptModal, 'display', 'block');
    this.scanIstimara();
  }
  closeReceipt() {
    console.log("close");
    const receiptModal = this.el.nativeElement.querySelector('#receiptNo');
    this.renderer.removeClass(receiptModal, 'show');
    this.renderer.setStyle(receiptModal, 'display', 'none');
  }
  scanIstimara() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCodeId');
      if (myInput) {
        myInput.focus();
      }
    }, 300);
  }
  get formControls() {
    return this.landingForm.controls;
  }
  onBarcodeInput(event) {
    console.log("test");
    const barcodeValue = event.target.value;
    this.landingForm.get('displayBarCode').setValue(barcodeValue);
    this.isBarCodeScanned = true;
    this.readBarCode();
  }
  onIstimaraInput(event) {
    this.manualEntry();
  }
  checkServices() {
    console.log(this.landingForm.get('istimaraCode').value);
    const plateType = parseInt(this.landingForm.get('istimaraCode').value.substring(0, 2));
    const plateNo = parseInt(this.landingForm.get('istimaraCode').value.substring(2));
    const vehDetails = {
      plateNo: plateNo,
      plateType: plateType,
      stationId: this.stationId
    };
    this.vehicleService.getVehicleDetails(vehDetails).subscribe(response => {
      const servDets = {
        categoryId: response.items.categoryId,
        plateNo: plateNo,
        plateType: plateType,
        stationId: this.stationId
      };
      this.vehicleService.getVehicleServices(servDets).subscribe(response => {
        for (const ins of response.items.inspectionServices) {
          if (ins.isActive && ins.isPaid) {
            this.activeIns = true;
            this.landingForm.get('selectServiceType').setValue(1);
          }
        }
        for (const vins of response.items.vinStampingServices) {
          if (vins.isActive && vins.isPaid) {
            this.activeVin = true;
            if (!this.activeIns) {
              this.landingForm.get('selectServiceType').setValue(2);
            }
          }
        }
        for (const tanks of response.items.tankerCertServices) {
          if (tanks.isActive && tanks.isPaid) {
            this.activeTank = true;
            if (!this.activeIns && !this.activeVin) {
              this.landingForm.get('selectServiceType').setValue(3);
            }
          }
        }
      });
    });
  }
  readBarCode() {
    const displayBarCodeControl = this.landingForm.get('displayBarCode');
    if (displayBarCodeControl.valid) {
      //this.sharedDataService.setBarCodeIns(this.landingForm.get('displayBarCode').value);
      this.sharedDataService.setRecNo(this.landingForm.get('displayBarCode').value);
      this.router.navigate(['inspection/vehicle-inspection']);
      const modalElement = document.getElementById('receiptNo');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
  }
  showPlate() {
    this.landingForm.get("isPlate").setValue(true);
    this.landingForm.get("isVin").setValue(false);
    this.landingForm.get("isReq").setValue(false);
    this.activeIns = false;
    this.activeVin = false;
    this.activeTank = false;
    this.landingForm.get('selectServiceType').setValue(null);
    //this.checkServices();
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCodeId2');
      if (myInput) {
        myInput.focus();
      }
    }, 300);
    this.activeButton = 1;
  }
  showVin() {
    this.landingForm.get("isVin").setValue(true);
    this.landingForm.get("isPlate").setValue(false);
    this.landingForm.get("isReq").setValue(false);
    this.activeIns = true;
    this.activeVin = true;
    this.activeTank = true;
    this.landingForm.get('selectServiceType').setValue(1);
    this.activeButton = 2;
  }
  showRequestNo() {
    this.landingForm.get("isReq").setValue(true);
    this.landingForm.get("isVin").setValue(false);
    this.landingForm.get("isPlate").setValue(false);
    this.activeButton = 3;
  }
  manualEntry() {
    if (this.landingForm.get("isPlate").value) {
      if (this.landingForm.get('istimaraCode').value) {
        this.sharedDataService.setBarCodeIns(this.landingForm.get('istimaraCode').value);
        this.sharedDataService.setServiceType(parseInt(this.landingForm.get('selectServiceType').value));
        this.fillFields = false;
        this.sharedDataService.setVinNo('');
        this.router.navigate(['inspection/vehicle-inspection']);
      }
      // if (this.landingForm.get('inputPlateNo').value) {
      //   this.sharedDataService.setPlateNo(this.landingForm.get('inputPlateNo').value);
      //   this.sharedDataService.setPlateType(this.landingForm.get('inputPlateType').value);
      //   console.log(this.landingForm.get('selectServiceType').value);
      //   this.sharedDataService.setServiceType(this.landingForm.get('selectServiceType').value);
      //   this.fillFields = false;
      //   this.sharedDataService.setVinNo('');
      //   this.router.navigate(['inspection/vehicle-inspection']);
      // }
      // else {
      //   this.fillFields = true;
      // }
    }

    if (this.landingForm.get("isVin").value) {
      if (this.landingForm.get('inputVinNo').value) {
        this.sharedDataService.setVinNo(this.landingForm.get('inputVinNo').value);
        this.sharedDataService.setServiceType(parseInt(this.landingForm.get('selectServiceType').value));
        this.fillFields = false;
        this.router.navigate(['inspection/vehicle-inspection']);
      } else {
        this.fillFields = true;
      }
    }
    if (this.landingForm.get("isReq").value) {
      if (this.landingForm.get("inputReqNo").value) {
        this.sharedDataService.setRecNo(this.landingForm.get('inputReqNo').value);
        this.fillFields = false;
        this.router.navigate(['inspection/vehicle-inspection']);
      } else {
        this.fillFields = true;
      }
    }
  }
  static #_ = this.ɵfac = function LandingPageComponent_Factory(t) {
    return new (t || LandingPageComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_1__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_2__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_3__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_4__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_5__.InspectionServiceService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: LandingPageComponent,
    selectors: [["app-landing-page"]],
    viewQuery: function LandingPageComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c1, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.barCodeId = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.barCodeId2 = _t.first);
      }
    },
    decls: 61,
    vars: 18,
    consts: [[3, "formGroup"], [1, "main-container-wrap"], [1, "rvd"], [1, "rvd-links"], ["data-bs-toggle", "modal", "data-bs-target", "#receiptNo", 3, "click"], ["src", "./assets/img/scan.svg"], ["src", "./assets/img/camera.svg"], ["data-bs-toggle", "modal", "data-bs-target", "#manualEntry", 1, "btn", "btn-link"], ["src", "./assets/img/keyboard.svg"], ["id", "receiptNo", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["src", "./assets/img/scan.svg", "width", "50px"], ["type", "button", 1, "btn-close", 3, "click"], [1, "modal-body"], ["id", "barCodeId", "type", "text", "formControlName", "displayBarCode", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCodeId", ""], ["class", "error-message", 4, "ngIf"], ["class", "info-msg", 4, "ngIf"], ["id", "manualEntry", "tabindex", "-1", "aria-labelledby", "manualEntryLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["src", "./assets/img/keyboard.svg", "width", "40px"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "button", 1, "btn", "btn-orange", "spacious-btn", 3, "ngClass", "click"], ["id", "vinId", 1, "col-md-6", "col-lg-3"], ["class", "col-12 col-lg-3", 4, "ngIf"], ["class", "col-md-6 col-lg-3", 4, "ngIf"], [1, "col-lg-12", "sr-vc"], ["class", "check-inspection", 4, "ngIf"], ["class", "row form-fields", "class", "error-message", 4, "ngIf"], [1, "error-message"], [1, "info-msg"], [1, "col-12", "col-lg-3"], ["for", "myInput"], ["type", "text", "id", "barCode2", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "istimaraCode", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCode2", ""], ["type", "text", "formControlName", "inputVinNo", 1, "form-control"], ["formControlName", "selectServiceType", 1, "form-control"], ["value", "1", 4, "ngIf"], ["value", "2", 4, "ngIf"], ["value", "3", 4, "ngIf"], ["value", "1"], ["value", "2"], ["value", "3"], ["type", "text", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "inputReqNo", 1, "form-control"], [1, "check-inspection"], ["type", "submit", "data-bs-dismiss", "modal", 1, "btn", "btn-orange", 3, "disabled", "click"]],
    template: function LandingPageComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "form", 0)(1, "div", 1)(2, "div", 2)(3, "h3");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4, " Read Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, " Choose the preferred option ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "div", 3)(8, "a", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_a_click_8_listener() {
          return ctx.scanIstimara();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](9, "img", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](11, "Scan Receipt");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](12, "a");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](13, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](14, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, "Capture Plate No");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](17, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](19, "Manual Entry");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](20, "div", 9)(21, "div", 10)(22, "div", 11)(23, "div", 12)(24, "h1", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](25, "img", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](26, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_27_listener() {
          return ctx.closeReceipt();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](28, "div", 16)(29, "input", 17, 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("keyup.enter", function LandingPageComponent_Template_input_keyup_enter_29_listener($event) {
          return ctx.onBarcodeInput($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](31, LandingPageComponent_div_31_Template, 2, 0, "div", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](32, LandingPageComponent_div_32_Template, 2, 0, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "div", 21)(34, "div", 10)(35, "div", 11)(36, "div", 12)(37, "h1", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](38, "img", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](39, " Manual Entry ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "div", 16)(41, "div", 23)(42, "div", 24)(43, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_43_listener() {
          return ctx.showPlate();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](44, " Plate No - Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](45, "div", 26)(46, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_46_listener() {
          return ctx.showVin();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](47, " VIN No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "div", 24)(49, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function LandingPageComponent_Template_button_click_49_listener() {
          return ctx.showRequestNo();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](50, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](51, "br")(52, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](53, "div", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](54, LandingPageComponent_div_54_Template, 6, 1, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](55, LandingPageComponent_div_55_Template, 4, 0, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](56, LandingPageComponent_div_56_Template, 7, 3, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](57, LandingPageComponent_div_57_Template, 5, 1, "div", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](58, "div", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](59, LandingPageComponent_div_59_Template, 3, 1, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](60, LandingPageComponent_div_60_Template, 2, 0, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.landingForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("displayBarCode").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.valid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](12, _c2, ctx.activeButton === 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](14, _c2, ctx.activeButton === 2));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](16, _c2, ctx.activeButton === 3));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isPlate").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isVin").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isVin").value || ctx.landingForm.get("isPlate").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isReq").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.landingForm.get("isVin").value || ctx.landingForm.get("isPlate").value || ctx.landingForm.get("isReq").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.fillFields);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: ["input[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n  appearance: none;\r\n  margin: 0;\r\n}\r\n\r\n.spacious-btn[_ngcontent-%COMP%] {\r\n  padding: 15px;\r\n  font-size: 16px;\r\n  white-space: nowrap;\r\n}\r\n\r\n#vinId[_ngcontent-%COMP%] {\r\n  margin-left: 17px;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n  color: red;\r\n  font-style: italic;\r\n}\r\n\r\n.info-msg[_ngcontent-%COMP%] {\r\n  color: grey;\r\n  font-style: italic !important;\r\n}\r\n\r\n.btn-orange.active[_ngcontent-%COMP%] {\r\n  color: #fff;\r\n  background: #00539B;\r\n  border-color: #00539B;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n  background-color: #ef9c3d;\r\n  color: #ffff;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL2NvbXBvbmVudHMvbGFuZGluZy1wYWdlL2xhbmRpbmctcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztFQUdFLGdCQUFnQjtFQUNoQixTQUFTO0FBQ1g7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGlCQUFpQjtBQUNuQjs7QUFFQTtFQUNFLFVBQVU7RUFDVixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsNkJBQTZCO0FBQy9COztBQUVBO0VBQ0UsV0FBVztFQUNYLG1CQUFtQjtFQUNuQixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsWUFBWTtBQUNkIiwic291cmNlc0NvbnRlbnQiOlsiaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XHJcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xyXG4gIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4uc3BhY2lvdXMtYnRuIHtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG59XHJcblxyXG4jdmluSWQge1xyXG4gIG1hcmdpbi1sZWZ0OiAxN3B4O1xyXG59XHJcblxyXG4uZXJyb3ItbWVzc2FnZSB7XHJcbiAgY29sb3I6IHJlZDtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbn1cclxuXHJcbi5pbmZvLW1zZyB7XHJcbiAgY29sb3I6IGdyZXk7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlLmFjdGl2ZSB7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgYmFja2dyb3VuZDogIzAwNTM5QjtcclxuICBib3JkZXItY29sb3I6ICMwMDUzOUI7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gIGNvbG9yOiAjZmZmZjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 59560:
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/inspection/components/vehicle-inspection/vehicle-inspection.component.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VehicleInspectionComponent": () => (/* binding */ VehicleInspectionComponent)
/* harmony export */ });
/* harmony import */ var C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _microsoft_signalr__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @microsoft/signalr */ 77930);
/* harmony import */ var _microsoft_signalr__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @microsoft/signalr */ 14449);
/* harmony import */ var src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/device-input-code */ 39553);
/* harmony import */ var src_app_core_models_device_results_dto__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/models/device-results-dto */ 17238);
/* harmony import */ var src_app_core_models_inspection_request__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/inspection-request */ 36591);
/* harmony import */ var src_app_core_utilities_enums_device_inspection_status_enum__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utilities/enums/device-inspection-status.enum */ 74676);
/* harmony import */ var src_app_core_utilities_enums_inspection_save_action_types_enum__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/inspection-save-action-types.enum */ 40681);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/object-value-checker */ 12452);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_authentication_service_ts_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/authentication-service.ts.service */ 21022);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! primeng/progressbar */ 88395);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! primeng/tooltip */ 24329);
/* harmony import */ var _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../../pages/visualDefect/visual-defect-list/visual-defect-list.component */ 12207);
































function VehicleInspectionComponent_li_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "li", 4)(1, "button", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_li_10_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r41);
      const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r40.setActiveTab("vin"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, "VIN Stamping");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleProp"]("pointer-events", !ctx_r0.insForm.get("isVinCh").value || !ctx_r0.insForm.get("isPlateCh").value || !ctx_r0.insForm.get("isManfCh").value ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx_r0.activeTab === "vin");
  }
}
function VehicleInspectionComponent_li_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r43 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "li", 4)(1, "button", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_li_11_Template_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r43);
      const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r42.setActiveTab("tanker"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2, "Tanker Certificate ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleProp"]("pointer-events", ctx_r1.isConfirmedDefects || !ctx_r1.insForm.get("isVinCh").value || !ctx_r1.insForm.get("isPlateCh").value || !ctx_r1.insForm.get("isManfCh").value ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx_r1.activeTab === "tanker");
  }
}
function VehicleInspectionComponent_span_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " External ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 133)(1, "div", 134);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate3"](" ", ctx_r3.format(ctx_r3.mm), ":", ctx_r3.format(ctx_r3.ss), ":", ctx_r3.format(ctx_r3.ms), "");
  }
}
const _c0 = function () {
  return {
    position: "sticky",
    height: "8px",
    width: "100%",
    top: "0",
    right: "0"
  };
};
function VehicleInspectionComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 135)(1, "h5");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](3, "p-progressBar", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](ctx_r4.deviceStatusDescription);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](3, _c0));
  }
}
function VehicleInspectionComponent_div_143_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 17)(1, "div", 18)(2, "div", 69)(3, "div", 25)(4, "div", 137)(5, "div", 27)(6, "h2", 138)(7, "button", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](8, " Contact Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](9, "div", 140)(10, "div", 31)(11, "div", 141)(12, "div", 47)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](14, "Phone No");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](15, "input", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](16, "div", 47)(17, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](18, "PID");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](19, "input", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](20, "div", 47)(21, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](22, "Email");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](23, "input", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()();
  }
}
function VehicleInspectionComponent_button_148_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 145);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_148_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r45);
      const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r44.nextVI());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Next ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx_r6.insForm.get("isVinCh").value || !ctx_r6.insForm.get("isPlateCh").value || !ctx_r6.insForm.get("isManfCh").value);
  }
}
function VehicleInspectionComponent_div_154_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 17)(1, "div", 146)(2, "label", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, " Qatar VIN No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](4, "input", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
}
function VehicleInspectionComponent_div_155_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 17)(1, "div", 146)(2, "label", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, " Fahes Serial No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](4, "input", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
}
function VehicleInspectionComponent_div_156_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 17)(1, "div", 149)(2, "label", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, " Original VIN No ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4, "x ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](5, "input", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
}
function VehicleInspectionComponent_option_180_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "option", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r46 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("value", item_r46.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", item_r46.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_div_181_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_186_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_191_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_196_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_202_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_219_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_220_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Note : Tanker Measurement Differs From Last Year ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_h3_232_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "i", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const instruction_r47 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", instruction_r47.instructionNameEn, " ");
  }
}
function VehicleInspectionComponent_div_250_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 155)(1, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](2, "input", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "label", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ft_r48 = ctx.$implicit;
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", "f" + ft_r48.lkCodeValue)("value", ft_r48.lkCodeValue)("checked", ctx_r19.configDisabled && ctx_r19.insForm.get("selectedFuelType").value == ft_r48.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵattribute"]("disabled", ctx_r19.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("for", "f" + ft_r48.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ft_r48.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_div_256_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 155)(1, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](2, "input", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "label", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const dm_r50 = ctx.$implicit;
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", "d" + dm_r50.lkCodeValue)("value", dm_r50.lkCodeValue)("checked", ctx_r20.configDisabled && ctx_r20.insForm.get("selectedDriveMode").value == dm_r50.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵattribute"]("disabled", ctx_r20.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("for", "d" + dm_r50.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", dm_r50.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_div_262_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 160)(1, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](2, "input", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "label", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const pb_r51 = ctx.$implicit;
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("id", "p" + pb_r51.lkCodeValue)("value", pb_r51.lkCodeValue)("checked", ctx_r21.configDisabled && ctx_r21.insForm.get("selectedParkingBrake").value == pb_r51.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵattribute"]("disabled", ctx_r21.configDisabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("for", "p" + pb_r51.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", pb_r51.lkValueEname, " ");
  }
}
function VehicleInspectionComponent_span_273_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_275_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 17)(1, "div", 65)(2, "button", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_div_275_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r53);
      const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r52.cancelConfig());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](4, "button", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_div_275_Template_button_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r53);
      const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r54.saveConfiguration());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](5, "Confirm");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx_r23.insForm.valid || ctx_r23.savedConfig);
  }
}
const _c1 = function (a0) {
  return {
    "color": a0
  };
};
function VehicleInspectionComponent_b_285_Template(rf, ctx) {
  if (rf & 1) {
    const _r56 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "b", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_b_285_Template_b_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r56);
      const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r55.showBrakeReads());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Brake ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](1, _c1, ctx_r24.deviceResultsDto.isBrakePassed ? "green" : "red"));
  }
}
function VehicleInspectionComponent_b_287_Template(rf, ctx) {
  if (rf & 1) {
    const _r58 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "b", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_b_287_Template_b_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r58);
      const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r57.showExhaustReads());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Exhaust Emiss ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngStyle", _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction1"](1, _c1, ctx_r25.deviceResultsDto.isExhaustEmissPassed ? "green" : "red"));
  }
}
function VehicleInspectionComponent_th_295_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "th", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, "Defect Location");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_tr_305_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](d_r59.defectMainCategory);
  }
}
function VehicleInspectionComponent_tr_305_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](d_r59.defect);
  }
}
function VehicleInspectionComponent_tr_305_td_5_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2).$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](d_r59.defectLocation);
  }
}
function VehicleInspectionComponent_tr_305_td_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, VehicleInspectionComponent_tr_305_td_5_span_1_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r63.editDefect);
  }
}
function VehicleInspectionComponent_tr_305_span_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](d_r59.remarks);
  }
}
function VehicleInspectionComponent_tr_305_span_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](d_r59.evalution);
  }
}
function VehicleInspectionComponent_tr_305_span_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const d_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate"](d_r59.defectClassification);
  }
}
function VehicleInspectionComponent_tr_305_Template(rf, ctx) {
  if (rf & 1) {
    const _r75 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "tr")(1, "td", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](2, VehicleInspectionComponent_tr_305_span_2_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](4, VehicleInspectionComponent_tr_305_span_4_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](5, VehicleInspectionComponent_tr_305_td_5_Template, 2, 1, "td", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](7, VehicleInspectionComponent_tr_305_span_7_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](8, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](9, VehicleInspectionComponent_tr_305_span_9_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](10, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](11, VehicleInspectionComponent_tr_305_span_11_Template, 2, 1, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "td")(13, "a", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_tr_305_Template_a_click_13_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r75);
      const i_r60 = restoredCtx.index;
      const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r74.checkDeleteDef(i_r60));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](14, "i", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const d_r59 = ctx.$implicit;
    const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r27.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r27.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r27.isLocationEmpty);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r27.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r27.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx_r27.editDefect);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("hidden", d_r59.defectSource == 2);
  }
}
function VehicleInspectionComponent_div_306_span_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Technical Evaluation: Passed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_306_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span", 170);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Legal Evaluation: Passed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_306_span_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Technical Evaluation: Failed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_306_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span", 171);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Legal Evaluation: Failed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_306_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](1, VehicleInspectionComponent_div_306_span_1_Template, 2, 0, "span", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](2, VehicleInspectionComponent_div_306_span_2_Template, 2, 0, "span", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](3, VehicleInspectionComponent_div_306_span_3_Template, 2, 0, "span", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](4, VehicleInspectionComponent_div_306_span_4_Template, 2, 0, "span", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r28.classificationsResult.isTechnichalPassed || ctx_r28.classificationsResult.isTechnichalPassed == null);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r28.classificationsResult.isLegalPassed || ctx_r28.classificationsResult.isLegalPassed == null);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r28.classificationsResult.isTechnichalPassed != null && !ctx_r28.classificationsResult.isTechnichalPassed);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx_r28.classificationsResult.isLegalPassed != null && !ctx_r28.classificationsResult.isLegalPassed);
  }
}
function VehicleInspectionComponent_span_315_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " & Update");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_button_316_Template(rf, ctx) {
  if (rf & 1) {
    const _r81 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_316_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r81);
      const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      ctx_r80.isDefectConfirm = true;
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r80.actionType = 1);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, "Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_327_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Are you sure you want to cancel ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_328_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " Is the car inspection defects ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, " list accurate and complete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_329_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1, " You have unsaved changes ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](2, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](3, " are you sure you want to cancel? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_div_330_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" Are you sure you want to delete this ", ctx_r34.confirmEval, " defect ? ");
  }
}
function VehicleInspectionComponent_button_335_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_335_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r83);
      const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r82.confirmAction());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "img", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_button_336_Template(rf, ctx) {
  if (rf & 1) {
    const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_336_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r85);
      const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r84.deleteDefectItemList(ctx_r84.defectDelIndex));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "img", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_button_337_Template(rf, ctx) {
  if (rf & 1) {
    const _r87 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "button", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_button_337_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵrestoreView"](_r87);
      const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵresetView"](ctx_r86.cancelDefectList());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "img", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
  }
}
function VehicleInspectionComponent_tr_377_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reads_r88 = ctx.$implicit;
    let tmp_0_0;
    let tmp_1_0;
    let tmp_2_0;
    let tmp_3_0;
    let tmp_4_0;
    let tmp_6_0;
    let tmp_7_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_0_0 = reads_r88.descriptionEn) !== null && tmp_0_0 !== undefined ? tmp_0_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_1_0 = reads_r88.leftValue) !== null && tmp_1_0 !== undefined ? tmp_1_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_2_0 = reads_r88.rightValue) !== null && tmp_2_0 !== undefined ? tmp_2_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_3_0 = reads_r88.weight) !== null && tmp_3_0 !== undefined ? tmp_3_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_4_0 = reads_r88.maxDifference) !== null && tmp_4_0 !== undefined ? tmp_4_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", reads_r88.actualDifferences, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_6_0 = reads_r88.minDeceleration) !== null && tmp_6_0 !== undefined ? tmp_6_0 : "", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", (tmp_7_0 = reads_r88.actualDeceleration) !== null && tmp_7_0 !== undefined ? tmp_7_0 : "", " ");
  }
}
function VehicleInspectionComponent_tr_393_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const reads_r89 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", reads_r89.descriptionEn, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", reads_r89.deviceOutputCode, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", reads_r89.readingValue, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", reads_r89.operation, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", reads_r89.limitValue, " ");
  }
}
const _c2 = function () {
  return {
    width: "50vw"
  };
};
class VehicleInspectionComponent {
  constructor(sharedService, inspectionService, fb, location, lookupServ, vehicleService, router, elementRef, sharedLookup, sideNav, visualDefectService, globalServ, authService, zone, thousandServ) {
    this.sharedService = sharedService;
    this.inspectionService = inspectionService;
    this.fb = fb;
    this.location = location;
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.router = router;
    this.elementRef = elementRef;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.visualDefectService = visualDefectService;
    this.globalServ = globalServ;
    this.authService = authService;
    this.zone = zone;
    this.thousandServ = thousandServ;
    this.changeCategory = new _angular_core__WEBPACK_IMPORTED_MODULE_21__.EventEmitter();
    this.brakeReads = [];
    this.exhaustEmissReads = [];
    this.inpectionDeviceStatus = 0;
    this.isDeviceStatusShown = false;
    this.deviceStatusDescription = '';
    this.isTimerVisiable = false;
    this.isConfigActive = false;
    this.defectList = null;
    this.editDefect = false;
    this.visualDefectActive = false;
    this.savedConfig = false;
    this.isExternal = false;
    this.isVinService = false;
    this.isReStamp = false;
    this.isNewStamp = false;
    this.isTankerService = false;
    this.isTank = false;
    this.saveSubDefectComments = [];
    this.formDataArray = [];
    this.techEv = false;
    this.legalEv = true;
    this.enableVinSubmit = true;
    // timer :
    this.mm = 0;
    this.ss = 0;
    this.ms = 0;
    this.isRunning = false;
    this.timerId = 0;
    this.insForm = fb.group({
      inspectiondetails: fb.group({
        inspectionReqId: [''],
        requestId: [''],
        inspectionServiceType: [],
        fahesReceiptNo: [''],
        isSectionSeqRequired: [],
        inspectionServiceId: [],
        plateNo: [''],
        plateType: [''],
        vinNo: [''],
        contactType: [''],
        serviceId: [''],
        serviceName: [''],
        serviceType: [''],
        colorId: [''],
        subColorId: [''],
        categoryId: [''],
        vehicleModelId: [''],
        modelEname: [''],
        manufacturerId: [''],
        manufacturersEname: [''],
        manufacturerYear: [''],
        cylinders: [''],
        weight: [''],
        payloadWeight: [''],
        shapeCode: [''],
        noOfSeat: [''],
        licenseExpiryDate: [''],
        ownerType: [''],
        contactPersonPID: [''],
        contactPersonEmail: [''],
        contactPersonPhone: [''],
        ownerId: [''],
        ownerPID: [''],
        ownerName: [''],
        isFinalStep: [''],
        isVehicleConfigRequired: [''],
        inspectionStepId: [''],
        vehicleType: [''],
        stationId: [''],
        stationNameAr: [''],
        stationNameEn: [''],
        plateTypeName: [''],
        finalResult: [null],
        finalResultValue: [null],
        vehicleConfiguration: [''],
        selectedDefects: ['']
      }),
      fuelTypes: [[]],
      driveModes: [[]],
      parkingBrakes: [[]],
      selectedFuelType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      selectedDriveMode: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      selectedParkingBrake: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      nbAxles: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      milage: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      colorList: [[]],
      ownerTypes: [[]],
      vehicleCategories: [[]],
      plateTypes: [[]],
      colorValue: [''],
      subclr: [' '],
      pidValue: [],
      vcategory: [],
      plateTypeName: [''],
      formatExpDate: [],
      qatarVinNo: [''],
      fahesSerialNo: [''],
      isVinCh: [null],
      isPlateCh: [null],
      isManfCh: [null]
    });
    this.deviceInspectionProcessDto = new src_app_core_models_device_results_dto__WEBPACK_IMPORTED_MODULE_2__.DeviceInspectionProcessDto();
    this.deviceResultsDto = new src_app_core_models_device_results_dto__WEBPACK_IMPORTED_MODULE_2__.DeviceResultsDto();
  }
  showExhaustReads() {
    this.getDeviceInspectionReads(false, true);
  }
  showBrakeReads() {
    this.getDeviceInspectionReads(true, false);
  }
  backToVisualDefectsPage() {
    console.log(this.barCodeTxt);
    this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.searchLicense, this.barCodeTxt, this.selectServiceType).subscribe(response => {
      if (response.items != null) {
        console.log(response.items);
        this.insForm.get('inspectiondetails').setValue(response.items);
        this.requestId = this.insForm.get('inspectiondetails').value.requestId;
        this.sharedService.setSelectedDefectsPrevList(this.insForm.get('inspectiondetails').value.selectedDefects);
        this.sharedService.setConfirmDef(false);
      }
    });
    this.setActiveTab('visual-defect');
    this.sharedService.setBackMainDefects();
    this.visualDefectActive = true;
    this.isConfirmedDefects = false;
  }
  getDeviceInspectionReads(isBrake, isExhaust) {
    let deviceSectionInspectionDto = {
      requestId: this.requestId,
      sectionId: this.sectionId
    };
    this.inspectionService.getDeviceInspectionReads(deviceSectionInspectionDto).subscribe(res => {
      this.brakeReads = res.items.brakeReads;
      this.exhaustEmissReads = res.items.exhaustEmissReads;
      if (isBrake) this.brakeVisiblility = true;
      if (isExhaust) this.exhaustVisiblility = true;
    });
  }
  ngOnInit() {
    console.log('test');
    /* this.sharedService.userId$.subscribe((userId) => {
       this.userId = userId;
     });
     */
    this.userId = parseInt(localStorage.getItem('userId'));
    this.sideNav.setHeaderValue(true, false);
    this.sideNav.setActiveEnt(3, 36);
    this.setActiveTab('details');
    // get the data used in inspection from shared services
    this.sharedService.vinNo$.subscribe(vinNo => {
      this.vinNo = vinNo;
    });
    this.sharedService.plateNo$.subscribe(plateNo => {
      this.plateNo = plateNo;
    });
    this.sharedService.plateType$.subscribe(plateType => {
      this.plateType = plateType;
    });
    this.sharedService.reqNo$.subscribe(reqNo => {
      this.reqNo = reqNo;
    });
    this.sharedService.recNo$.subscribe(recNo => {
      this.recNo = recNo;
    });
    this.sharedService.externalPlateType$.subscribe(externalPlateType => {
      this.externalPlateType = externalPlateType;
    });
    this.sharedService.externalPlateNo$.subscribe(externalPlateNo => {
      this.externalPlateNo = externalPlateNo;
    });
    this.sharedService.insSelectedService$.subscribe(insServiceId => {
      this.selectServiceType = insServiceId;
    });
    this.sharedService.isExternalIns$.subscribe(isExternal => {
      this.isExternal = isExternal;
    });
    this.sharedLookup.colorList$.subscribe(data => {
      this.insForm.get('colorList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.insForm.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.insForm.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.insForm.get('plateTypes').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.fuelType).subscribe(data => {
      this.insForm.get('fuelTypes').setValue(data.items);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.driveMode).subscribe(data => {
      this.insForm.get('driveModes').setValue(data.items);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.parkingBrake).subscribe(data => {
      this.insForm.get('parkingBrakes').setValue(data.items);
    });
    //  this.sharedService.insSectionId$.subscribe((sectionId) => {
    //   this.sectionId = sectionId;
    // });
    this.getTankerCetificateFactorValue();
    this.sectionId = parseInt(localStorage.getItem('sectionId'));
    if (this.sectionId == 2) {
      this.visualDefectActive = true;
    }
    // this.sharedService.laneId$.subscribe((laneId) => {
    //  this.laneId = laneId;
    // });
    this.laneId = parseInt(localStorage.getItem('laneId'));
    this.sharedService.barCodeIns$.subscribe(text => {
      if (text) {
        const plateType = text.substring(0, 2);
        const plateNo = text.substring(2);
        this.plateNo = plateNo;
        this.plateType = plateType;
        this.barCodeTxt = text;
      }
    });
    // init tanker form
    this.createTankereRequestForm();
    if (!(this.vinNo || this.plateNo || this.externalPlateNo || this.externalPlateType || this.recNo)) {
      this.router.navigate(['/inspection/landing-inspection']);
    }
    if (this.plateNo) {
      this.isExternal = false;
      let licenseCode;
      // if (this.plateType.length === 1) {
      //   // Add '0' before plateNo if plateType is 1 digit
      //   licenseCode = '0' + this.plateType + this.plateNo;
      // } else {
      //   // Concatenate plateType and plateNo as usual if plateType is not 1 digit
      //   licenseCode = this.plateType + this.plateNo;
      // }
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.searchLicense, this.barCodeTxt, this.selectServiceType).subscribe(response => {
        if (response.items != null) {
          console.log(response.items);
          this.insForm.get('inspectiondetails').setValue(response.items);
          this.requestId = this.insForm.get('inspectiondetails').value.requestId;
          this.setVehicleDetailValues();
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
          });
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    if (this.vinNo) {
      this.isExternal = false;
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.searchVin, this.vinNo.toString(), this.selectServiceType).subscribe(response => {
        if (response.items != null) {
          this.insForm.get('inspectiondetails').setValue(response.items);
          this.setVehicleDetailValues();
          let plateType = this.insForm.get('inspectiondetails').value.plateType.toString().padStart(2, '0');
          let plateNo = this.insForm.get('inspectiondetails').value.plateNo;
          this.barCodeTxt = plateType + plateNo;
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
          });
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    if (this.recNo) {
      this.isExternal = false;
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.serachReceiptNo, this.recNo.toString(), null).subscribe(response => {
        if (response.items != null) {
          this.insForm.get('inspectiondetails').setValue(response.items);
          this.selectServiceType = this.insForm.get('inspectiondetails').value.inspectionServiceType;
          let plateType = this.insForm.get('inspectiondetails').value.plateType.toString().padStart(2, '0');
          let plateNo = this.insForm.get('inspectiondetails').value.plateNo;
          this.barCodeTxt = plateType + plateNo;
          this.requestId = this.insForm.get('inspectiondetails').value.requestId;
          this.setVehicleDetailValues();
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
          });
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        console.log('ERRRRORRRRR', error);
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    if (this.externalPlateType && this.externalPlateNo) {
      let plateTypeAndNo = this.externalPlateType + '' + this.externalPlateNo;
      this.inspectionService.searchInpsectionRequestDetails(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.searchLicense, plateTypeAndNo, this.selectServiceType).subscribe(response => {
        if (response.items != null) {
          this.insForm.get('inspectiondetails').setValue(response.items);
          this.setVehicleDetailValues();
          this.deviceInspectionProcessDto.requestId = this.requestId;
          this.deviceInspectionProcessDto.sectionId = this.sectionId;
          this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
            this.deviceResultsDto = res.items;
            console.log(this.deviceResultsDto);
          });
        } else {
          this.router.navigate(['/inspection/landing-inspection']);
        }
      }, error => {
        this.router.navigate(['/inspection/landing-inspection']);
      });
    }
    // this.setActiveTab('config');
    this.sharedService.defectCommentList$.subscribe(def => {
      if (def) {
        def.length > 0 ? this.isDefect = true : false;
      }
    });
    this.tankereRequestForm.get('height').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: this.tankereRequestForm.get('length').value,
        height: value,
        width: this.tankereRequestForm.get('width').value,
        factor: this.tankereRequestForm.get('factor').value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.tankereRequestForm.get('length').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: value,
        height: this.tankereRequestForm.get('height').value,
        width: this.tankereRequestForm.get('width').value,
        factor: this.tankereRequestForm.get('factor').value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.tankereRequestForm.get('width').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: this.tankereRequestForm.get('length').value,
        height: this.tankereRequestForm.get('height').value,
        width: value,
        factor: this.tankereRequestForm.get('factor').value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.tankereRequestForm.get('factor').valueChanges.subscribe(value => {
      let tankerVolumeVariablesDto = {
        length: this.tankereRequestForm.get('length').value,
        height: this.tankereRequestForm.get('height').value,
        width: this.tankereRequestForm.get('width').value,
        factor: value,
        tankerShape: this.tankereRequestForm.get('shapeId').value
      };
      if (src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.factor) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.length) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.height) && src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_8__.ObjectValueChecker.isNullOrEmpty(tankerVolumeVariablesDto.width)) this.inspectionService.calculateTankerCertificateVolume(tankerVolumeVariablesDto).subscribe(res => {
        this.tankereRequestForm.get('volume').setValue(res.items.volumeInLitre);
        this.tankereRequestForm.get('volumeUS').setValue(res.items.volumeInUSGallon);
        this.tankereRequestForm.get('volumeUK').setValue(res.items.volumeInUKGallon);
        this.isTankerMeasurementDiffersFromLastYear = res.items.isTankerMeasurementDiffersFromLastYear;
      });
    });
    this.sharedService.isConfirmDef$.subscribe(isConfirm => {
      this.isConfirmedDefects = isConfirm;
      console.log(this.isConfirmedDefects);
      if (this.isConfirmedDefects) {
        this.getDefectList();
      }
    });
    //Open websocket call for fecthing the results of the devices
    this.hubConnectionBuilder = new _microsoft_signalr__WEBPACK_IMPORTED_MODULE_23__.HubConnectionBuilder().withUrl(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__.environment.signalR.deviceInspectionStatusHubUrl).configureLogging(_microsoft_signalr__WEBPACK_IMPORTED_MODULE_24__.LogLevel.Information).build();
    this.hubConnectionBuilder.start().then(() => console.log('Connection started.......!')).catch(err => console.log('Error while connect with server'));
    this.hubConnectionBuilder.on('sentDeviceStatus', result => {
      console.log('device status=>', result);
      this.inpectionDeviceStatus = result.status;
      this.deviceStatusDescription = result.currentStatusDescription;
      if (this.inpectionDeviceStatus == src_app_core_utilities_enums_device_inspection_status_enum__WEBPACK_IMPORTED_MODULE_4__.DeviceInspectionStatus.InProgress) {
        this.isDeviceStatusShown = true;
        if (!this.isRunning) {
          this.isTimerVisiable = true;
          this.startStopTimer();
        }
      } else {
        if (this.isRunning) this.startStopTimer();
        this.isDeviceStatusShown = false;
        this.deviceInspectionProcessDto.requestId = this.requestId;
        this.deviceInspectionProcessDto.sectionId = this.sectionId;
        this.inspectionService.getFinalInspectionDeviceResult(this.deviceInspectionProcessDto).subscribe(res => {
          this.deviceResultsDto = res.items;
          console.log(this.deviceResultsDto);
        });
      }
    });
  }
  getTankerCetificateFactorValue() {
    this.globalServ.getTankerCetificateFactorValue().subscribe(res => {
      this.tankereRequestForm.get('factor').setValue(res.items);
    });
  }
  calculateTankVolume() {
    // Volume = Length * Width * Height * 1000 * 0.7854
    const volume = this.tankereRequestForm.get('length').value * this.tankereRequestForm.get('width').value * this.tankereRequestForm.get('height').value * 1000 * 0.7854;
    // volume in litre
    return volume;
  }
  createTankerCertificateRequest() {
    if (this.isTankerService) {
      let tankerRequest = this.tankereRequestForm.value;
      tankerRequest.tankerCertRequestId = this.insForm.get('inspectiondetails').value.inspectionReqId;
      console.log(tankerRequest);
      this.inspectionService.submitTankerCertificateRequest(tankerRequest).subscribe(res => {
        if (res.errorMessage == null) this.logout();
      });
    }
    if (this.isTank) {
      const tankDetails = {
        requestId: this.insForm.get('inspectiondetails').value.requestId,
        length: parseFloat(this.tankereRequestForm.get('length').value),
        width: parseFloat(this.tankereRequestForm.get('width').value),
        height: parseFloat(this.tankereRequestForm.get('height').value),
        volume: parseInt(this.tankereRequestForm.get('volume').value)
      };
      this.inspectionService.fillInspectionTankValues(tankDetails).subscribe(res => {
        this.setActiveTab('visual-defect');
      });
    }
  }
  assignVehicleConfig(vconfig) {
    this.configDisabled = true;
    for (const config of vconfig) {
      switch (config.codeOperation) {
        case 25:
          this.insForm.get('selectedFuelType').setValue(config.codeValues);
          break;
        case 26:
          this.insForm.get('selectedDriveMode').setValue(config.codeValues);
          break;
        case 27:
          this.insForm.get('selectedParkingBrake').setValue(config.codeValues);
          break;
        case 28:
          this.insForm.get('milage').setValue(config.codeValues);
          break;
        case 29:
          this.insForm.get('nbAxles').setValue(config.codeValues);
          break;
        default:
          // Handle default case if necessary
          break;
      }
    }
    this.sharedService.setNbAxles(this.insForm.get('nbAxles').value);
  }
  removeConfigValidation() {
    this.insForm.get('selectedFuelType').clearValidators();
    this.insForm.get('selectedFuelType').updateValueAndValidity();
    this.insForm.get('selectedDriveMode').clearValidators();
    this.insForm.get('selectedDriveMode').updateValueAndValidity();
    this.insForm.get('selectedParkingBrake').clearValidators();
    this.insForm.get('selectedParkingBrake').updateValueAndValidity();
    this.insForm.get('nbAxles').clearValidators();
    this.insForm.get('nbAxles').updateValueAndValidity();
  }
  setVehicleDetailValues() {
    console.log(this.insForm.get('inspectiondetails').value);
    console.log(this.insForm.get('inspectiondetails').value.plateNo);
    this.sharedService.setSelectedDefectsPrevList(this.insForm.get('inspectiondetails').value.selectedDefects);
    if (this.insForm.get('inspectiondetails').value.vehicleConfiguration != null) {
      const vconfig = this.insForm.get('inspectiondetails').value.vehicleConfiguration;
      this.assignVehicleConfig(vconfig);
      //   this.setActiveTab("visual-defect");
      this.visualDefectActive = true;
    }
    if (this.selectServiceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.VINStamping) {
      //   this.setActiveTab("vin");
      this.isVinService = true;
      if (this.insForm.get('inspectiondetails').value.serviceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.NewStamping) {
        this.isNewStamp = true;
        this.checkVinSeq();
        this.inspectionService.getQatarVinNumbersDetails(this.insForm.get('inspectiondetails').value.categoryId, this.insForm.get('inspectiondetails').value.requestId).subscribe(response => {
          this.insForm.get('qatarVinNo').setValue(response.items.qatarVinNo);
          this.insForm.get('fahesSerialNo').setValue(response.items.fahesSerialNo);
        });
      }
      if (this.insForm.get('inspectiondetails').value.serviceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.ReStamping) {
        this.isReStamp = true;
      }
    }
    if (this.selectServiceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.TankerCertificate) {
      //   this.setActiveTab("tanker");
      this.isTankerService = true;
      this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.tankerShapes).subscribe(data => {
        this.tankerShapes = data.items;
      });
    }
    if (this.isExternal) {
      this.removeConfigValidation();
    }
    console.log(this.insForm.get('inspectiondetails').value);
    this.getDefectList();
    if (this.defectList) {
      this.setActiveTab('visual-defect');
    }
    this.sharedService.setVinNo(this.insForm.get('inspectiondetails').value.vinNo);
    if (this.insForm.get('inspectiondetails').value.categoryId == 6 && this.selectServiceType == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.Inspection) {
      this.isTank = true;
      this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.tankerShapes).subscribe(data => {
        this.tankerShapes = data.items;
      });
    }
    const color = this.insForm.get('colorList').value.find(color => color.lkCodeValue == this.insForm.get('inspectiondetails').value.colorId);
    this.insForm.get('colorValue').setValue(color.lkValueEname);
    this.insForm.get('pidValue').setValue(this.insForm.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.insForm.get('inspectiondetails').value.ownerType).lkValueEname);
    this.insForm.get('vcategory').setValue(this.insForm.get('vehicleCategories').value.find(category => category.categoryId == this.insForm.get('inspectiondetails').value.categoryId).descriptionEn);
    this.insForm.get('plateTypeName').setValue(this.insForm.get('plateTypes').value.find(plate => plate.lkCodeValue == this.insForm.get('inspectiondetails').value.plateType).lkValueEname);
    const isoDate = new Date(this.insForm.get('inspectiondetails').value.licenseExpiryDate);
    const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_25__.DatePipe('en-US').transform(isoDate, 'MM-dd-yyyy');
    this.insForm.get('formatExpDate').setValue(dateFormat);
    // save the category type id
    const insCategId = this.insForm.get('inspectiondetails').value.categoryId;
    for (let ins of this.insForm.get('vehicleCategories').value) {
      if (ins.categoryId == insCategId) {
        this.sharedService.setVehcileCategory(ins.categoryTypeId);
      }
    }
    const reqId = this.insForm.get('inspectiondetails').value.requestId;
    this.inspectionService.getInspectionInstructionsByRequestId(this.insForm.get('inspectiondetails').value.serviceId, 1).subscribe(response => {
      console.log(response.items);
      this.instructions = response.items;
      //this.sharedService.setInsSection(this.instructions[0].sectionId);
      this.sharedService.setInsServId(parseInt(this.insForm.get('inspectiondetails').value.inspectionServiceId));
      this.sharedService.setVehicleType(parseInt(this.insForm.get('inspectiondetails').value.vehicleType));
      this.sharedService.setReqNo(this.insForm.get('inspectiondetails').value.requestId);
      if (this.isExternal) {
        this.sharedService.setInsRequest(this.insForm.get('inspectiondetails').value.inspectionReqId);
        const insStep = {
          inspectionReqId: this.insForm.get('inspectiondetails').value.inspectionReqId,
          requestId: reqId,
          inspectionServiceId: this.insForm.get('inspectiondetails').value.inspectionServiceId,
          laneId: this.laneId,
          sectionId: this.sectionId,
          inspectorId: this.userId,
          remarks: ''
        };
        if (!this.insForm.get('inspectiondetails').value.inspectionStepId) {
          this.inspectionService.createInspectionStep(insStep).subscribe(response => {
            this.sharedService.setInsStepId(response.items);
            console.log('test ins step', response.items);
          });
        } else {
          this.sharedService.setInsStepId(this.insForm.get('inspectiondetails').value.inspectionStepId);
        }
      }
      if (this.insForm.get('inspectiondetails').value.vehicleConfiguration != null) {
        const configurationRequest = {
          requestId: reqId,
          inspectorId: this.userId,
          sectionId: this.sectionId,
          laneId: this.laneId,
          remarks: 'remarks',
          deviceInputCodes: this.insForm.get('inspectiondetails').value.vehicleConfiguration
        };
        this.inspectionRequest = new src_app_core_models_inspection_request__WEBPACK_IMPORTED_MODULE_3__.InspectionRequest(configurationRequest);
        console.log(this.inspectionRequest);
        this.inspectionService.createInspectionRequest(this.inspectionRequest).subscribe(response => {
          this.insForm.get('inspectiondetails.inspectionReqId').setValue(response.items.inspectionRequestId);
          this.sharedService.setInsStepId(response.items.inspectionStepId);
          this.sharedService.setInsRequest(parseInt(response.items.inspectionRequestId));
          this.savedConfig = true;
          //Open websocket call for fecthing the results of the devices
          this.hubConnectionBuilder = new _microsoft_signalr__WEBPACK_IMPORTED_MODULE_23__.HubConnectionBuilder().withUrl(src_environments_environment__WEBPACK_IMPORTED_MODULE_9__.environment.signalR.deviceInspectionStatusHubUrl).configureLogging(_microsoft_signalr__WEBPACK_IMPORTED_MODULE_24__.LogLevel.Information).build();
          this.hubConnectionBuilder.start().then(() => console.log('Connection started.......!')).catch(err => console.log('Error while connect with server'));
          this.hubConnectionBuilder.on('sentDeviceStatus', result => {
            this.inpectionDeviceStatus = result.status;
            this.deviceStatusDescription = result.currentStatusDescription;
            if (this.inpectionDeviceStatus == src_app_core_utilities_enums_device_inspection_status_enum__WEBPACK_IMPORTED_MODULE_4__.DeviceInspectionStatus.InProgress) {
              this.isDeviceStatusShown = true;
              if (!this.isRunning) {
                this.startStopTimer();
                this.isTimerVisiable = true;
              }
            } else {
              if (this.isRunning) this.startStopTimer();
              this.isDeviceStatusShown = false;
            }
          });
        });
      }
    });
    this.vehicleCategory = this.insForm.get('vcategory').value;
    let subColor = this.insForm.get('colorList').value.find(color => color.lkCodeValue == this.insForm.get('inspectiondetails').value.subColorId) != undefined ? this.insForm.get('colorList').value.find(color => color.lkCodeValue == this.insForm.get('inspectiondetails').value.subColorId).lkValueEname : null;
    this.insForm.get('subclr').setValue(subColor);
  }
  createTankereRequestForm() {
    this.tankereRequestForm = this.fb.group({
      shapeId: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      length: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      width: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      height: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      factor: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.Validators.required],
      volume: [null],
      volumeUK: [null],
      volumeUS: [null],
      remarks: [null]
    });
  }
  submitVinRequest() {
    if (this.isReStamp) {
      const vinRequest = {
        vinStampingRequestId: this.insForm.get('inspectiondetails').value.inspectionReqId,
        qatarVinNo: this.insForm.get('inspectiondetails').value.vinNo,
        vinType: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.ReStamping,
        vehicleCategoryId: this.insForm.get('inspectiondetails').value.categoryId
      };
      this.inspectionService.submitVinStampingRequest(vinRequest).subscribe(res => {
        if (res.errorMessage == null) this.logout();
      });
    }
    if (this.isNewStamp) {
      const vinRequest = {
        vinStampingRequestId: this.insForm.get('inspectiondetails').value.inspectionReqId,
        qatarVinNo: this.insForm.get('qatarVinNo').value,
        vinType: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_7__.SystemLookupValueCodes.NewStamping,
        vehicleCategoryId: this.insForm.get('inspectiondetails').value.categoryId
      };
      this.inspectionService.submitVinStampingRequest(vinRequest).subscribe(res => {
        if (res.errorMessage == null) this.logout();
      });
    }
  }
  setActiveTab(tab) {
    this.activeTab = tab;
    console.log(this.activeTab);
  }
  confirmIns() {
    // if (this.isExternal || this.sectionId == 2) {
    //   this.setActiveTab("visual-defect");
    // }
    // else {
    //   this.setActiveTab("config");
    // }
    this.setActiveTab('config');
  }
  cancelConfig() {
    this.isCancelConfig = true;
  }
  nextVI() {
    if (!this.isVinService || !this.isTankerService) {
      this.setActiveTab('config');
    }
    if (this.isVinService) {
      this.setActiveTab('vin');
    }
    if (this.isTankerService) {
      this.setActiveTab('tanker');
    }
  }
  checkVinSeq() {
    this.inspectionService.getVINSequences({
      categoryId: this.insForm.get('inspectiondetails').value.categoryId
    }).subscribe(response => {
      if (response.items[0].availableSeqCount <= 0) {
        this.enableVinSubmit = false;
        console.log(this.enableVinSubmit);
        console.log(!this.enableVinSubmit);
      } else {
        this.enableVinSubmit = true;
      }
    });
  }
  saveConfiguration() {
    console.log(this.insForm.get('selectedFuelType').value);
    console.log(this.insForm.get('selectedDriveMode').value);
    console.log(this.insForm.get('selectedParkingBrake').value);
    console.log(this.insForm.get('nbAxles').value);
    console.log(this.insForm.get('milage').value);
    this.deviceCodeList = [new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(25, this.insForm.get('selectedFuelType').value?.toString() ? this.insForm.get('selectedFuelType').value.toString() : null), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(26, this.insForm.get('selectedDriveMode').value?.toString() ? this.insForm.get('selectedDriveMode').value.toString() : null), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(27, this.insForm.get('selectedParkingBrake').value?.toString() ? this.insForm.get('selectedParkingBrake').value.toString() : null), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(28, this.insForm.get('milage').value.replace(/,/g, '')), new src_app_core_models_device_input_code__WEBPACK_IMPORTED_MODULE_1__.DeviceInputCode(29, this.insForm.get('nbAxles').value?.toString() ? this.insForm.get('nbAxles').value.toString() : null)];
    this.sharedService.setNbAxles(this.insForm.get('nbAxles').value);
    const reqId = this.insForm.get('inspectiondetails.requestId').value;
    const configurationRequest = {
      requestId: reqId,
      inspectorId: this.userId,
      sectionId: this.sectionId,
      laneId: this.laneId,
      remarks: 'remarks',
      deviceInputCodes: this.deviceCodeList
    };
    this.inspectionRequest = new src_app_core_models_inspection_request__WEBPACK_IMPORTED_MODULE_3__.InspectionRequest(configurationRequest);
    console.log(this.inspectionRequest);
    this.inspectionService.createInspectionRequest(this.inspectionRequest).subscribe(response => {
      this.insForm.get('inspectiondetails.inspectionReqId').setValue(response.items.inspectionRequestId);
      this.sharedService.setInsStepId(response.items.inspectionStepId);
      this.sharedService.setInsRequest(parseInt(response.items.inspectionRequestId));
      this.savedConfig = true;
      this.configDisabled = true;
    });
    if (this.isTank) {
      this.setActiveTab('tankdets');
    } else {
      this.setActiveTab('visual-defect');
    }
    this.visualDefectActive = true;
  }
  getDefectList() {
    if (this.isConfirmedDefects) {
      this.setActiveTab('defect-list');
    }
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_6__.SystemLookupCodes.evaluationList).subscribe(response => {
      this.evaluationList = response.items;
    });
    console.log(this.insForm.get('inspectiondetails.inspectionReqId').value);
    this.inspectionService.getInspectionDefects(this.insForm.get('inspectiondetails.inspectionReqId').value).subscribe(response => {
      this.defectList = response.items;
      this.defectListSaved = response.items;
      this.isLocationEmpty = this.defectList.every(defect => defect.defectLocation === '');
    });
    if (this.insForm.get('inspectiondetails').value.isFinalStep) {
      let baseInspectionRequestDto = {
        requestId: this.requestId ? this.requestId : this.insForm.get('inspectiondetails').value.requestId
      };
      this.inspectionService.getInspectionResultDetails(baseInspectionRequestDto).subscribe(res => {
        this.classificationsResult = res.items;
      });
    }
  }
  checkDeleteDef(index) {
    this.defectDelIndex = index;
    this.confirmEval = this.defectList[index].evalution;
    console.log(this.confirmEval);
  }
  deleteDefectItemList(index) {
    const deleteDef = {
      inspectionReqId: this.insForm.get('inspectiondetails.inspectionReqId').value,
      defectsCommentId: this.defectList[index].defectCommentId
    };
    this.inspectionService.deleteInspectionDefect(deleteDef).subscribe(response => {
      this.getDefectList();
      this.defectDelIndex = null;
    });
  }
  //Action Type : Save =1 | Save & Update =2
  confirmAction() {
    if (this.isCancelConfig) {
      this.resetConfig();
      this.router.navigate(['/inspection/landing-inspection']);
    }
    if (this.isDefectConfirm) {
      let stepId;
      this.sharedService.insStepId$.subscribe(step => {
        stepId = step;
      });
      this.inspectionService.finishInspectionStep(stepId).subscribe(response => {
        if (this.actionType == src_app_core_utilities_enums_inspection_save_action_types_enum__WEBPACK_IMPORTED_MODULE_5__.InspectionSaveActionTypes.SaveAndUpdate) this.confirmDefectList();else this.logout();
      });
    }
  }
  logout() {
    var _this = this;
    return (0,C_Users_thkil_FAHES_VIS_Fahes_Web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.authService.logout();
    })();
  }
  // reset the values chosen for vehicle configuration
  resetConfig() {
    this.insForm.get('selectedFuelType').setValue(null);
    this.insForm.get('selectedDriveMode').setValue(null);
    this.insForm.get('selectedParkingBrake').setValue(null);
    this.insForm.get('nbAxles').setValue(null);
    this.insForm.get('milage').setValue(null);
  }
  confirmDefectList() {
    if (this.insForm.get('inspectiondetails').value.isFinalStep) {
      this.inspectionService.submitInspectionRequest(this.insForm.get('inspectiondetails').value.requestId).subscribe(response => {
        this.logout();
        console.log('inspetion request ', response);
      });
    } else {
      this.logout();
    }
  }
  cancelDefectList() {
    // this.setActiveTab("visual-defect");
    window.location.reload();
  }
  back() {
    this.location.back();
  }
  confirmTankerCertificate() {
    this.createTankerCertificateRequest();
  }
  //#region timer:
  startStopTimer() {
    if (!this.isRunning && this.isDeviceStatusShown) {
      // Stop => Running
      this.timerId = setInterval(() => {
        this.ms++;
        if (this.ms >= 100) {
          this.ss++;
          this.ms = 0;
        }
        if (this.ss >= 60) {
          this.mm++;
          this.ss = 0;
        }
      }, 10);
    } else {
      clearInterval(this.timerId);
    }
    this.isRunning = !this.isRunning;
  }
  format(num) {
    return (num + '').length === 1 ? '0' + num : num + '';
  }
  //#endregion
  ngOnDestroy() {
    setTimeout(() => {
      this.zone.run(() => {
        location.reload();
      });
    }, 1500);
  }
  static #_ = this.ɵfac = function VehicleInspectionComponent_Factory(t) {
    return new (t || VehicleInspectionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_10__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_11__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_25__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_12__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_13__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_26__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_21__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_14__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_15__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_16__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_17__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_authentication_service_ts_service__WEBPACK_IMPORTED_MODULE_18__.AuthenticationServiceTsService), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_21__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_19__.ThousandSeparatorService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵdefineComponent"]({
    type: VehicleInspectionComponent,
    selectors: [["app-vehicle-inspection"]],
    inputs: {
      mainDefects: "mainDefects"
    },
    outputs: {
      vehicleCategory: "vehicleCategory",
      defectListSaved: "defectListSaved",
      changeCategory: "changeCategory"
    },
    decls: 412,
    vars: 103,
    consts: [[3, "formGroup"], [1, "inspection-tab-menu"], [1, "tabmenu-hld", "d-flex", "justify-content-between"], ["id", "myTab", "role", "tablist", 1, "nav", "nav-tabs"], ["role", "presentation", 1, "nav-item"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "v-details", "aria-selected", "true", 1, "nav-link", 3, "click"], ["class", "nav-item", "role", "presentation", 4, "ngIf"], ["role", "presentation", 1, "nav-item", 3, "hidden"], ["id", "profile-tab", "type", "button", "role", "tab", "aria-controls", "v-config", "aria-selected", "false", 1, "nav-link", "active", 3, "click"], ["id", "contact-tab", "type", "button", "role", "tab", "aria-controls", "contact", "aria-selected", "false", 1, "nav-link", 3, "click"], ["id", "defect-tab", "type", "button", "role", "tab", "aria-controls", "contact", "aria-selected", "false", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "instructions", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "plno", 1, "ml-auto"], [4, "ngIf"], [1, "inspection-tab-content"], ["class", "stop-watch", 4, "ngIf"], ["class", "device-status", 4, "ngIf"], [1, "row"], [1, "col-12"], ["id", "myTabContent", 1, "tab-content"], ["id", "v-details", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show", "active"], [1, "tab-item-content"], [1, "section", "dashboard"], [1, "col-lg-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "col"], ["id", "chvin", 1, "row", "form-fields"], ["id", "checkDets", 1, "form-check"], ["id", "rcb", 1, "row"], [1, "form-check"], ["type", "checkbox", "formControlName", "isVinCh", "id", "v1", 1, "form-check-input", "chkbx"], ["for", "v1", 1, "form-check-label"], ["type", "checkbox", "formControlName", "isPlateCh", "id", "p1", 1, "form-check-input", "chkbx"], ["for", "p1", 1, "form-check-label"], ["type", "checkbox", "formControlName", "isManfCh", "id", "m1", 1, "form-check-input", "chkbx"], ["for", "m1", 1, "form-check-label"], [1, "row", "form-fields"], ["formGroupName", "inspectiondetails", 1, "col-md-6", "col-lg-3"], ["for", "myInput"], ["type", "number", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "id", "myInput", "formControlName", "plateNo", "id", "highlightText", "readOnly", "", 1, "form-control"], [1, "col-md-6", "col-lg-3"], ["type", "text", "formControlName", "plateTypeName", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "vcategory", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "pidValue", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "ownerPID", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "ownerName", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "formatExpDate", "readonly", "", 1, "form-control"], ["type", "text", "id", "highlightText", "formControlName", "vinNo", "readOnly", "", 1, "form-control"], ["type", "text", "id", "highlightText", "formControlName", "manufacturersEname", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "modelEname", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "manufacturerYear", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "cylinders", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "weight", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "payloadWeight", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "colorValue", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "subclr", "readOnly", "", 1, "form-control"], ["type", "text", "formControlName", "noOfSeat", "readOnly", "", 1, "form-control"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["class", "btn btn-orange", 3, "disabled", "click", 4, "ngIf"], ["id", "vin", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [1, "card"], ["type", "button", 1, "btn", "btn-orange"], ["type", "button", 1, "btn", "btn-dark-gray"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"], ["id", "tanker", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [1, "col-md-3"], [1, "st-label"], ["formControlName", "shapeId", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "length", 1, "form-control"], ["type", "text", "formControlName", "width", 1, "form-control"], ["type", "text", "formControlName", "height", 1, "form-control"], ["type", "text", "formControlName", "factor", 1, "form-control"], ["type", "text", "formControlName", "volume", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "volumeUK", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "volumeUS", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "remarks", 1, "form-control"], ["style", "color: orange;margin-top: 10px;", 4, "ngIf"], [1, "modal-footer", "text-center", "mt-2"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#tankerConfirmationModal", 1, "btn", "btn-orange", 3, "disabled"], ["id", "instructions", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [4, "ngFor", "ngForOf"], ["type", "button", 1, "btn", "btn-orange", 3, "click"], ["id", "v-config", "role", "tabpanel", "aria-labelledby", "profile-tab", 1, "tab-pane", "fade", "show"], [1, "row", "justify-content-between"], [1, "col-lg-5"], ["class", "col-6", 4, "ngFor", "ngForOf"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], [1, "col-lg-6"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "placeholder", "ex: 2", "formControlName", "nbAxles", 1, "form-control", 3, "readonly"], ["type", "text", "placeholder", "ex: 100,0000", "oninput", "this.value = this.value.replace(/[^0-9,]/g, '').replace(/\\D/g, '').replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',').replace(/^0+(?=\\d)/, '')", "formControlName", "milage", 1, "form-control", 3, "readonly"], ["id", "vd-main-cat", "role", "tabpanel", "aria-labelledby", "contact-tab", 1, "tab-pane", "fade", "show"], ["id", "defect-list", "role", "tabpanel", "aria-labelledby", "home-tab", 1, "tab-pane", "fade", "show"], [1, "defect-list-title"], [1, "defect-device-result"], [3, "ngStyle", "click", 4, "ngIf"], [1, "table", "table-striped", "defect-table"], ["scope", "col"], ["scope", "col", 4, "ngIf"], ["id", "defRes", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-outline-gray"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-orange", 3, "click"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 3, "click", 4, "ngIf"], ["id", "confirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-body"], ["src", "./assets/img/red-question.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "class", "btn btn-outline-secondary border-0", "data-bs-dismiss", "modal", 3, "click", 4, "ngIf"], ["id", "confirmationModalDel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/Check circle.svg"], ["header", "Brake Reads", 3, "visible", "modal", "draggable", "resizable", "maximizable", "visibleChange"], [1, "table-bordered", "table-striped"], ["id", "headertb"], ["header", "Exhaust Read", 3, "visible", "modal", "draggable", "resizable", "maximizable", "visibleChange"], ["id", "tankerConfirmationModal", "tabindex", "-1", "role", "dialog", "aria-labelledby", "tankerConfirmationModal", "aria-hidden", "true", 1, "modal", "fade"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "vin", "aria-selected", "true", 1, "nav-link", 3, "click"], ["id", "home-tab", "type", "button", "role", "tab", "aria-controls", "tanker", "aria-selected", "true", 1, "nav-link", 3, "click"], [1, "stop-watch"], ["pTooltip", "Duration of device inspection", "tooltipPosition", "top", 1, "display"], [1, "device-status"], ["mode", "indeterminate"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], ["formGroupName", "inspectiondetails", 1, "row", "form-fields"], ["type", "number", "formControlName", "contactPersonPhone", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "contactPersonPID", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "contactPersonEmail", "readonly", "", 1, "form-control"], [1, "btn", "btn-orange", 3, "disabled", "click"], [1, "col-md-4"], ["type", "text", "formControlName", "qatarVinNo", "readonly", "", 1, "form-control"], ["type", "text", "formControlName", "fahesSerialNo", "readonly", "", 1, "form-control"], ["formGroupName", "inspectiondetails", 1, "col-md-4"], ["type", "text", "formControlName", "vinNo", "readonly", "", 1, "form-control"], [3, "value"], [1, "error-message"], [2, "color", "orange", "margin-top", "10px"], [1, "bi", "bi-arrow-right-square-fill", 2, "font-size", "14px"], [1, "col-6"], [1, "btn-radio"], ["type", "radio", "formControlName", "selectedFuelType", "name", "selectedFuelType", 3, "id", "value", "checked"], [1, "w-100", 3, "for"], ["type", "radio", "formControlName", "selectedDriveMode", "name", "selectedDriveMode", 3, "id", "value", "checked"], [1, "col-lg-4"], ["type", "radio", "formControlName", "selectedParkingBrake", "name", "selectedParkingBrake", 3, "id", "value", "checked"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "btn", "btn-outline-gray", 3, "click"], [3, "ngStyle", "click"], ["scope", "row"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmationModal", 1, "deletedefect", 3, "hidden", "click"], [1, "bi", "bi-trash3-fill"], ["id", "defRes"], ["class", "pass", 4, "ngIf"], ["class", "fail", 4, "ngIf"], [1, "pass"], [1, "fail"]],
    template: function VehicleInspectionComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](0, "html");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](2, "body")(3, "form", 0)(4, "div", 1)(5, "div", 2)(6, "ul", 3)(7, "li", 4)(8, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_8_listener() {
          return ctx.setActiveTab("details");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](9, " Vehicle Information ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](10, VehicleInspectionComponent_li_10_Template, 3, 4, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](11, VehicleInspectionComponent_li_11_Template, 3, 4, "li", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](12, "li", 7)(13, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_13_listener() {
          return ctx.setActiveTab("config");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](14, " Vehicle Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](15, "li", 7)(16, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_16_listener() {
          return ctx.setActiveTab("tankdets");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](17, " Tank Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](18, "li", 7)(19, "button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_19_listener() {
          return ctx.setActiveTab("visual-defect");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](20, " Visual Defect List ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](21, "li", 7)(22, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_22_listener() {
          return ctx.getDefectList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](23, "Defect List");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](24, "li", 7)(25, "button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_25_listener() {
          return ctx.setActiveTab("inst");
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](26, "Instructions");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](27, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](28, VehicleInspectionComponent_span_28_Template, 2, 0, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](29, " Vehicle Plate No: ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](30, "b");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](31);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](32, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](33, VehicleInspectionComponent_div_33_Template, 3, 3, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](34, VehicleInspectionComponent_div_34_Template, 4, 4, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](35, "div", 17)(36, "div", 18)(37, "div", 19)(38, "div", 20)(39, "div", 21)(40, "section", 22)(41, "div", 17)(42, "div", 23)(43, "div", 17)(44, "div", 18)(45, "div", 24)(46, "div", 25)(47, "div", 26)(48, "div", 27)(49, "h2", 28)(50, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](51, " Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](52, "div", 30)(53, "div", 31)(54, "div", 32)(55, "div", 33)(56, "div", 34)(57, "div", 35)(58, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](59, "input", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](60, "label", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](61, " VIN No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](62, "div", 35)(63, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](64, "input", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](65, "label", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](66, " License Plate No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](67, "div", 35)(68, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](69, "input", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](70, "label", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](71, " Manufacturer ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](72, "div", 43)(73, "div", 44)(74, "label", 45);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](75, " License Plate No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](76, "input", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](77, "div", 47)(78, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](79, " License Plate Type ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](80, "input", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](81, "div", 47)(82, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](83, "Vehicle Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](84, "input", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](85, "div", 47)(86, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](87, "Owner PID Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](88, "input", 50);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](89, "div", 44)(90, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](91, "Owner PID");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](92, "input", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](93, "div", 44)(94, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](95, "Owner Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](96, "input", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](97, "div", 47)(98, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](99, "Istimara Expiry Date");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](100, "input", 53);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](101, "div", 43)(102, "div", 44)(103, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](104, "VIN No");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](105, "input", 54);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](106, "div", 44)(107, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](108, "Manufacturer");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](109, "input", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](110, "div", 44)(111, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](112, "Model");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](113, "input", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](114, "div", 44)(115, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](116, "Manufacturing Year");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](117, "input", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](118, "div", 44)(119, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](120, "Cylinders");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](121, "input", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](122, "div", 44)(123, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](124, "Weight (kg)");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](125, "input", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](126, "div", 44)(127, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](128, "Payload Weight (kg)");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](129, "input", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](130, "div", 47)(131, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](132, "Color");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](133, "input", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](134, "div", 47)(135, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](136, "Sub Color");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](137, "input", 62);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](138, "div", 44)(139, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](140, "Seats");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](141, "input", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](142, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](143, VehicleInspectionComponent_div_143_Template, 24, 0, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](144, "div", 17)(145, "div", 65)(146, "button", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_146_listener() {
          return ctx.back();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](147, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](148, VehicleInspectionComponent_button_148_Template, 2, 1, "button", 67);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](149, "div", 68)(150, "div", 69)(151, "div", 21)(152, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](153, " VIN Stamping ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](154, VehicleInspectionComponent_div_154_Template, 5, 0, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](155, VehicleInspectionComponent_div_155_Template, 5, 0, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](156, VehicleInspectionComponent_div_156_Template, 6, 0, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](157, "br")(158, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](159, "div", 17)(160, "div", 65)(161, "button", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_161_listener() {
          return ctx.cancelDefectList();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](162, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](163, "button", 70);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](164, " Send to Device");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](165, "button", 71);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](166, " Refresh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](167, "button", 72);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_167_listener() {
          return ctx.submitVinRequest();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](168, " Submit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](169, "div", 73)(170, "div", 69)(171, "form", 0)(172, "div", 21)(173, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](174, " Tanker Certificate ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](175, "div", 17)(176, "div", 74)(177, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](178, "Tanker Shape *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](179, "select", 76);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](180, VehicleInspectionComponent_option_180_Template, 2, 2, "option", 77);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](181, VehicleInspectionComponent_div_181_Template, 2, 0, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](182, "div", 74)(183, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](184, " Length * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](185, "input", 79);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](186, VehicleInspectionComponent_div_186_Template, 2, 0, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](187, "div", 74)(188, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](189, " Width * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](190, "input", 80);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](191, VehicleInspectionComponent_div_191_Template, 2, 0, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](192, "div", 74)(193, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](194, " Height * ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](195, "input", 81);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](196, VehicleInspectionComponent_div_196_Template, 2, 0, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](197, "div", 17)(198, "div", 74)(199, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](200, "Factor *");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](201, "input", 82);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](202, VehicleInspectionComponent_div_202_Template, 2, 0, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](203, "div", 74)(204, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](205, "Volume In Liter");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](206, "input", 83);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](207, "div", 74)(208, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](209, "Volume In UK Gallon");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](210, "input", 84);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](211, "div", 74)(212, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](213, "Volume In US Gallon");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](214, "input", 85);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](215, "div", 74)(216, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](217, "Remarks");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](218, "input", 86);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](219, VehicleInspectionComponent_div_219_Template, 2, 0, "div", 78);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](220, VehicleInspectionComponent_div_220_Template, 2, 0, "div", 87);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](221, "br")(222, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](223, "div", 17)(224, "div", 88)(225, "button", 89);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](226, " Submit ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](227, "div", 90)(228, "div", 69)(229, "div", 21)(230, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](231, " Instructions ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](232, VehicleInspectionComponent_h3_232_Template, 3, 1, "h3", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](233, "div", 17)(234, "div", 65)(235, "button", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_235_listener() {
          return ctx.back();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](236, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](237, "button", 92);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_237_listener() {
          return ctx.confirmIns();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](238, "Next");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](239, "div", 93)(240, "div", 69)(241, "div", 21)(242, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](243, " Vehicle Configuration ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](244, "div", 94)(245, "div", 95)(246, "div", 17)(247, "div", 18)(248, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](249, "Fuel Type");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](250, VehicleInspectionComponent_div_250_Template, 5, 6, "div", 96);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](251, "div", 95)(252, "div", 17)(253, "div", 18)(254, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](255, "Drive Mode");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](256, VehicleInspectionComponent_div_256_Template, 5, 6, "div", 96);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](257, "div", 95)(258, "div", 17)(259, "div", 18)(260, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](261, "Parking Brake");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](262, VehicleInspectionComponent_div_262_Template, 5, 6, "div", 97);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](263, "div", 94)(264, "div", 95)(265, "div", 43)(266, "div", 98)(267, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](268, "No. of Axles");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](269, "input", 99);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](270, "div", 98)(271, "label", 75);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](272, "Mileage(km) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](273, VehicleInspectionComponent_span_273_Template, 2, 0, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](274, "input", 100);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](275, VehicleInspectionComponent_div_275_Template, 6, 1, "div", 64);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](276, "div", 101);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](277, "visual-defect-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](278, "div", 102)(279, "div", 69)(280, "div", 21)(281, "div", 103)(282, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](283, " Defects List ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](284, "div", 104);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](285, VehicleInspectionComponent_b_285_Template, 2, 3, "b", 105);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](286, " \u00A0 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](287, VehicleInspectionComponent_b_287_Template, 2, 3, "b", 105);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](288, "table", 106)(289, "thead")(290, "tr")(291, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](292, "Main Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](293, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](294, "Defects");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](295, VehicleInspectionComponent_th_295_Template, 2, 0, "th", 108);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](296, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](297, "Remarks");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](298, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](299, "Evaluation");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](300, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](301, "Classification");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](302, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](303, " -");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](304, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](305, VehicleInspectionComponent_tr_305_Template, 15, 7, "tr", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](306, VehicleInspectionComponent_div_306_Template, 5, 4, "div", 109);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](307, "div", 17)(308, "div", 65)(309, "button", 66);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_309_listener() {
          return ctx.backToVisualDefectsPage();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](310, " Back ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](311, "button", 110);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](312, " Cancel ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](313, "button", 111);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_313_listener() {
          ctx.isDefectConfirm = true;
          return ctx.actionType = 2;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](314, "Save ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](315, VehicleInspectionComponent_span_315_Template, 2, 0, "span", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](316, VehicleInspectionComponent_button_316_Template, 2, 0, "button", 112);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](317, "div", 113)(318, "div", 114)(319, "div", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](320, "div", 116);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](321, "div", 117)(322, "div", 17)(323, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](324, "img", 118);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](325, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](326, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](327, VehicleInspectionComponent_div_327_Template, 2, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](328, VehicleInspectionComponent_div_328_Template, 4, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](329, VehicleInspectionComponent_div_329_Template, 4, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](330, VehicleInspectionComponent_div_330_Template, 2, 1, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](331, "br")(332, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](333, "button", 119);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_333_listener() {
          ctx.isCancelConfig = false;
          ctx.isDefectConfirm = false;
          return ctx.defectDelIndex = null;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](334, "img", 120);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](335, VehicleInspectionComponent_button_335_Template, 2, 0, "button", 121);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](336, VehicleInspectionComponent_button_336_Template, 2, 0, "button", 121);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](337, VehicleInspectionComponent_button_337_Template, 2, 0, "button", 121);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](338, "div", 122)(339, "div", 114)(340, "div", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](341, "div", 116);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](342, "div", 117)(343, "div", 17)(344, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](345, "img", 123);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](346, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](347, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](348, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](349);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](350, "br")(351, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](352, "button", 124);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](353, "img", 120);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](354, "button", 119);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_354_listener() {
          return ctx.deleteDefectItemList(ctx.defectDelIndex);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](355, "img", 125);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](356, "p-dialog", 126);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("visibleChange", function VehicleInspectionComponent_Template_p_dialog_visibleChange_356_listener($event) {
          return ctx.brakeVisiblility = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](357, "table", 127)(358, "thead")(359, "tr", 128)(360, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](361, "Description");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](362, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](363, "Left Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](364, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](365, "Right Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](366, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](367, "Weight");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](368, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](369, "Max Difference");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](370, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](371, "Actual Difference");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](372, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](373, "Min Deceleration");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](374, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](375, "Actual Deceleration");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](376, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](377, VehicleInspectionComponent_tr_377_Template, 17, 8, "tr", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](378, "p-dialog", 129);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("visibleChange", function VehicleInspectionComponent_Template_p_dialog_visibleChange_378_listener($event) {
          return ctx.exhaustVisiblility = $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](379, "table", 127)(380, "thead")(381, "tr", 128)(382, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](383, " Description ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](384, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](385, " Device Output Code ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](386, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](387, "Reading Value ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](388, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](389, "Operation");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](390, "th", 107);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](391, "Limit Value");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](392, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtemplate"](393, VehicleInspectionComponent_tr_393_Template, 11, 5, "tr", 91);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](394, "div", 130)(395, "div", 114)(396, "div", 115);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](397, "div", 116);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](398, "div", 117)(399, "div", 17)(400, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](401, "img", 123);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](402, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](403, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](404, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtext"](405, " Are you sure from tanker measurement values ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](406, "br")(407, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](408, "button", 124);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](409, "img", 120);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementStart"](410, "button", 119);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵlistener"]("click", function VehicleInspectionComponent_Template_button_click_410_listener() {
          return ctx.confirmTankerCertificate();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelement"](411, "img", 125);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵelementEnd"]()()()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("formGroup", ctx.insForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "details");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isVinService);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleProp"]("pointer-events", ctx.isConfirmedDefects || !ctx.insForm.get("isVinCh").value || !ctx.insForm.get("isPlateCh").value || !ctx.insForm.get("isManfCh").value ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "config");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService || !ctx.isTank);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleProp"]("pointer-events", ctx.isConfirmedDefects ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "tankdets");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleProp"]("pointer-events", !ctx.visualDefectActive || ctx.isConfirmedDefects || !ctx.insForm.get("isVinCh").value || !ctx.insForm.get("isPlateCh").value || !ctx.insForm.get("isManfCh").value ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "visual-defect");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleProp"]("pointer-events", !ctx.isConfirmedDefects ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "defect-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("hidden", ctx.isVinService || ctx.isTankerService);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" ", ctx.insForm.get("inspectiondetails").value.plateNo, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isTimerVisiable);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isDeviceStatusShown);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "details");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](105);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.isConfirmedDefects);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "vin");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isNewStamp);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isNewStamp);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isReStamp);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", !ctx.enableVinSubmit);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "tanker" || ctx.activeTab === "tankdets");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("formGroup", ctx.tankereRequestForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.tankerShapes);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("shapeId").hasError("required") && ctx.tankereRequestForm.get("shapeId").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("length").hasError("required") && ctx.tankereRequestForm.get("length").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("width").hasError("required") && ctx.tankereRequestForm.get("width").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("height").hasError("required") && ctx.tankereRequestForm.get("height").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("factor").hasError("required") && ctx.tankereRequestForm.get("factor").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.tankereRequestForm.get("remarks").hasError("required") && ctx.tankereRequestForm.get("remarks").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isTankerMeasurementDiffersFromLastYear);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("disabled", ctx.tankereRequestForm.invalid);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "inst");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.instructions);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "config");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.insForm.get("fuelTypes").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.insForm.get("driveModes").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.insForm.get("parkingBrakes").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("readonly", ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isExternal);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("readonly", ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.configDisabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "visual-defect");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵclassProp"]("active", ctx.activeTab === "defect-list");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.deviceResultsDto.isBrakeTested);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.deviceResultsDto.isExhaustEmissTested);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.isLocationEmpty);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.defectList);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.classificationsResult != undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.insForm.get("inspectiondetails").value.isFinalStep);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.insForm.get("inspectiondetails").value.isSectionSeqRequired);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.isDefectConfirm && ctx.activeTab == "defect-list" && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isDefectConfirm && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isCancelConfig && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.defectDelIndex != null && !ctx.isDefectConfirm && !ctx.isCancelConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.isDefectConfirm || ctx.isCancelConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", ctx.defectDelIndex != null && !ctx.isDefectConfirm && !ctx.isCancelConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngIf", !ctx.isDefectConfirm && ctx.activeTab == "defect-list" && ctx.defectDelIndex == null);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵtextInterpolate1"](" Are you sure you want to delete this ", ctx.confirmEval, " defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](101, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("visible", ctx.brakeVisiblility)("modal", true)("draggable", false)("resizable", false)("maximizable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](21);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.brakeReads);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵstyleMap"](_angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵpureFunction0"](102, _c2));
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("visible", ctx.exhaustVisiblility)("modal", true)("draggable", false)("resizable", false)("maximizable", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_21__["ɵɵproperty"]("ngForOf", ctx.exhaustEmissReads);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_25__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_25__.NgStyle, _angular_forms__WEBPACK_IMPORTED_MODULE_22__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_22__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_22__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormControlName, _angular_forms__WEBPACK_IMPORTED_MODULE_22__.FormGroupName, primeng_progressbar__WEBPACK_IMPORTED_MODULE_27__.ProgressBar, primeng_dialog__WEBPACK_IMPORTED_MODULE_28__.Dialog, primeng_tooltip__WEBPACK_IMPORTED_MODULE_29__.Tooltip, _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_20__.VisualDefectListComponent],
    styles: ["#confirmationModal[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    font-size: 20px;\r\n}\r\n\r\n#confirmationModal2[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    font-size: 20px;\r\n}\r\n\r\n#confirmationModalDel[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    font-size: 20px;\r\n}\r\n\r\n.device-status[_ngcontent-%COMP%] {\r\n    padding: 10px;\r\n}\r\n\r\n#plno[_ngcontent-%COMP%] {\r\n    padding: 20px;\r\n    float: right;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    color: red;\r\n    font-style: italic;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n    appearance: none;\r\n    margin: 0;\r\n}\r\n\r\n#v-details[_ngcontent-%COMP%] {\r\n    background-color: #ffff;\r\n}\r\n\r\nh2[_ngcontent-%COMP%] {\r\n    border: 0px;\r\n}\r\n\r\n.accordion-item[_ngcontent-%COMP%] {\r\n    border: 0px;\r\n}\r\n\r\n[_ngcontent-%COMP%]::placeholder {\r\n    font-size: 14px;\r\n    color: grey !important;\r\n    opacity: 0.5;\r\n    font-style: italic;\r\n}\r\n\r\n#btnConfirm[_ngcontent-%COMP%] {\r\n    margin-top: 0;\r\n}\r\n\r\n.end-btns[_ngcontent-%COMP%] {\r\n    margin-top: 0px;\r\n}\r\n\r\n#techLeg[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin-bottom: 30px;\r\n    display: flex;\r\n    justify-content: center;\r\n}\r\n\r\n#defRes[_ngcontent-%COMP%] {\r\n    border-radius: 5px;\r\n    padding: 10px;\r\n    width: 600px !important;\r\n    background-color: #ffff;\r\n    color: #ef9c3d;\r\n    font-weight: bold;\r\n    font-size: large;\r\n    margin-right: 20px;\r\n    margin-left: 200px;\r\n}\r\n\r\n.pass[_ngcontent-%COMP%] {\r\n    border: 1px solid rgb(35, 168, 35);\r\n    border-radius: 5px;\r\n    padding: 10px;\r\n    width: 200px;\r\n    color: rgb(35, 168, 35);\r\n    background-color: #ffff;\r\n    font-weight: bold;\r\n    justify-content: center;\r\n    margin-right: 40px;\r\n}\r\n\r\n.fail[_ngcontent-%COMP%] {\r\n    border: 1px solid red;\r\n    border-radius: 5px;\r\n    padding: 10px;\r\n    width: 200px;\r\n    color: red;\r\n    background-color: #ffff;\r\n    font-weight: bold;\r\n    justify-content: center;\r\n    margin-left: 40px;\r\n}\r\n\r\n.defect-device-result[_ngcontent-%COMP%] {\r\n    font-size: 19px;\r\n    text-align: right;\r\n}\r\n\r\n.defect-list-title[_ngcontent-%COMP%] {\r\n    float: left;\r\n}\r\n\r\np-dialog[_ngcontent-%COMP%]   table[_ngcontent-%COMP%] {\r\n    width: 100% !important;\r\n}\r\n\r\n.classification-result[_ngcontent-%COMP%] {\r\n    margin: 27px;\r\n    font-size: medium;\r\n    font-weight: 700;\r\n}\r\n\r\n.chkbx[_ngcontent-%COMP%] {\r\n    width: 1.5em;\r\n    height: 1.5em;\r\n}\r\n\r\n.chkbx[_ngcontent-%COMP%]:focus {\r\n    outline: none;\r\n    border: none;\r\n}\r\n\r\n.chkbx[_ngcontent-%COMP%]   input[type=\"checkbox\"][_ngcontent-%COMP%]:checked {\r\n    background-color: #F89828 !important;\r\n    border: solid 1px #F89828 !important;\r\n}\r\n\r\ninput[type=\"checkbox\"][_ngcontent-%COMP%] {\r\n    margin-right: 10px;\r\n    color: #ef9c3d;\r\n}\r\n\r\n.form-check-label[_ngcontent-%COMP%] {\r\n    margin-left: 5px;\r\n    color: black;\r\n}\r\n\r\n#rcb[_ngcontent-%COMP%] {\r\n    margin-top: 5px;\r\n}\r\n\r\n#tankerConfirmationModal[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    font-size: 20px;\r\n}\r\n\r\n#checkDets[_ngcontent-%COMP%] {\r\n    border: 1px solid #ef9c3d;\r\n    width: 200px;\r\n    border-radius: 10px;\r\n    font-size: larger;\r\n    margin-bottom: 20px;\r\n}\r\n\r\n#v1[_ngcontent-%COMP%], #p1[_ngcontent-%COMP%], #m1[_ngcontent-%COMP%] {\r\n    color: black;\r\n}\r\n\r\n#highlightText[_ngcontent-%COMP%] {\r\n    border: 1px solid #ef9c3d;\r\n}\r\n\r\n.stop-watch[_ngcontent-%COMP%] {\r\n    font-family: 'Source Code Pro', monospace;\r\n    text-align: center;\r\n    font-size: 2em;\r\n    padding: 30px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL2NvbXBvbmVudHMvdmVoaWNsZS1pbnNwZWN0aW9uL3ZlaGljbGUtaW5zcGVjdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGtCQUFrQjtJQUNsQixlQUFlO0FBQ25COztBQUVBO0lBQ0ksYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGFBQWE7SUFDYixZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksVUFBVTtJQUNWLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHlCQUF5QjtJQUN6QixZQUFZO0FBQ2hCOztBQUVBOztJQUdJLGdCQUFnQjtJQUNoQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSx1QkFBdUI7QUFDM0I7O0FBRUE7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxlQUFlO0lBQ2Ysc0JBQXNCO0lBQ3RCLFlBQVk7SUFDWixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsYUFBYTtJQUNiLHVCQUF1QjtBQUMzQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2QsaUJBQWlCO0lBQ2pCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksa0NBQWtDO0lBQ2xDLGtCQUFrQjtJQUNsQixhQUFhO0lBQ2IsWUFBWTtJQUNaLHVCQUF1QjtJQUN2Qix1QkFBdUI7SUFDdkIsaUJBQWlCO0lBQ2pCLHVCQUF1QjtJQUN2QixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxxQkFBcUI7SUFDckIsa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixZQUFZO0lBQ1osVUFBVTtJQUNWLHVCQUF1QjtJQUN2QixpQkFBaUI7SUFDakIsdUJBQXVCO0lBQ3ZCLGlCQUFpQjtBQUNyQjs7QUFFQTtJQUNJLGVBQWU7SUFDZixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxzQkFBc0I7QUFDMUI7O0FBRUE7SUFDSSxZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLFlBQVk7SUFDWixhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksYUFBYTtJQUNiLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxvQ0FBb0M7SUFDcEMsb0NBQW9DO0FBQ3hDOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixpQkFBaUI7SUFDakIsbUJBQW1CO0FBQ3ZCOztBQUVBOzs7SUFHSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0kseUJBQXlCO0FBQzdCOztBQUVBO0lBQ0kseUNBQXlDO0lBQ3pDLGtCQUFrQjtJQUNsQixjQUFjO0lBQ2QsYUFBYTtBQUNqQiIsInNvdXJjZXNDb250ZW50IjpbIiNjb25maXJtYXRpb25Nb2RhbCB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuI2NvbmZpcm1hdGlvbk1vZGFsMiB7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuI2NvbmZpcm1hdGlvbk1vZGFsRGVsIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4uZGV2aWNlLXN0YXR1cyB7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcblxyXG4jcGxubyB7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcblxyXG4uZXJyb3ItbWVzc2FnZSB7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59XHJcblxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxyXG5pbnB1dFt0eXBlPVwibnVtYmVyXCJdOjotd2Via2l0LW91dGVyLXNwaW4tYnV0dG9uIHtcclxuICAgIC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbiN2LWRldGFpbHMge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmY7XHJcbn1cclxuXHJcbmgyIHtcclxuICAgIGJvcmRlcjogMHB4O1xyXG59XHJcblxyXG4uYWNjb3JkaW9uLWl0ZW0ge1xyXG4gICAgYm9yZGVyOiAwcHg7XHJcbn1cclxuXHJcbjo6cGxhY2Vob2xkZXIge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6IGdyZXkgIWltcG9ydGFudDtcclxuICAgIG9wYWNpdHk6IDAuNTtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxufVxyXG5cclxuI2J0bkNvbmZpcm0ge1xyXG4gICAgbWFyZ2luLXRvcDogMDtcclxufVxyXG5cclxuLmVuZC1idG5zIHtcclxuICAgIG1hcmdpbi10b3A6IDBweDtcclxufVxyXG5cclxuI3RlY2hMZWcge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuI2RlZlJlcyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgd2lkdGg6IDYwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZjtcclxuICAgIGNvbG9yOiAjZWY5YzNkO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IGxhcmdlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwMHB4O1xyXG59XHJcblxyXG4ucGFzcyB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMzUsIDE2OCwgMzUpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICAgIGNvbG9yOiByZ2IoMzUsIDE2OCwgMzUpO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmY7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xyXG59XHJcblxyXG4uZmFpbCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZWQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgd2lkdGg6IDIwMHB4O1xyXG4gICAgY29sb3I6IHJlZDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIG1hcmdpbi1sZWZ0OiA0MHB4O1xyXG59XHJcblxyXG4uZGVmZWN0LWRldmljZS1yZXN1bHQge1xyXG4gICAgZm9udC1zaXplOiAxOXB4O1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbn1cclxuXHJcbi5kZWZlY3QtbGlzdC10aXRsZSB7XHJcbiAgICBmbG9hdDogbGVmdDtcclxufVxyXG5cclxucC1kaWFsb2cgdGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmNsYXNzaWZpY2F0aW9uLXJlc3VsdCB7XHJcbiAgICBtYXJnaW46IDI3cHg7XHJcbiAgICBmb250LXNpemU6IG1lZGl1bTtcclxuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbn1cclxuXHJcbi5jaGtieCB7XHJcbiAgICB3aWR0aDogMS41ZW07XHJcbiAgICBoZWlnaHQ6IDEuNWVtO1xyXG59XHJcblxyXG4uY2hrYng6Zm9jdXMge1xyXG4gICAgb3V0bGluZTogbm9uZTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLmNoa2J4IGlucHV0W3R5cGU9XCJjaGVja2JveFwiXTpjaGVja2VkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGODk4MjggIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICNGODk4MjggIWltcG9ydGFudDtcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdIHtcclxuICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgIGNvbG9yOiAjZWY5YzNkO1xyXG59XHJcblxyXG4uZm9ybS1jaGVjay1sYWJlbCB7XHJcbiAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG59XHJcblxyXG4jcmNiIHtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxufVxyXG5cclxuI3RhbmtlckNvbmZpcm1hdGlvbk1vZGFsIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcblxyXG4jY2hlY2tEZXRzIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNlZjljM2Q7XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgZm9udC1zaXplOiBsYXJnZXI7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG4jdjEsXHJcbiNwMSxcclxuI20xIHtcclxuICAgIGNvbG9yOiBibGFjaztcclxufVxyXG5cclxuI2hpZ2hsaWdodFRleHQge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2VmOWMzZDtcclxufVxyXG5cclxuLnN0b3Atd2F0Y2gge1xyXG4gICAgZm9udC1mYW1pbHk6ICdTb3VyY2UgQ29kZSBQcm8nLCBtb25vc3BhY2U7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDJlbTtcclxuICAgIHBhZGRpbmc6IDMwcHg7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9 */"]
  });
}

/***/ }),

/***/ 75303:
/*!*****************************************************************************************!*\
  !*** ./src/app/modules/inspection/external-inspection/external-inspection.component.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExternalInspectionComponent": () => (/* binding */ ExternalInspectionComponent)
/* harmony export */ });
/* harmony import */ var src_app_core_utilities_enums_external_inspection_status__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/external-inspection-status */ 33219);
/* harmony import */ var src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/object-value-checker */ 12452);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);










function ExternalInspectionComponent_option_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const area_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", area_r5.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", area_r5.labelEname, " ");
  }
}
function ExternalInspectionComponent_option_18_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const location_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", location_r6.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"]("", location_r6.labelEname, " ");
  }
}
function ExternalInspectionComponent_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " Date to must be more than date from ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
  }
}
function ExternalInspectionComponent_tr_65_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](9, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](11, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](15, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](17, "td")(18, "button", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_tr_65_Template_button_click_18_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r9);
      const ext_r7 = restoredCtx.$implicit;
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r8.startExternalInspection(ext_r7));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](19, " Start External Inspection ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ext_r7 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.receiptNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.plateNo, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.customerId, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.customerName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.contactPersonPhone, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.areaEname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ext_r7.locationEname, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ext_r7.externalVehicleStatusDescriptionEn);
  }
}
const _c0 = function (a0) {
  return {
    "active": a0
  };
};
function ExternalInspectionComponent_li_71_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "li", 33)(1, "a", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_li_71_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r12);
      const i_r10 = restoredCtx.$implicit;
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      ctx_r11.currentPage = i_r10 + 1;
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r11.getPagedExternal(ctx_r11.currentPage));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const i_r10 = ctx.$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](2, _c0, ctx_r4.currentPage === i_r10 + 1));
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](i_r10 + 1);
  }
}
const _c1 = function (a0) {
  return {
    "disabled": a0
  };
};
class ExternalInspectionComponent {
  constructor(inspectionService, vehicleService, fb, sharedData, router, sideNav) {
    this.inspectionService = inspectionService;
    this.vehicleService = vehicleService;
    this.fb = fb;
    this.sharedData = sharedData;
    this.router = router;
    this.sideNav = sideNav;
    this.areaList = [];
    this.externalRequest = [];
    this.currentPage = 1;
    this.itemsPerPage = 10;
    this.externalInspectionStatus = src_app_core_utilities_enums_external_inspection_status__WEBPACK_IMPORTED_MODULE_0__.ExternalInpsectionStatus;
    this.isDateFilterValid = true;
    this.extInspectionForm = fb.group({
      selectedArea: [''],
      selectedLocation: [''],
      custName: [''],
      fromDate: [''],
      toDate: [''],
      receiptNo: ['']
    });
  }
  ngOnInit() {
    this.sideNav.setHeaderValue(true, false);
    this.sideNav.setActiveEnt(3, 80);
    this.stationId = parseInt(localStorage.getItem("stationId"));
    const extReq = {
      itemsFilter: {
        locationId: null,
        areaId: null,
        customerName: null,
        stationId: this.stationId,
        fromDate: null,
        toDate: null,
        receiptNo: null
      },
      pageIndex: 1,
      pageSize: this.itemsPerPage
    };
    this.inspectionService.getExternalInspectionRequests(extReq).subscribe(response => {
      this.externalRequest = response.items.result;
      this.totalExt = response.items.totalRecords;
    });
    this.vehicleService.getAreas().subscribe(data => {
      this.areaList = data.items;
    });
  }
  checkAndSetToDate() {
    let toDate = this.extInspectionForm.get('toDate').value;
    let toDateObj = new Date(toDate);
    toDateObj.setHours(23, 59, 59, 999);
    console.log(toDateObj.toISOString());
    toDate = toDateObj.toISOString();
    this.updatedToDate = toDate;
  }
  validateDateFilter() {
    this.checkAndSetToDate();
    if (new Date(this.extInspectionForm.get('fromDate').value) > new Date(this.extInspectionForm.get('toDate').value)) {
      this.isDateFilterValid = false;
    } else {
      this.isDateFilterValid = true;
    }
  }
  getLocationArea() {
    this.vehicleService.getAreaLocations(this.extInspectionForm.get('selectedArea').value).subscribe(data => {
      this.locationList = data.items;
    });
    this.extInspectionForm.get('selectedLocation').setValue(this.extInspectionForm.get('selectedArea').value != 0 ? this.extInspectionForm.get('selectedArea').value : null);
  }
  filterExternal(action) {
    // Action:
    // 1 -> filter
    // 2 -> clear
    let extReq;
    if (action == 1) {
      extReq = {
        itemsFilter: {
          locationId: this.extInspectionForm.get('selectedLocation').value ? this.extInspectionForm.get('selectedLocation').value : null,
          areaId: this.extInspectionForm.get('selectedArea').value ? this.extInspectionForm.get('selectedArea').value : null,
          customerName: this.extInspectionForm.get('custName').value,
          stationId: this.stationId,
          fromDate: this.extInspectionForm.get('fromDate').value != "" ? new Date(this.extInspectionForm.get('fromDate').value) : null,
          toDate: this.extInspectionForm.get('toDate').value != "" ? this.updatedToDate : null,
          receiptNo: this.extInspectionForm.get('receiptNo').value
        },
        pageIndex: 1,
        pageSize: this.itemsPerPage
      };
    } else {
      this.extInspectionForm.get('selectedLocation').setValue(null);
      this.extInspectionForm.get('selectedArea').setValue(null);
      this.extInspectionForm.get('custName').setValue('');
      this.extInspectionForm.get('fromDate').setValue('');
      this.extInspectionForm.get('toDate').setValue('');
      this.extInspectionForm.get('receiptNo').setValue('');
      extReq = {
        itemsFilter: {
          locationId: null,
          areaId: null,
          customerName: null,
          stationId: this.stationId,
          fromDate: null,
          toDate: null,
          receiptNo: null
        },
        pageIndex: 1,
        pageSize: this.itemsPerPage
      };
    }
    this.inspectionService.getExternalInspectionRequests(extReq).subscribe(response => {
      this.externalRequest = response.items.result;
      this.totalExt = response.items.totalRecords;
    });
  }
  get totalPages() {
    if (this.totalExt > this.itemsPerPage) {
      return Math.ceil(this.totalExt / this.itemsPerPage);
    } else {
      return 1;
    }
  }
  pagesArray(totalPages) {
    return Array.from({
      length: totalPages
    }, (_, index) => index);
  }
  getPagedExternal(page) {
    const extReq = {
      itemsFilter: {
        locationId: this.extInspectionForm.get('selectedLocation').value ? this.extInspectionForm.get('selectedLocation').value : null,
        areaId: this.extInspectionForm.get('selectedArea').value ? this.extInspectionForm.get('selectedArea').value : null,
        customerName: this.extInspectionForm.get('custName').value,
        stationId: this.stationId,
        fromDate: this.extInspectionForm.get('fromDate').value != "" ? new Date(this.extInspectionForm.get('fromDate').value) : null,
        toDate: this.extInspectionForm.get('toDate').value != "" ? new Date(this.extInspectionForm.get('toDate').value) : null,
        receiptNo: this.extInspectionForm.get('receiptNo').value ? this.extInspectionForm.get('receiptNo').value.toString() : null
      },
      pageIndex: page,
      pageSize: this.itemsPerPage
    };
    this.inspectionService.getExternalInspectionRequests(extReq).subscribe(response => {
      this.externalRequest = response.items.result;
      this.totalExt = response.items.totalRecords;
    });
  }
  startExternalInspection(ext) {
    // Reset the saved defect data from shared component
    //  this.sharedData.resetDefCmnt();
    //  this.sharedData.resetSaveDefectSrc();
    let startExternalRequestBody = {
      plateNo: ext.plateNo,
      plateType: ext.plateType,
      vinNo: ext.vinNo,
      requestId: ext.requestId
    };
    this.inspectionService.startExternalInspectionRequest(startExternalRequestBody).subscribe(res => {
      var test = src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_1__.ObjectValueChecker.isNullOrEmpty(res.errorMessage);
      if (!src_app_core_utilities_object_value_checker__WEBPACK_IMPORTED_MODULE_1__.ObjectValueChecker.isNullOrEmpty(res.errorMessage)) {
        this.sharedData.setExternalPlateType(ext.plateType > 9 ? ext.plateType : '0' + ext.plateType);
        this.sharedData.setExternalPlateNumber(ext.plateNo);
        this.sharedData.setExternalIns(true);
        this.router.navigate(['/inspection/vehicle-inspection']);
      }
    });
  }
  static #_ = this.ɵfac = function ExternalInspectionComponent_Factory(t) {
    return new (t || ExternalInspectionComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_2__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_3__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_4__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_5__.SidenavService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: ExternalInspectionComponent,
    selectors: [["app-external-inspection"]],
    decls: 75,
    vars: 13,
    consts: [[3, "formGroup"], [1, "filter-section"], [1, "row", "mb-4"], [1, "col-lg-6"], [1, "row"], [1, "col-md-4"], ["formControlName", "selectedArea", 1, "form-control", 3, "change"], ["value", ""], [3, "value", 4, "ngFor", "ngForOf"], ["formControlName", "selectedLocation", 1, "form-control"], ["type", "text", "formControlName", "receiptNo", 1, "form-control"], ["type", "text", "formControlName", "custName", 1, "form-control"], ["type", "date", "formControlName", "fromDate", 1, "form-control", 3, "ngModelChange"], ["type", "date", "formControlName", "toDate", 1, "form-control", 3, "ngModelChange"], ["class", "error-message", 4, "ngIf"], ["id", "btnFilter", 1, "col-md-4"], ["id", "btFilter", 1, "btn", "btn-outline-orange", 3, "disabled", "click"], ["id", "btClear", 1, "btn", "btn-outline-gray", 3, "click"], [1, "container", "mt-4"], [1, "table-bordered", "table-striped"], ["id", "headertb"], ["scope", "col"], [4, "ngFor", "ngForOf"], [1, "pagination-container"], [1, "pagination"], [1, "page-item"], [1, "page-link", 3, "ngClass", "click"], [1, "bi", "bi-chevron-left"], ["class", "page-item", 3, "ngClass", 4, "ngFor", "ngForOf"], [1, "bi", "bi-chevron-right"], [3, "value"], [1, "error-message"], ["id", "btnExt", 1, "btn", "btn-outline-orange", 3, "click"], [1, "page-item", 3, "ngClass"], ["id", "pagesId", 1, "page-link", 3, "click"]],
    template: function ExternalInspectionComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "html")(1, "body")(2, "form", 0)(3, "div", 1)(4, "div", 2)(5, "div", 3)(6, "div", 4)(7, "div", 5)(8, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](9, " Area ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](10, "select", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("change", function ExternalInspectionComponent_Template_select_change_10_listener() {
          return ctx.getLocationArea();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](11, "option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](12, ExternalInspectionComponent_option_12_Template, 2, 2, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "div", 5)(14, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](15, " Location ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "select", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](17, "option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](18, ExternalInspectionComponent_option_18_Template, 2, 2, "option", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](19, "div", 5)(20, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](21, " Receipt No ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](22, "input", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](23, "div", 5)(24, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](25, " Customer Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](26, "input", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](27, "div", 5)(28, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](29, " From Date ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](30, "input", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ExternalInspectionComponent_Template_input_ngModelChange_30_listener() {
          return ctx.validateDateFilter();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "div", 5)(32, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](33, " To Date ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](34, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function ExternalInspectionComponent_Template_input_ngModelChange_34_listener() {
          return ctx.validateDateFilter();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](35, ExternalInspectionComponent_div_35_Template, 2, 0, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](36, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](37, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](38, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_button_click_38_listener() {
          return ctx.filterExternal(1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](39, " Filter Results ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](40, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_button_click_40_listener() {
          return ctx.filterExternal(2);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](41, " Clear Filter");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](42, "div", 18)(43, "table", 19)(44, "thead")(45, "tr", 20)(46, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](47, " Receipt No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](49, " Plate No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](50, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](51, " Customer ID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](52, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](53, " Customer Name ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](54, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](55, " Phone No. ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](57, " Area ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](58, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](59, " Location ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](60, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](61, " Status ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](62, "th", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](63, " Action ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](64, "tbody");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](65, ExternalInspectionComponent_tr_65_Template, 20, 8, "tr", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "div", 23)(67, "ul", 24)(68, "li", 25)(69, "a", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_a_click_69_listener() {
          ctx.currentPage = ctx.currentPage - 1;
          return ctx.getPagedExternal(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](70, "i", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](71, ExternalInspectionComponent_li_71_Template, 3, 4, "li", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](72, "li", 25)(73, "a", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ExternalInspectionComponent_Template_a_click_73_listener() {
          ctx.currentPage = ctx.currentPage + 1;
          return ctx.getPagedExternal(ctx.currentPage);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](74, "i", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formGroup", ctx.extInspectionForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.areaList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.locationList);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx.isDateFilterValid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("disabled", !ctx.isDateFilterValid);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.externalRequest);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](9, _c1, ctx.currentPage == 1));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.pagesArray(ctx.totalPages));
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵpureFunction1"](11, _c1, ctx.currentPage * ctx.itemsPerPage >= ctx.totalExt));
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_7__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlName],
    styles: ["table[_ngcontent-%COMP%] {\r\n    margin-top: 50px;\r\n    text-align: center;\r\n    width: 100%;\r\n    border-collapse: collapse;\r\n    border-color: #fff;\r\n}\r\n\r\n#btnSearch[_ngcontent-%COMP%] {\r\n    float: right;\r\n}\r\n\r\n#btnExt[_ngcontent-%COMP%] {\r\n    font-size: 15px;\r\n}\r\n\r\n.pagination-container[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    margin-left: 500px;\r\n}\r\n\r\n.page-item[_ngcontent-%COMP%] {\r\n    margin: 0 2px;\r\n}\r\n\r\n.page-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n    padding: 5px 5px;\r\n    text-decoration: none;\r\n}\r\n\r\n#pagesId[_ngcontent-%COMP%] {\r\n    background-color: white;\r\n    color: #F89828;\r\n}\r\n\r\nli.page-item.active[_ngcontent-%COMP%]   #pagesId[_ngcontent-%COMP%] {\r\n    background-color: #F89828;\r\n    color: white;\r\n    font-weight: bold;\r\n    border-color: #F89828;\r\n}\r\n\r\n.bi[_ngcontent-%COMP%] {\r\n    color: #F89828;\r\n}\r\n\r\n#btnFilter[_ngcontent-%COMP%] {\r\n    margin-top: 25px;\r\n}\r\n\r\n#btFilter[_ngcontent-%COMP%] {\r\n    margin-right: 5px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL2V4dGVybmFsLWluc3BlY3Rpb24vZXh0ZXJuYWwtaW5zcGVjdGlvbi5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixXQUFXO0lBQ1gseUJBQXlCO0lBQ3pCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLFlBQVk7QUFDaEI7O0FBRUE7SUFDSSxlQUFlO0FBQ25COztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGFBQWE7QUFDakI7O0FBRUE7SUFDSSxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLHVCQUF1QjtJQUN2QixjQUFjO0FBQ2xCOztBQUVBO0lBQ0kseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixpQkFBaUI7SUFDakIscUJBQXFCO0FBQ3pCOztBQUVBO0lBQ0ksY0FBYztBQUNsQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGlCQUFpQjtBQUNyQiIsInNvdXJjZXNDb250ZW50IjpbInRhYmxlIHtcclxuICAgIG1hcmdpbi10b3A6IDUwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICBib3JkZXItY29sb3I6ICNmZmY7XHJcbn1cclxuXHJcbiNidG5TZWFyY2gge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcblxyXG4jYnRuRXh0IHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG5cclxuLnBhZ2luYXRpb24tY29udGFpbmVyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi1sZWZ0OiA1MDBweDtcclxufVxyXG5cclxuLnBhZ2UtaXRlbSB7XHJcbiAgICBtYXJnaW46IDAgMnB4O1xyXG59XHJcblxyXG4ucGFnZS1saW5rIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHBhZGRpbmc6IDVweCA1cHg7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuXHJcbiNwYWdlc0lkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgY29sb3I6ICNGODk4Mjg7XHJcbn1cclxuXHJcbmxpLnBhZ2UtaXRlbS5hY3RpdmUgI3BhZ2VzSWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Y4OTgyODtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgYm9yZGVyLWNvbG9yOiAjRjg5ODI4O1xyXG59XHJcblxyXG4uYmkge1xyXG4gICAgY29sb3I6ICNGODk4Mjg7XHJcbn1cclxuXHJcbiNidG5GaWx0ZXIge1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxufVxyXG5cclxuI2J0RmlsdGVyIHtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 98442:
/*!*****************************************************************!*\
  !*** ./src/app/modules/inspection/inspection-base.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionBaseComponent": () => (/* binding */ InspectionBaseComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 60124);


class InspectionBaseComponent {
  static #_ = this.ɵfac = function InspectionBaseComponent_Factory(t) {
    return new (t || InspectionBaseComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: InspectionBaseComponent,
    selectors: [["app-inspection-base"]],
    decls: 1,
    vars: 0,
    template: function InspectionBaseComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    encapsulation: 2
  });
}

/***/ }),

/***/ 81473:
/*!*********************************************************!*\
  !*** ./src/app/modules/inspection/inspection.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionModule": () => (/* binding */ InspectionModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var primeng_progressbar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! primeng/progressbar */ 88395);
/* harmony import */ var primeng_badge__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! primeng/badge */ 52381);
/* harmony import */ var _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./components/landing-page/landing-page.component */ 16564);
/* harmony import */ var _inspection_base_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inspection-base.component */ 98442);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _components_vehicle_inspection_vehicle_inspection_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/vehicle-inspection/vehicle-inspection.component */ 59560);
/* harmony import */ var _pages_visualDefect_main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/visualDefect/main-visual-defect/main-visual-defect.component */ 26591);
/* harmony import */ var _pages_visualDefect_sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/visualDefect/sub-visual-defect/sub-visual-defect.component */ 39481);
/* harmony import */ var _pages_visualDefect_sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/visualDefect/sub-visual-defect-comments/sub-visual-defect-comments.component */ 97226);
/* harmony import */ var _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/visualDefect/visual-defect-list/visual-defect-list.component */ 12207);
/* harmony import */ var _external_inspection_external_inspection_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./external-inspection/external-inspection.component */ 75303);
/* harmony import */ var _pages_visualDefect_popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/visualDefect/popup-defect/popup-defect.component */ 92961);
/* harmony import */ var _pages_visualDefect_confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/visualDefect/confirm-defects/confirm-defects.component */ 17767);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var primeng_tooltip__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! primeng/tooltip */ 24329);
/* harmony import */ var _components_delete_confirm_delete_confirm_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./components/delete-confirm/delete-confirm.component */ 82412);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 22560);





















const routes = [{
  path: '',
  component: _inspection_base_component__WEBPACK_IMPORTED_MODULE_1__.InspectionBaseComponent,
  children: [{
    path: 'landing-inspection',
    component: _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent
  }, {
    path: 'vehicle-inspection',
    component: _components_vehicle_inspection_vehicle_inspection_component__WEBPACK_IMPORTED_MODULE_3__.VehicleInspectionComponent
  }, {
    path: 'external-inspection',
    component: _external_inspection_external_inspection_component__WEBPACK_IMPORTED_MODULE_8__.ExternalInspectionComponent
  }]
}];
class InspectionModule {
  static #_ = this.ɵfac = function InspectionModule_Factory(t) {
    return new (t || InspectionModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineNgModule"]({
    type: InspectionModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule.forChild(routes), _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, primeng_progressbar__WEBPACK_IMPORTED_MODULE_16__.ProgressBarModule, primeng_badge__WEBPACK_IMPORTED_MODULE_17__.BadgeModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_18__.DialogModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_19__.TooltipModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_12__["ɵɵsetNgModuleScope"](InspectionModule, {
    declarations: [_inspection_base_component__WEBPACK_IMPORTED_MODULE_1__.InspectionBaseComponent, _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_0__.LandingPageComponent, _components_vehicle_inspection_vehicle_inspection_component__WEBPACK_IMPORTED_MODULE_3__.VehicleInspectionComponent, _pages_visualDefect_main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_4__.MainVisualDefectComponent, _pages_visualDefect_sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_5__.SubVisualDefectComponent, _pages_visualDefect_sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_6__.SubVisualDefectCommentsComponent, _pages_visualDefect_visual_defect_list_visual_defect_list_component__WEBPACK_IMPORTED_MODULE_7__.VisualDefectListComponent, _external_inspection_external_inspection_component__WEBPACK_IMPORTED_MODULE_8__.ExternalInspectionComponent, _pages_visualDefect_popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_9__.PopupDefectComponent, _pages_visualDefect_confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_10__.ConfirmDefectsComponent, _components_delete_confirm_delete_confirm_component__WEBPACK_IMPORTED_MODULE_11__.DeleteConfirmComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_13__.CommonModule, _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouterModule, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormsModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, primeng_progressbar__WEBPACK_IMPORTED_MODULE_16__.ProgressBarModule, primeng_badge__WEBPACK_IMPORTED_MODULE_17__.BadgeModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_18__.DialogModule, primeng_tooltip__WEBPACK_IMPORTED_MODULE_19__.TooltipModule]
  });
})();

/***/ }),

/***/ 17767:
/*!****************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/confirm-defects/confirm-defects.component.ts ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfirmDefectsComponent": () => (/* binding */ ConfirmDefectsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);





function ConfirmDefectsComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Are you sure no more defects to be added ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ConfirmDefectsComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Are you sure there are no defects ? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function ConfirmDefectsComponent_button_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ConfirmDefectsComponent_button_18_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r3.confirmSaveDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
class ConfirmDefectsComponent {
  constructor(sharedService, visualDefectService, globalServ) {
    this.sharedService = sharedService;
    this.visualDefectService = visualDefectService;
    this.globalServ = globalServ;
    this.deletionTrigger = false;
    this.isDefect = false;
    this.reviewClick = false;
    this.saveSubDefectComments = [];
    this.formDataArray = [];
  }
  ngOnChanges(changes) {
    console.log(changes);
    this.sharedService.isDeleteDefCmnt$.subscribe(del => {
      this.deletionTrigger = del;
      console.log(this.deletionTrigger);
      if (this.deletionTrigger) {
        console.log('Deletion occurred, refreshing...');
        this.sharedService.defectCommentList$.subscribe(def => {
          if (def) {
            def.length > 0 ? this.isDefect = true : this.isDefect = false;
            console.log(def.length);
            console.log(this.isDefect);
          }
        });
      }
      console.log(this.isDefect);
    });
  }
  ngOnInit() {
    this.sharedService.defectCommentList$.subscribe(def => {
      if (def) {
        def.length > 0 ? this.isDefect = true : this.isDefect = false;
      }
    });
  }
  confirmSaveDefects() {
    if (this.isDefect) {
      this.sharedService.saveSubDefectComments$.subscribe(saveDef => {
        console.log(saveDef);
        if (saveDef) {
          this.saveSubDefectComments = saveDef;
          if (this.reviewClick) {
            console.log("CLICK ON CREATE INS REVIEWWWWWW");
            this.visualDefectService.createInspectionResult(this.saveSubDefectComments).subscribe(response => {
              if (response.items) {
                this.sharedService.setConfirmDef(true);
                this.sharedService.resetDefCmnt();
                this.sharedService.resetSaveDefectSrc();
                this.sharedService.formData$.subscribe(files => {
                  this.formDataArray = files;
                });
                for (const file of this.formDataArray) {
                  this.globalServ.uploadAttachement(file).subscribe(response => {});
                }
                this.reviewClick = false;
              }
            });
          }
        }
      });
    } else {
      this.sharedService.setConfirmDef(true);
    }
  }
  static #_ = this.ɵfac = function ConfirmDefectsComponent_Factory(t) {
    return new (t || ConfirmDefectsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_2__.GlobalConfigService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: ConfirmDefectsComponent,
    selectors: [["app-confirm-defects"]],
    inputs: {
      deletionTrigger: "deletionTrigger"
    },
    features: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵNgOnChangesFeature"]],
    decls: 19,
    vars: 3,
    consts: [["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#confirmationModal2", 1, "btn", "btn-orange", 3, "click"], ["id", "confirmationModal2", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-body"], [1, "row"], [1, "col-12"], ["src", "./assets/img/red-question.svg", "width", "40px"], [4, "ngIf"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "class", "btn btn-outline-secondary border-0", "data-bs-dismiss", "modal", 3, "click", 4, "ngIf"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"]],
    template: function ConfirmDefectsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function ConfirmDefectsComponent_Template_button_click_0_listener() {
          return ctx.reviewClick = true;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Review");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 1)(3, "div", 2)(4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 5)(7, "div", 6)(8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, ConfirmDefectsComponent_div_12_Template, 2, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, ConfirmDefectsComponent_div_13_Template, 2, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](14, "br")(15, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](17, "img", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](18, ConfirmDefectsComponent_button_18_Template, 2, 0, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isDefect);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.isDefect);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.reviewClick);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf],
    styles: ["#confirmationModal2[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    font-size: 20px;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9jb25maXJtLWRlZmVjdHMvY29uZmlybS1kZWZlY3RzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLGVBQWU7QUFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyIjY29uZmlybWF0aW9uTW9kYWwyIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 26591:
/*!**********************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/main-visual-defect/main-visual-defect.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainVisualDefectComponent": () => (/* binding */ MainVisualDefectComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_utilities_enums_main_defects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/main-defects */ 54733);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../confirm-defects/confirm-defects.component */ 17767);








function MainVisualDefectComponent_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 3)(1, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MainVisualDefectComponent_div_12_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r5);
      const defect_r3 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r4.onSelectDefect(defect_r3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 15)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 18)(6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const defect_r3 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r0.getDefectIconByDefectId(defect_r3 == null ? null : defect_r3.mainDefectId), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", defect_r3 == null ? null : defect_r3.mainDefectId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", defect_r3 == null ? null : defect_r3.defectNameEn, "");
  }
}
function MainVisualDefectComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 3)(1, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MainVisualDefectComponent_div_14_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.onSelectDefect(ctx_r6.legalRequirement));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 19)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 18)(6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", ctx_r1.getDefectIconByDefectId(ctx_r1.legalRequirement == null ? null : ctx_r1.legalRequirement.mainDefectId), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r1.legalRequirement == null ? null : ctx_r1.legalRequirement.mainDefectId, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.legalRequirement == null ? null : ctx_r1.legalRequirement.defectNameEn);
  }
}
function MainVisualDefectComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 3)(1, "a", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function MainVisualDefectComponent_div_15_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r9);
      const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r8.showAllComments());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 20)(3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "img", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Comments ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
  }
}
class MainVisualDefectComponent {
  constructor(visualDefectService, sharedData) {
    this.visualDefectService = visualDefectService;
    this.sharedData = sharedData;
    this.selectedDefect = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.mainDefectList = [];
    this.mainDefectFilter = '';
    this.isOkComments = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    this.mainDefects = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
  }
  ngOnInit() {
    this.getMainVisualDefects();
    this.sharedData.isDeleteDefCmnt$.subscribe(def => {
      this.deletionTrigger = def;
    });
  }
  getDefectIconByDefectId(defectId) {
    switch (defectId) {
      case 2100:
        return './assets/img/defects-icon/brake_system.svg';
      case 2200:
        return './assets/img/defects-icon/steering.svg';
      case 2300:
        return './assets/img/defects-icon/visibility.svg';
      case 2400:
        return './assets/img/defects-icon/lighting.svg';
      case 2500:
        return './assets/img/defects-icon/axles.svg';
      case 2600:
        return './assets/img/defects-icon/chasis.svg';
      case 2700:
        return './assets/img/defects-icon/engine.svg';
      case 2800:
        return './assets/img/defects-icon/other_equip.svg';
      case 2900:
        return './assets/img/defects-icon/environment.svg';
      case 3000:
        return './assets/img/defects-icon/public_transport.svg';
      case 3100:
        return './assets/img/defects-icon/brake_system.svg';
      case 4100:
        return './assets/img/defects-icon/water_tanker.svg';
    }
    return '';
  }
  getMainVisualDefects() {
    this.visualDefectService.getMainVisualDefects({
      requestId: this.requestId,
      nameEn: this.mainDefectFilter == '' ? null : this.mainDefectFilter
    }).subscribe(res => {
      this.mainDefectList = res.items;
      let legalRequirementIndex = this.mainDefectList.findIndex(x => x.mainDefectId == src_app_core_utilities_enums_main_defects__WEBPACK_IMPORTED_MODULE_0__.MainDefectEnum.LegalRequirements);
      if (legalRequirementIndex > -1) this.legalRequirement = this.mainDefectList.splice(legalRequirementIndex, 1)[0];
    });
  }
  onSelectDefect(defectId) {
    this.selectedDefect.emit(defectId);
  }
  showAllComments() {
    this.isOkComments.emit(true);
  }
  static #_ = this.ɵfac = function MainVisualDefectComponent_Factory(t) {
    return new (t || MainVisualDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_1__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: MainVisualDefectComponent,
    selectors: [["main-visual-defect"]],
    inputs: {
      requestId: "requestId"
    },
    outputs: {
      selectedDefect: "selectedDefect",
      isOkComments: "isOkComments",
      mainDefects: "mainDefects"
    },
    decls: 19,
    vars: 5,
    consts: [[1, "vd-content-hld"], [1, "vd-title"], [1, "row"], [1, "col-lg-4"], [1, "search-fld"], [1, "bi", "bi-search"], ["type", "text", "placeholder", "Search Main Visual Defects", "value", "", 1, "form-control", 2, "padding-left", "45px", 3, "ngModel", "ngModelChange"], [1, "col-12"], [1, "row", 2, "--bs-gutter-y", "1.5rem"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], [1, "row", 2, "--bs-gutter-y", "0.75rem", "margin-top", "1.5rem", "margin-bottom", "1.5rem"], ["class", "col-lg-4", 4, "ngIf"], ["id", "btnConfirm", 1, "col-12", "end-btns"], [3, "deletionTrigger"], [1, "card-link", 3, "click"], [1, "vd-card", "red-card"], [1, "vd-icon"], [3, "src"], [1, "vd-card-title"], [1, "vd-card", "yellow-card"], [1, "vd-card", "green-card"], ["src", "./assets/img/defects-icon/comments.svg"]],
    template: function MainVisualDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div")(1, "div", 0)(2, "div", 1)(3, "div", 2)(4, "div", 3)(5, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "i", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "input", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function MainVisualDefectComponent_Template_input_ngModelChange_7_listener($event) {
          return ctx.mainDefectFilter = $event;
        })("ngModelChange", function MainVisualDefectComponent_Template_input_ngModelChange_7_listener() {
          return ctx.getMainVisualDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 7)(9, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, " Visual Defect Main Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, MainVisualDefectComponent_div_12_Template, 10, 3, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, MainVisualDefectComponent_div_14_Template, 10, 3, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, MainVisualDefectComponent_div_15_Template, 9, 0, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 2)(17, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "app-confirm-defects", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx.mainDefectFilter);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.mainDefectList);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.legalRequirement != undefined && ctx.legalRequirement.defectNameEn.includes(ctx.mainDefectFilter) || "3100".includes(ctx.mainDefectFilter));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", "Comments".toLowerCase().includes(ctx.mainDefectFilter.toLowerCase()));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("deletionTrigger", ctx.deletionTrigger);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_3__.ConfirmDefectsComponent],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 92961:
/*!**********************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/popup-defect/popup-defect.component.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PopupDefectComponent": () => (/* binding */ PopupDefectComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 59295);
/* harmony import */ var src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-comments-type */ 53104);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);










function PopupDefectComponent_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r0.errorMessage, " ");
  }
}
function PopupDefectComponent_div_13_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 28)(1, "div", 29)(2, "div", 30)(3, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](4, "img", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_13_div_1_Template_input_change_5_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r11);
      const sd_r8 = restoredCtx.$implicit;
      const i_r9 = restoredCtx.index;
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r10.selectedDefCmnt(sd_r8, i_r9, 3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "label", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "a", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PopupDefectComponent_div_13_div_1_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r11);
      const i_r9 = restoredCtx.index;
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r12.deleteDefectComment(i_r9, ctx_r12.savedDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "i", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "a", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](11, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const sd_r8 = ctx.$implicit;
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("src", ctx_r7.getSubDefectCommentIconByDefectId(sd_r8.commentType), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsanitizeUrl"])("title", ctx_r7.mapEvaluationName(sd_r8.commentType));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("id", sd_r8.defCommentId)("value", sd_r8.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("shrink-text", (sd_r8 == null ? null : sd_r8.descriptionEn) && (sd_r8 == null ? null : sd_r8.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("for", sd_r8.defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](sd_r8.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵstyleProp"]("pointer-events", sd_r8.defectSource == 2 ? "none" : "auto");
  }
}
function PopupDefectComponent_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, PopupDefectComponent_div_13_div_1_Template, 12, 10, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r1.selectedDefectsPrevList);
  }
}
function PopupDefectComponent_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 28)(1, "div", 29)(2, "div", 30)(3, "input", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_14_Template_input_change_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r16);
      const df_r13 = restoredCtx.$implicit;
      const i_r14 = restoredCtx.index;
      const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r15.selectedDefCmnt(df_r13.defectCmnt, i_r14, 2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "label", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "a", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PopupDefectComponent_div_14_Template_a_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r16);
      const i_r14 = restoredCtx.index;
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r17.deleteDefectComment(i_r14, ctx_r17.prevDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](7, "i", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "a", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const df_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("id", df_r13 == null ? null : df_r13.defectCmnt.defCommentId)("value", df_r13 == null ? null : df_r13.defectCmnt.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("shrink-text", (df_r13 == null ? null : df_r13.descriptionEn) && (df_r13 == null ? null : df_r13.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("for", df_r13 == null ? null : df_r13.defectCmnt.defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](df_r13 == null ? null : df_r13.defectCmnt.descriptionEn);
  }
}
function PopupDefectComponent_span_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
}
function PopupDefectComponent_div_26_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "input", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function PopupDefectComponent_div_26_ng_container_1_ng_container_1_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r23.selectedEvaluation = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2).$implicit;
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("id", ev_r18.lkCodeValue)("value", ev_r18.lkValueEname)("ngModel", ctx_r21.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("for", ev_r18.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ev_r18.lkValueEname, " ");
  }
}
function PopupDefectComponent_div_26_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "input", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function PopupDefectComponent_div_26_ng_container_1_ng_container_2_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r27);
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r26.selectedEvaluation = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2).$implicit;
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("id", ev_r18.lkCodeValue)("value", ev_r18.lkValueEname)("ngModel", ctx_r22.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("for", ev_r18.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ev_r18.lkValueEname, " ");
  }
}
function PopupDefectComponent_div_26_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, PopupDefectComponent_div_26_ng_container_1_ng_container_1_Template, 4, 5, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, PopupDefectComponent_div_26_ng_container_1_ng_container_2_Template, 4, 6, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx_r20.isReadOnlyEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r20.isReadOnlyEvaluation && ctx_r20.selectedEvaluation == ev_r18.lkValueEname);
  }
}
function PopupDefectComponent_div_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, PopupDefectComponent_div_26_ng_container_1_Template, 3, 2, "ng-container", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ev_r18 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ev_r18.lkCodeValue != 1);
  }
}
function PopupDefectComponent_div_27_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r42 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r42);
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r41.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r30.selectedDefLocArray == null ? null : ctx_r30.selectedDefLocArray.includes("FC"))("disabled", ctx_r30.disableDef);
  }
}
function PopupDefectComponent_div_27_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r44 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r44);
      const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r43.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r31.selectedDefLocArray == null ? null : ctx_r31.selectedDefLocArray.includes("FL"))("disabled", ctx_r31.disableDef);
  }
}
function PopupDefectComponent_div_27_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r46 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r46);
      const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r45.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r32.selectedDefLocArray == null ? null : ctx_r32.selectedDefLocArray.includes("FR"))("disabled", ctx_r32.disableDef);
  }
}
function PopupDefectComponent_div_27_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r48);
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r47.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r33.selectedDefLocArray == null ? null : ctx_r33.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r33.disableDef);
  }
}
function PopupDefectComponent_div_27_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r50);
      const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r49.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r34.selectedDefLocArray == null ? null : ctx_r34.selectedDefLocArray.includes("CL"))("disabled", ctx_r34.disableDef);
  }
}
function PopupDefectComponent_div_27_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r52 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r52);
      const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r51.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r35.selectedDefLocArray == null ? null : ctx_r35.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r35.disableDef);
  }
}
function PopupDefectComponent_div_27_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_19_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r54);
      const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r53.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r36.selectedDefLocArray == null ? null : ctx_r36.selectedDefLocArray.includes("CC"))("disabled", ctx_r36.disableDef);
  }
}
function PopupDefectComponent_div_27_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r56 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r56);
      const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r55.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r37.selectedDefLocArray == null ? null : ctx_r37.selectedDefLocArray.includes("CR"))("disabled", ctx_r37.disableDef);
  }
}
function PopupDefectComponent_div_27_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r58 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_25_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r58);
      const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r57.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r38.selectedDefLocArray == null ? null : ctx_r38.selectedDefLocArray.includes("RC"))("disabled", ctx_r38.disableDef);
  }
}
function PopupDefectComponent_div_27_div_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r60 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_27_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r60);
      const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r59.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r39.selectedDefLocArray == null ? null : ctx_r39.selectedDefLocArray.includes("RL"))("disabled", ctx_r39.disableDef);
  }
}
function PopupDefectComponent_div_27_div_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r62 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_27_div_29_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r62);
      const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r61.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r40.selectedDefLocArray == null ? null : ctx_r40.selectedDefLocArray.includes("RR"))("disabled", ctx_r40.disableDef);
  }
}
function PopupDefectComponent_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 7)(1, "div", 43)(2, "div", 44)(3, "div", 45)(4, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, PopupDefectComponent_div_27_div_5_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, PopupDefectComponent_div_27_div_7_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, PopupDefectComponent_div_27_div_9_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 50)(11, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](12, PopupDefectComponent_div_27_div_12_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, PopupDefectComponent_div_27_div_14_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, PopupDefectComponent_div_27_div_16_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "div", 54)(18, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, PopupDefectComponent_div_27_div_19_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "div", 56)(21, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, PopupDefectComponent_div_27_div_22_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 57)(24, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](25, PopupDefectComponent_div_27_div_25_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](26, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](27, PopupDefectComponent_div_27_div_27_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](28, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](29, PopupDefectComponent_div_27_div_29_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](30, "img", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.fc);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.fl);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.fr);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.axle1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.cl);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.axle2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.cc);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.cr);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.rc);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.rl);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r5.selectedDefItemLocation == null ? null : ctx_r5.selectedDefItemLocation.rr);
  }
}
function PopupDefectComponent_div_28_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r82);
      const ctx_r81 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r81.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r63.selectedDefLocArray == null ? null : ctx_r63.selectedDefLocArray.includes("FC"))("disabled", ctx_r63.disableDef);
  }
}
function PopupDefectComponent_div_28_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r84);
      const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r83.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r64 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r64.selectedDefLocArray == null ? null : ctx_r64.selectedDefLocArray.includes("FL"))("disabled", ctx_r64.disableDef);
  }
}
function PopupDefectComponent_div_28_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r86);
      const ctx_r85 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r85.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r65.selectedDefLocArray == null ? null : ctx_r65.selectedDefLocArray.includes("FR"))("disabled", ctx_r65.disableDef);
  }
}
function PopupDefectComponent_div_28_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r88);
      const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r87.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r66.selectedDefLocArray == null ? null : ctx_r66.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r66.disableDef);
  }
}
function PopupDefectComponent_div_28_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r90);
      const ctx_r89 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r89.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r67.selectedDefLocArray == null ? null : ctx_r67.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r67.disableDef);
  }
}
function PopupDefectComponent_div_28_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r92);
      const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r91.updateSelectedValues(4, $event, "axle3"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 3 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r68.selectedDefLocArray == null ? null : ctx_r68.selectedDefLocArray.includes("AXLE3"))("disabled", ctx_r68.disableDef);
  }
}
function PopupDefectComponent_div_28_div_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r94 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_18_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r94);
      const ctx_r93 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r93.updateSelectedValues(8, $event, "axle4"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 4 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r69.selectedDefLocArray == null ? null : ctx_r69.selectedDefLocArray.includes("AXLE4"))("disabled", ctx_r69.disableDef);
  }
}
function PopupDefectComponent_div_28_div_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r96 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_20_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r96);
      const ctx_r95 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r95.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r70.selectedDefLocArray == null ? null : ctx_r70.selectedDefLocArray.includes("CL"))("disabled", ctx_r70.disableDef);
  }
}
function PopupDefectComponent_div_28_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r98 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r98);
      const ctx_r97 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r97.updateSelectedValues(16, $event, "axle5"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 5 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r71.selectedDefLocArray == null ? null : ctx_r71.selectedDefLocArray.includes("AXLE5"))("disabled", ctx_r71.disableDef);
  }
}
function PopupDefectComponent_div_28_div_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r100 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_24_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r100);
      const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r99.updateSelectedValues(32, $event, "axle6"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 6 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r72.selectedDefLocArray == null ? null : ctx_r72.selectedDefLocArray.includes("AXLE6"))("disabled", ctx_r72.disableDef);
  }
}
function PopupDefectComponent_div_28_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r102 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_26_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r102);
      const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r101.updateSelectedValues(64, $event, "axle7"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 7 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r73.selectedDefLocArray == null ? null : ctx_r73.selectedDefLocArray.includes("AXLE7"))("disabled", ctx_r73.disableDef);
  }
}
function PopupDefectComponent_div_28_div_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r104 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_28_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r104);
      const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r103.updateSelectedValues(128, $event, "axle8"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 8 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r74.selectedDefLocArray == null ? null : ctx_r74.selectedDefLocArray.includes("AXLE8"))("disabled", ctx_r74.disableDef);
  }
}
function PopupDefectComponent_div_28_div_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r106 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_30_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r106);
      const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r105.updateSelectedValues(256, $event, "axle9"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " 9 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r75.selectedDefLocArray == null ? null : ctx_r75.selectedDefLocArray.includes("AXLE9"))("disabled", ctx_r75.disableDef);
  }
}
function PopupDefectComponent_div_28_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r108 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_33_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r108);
      const ctx_r107 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r107.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r76.selectedDefLocArray == null ? null : ctx_r76.selectedDefLocArray.includes("CC"))("disabled", ctx_r76.disableDef);
  }
}
function PopupDefectComponent_div_28_div_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r110 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_36_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r110);
      const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r109.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r77.selectedDefLocArray == null ? null : ctx_r77.selectedDefLocArray.includes("CR"))("disabled", ctx_r77.disableDef);
  }
}
function PopupDefectComponent_div_28_div_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r112 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_39_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r112);
      const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r111.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r78.selectedDefLocArray == null ? null : ctx_r78.selectedDefLocArray.includes("RC"))("disabled", ctx_r78.disableDef);
  }
}
function PopupDefectComponent_div_28_div_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r114 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_41_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r114);
      const ctx_r113 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r113.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r79 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r79.selectedDefLocArray == null ? null : ctx_r79.selectedDefLocArray.includes("RL"))("disabled", ctx_r79.disableDef);
  }
}
function PopupDefectComponent_div_28_div_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r116 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 59)(1, "input", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("change", function PopupDefectComponent_div_28_div_43_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r116);
      const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r115.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "label", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("checked", ctx_r80.selectedDefLocArray == null ? null : ctx_r80.selectedDefLocArray.includes("RR"))("disabled", ctx_r80.disableDef);
  }
}
function PopupDefectComponent_div_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 7)(1, "div", 43)(2, "div", 44)(3, "div", 45)(4, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, PopupDefectComponent_div_28_div_5_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, PopupDefectComponent_div_28_div_7_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, PopupDefectComponent_div_28_div_9_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 81)(11, "div", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](12, PopupDefectComponent_div_28_div_12_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, PopupDefectComponent_div_28_div_14_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "div", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](16, PopupDefectComponent_div_28_div_16_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](17, "div", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](18, PopupDefectComponent_div_28_div_18_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](19, "div", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](20, PopupDefectComponent_div_28_div_20_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](22, PopupDefectComponent_div_28_div_22_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](23, "div", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](24, PopupDefectComponent_div_28_div_24_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "div", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, PopupDefectComponent_div_28_div_26_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](27, "div", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](28, PopupDefectComponent_div_28_div_28_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div", 91);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](30, PopupDefectComponent_div_28_div_30_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](31, "div", 54)(32, "div", 92);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](33, PopupDefectComponent_div_28_div_33_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "div", 93)(35, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](36, PopupDefectComponent_div_28_div_36_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](37, "div", 57)(38, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](39, PopupDefectComponent_div_28_div_39_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](40, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](41, PopupDefectComponent_div_28_div_41_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](42, "div", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](43, PopupDefectComponent_div_28_div_43_Template, 4, 2, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](44, "img", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.fc);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.fl);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.fr);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 1 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle1));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 2 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle2));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 3 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle3));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 4 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle4));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.cl);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 5 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle5));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 6 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle6));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 7 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle7));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 8 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle8));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.nbAxles >= 9 && (ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.axle9));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.cc);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.cr);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.rc);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.rl);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r6.selectedDefItemLocation == null ? null : ctx_r6.selectedDefItemLocation.rr);
  }
}
class PopupDefectComponent {
  constructor(sharedData, lookupServ, el, renderer, inspectionService) {
    this.sharedData = sharedData;
    this.lookupServ = lookupServ;
    this.el = el;
    this.renderer = renderer;
    this.inspectionService = inspectionService;
    this.deleteDefectCommentEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
    this.onClickFileEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
    this.checkboxStates = {};
    this.prevSavedDefects = [];
    this.selectedDefLocArray = [];
    this.showDefectVehicle = false;
    this.showDefectTruck = false;
    this.evaluationList = [];
    this.prevDef = 2;
    this.savedDef = 3;
  }
  ngOnInit() {
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_1__.SystemLookupCodes.evaluationList).subscribe(response => {
      this.evaluationList = response.items;
    });
    // get if vehicle is heavy or light to display popup
    this.sharedData.vehicleType$.subscribe(categType => {
      this.categoryType = categType;
      this.categoryType == 1 ? this.showDefectVehicle = true : this.showDefectTruck = true;
      console.log(this.categoryType);
    });
    this.sharedData.insRequestId$.subscribe(insReqID => {
      this.insRequestId = insReqID;
    });
    // get nb axles to display heavy equipment axles
    this.sharedData.nbAxles$.subscribe(axles => {
      if (axles == null) {
        this.nbAxles = 9;
      } else {
        this.nbAxles = axles;
      }
    });
    this.sharedData.selectedDefectsPrevList$.subscribe(defects => {
      this.selectedDefectsPrevList = defects;
      console.log(defects);
    });
    this.sharedData.defectCommentList$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.take)(1)).subscribe(def => {
      this.prevSavedDefects = def;
      console.log("subs prev def");
    });
    console.log(this.selectedDefectsPrevList[0]);
    this.selectedDefCmnt(this.prevSavedDefects[0].defectCmnt, 0, this.prevDef);
    console.log(this.prevSavedDefects[0]);
    console.log(this.prevDef);
    // this.selectedDefCmnt(this.selectedDefectsPrevList[0], 0, this.prevDef);
  }

  selectedDefCmnt(defectCmnt, index, defSource) {
    console.log(defectCmnt);
    this.isRemarkRequired = defectCmnt.isRemarkRequired;
    console.log(defectCmnt);
    this.selectedDefItemLocation = defectCmnt.defectLocation;
    console.log(this.selectedDefItemLocation);
    if (defSource == 1) {
      this.disableDef = false;
      this.remarkCmnt = this.saveSubDefectComments[index]?.remarks;
      this.selectedEvaluation = this.mapEvaluationName(this.saveSubDefectComments[index]?.evalutionId);
      if (this.selectedEvaluation == "Comment") {
        this.selectedEvaluation = "OK/Comment";
      }
      this.selectedEvaluationCode = this.saveSubDefectComments[index]?.evalutionId;
      this.selectedDefLocArray = this.saveSubDefectComments[index] ? this.saveSubDefectComments[index].locations : [];
    }
    if (defSource == 2) {
      this.disableDef = false;
      this.sharedData.saveSubDefectComments$.subscribe(savedef => {
        this.saveSubDefectComments = savedef;
        this.selectedDefLocArray = savedef[index] ? savedef[index].locations : [];
        this.remarkCmnt = savedef[index] ? savedef[index].remarks : null;
        this.selectedEvaluation = this.mapEvaluationName(savedef[index] ? savedef[index].evalutionId : null);
        if (this.selectedEvaluation == "Comment") {
          this.selectedEvaluation = "OK/Comment";
        }
        this.selectedEvaluationCode = savedef[index] ? savedef[index].evalutionId : null;
      });
    }
    if (defSource == 3) {
      this.disableDef = true;
      this.remarkCmnt = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].remarks : null;
      this.selectedEvaluation = this.mapEvaluationName(this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null);
      if (this.selectedEvaluation == "Comment") {
        this.selectedEvaluation = "OK/Comment";
      }
      this.selectedEvaluationCode = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null;
      this.selectedDefectValues = this.selectedDefectsPrevList[index].locationValue ? this.selectedDefectsPrevList[index].locationValue : 0;
      this.selectedDefLocArray = this.selectedDefectsPrevList[index].selectedDefectLocation;
      console.log(this.selectedDefectsPrevList[index]);
    }
    console.log(this.selectedDefLocArray.includes('AXLE1'));
    console.log(this.selectedDefLocArray);
    //this.resetCheckboxes();
    //  this.selectedDefItemLocation = defectCmnt.defectLocation;
    this.defectCommentIndex = index;
    //this.isCheckboxDisable = defectCmnt.locationValue ? true : false;
    this.isReadOnlyEvaluation = true;
  }
  updateSelectedValues(value, event, loc) {
    const isChecked = event.target.checked;
    if (isChecked) {
      this.selectedDefectValues += value;
      this.selectedDefLocArray.push(loc.toUpperCase());
      this.checkDefectLocation(loc);
      this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray;
      this.sharedData.setSaveSubDefectComments(this.saveSubDefectComments);
    } else {
      this.selectedDefectValues -= value;
      const locIndex = this.selectedDefLocArray.indexOf(loc.toUpperCase());
      if (locIndex !== -1) {
        this.selectedDefLocArray.splice(locIndex, 1);
      }
    }
  }
  updateRemark() {
    this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt : this.selectedDefectsPrevList[this.defectCommentIndex].remarks = this.remarkCmnt;
    //this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt;
  }

  checkDefectLocation(loc) {
    const defectLoc = this.selectedSubDefectComments[this.defectCommentIndex].defectLocation;
    switch (loc) {
      case 'fl':
        defectLoc.fl = true;
        break;
      case 'fc':
        defectLoc.fc = true;
        break;
      case 'fr':
        defectLoc.fr = true;
        break;
      case 'cl':
        defectLoc.cl = true;
        break;
      case 'cc':
        defectLoc.cc = true;
        break;
      case 'cr':
        defectLoc.cr = true;
        break;
      case 'axle1':
        defectLoc.axle1 = true;
        break;
      case 'axle2':
        defectLoc.axle2 = true;
        break;
      case 'axle3':
        defectLoc.axle3 = true;
        break;
      case 'axle4':
        defectLoc.axle4 = true;
        break;
      case 'axle5':
        defectLoc.axle5 = true;
        break;
      case 'axle6':
        defectLoc.axle6 = true;
        break;
      case 'axle7':
        defectLoc.axle7 = true;
        break;
      case 'axle8':
        defectLoc.axle8 = true;
        break;
      case 'axle9':
        defectLoc.axle9 = true;
        break;
      case 'rl':
        defectLoc.rl = true;
        break;
      case 'rr':
        defectLoc.rr = true;
        break;
      case 'rc':
        defectLoc.rc = true;
        break;
      default:
        break;
    }
    this.selectedDefItemLocation = defectLoc;
  }
  mapEvaluationName(evId) {
    return evId == 3 ? "Major" : evId == 4 ? "Minor" : evId == 1 ? "Inspector Decides" : "Comment";
  }
  getSubDefectCommentIconByDefectId(defectCommentType) {
    switch (defectCommentType) {
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.InspectorDecides:
        return './assets/img/defects-icon/status_info.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.OKComment:
        return './assets/img/defects-icon/status_comment.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.Major:
        return './assets/img/defects-icon/status_up.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentType.Minor:
        return './assets/img/defects-icon/status_down.svg';
    }
    return '';
  }
  resetCheckboxes() {
    for (const key in this.checkboxStates) {
      if (this.checkboxStates.hasOwnProperty(key)) {
        this.checkboxStates[key] = false;
      }
    }
  }
  checkDeleteDef(index, sourcenb) {
    this.defectDelIndex = index;
    //this.confirmEval = 
    this.delSource = sourcenb;
  }
  deleteDefectComment(index, source) {
    this.remarkCmnt = '';
    if (source == this.savedDef) {
      this.sharedData.deleteDefectCmnt(this.selectedDefectsPrevList[index].defCommentId);
      const deleteDef = {
        inspectionReqId: this.insRequestId,
        defectsCommentId: this.selectedDefectsPrevList[index].defCommentId
      };
      console.log(deleteDef);
      this.inspectionService.deleteInspectionDefect(deleteDef).subscribe(response => {
        this.selectedDefectsPrevList.splice(index, 1);
      });
    }
    if (source == this.prevDef) {
      this.sharedData.deleteSaveSubDefectComment(this.prevSavedDefects[index].defectCmnt.defCommentId);
      this.prevSavedDefects.splice(index, 1);
      this.sharedData.setDeleteDefCmnt();
    }
    if (this.selectedSubDefectComments?.length + this.prevSavedDefects?.length + this.selectedDefectsPrevList?.length == 0) {
      this.closeVehicleImage();
    }
  }
  onFileUploadModalHidden() {
    console.log("file hidden");
    const fileUploadModal = this.el.nativeElement.querySelector('#fileUploadModal');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
  }
  closeVehicleImage() {
    const fileUploadModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
  }
  onFileUploadData(fInfo) {
    console.log("test");
    //  this.onFileUploadModalHidden();
  }
  static #_ = this.ɵfac = function PopupDefectComponent_Factory(t) {
    return new (t || PopupDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_2__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_3__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_4__.InspectionServiceService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({
    type: PopupDefectComponent,
    selectors: [["app-popup-defect"]],
    inputs: {
      selectedDefectsPrevList: "selectedDefectsPrevList",
      errorMessage: "errorMessage"
    },
    outputs: {
      deleteDefectCommentEvent: "deleteDefectCommentEvent",
      onClickFileEvent: "onClickFileEvent"
    },
    decls: 52,
    vars: 10,
    consts: [[1, "modal-header"], [1, "df-counter"], [1, "counter-btn"], ["class", "error-message", 4, "ngIf"], [1, "modal-body"], [1, "pop-content"], [1, "row"], [1, "col-lg-6"], [1, "row", "form-fields"], [4, "ngIf"], ["class", "col-lg-12 mb-2", 4, "ngFor", "ngForOf"], [1, "col-12"], [1, "st-label"], [1, "txtarea", "w-100", 3, "ngModel", "disabled", "ngModelChange", "change"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-lg-6", 4, "ngIf"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-orange"], ["id", "confirmationModalDel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabeldel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"], [1, "error-message"], [1, "col-lg-12", "mb-2"], [1, "outline-radio-container"], [1, "outline-radio", "d-flex", "align-items-center"], [1, "defect-evaluation-classification-coloir"], ["data-toggle", "tooltip", "data-placement", "top", 2, "height", "33px", 3, "src", "title"], ["type", "radio", "name", "sd.defCommentCode", 3, "id", "value", "change"], ["id", "labelPop", 3, "for"], [3, "click"], [1, "bi", "bi-trash-fill", "poptrash"], ["data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal"], [1, "bi", "bi-paperclip"], ["type", "radio", "name", "df?.defCommentCode", 3, "id", "value", "change"], [3, "for"], [1, "btn-radio"], ["type", "radio", "name", "ev.lkValueEname", 3, "id", "value", "ngModel", "ngModelChange"], [1, "car-img-wrap"], [1, "car-img-hold"], [1, "top-chkboxes"], [1, "fc", "chkbx"], ["class", "form-check", 4, "ngIf"], [1, "fl", "chkbx"], [1, "fr", "chkbx"], [1, "left-chkboxes"], [1, "b1", "chkbx"], [1, "cl", "chkbx"], [1, "b2", "chkbx"], [1, "center-chkboxes"], [1, "c", "chkbx"], [1, "right-chkboxes"], [1, "bottom-chkboxes"], ["src", " ./assets/img/car_outline.svg", 1, "car-img"], [1, "form-check"], ["type", "checkbox", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fc", 1, "form-check-label"], ["type", "checkbox", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fl", 1, "form-check-label"], ["type", "checkbox", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b1", 1, "form-check-label"], ["type", "checkbox", "id", "cl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b2", 1, "form-check-label"], ["type", "checkbox", "id", "c", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "c", 1, "form-check-label"], ["type", "checkbox", "id", "cr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cr", 1, "form-check-label"], ["type", "checkbox", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rc", 1, "form-check-label"], ["type", "checkbox", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], [1, "truck-left-chkboxes"], [1, "t1", "chkbx"], [1, "t2", "chkbx"], [1, "t3", "chkbx"], [1, "t4", "chkbx"], [1, "tcl", "chkbx"], [1, "t5", "chkbx"], [1, "t6", "chkbx"], [1, "t7", "chkbx"], [1, "t8", "chkbx"], [1, "t9", "chkbx"], [1, "c-truck", "chkbx"], [1, "truck-right-chkboxes"], [1, "tcr", "chkbx"], ["src", "./assets/img/truck-outline.svg", 1, "car-img"], ["type", "checkbox", "value", "", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t1", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t2", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t3", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t3", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t4", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t4", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t5", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t6", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t7", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t7", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t8", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t8", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t9", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t9", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rr", 1, "form-check-label"]],
    template: function PopupDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, PopupDefectComponent_div_6_Template, 2, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "div", 8)(12, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](13, PopupDefectComponent_div_13_Template, 2, 1, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](14, PopupDefectComponent_div_14_Template, 10, 6, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "div", 6)(16, "div", 11)(17, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](18, " Remarks ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](19, PopupDefectComponent_span_19_Template, 2, 0, "span", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](20, "textarea", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("ngModelChange", function PopupDefectComponent_Template_textarea_ngModelChange_20_listener($event) {
          return ctx.remarkCmnt = $event;
        })("change", function PopupDefectComponent_Template_textarea_change_20_listener() {
          return ctx.updateRemark();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](21, "div", 6)(22, "div", 11)(23, "label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](24, "Evaluation");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](25, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](26, PopupDefectComponent_div_26_Template, 2, 1, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](27, PopupDefectComponent_div_27_Template, 31, 11, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](28, PopupDefectComponent_div_28_Template, 45, 18, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](29, "div", 16)(30, "button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](31, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](32, "button", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](33, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](34, "div", 19)(35, "div", 20)(36, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](37, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](38, "div", 4)(39, "div", 6)(40, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](41, "img", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](42, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](43, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](44, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](45, " Are you sure you want to delete this defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](46, "br")(47, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](48, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](49, "img", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](50, "button", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PopupDefectComponent_Template_button_click_50_listener() {
          return ctx.deleteDefectComment(ctx.defectDelIndex, ctx.delSource);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](51, "img", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", (ctx.selectedSubDefectComments == null ? null : ctx.selectedSubDefectComments.length) + (ctx.prevSavedDefects == null ? null : ctx.prevSavedDefects.length) + (ctx.selectedDefectsPrevList == null ? null : ctx.selectedDefectsPrevList.length), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.errorMessage);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.selectedDefectsPrevList);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.prevSavedDefects);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.isRemarkRequired);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngModel", ctx.remarkCmnt)("disabled", ctx.disableDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.evaluationList.slice().reverse());
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.showDefectVehicle);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.showDefectTruck && !ctx.showDefectVehicle);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgModel],
    styles: ["#fileUploadModal[_ngcontent-%COMP%] {\r\n    z-index: 2000;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9wb3B1cC1kZWZlY3QvcG9wdXAtZGVmZWN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0FBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiI2ZpbGVVcGxvYWRNb2RhbCB7XHJcbiAgICB6LWluZGV4OiAyMDAwO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 97226:
/*!**************************************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/sub-visual-defect-comments/sub-visual-defect-comments.component.ts ***!
  \**************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubVisualDefectCommentsComponent": () => (/* binding */ SubVisualDefectCommentsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_utilities_enums_defect_comments_sort_type__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-comments-sort-type */ 84187);
/* harmony import */ var src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-comments-type */ 53104);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_models_visual_defects_save_sub_defects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/models/visual-defects/save-sub-defects */ 46587);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 59295);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../confirm-defects/confirm-defects.component */ 17767);


















function SubVisualDefectCommentsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 4)(1, "div", 5)(2, "span", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "a", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_11_Template_a_click_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r10.navigateBackToSubDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](5, "i", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6, " Change Sub Category ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx_r0.selectedSubDefect.descriptionEn, " ");
  }
}
const _c0 = function (a0) {
  return {
    "lightblue-card-selected": a0
  };
};
const _c1 = function (a0) {
  return {
    "lightblue-card": a0
  };
};
function SubVisualDefectCommentsComponent_div_44_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 14)(1, "a", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_44_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r15);
      const subDefectComment_r12 = restoredCtx.$implicit;
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r14.onSelectSubDefectComment(subDefectComment_r12));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "div", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](3, "img", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "div", 67)(5, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const subDefectComment_r12 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("pointer-events", ctx_r1.isDefectCommentPresent(subDefectComment_r12) ? "none" : "auto");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](8, _c0, subDefectComment_r12.selected))("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](10, _c1, !subDefectComment_r12.selected));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx_r1.getSubDefectCommentIconByDefectId(subDefectComment_r12.commentType), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"])("title", ctx_r1.mapEvaluationName(subDefectComment_r12.commentType));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", subDefectComment_r12.defCommentCode, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", subDefectComment_r12.descriptionEn, " ");
  }
}
function SubVisualDefectCommentsComponent_div_54_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx_r16.errorMessage, " ");
  }
}
function SubVisualDefectCommentsComponent_div_54_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 10)(1, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, " Defects ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, SubVisualDefectCommentsComponent_div_54_div_5_Template, 2, 1, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", (ctx_r2.selectedSubDefectComments == null ? null : ctx_r2.selectedSubDefectComments.length) + (ctx_r2.prevSavedDefects == null ? null : ctx_r2.prevSavedDefects.length) + (ctx_r2.selectedDefectsPrevList == null ? null : ctx_r2.selectedDefectsPrevList.length), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r2.errorMessage);
  }
}
function SubVisualDefectCommentsComponent_div_55_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ctx_r17.errorMessage, " ");
  }
}
function SubVisualDefectCommentsComponent_div_55_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 10)(1, "div", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](2, " Defect ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, SubVisualDefectCommentsComponent_div_55_div_3_Template, 2, 1, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r3.errorMessage);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div")(1, "div", 72)(2, "div", 73)(3, "div", 74)(4, "input", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_1_Template_input_ngModelChange_4_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r21);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r20.selectedSubDefCmnt = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](7, "a", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_1_Template_a_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r21);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r22.deleteDefectComment(ctx_r22.selectedSubDefectComments.length - 1, ctx_r22.currentDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](8, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](9, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_1_Template_a_click_9_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r21);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r23.onClickFile(ctx_r23.selectedSubDefectComments[ctx_r23.selectedSubDefectComments.length - 1] == null ? null : ctx_r23.selectedSubDefectComments[ctx_r23.selectedSubDefectComments.length - 1].defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](10, "span", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].defCommentId)("value", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn)("ngModel", ctx_r18.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1] == null ? null : ctx_r18.selectedSubDefectComments[ctx_r18.selectedSubDefectComments.length - 1].descriptionEn);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72)(1, "div", 73)(2, "div", 74)(3, "div", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](4, "img", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](5, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_input_ngModelChange_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r30.selectedSubDefCmnt = $event);
    })("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_input_ngModelChange_5_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const sd_r28 = restoredCtx.$implicit;
      const i_r29 = restoredCtx.index;
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r32.selectedDefCmnt(sd_r28, i_r29, 3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "label", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const i_r29 = restoredCtx.index;
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r33.checkDeleteDef(i_r29, ctx_r33.savedDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template_a_click_10_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r31);
      const sd_r28 = restoredCtx.$implicit;
      const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r34.onClickFile(sd_r28.defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](11, "span", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const sd_r28 = ctx.$implicit;
    const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx_r27.getSubDefectCommentIconByDefectId(sd_r28.commentType), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"])("title", ctx_r27.mapEvaluationName(sd_r28.commentType));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", sd_r28.defCommentId)("value", sd_r28.descriptionEn)("ngModel", ctx_r27.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (sd_r28 == null ? null : sd_r28.descriptionEn) && (sd_r28 == null ? null : sd_r28.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", sd_r28.defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](sd_r28.descriptionEn);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("pointer-events", sd_r28.defectSource == 2 ? "none" : "auto");
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_60_div_2_div_1_div_1_Template, 12, 11, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r24.selectedDefectsPrevList);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72)(1, "div", 73)(2, "div", 74)(3, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_input_ngModelChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r37.selectedSubDefCmnt = $event);
    })("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_input_ngModelChange_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const df_r35 = restoredCtx.$implicit;
      const i_r36 = restoredCtx.index;
      const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r39.selectedDefCmnt(df_r35.defectCmnt, i_r36, 2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "a", 86);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_a_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const i_r36 = restoredCtx.index;
      const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r40.checkDeleteDef(i_r36, ctx_r40.prevDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r38);
      const df_r35 = restoredCtx.$implicit;
      const i_r36 = restoredCtx.index;
      const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r41.onClickFile(df_r35[i_r36].defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "span", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const df_r35 = ctx.$implicit;
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", df_r35 == null ? null : df_r35.defectCmnt.defCommentId)("value", df_r35 == null ? null : df_r35.defectCmnt.descriptionEn)("ngModel", ctx_r25.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (df_r35 == null ? null : df_r35.descriptionEn) && (df_r35 == null ? null : df_r35.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", df_r35 == null ? null : df_r35.defectCmnt.defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](df_r35 == null ? null : df_r35.defectCmnt.descriptionEn);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 72)(1, "div", 73)(2, "div", 74)(3, "input", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_input_ngModelChange_3_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r44.selectedSubDefCmnt = $event);
    })("ngModelChange", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_input_ngModelChange_3_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const sd_r42 = restoredCtx.$implicit;
      const i_r43 = restoredCtx.index;
      const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r46.selectedDefCmnt(sd_r42, i_r43, 1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](4, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "a", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_a_click_6_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const i_r43 = restoredCtx.index;
      const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r47.deleteDefectComment(i_r43, ctx_r47.currentDef));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](7, "i", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template_a_click_8_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r45);
      const sd_r42 = restoredCtx.$implicit;
      const ctx_r48 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r48.onClickFile(sd_r42.defCommentId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "span", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const sd_r42 = ctx.$implicit;
    const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", sd_r42.defCommentId)("value", sd_r42.descriptionEn)("ngModel", ctx_r26.selectedSubDefCmnt);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵclassProp"]("shrink-text", (sd_r42 == null ? null : sd_r42.descriptionEn) && (sd_r42 == null ? null : sd_r42.descriptionEn.length) > 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", sd_r42.defCommentId);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate"](sd_r42.descriptionEn);
  }
}
function SubVisualDefectCommentsComponent_div_60_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_60_div_2_div_1_Template, 2, 1, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, SubVisualDefectCommentsComponent_div_60_div_2_div_2_Template, 10, 7, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](3, SubVisualDefectCommentsComponent_div_60_div_2_div_3_Template, 10, 7, "div", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r19.selectedDefectsPrevList);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r19.prevSavedDefects);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx_r19.selectedSubDefectComments);
  }
}
function SubVisualDefectCommentsComponent_div_60_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_60_div_1_Template, 11, 7, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, SubVisualDefectCommentsComponent_div_60_div_2_Template, 4, 3, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx_r4.isDefectCountSelected);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r4.isDefectCountSelected);
  }
}
function SubVisualDefectCommentsComponent_span_65_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1, " * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function SubVisualDefectCommentsComponent_label_75_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "label", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](1, "Evaluation");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
}
function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r55 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "input", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r55);
      const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r54.selectedEvaluation = $event);
    })("change", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template_input_change_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r55);
      const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      const i_r50 = ctx_r57.index;
      const ev_r49 = ctx_r57.$implicit;
      const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      ctx_r56.errorMessage = "";
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r56.selectEvaluation(i_r50, ev_r49.lkCodeValue));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", ev_r49.lkCodeValue)("value", ev_r49.lkValueEname)("ngModel", ctx_r52.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", ev_r49.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ev_r49.lkValueEname, " ");
  }
}
function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r60 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](1, "input", 89);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template_input_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r60);
      const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r59.selectedEvaluation = $event);
    })("change", function SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template_input_change_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r60);
      const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      const i_r50 = ctx_r62.index;
      const ev_r49 = ctx_r62.$implicit;
      const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
      ctx_r61.errorMessage = "";
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r61.selectEvaluation(i_r50, ev_r49.lkCodeValue));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2).$implicit;
    const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("id", ev_r49.lkCodeValue)("value", ev_r49.lkValueEname)("ngModel", ctx_r53.selectedEvaluation);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("for", ev_r49.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", ev_r49.lkValueEname, " ");
  }
}
function SubVisualDefectCommentsComponent_div_77_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_1_Template, 4, 6, "ng-container", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](2, SubVisualDefectCommentsComponent_div_77_ng_container_1_ng_container_2_Template, 4, 5, "ng-container", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]().$implicit;
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r51.isReadOnlyEvaluation && ctx_r51.selectedEvaluation == ev_r49.lkValueEname);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx_r51.isReadOnlyEvaluation);
  }
}
function SubVisualDefectCommentsComponent_div_77_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 88);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](1, SubVisualDefectCommentsComponent_div_77_ng_container_1_Template, 3, 2, "ng-container", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ev_r49 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ev_r49.lkCodeValue != 1);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r77 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 107);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r77);
      const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r76.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r65.selectedDefLocArray == null ? null : ctx_r65.selectedDefLocArray.includes("FC"))("disabled", ctx_r65.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r79 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 109);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r79);
      const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r78.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r66 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r66.selectedDefLocArray == null ? null : ctx_r66.selectedDefLocArray.includes("FL"))("disabled", ctx_r66.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r81 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r81);
      const ctx_r80 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r80.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r67.selectedDefLocArray == null ? null : ctx_r67.selectedDefLocArray.includes("FR"))("disabled", ctx_r67.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r83);
      const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r82.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 114);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r68.selectedDefLocArray == null ? null : ctx_r68.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r68.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r85 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r85);
      const ctx_r84 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r84.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r69 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r69.selectedDefLocArray == null ? null : ctx_r69.selectedDefLocArray.includes("CL"))("disabled", ctx_r69.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r87 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r87);
      const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r86.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r70 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r70.selectedDefLocArray == null ? null : ctx_r70.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r70.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r89 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_19_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r89);
      const ctx_r88 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r88.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r71 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r71.selectedDefLocArray == null ? null : ctx_r71.selectedDefLocArray.includes("CC"))("disabled", ctx_r71.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r91 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r91);
      const ctx_r90 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r90.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r72.selectedDefLocArray == null ? null : ctx_r72.selectedDefLocArray.includes("CR"))("disabled", ctx_r72.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r93 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_25_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r93);
      const ctx_r92 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r92.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r73.selectedDefLocArray == null ? null : ctx_r73.selectedDefLocArray.includes("RC"))("disabled", ctx_r73.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_27_Template(rf, ctx) {
  if (rf & 1) {
    const _r95 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 125);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_27_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r95);
      const ctx_r94 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r94.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r74 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r74.selectedDefLocArray == null ? null : ctx_r74.selectedDefLocArray.includes("RL"))("disabled", ctx_r74.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_div_29_Template(rf, ctx) {
  if (rf & 1) {
    const _r97 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 127);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_78_div_29_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r97);
      const ctx_r96 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r96.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r75 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r75.selectedDefLocArray == null ? null : ctx_r75.selectedDefLocArray.includes("RR"))("disabled", ctx_r75.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_78_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 3)(1, "div", 90)(2, "div", 91)(3, "div", 92)(4, "div", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, SubVisualDefectCommentsComponent_div_78_div_5_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, SubVisualDefectCommentsComponent_div_78_div_7_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, SubVisualDefectCommentsComponent_div_78_div_9_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 97)(11, "div", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, SubVisualDefectCommentsComponent_div_78_div_12_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, SubVisualDefectCommentsComponent_div_78_div_14_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](16, SubVisualDefectCommentsComponent_div_78_div_16_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "div", 101)(18, "div", 102);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](19, SubVisualDefectCommentsComponent_div_78_div_19_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](20, "div", 103)(21, "div", 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](22, SubVisualDefectCommentsComponent_div_78_div_22_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "div", 104)(24, "div", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](25, SubVisualDefectCommentsComponent_div_78_div_25_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](26, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](27, SubVisualDefectCommentsComponent_div_78_div_27_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](29, SubVisualDefectCommentsComponent_div_78_div_29_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](30, "img", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.fc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.fl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.fr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.axle1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.cl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.axle2));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.cc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.cr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.rc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.rl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r8.defectCommentValue == null ? null : ctx_r8.defectCommentValue.locationValue) && (ctx_r8.selectedDefItemLocation == null ? null : ctx_r8.selectedDefItemLocation.rr));
  }
}
function SubVisualDefectCommentsComponent_div_79_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r117 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_5_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r117);
      const ctx_r116 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r116.updateSelectedValues(1024, $event, "fc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 108);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r98 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r98.selectedDefLocArray == null ? null : ctx_r98.selectedDefLocArray.includes("FC"))("disabled", ctx_r98.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r119 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_7_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r119);
      const ctx_r118 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r118.updateSelectedValues(512, $event, "fl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 110);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r99.selectedDefLocArray == null ? null : ctx_r99.selectedDefLocArray.includes("FL"))("disabled", ctx_r99.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r121 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 127);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_9_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r121);
      const ctx_r120 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r120.updateSelectedValues(2048, $event, "fr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 112);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " FR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r100 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r100.selectedDefLocArray == null ? null : ctx_r100.selectedDefLocArray.includes("FR"))("disabled", ctx_r100.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r123 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 145);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_12_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r123);
      const ctx_r122 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r122.updateSelectedValues(1, $event, "axle1"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 1 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r101 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r101.selectedDefLocArray == null ? null : ctx_r101.selectedDefLocArray.includes("AXLE1"))("disabled", ctx_r101.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r125 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_14_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r125);
      const ctx_r124 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r124.updateSelectedValues(2, $event, "axle2"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 2 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r102.selectedDefLocArray == null ? null : ctx_r102.selectedDefLocArray.includes("AXLE2"))("disabled", ctx_r102.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r127 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_16_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r127);
      const ctx_r126 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r126.updateSelectedValues(4, $event, "axle3"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 3 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r103.selectedDefLocArray == null ? null : ctx_r103.selectedDefLocArray.includes("AXLE3"))("disabled", ctx_r103.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r129 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_18_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r129);
      const ctx_r128 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r128.updateSelectedValues(8, $event, "axle4"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 4 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r104 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r104.selectedDefLocArray == null ? null : ctx_r104.selectedDefLocArray.includes("AXLE4"))("disabled", ctx_r104.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r131 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_20_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r131);
      const ctx_r130 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r130.updateSelectedValues(4096, $event, "cl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r105.selectedDefLocArray == null ? null : ctx_r105.selectedDefLocArray.includes("CL"))("disabled", ctx_r105.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r133 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 155);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_22_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r133);
      const ctx_r132 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r132.updateSelectedValues(16, $event, "axle5"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 146);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 5 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r106 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r106.selectedDefLocArray == null ? null : ctx_r106.selectedDefLocArray.includes("AXLE5"))("disabled", ctx_r106.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r135 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_24_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r135);
      const ctx_r134 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r134.updateSelectedValues(32, $event, "axle6"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 6 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r107 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r107.selectedDefLocArray == null ? null : ctx_r107.selectedDefLocArray.includes("AXLE6"))("disabled", ctx_r107.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r137 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 157);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_26_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r137);
      const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r136.updateSelectedValues(64, $event, "axle7"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 158);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 7 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r108.selectedDefLocArray == null ? null : ctx_r108.selectedDefLocArray.includes("AXLE7"))("disabled", ctx_r108.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_28_Template(rf, ctx) {
  if (rf & 1) {
    const _r139 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 159);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_28_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r139);
      const ctx_r138 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r138.updateSelectedValues(128, $event, "axle8"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 160);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 8 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r109 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r109.selectedDefLocArray == null ? null : ctx_r109.selectedDefLocArray.includes("AXLE8"))("disabled", ctx_r109.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_30_Template(rf, ctx) {
  if (rf & 1) {
    const _r141 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_30_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r141);
      const ctx_r140 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r140.updateSelectedValues(256, $event, "axle9"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " 9 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r110 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r110.selectedDefLocArray == null ? null : ctx_r110.selectedDefLocArray.includes("AXLE9"))("disabled", ctx_r110.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r143 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 119);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_33_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r143);
      const ctx_r142 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r142.updateSelectedValues(8192, $event, "cc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 120);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " C ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r111.selectedDefLocArray == null ? null : ctx_r111.selectedDefLocArray.includes("CC"))("disabled", ctx_r111.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_36_Template(rf, ctx) {
  if (rf & 1) {
    const _r145 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 163);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_36_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r145);
      const ctx_r144 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r144.updateSelectedValues(16384, $event, "cr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " CR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r112 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r112.selectedDefLocArray == null ? null : ctx_r112.selectedDefLocArray.includes("CR"))("disabled", ctx_r112.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_39_Template(rf, ctx) {
  if (rf & 1) {
    const _r147 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_39_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r147);
      const ctx_r146 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r146.updateSelectedValues(65536, $event, "rc"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 124);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r113 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r113.selectedDefLocArray == null ? null : ctx_r113.selectedDefLocArray.includes("RC"))("disabled", ctx_r113.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_41_Template(rf, ctx) {
  if (rf & 1) {
    const _r149 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 166);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_41_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r149);
      const ctx_r148 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r148.updateSelectedValues(32768, $event, "rl"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RL ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r114 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r114.selectedDefLocArray == null ? null : ctx_r114.selectedDefLocArray.includes("RL"))("disabled", ctx_r114.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_div_43_Template(rf, ctx) {
  if (rf & 1) {
    const _r151 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 106)(1, "input", 167);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("change", function SubVisualDefectCommentsComponent_div_79_div_43_Template_input_change_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵrestoreView"](_r151);
      const ctx_r150 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵresetView"](ctx_r150.updateSelectedValues(131072, $event, "rr"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](2, "label", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](3, " RR ");
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("checked", ctx_r115.selectedDefLocArray == null ? null : ctx_r115.selectedDefLocArray.includes("RR"))("disabled", ctx_r115.disableDef);
  }
}
function SubVisualDefectCommentsComponent_div_79_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 3)(1, "div", 90)(2, "div", 91)(3, "div", 92)(4, "div", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](5, SubVisualDefectCommentsComponent_div_79_div_5_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](6, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](7, SubVisualDefectCommentsComponent_div_79_div_7_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](9, SubVisualDefectCommentsComponent_div_79_div_9_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](10, "div", 128)(11, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](12, SubVisualDefectCommentsComponent_div_79_div_12_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](13, "div", 130);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](14, SubVisualDefectCommentsComponent_div_79_div_14_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](16, SubVisualDefectCommentsComponent_div_79_div_16_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "div", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](18, SubVisualDefectCommentsComponent_div_79_div_18_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "div", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](20, SubVisualDefectCommentsComponent_div_79_div_20_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](21, "div", 134);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](22, SubVisualDefectCommentsComponent_div_79_div_22_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](23, "div", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](24, SubVisualDefectCommentsComponent_div_79_div_24_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "div", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](26, SubVisualDefectCommentsComponent_div_79_div_26_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](27, "div", 137);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](28, SubVisualDefectCommentsComponent_div_79_div_28_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](29, "div", 138);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](30, SubVisualDefectCommentsComponent_div_79_div_30_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](31, "div", 101)(32, "div", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](33, SubVisualDefectCommentsComponent_div_79_div_33_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](34, "div", 140)(35, "div", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](36, SubVisualDefectCommentsComponent_div_79_div_36_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](37, "div", 104)(38, "div", 93);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](39, SubVisualDefectCommentsComponent_div_79_div_39_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](40, "div", 95);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](41, SubVisualDefectCommentsComponent_div_79_div_41_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](42, "div", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](43, SubVisualDefectCommentsComponent_div_79_div_43_Template, 4, 2, "div", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](44, "img", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.fc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.fl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.fr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 1 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle1));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 2 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle2));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 3 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle3));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 4 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle4));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.cl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 5 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle5));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 6 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle6));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 7 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle7));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 8 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle8));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx_r9.nbAxles >= 9 && (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.axle9));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.cc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.cr));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.rc));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.rl));
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", (ctx_r9.defectCommentValue == null ? null : ctx_r9.defectCommentValue.locationValue) && (ctx_r9.selectedDefItemLocation == null ? null : ctx_r9.selectedDefItemLocation.rr));
  }
}
const _c2 = function (a0) {
  return {
    "whitebg": a0
  };
};
class SubVisualDefectCommentsComponent {
  constructor(visualDefectService, lookupServ, sharedData, fileService, globalServ, renderer, el, inspectionService, ngZone) {
    this.visualDefectService = visualDefectService;
    this.lookupServ = lookupServ;
    this.sharedData = sharedData;
    this.fileService = fileService;
    this.globalServ = globalServ;
    this.renderer = renderer;
    this.el = el;
    this.inspectionService = inspectionService;
    this.ngZone = ngZone;
    this.isOkComments = false;
    this.selectedComment = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.changeCategory = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.changeSubCategory = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.openModalEvent = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.selectedDefect = new _angular_core__WEBPACK_IMPORTED_MODULE_13__.EventEmitter();
    this.selectedSubDefectComments = [];
    this.saveSubDefectComments = [];
    this.prevSavedDefects = [];
    this.defDetailsAdd = [];
    this.showDefectVehicle = false;
    this.showDefectTruck = false;
    this.isCheckboxDisable = false;
    this.isDefectSaved = false;
    this.evaluationList = [];
    this.formDataArray = [];
    this.decimalValue = 300;
    this.decimalValue2 = 130;
    this.binaryDecomposition = [];
    this.isReadOnlyEvaluation = false;
    this.selectedDefectValues = 0;
    this.checkboxStates = {};
    this.remarkCmnt = '';
    this.isDefectCountSelected = false;
    // assign value flags to check from which origin are the defects:
    this.currentDef = 1;
    this.prevDef = 2;
    this.savedDef = 3;
    this.locationAdded = false;
    this.selectedDefLocArray = [];
    this.fileInfo = [];
  }
  ngOnInit() {
    /*  this.sharedData.userId$.subscribe((userId) => {
        this.userId = userId;
      });
      */
    this.userId = parseInt(localStorage.getItem('userId'));
    console.log(this.defectListSaved);
    if (this.isOkComments) {
      this.defectCommentRequestDto = {
        mainDefectId: undefined,
        subDefectId: undefined,
        descriptionEn: undefined,
        orderByCommentId: undefined,
        orderByDescription: undefined,
        recent: 10
      };
    } else {
      this.defectCommentRequestDto = {
        mainDefectId: this.selectedMainDefect.mainDefectId,
        subDefectId: this.selectedSubDefect.subDefectId,
        descriptionEn: undefined,
        orderByCommentId: undefined,
        orderByDescription: undefined,
        recent: 10
      };
    }
    this.getSubVisualDefectsComments();
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_2__.SystemLookupCodes.evaluationList).subscribe(response => {
      this.evaluationList = response.items;
    });
    // get if vehicle is heavy or light to display popup
    this.sharedData.vehicleType$.subscribe(categType => {
      this.categoryType = categType;
    });
    this.categoryType == 1 ? this.showDefectVehicle = true : this.showDefectTruck = true;
    this.calculateBinaryDecomposition();
    // get the request id to check the vehicle defects
    this.sharedData.reqNo$.subscribe(reqID => {
      this.requestId = parseInt(reqID);
    });
    this.sharedData.insRequestId$.subscribe(insReqID => {
      this.insRequestId = insReqID;
    });
    this.sharedData.insServiceId$.subscribe(servId => {
      this.insServiceId = servId;
    });
    this.sharedData.insSectionId$.subscribe(sectionId => {
      this.sectionId = sectionId;
    });
    this.sharedData.insStepId$.subscribe(stepId => {
      this.inspectionStepId = stepId;
    });
    this.sharedData.selectedDefectsPrevList$.subscribe(defects => {
      this.selectedDefectsPrevList = defects;
    });
    this.sharedData.defectCommentList$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_14__.take)(1)).subscribe(def => {
      this.prevSavedDefects = def;
    });
    this.sharedData.saveSubDefectComments$.subscribe(def => {
      console.log("saved def", def);
    });
    // get nb axles to display heavy equipment axles
    this.sharedData.nbAxles$.subscribe(axles => {
      if (axles == null) {
        this.nbAxles = 9;
      } else {
        this.nbAxles = axles;
      }
    });
  }
  openModal() {
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    console.log(carImagePopModal);
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
    this.openModalEvent.emit();
  }
  isDefectCommentPresent(subDefectComment) {
    let isPresent = false; //this.prevSavedDefects[0]?.defectCmnt.defCommentId == subDefectComment.defCommentId;
    if (this.prevSavedDefects && this.prevSavedDefects.length > 0) {
      for (let df of this.prevSavedDefects) {
        if (df.defectCmnt.defCommentId == subDefectComment.defCommentId) {
          return true;
        }
      }
      return isPresent;
    }
    if (this.selectedDefectsPrevList.length > 0) {
      for (let df of this.selectedDefectsPrevList) {
        if (df.defCommentId == subDefectComment.defCommentId) {
          return true;
        }
      }
      return isPresent;
    }
    return false;
  }
  filterOnDescription() {
    this.visualDefectService.getSubVisualDefectsComments(this.defectCommentRequestDto).subscribe(res => {
      this.subDefectCommentsList = res.items;
    });
  }
  getSubDefectCommentIconByDefectId(defectCommentType) {
    switch (defectCommentType) {
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.InspectorDecides:
        return './assets/img/defects-icon/status_info.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.OKComment:
        return './assets/img/defects-icon/status_comment.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.Major:
        return './assets/img/defects-icon/status_up.svg';
      case src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.Minor:
        return './assets/img/defects-icon/status_down.svg';
    }
    return '';
  }
  getSubVisualDefectsComments() {
    this.visualDefectService.getSubVisualDefectsComments(this.defectCommentRequestDto).subscribe(res => {
      this.subDefectCommentsList = res.items;
    });
  }
  toggleOrderByCommentId() {
    this.defectCommentRequestDto.orderByCommentId = this.defectCommentRequestDto.orderByCommentId ? undefined : src_app_core_utilities_enums_defect_comments_sort_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentSortType.Ascending;
    this.defectCommentRequestDto.recent = undefined;
    this.defectCommentRequestDto.orderByDescription = undefined;
    this.getSubVisualDefectsComments();
  }
  toggleOrderByDescription() {
    this.defectCommentRequestDto.orderByDescription = this.defectCommentRequestDto.orderByDescription ? undefined : src_app_core_utilities_enums_defect_comments_sort_type__WEBPACK_IMPORTED_MODULE_0__.DefectCommentSortType.Ascending;
    this.defectCommentRequestDto.orderByCommentId = undefined;
    this.defectCommentRequestDto.recent = undefined;
    this.getSubVisualDefectsComments();
  }
  toggleRecentFilter() {
    this.defectCommentRequestDto.recent = this.defectCommentRequestDto.recent ? undefined : 10;
    this.defectCommentRequestDto.orderByDescription = undefined;
    this.defectCommentRequestDto.orderByCommentId = undefined;
    this.getSubVisualDefectsComments();
  }
  isDefectCommentSelected(subDefectCommentId) {
    return this.selectedSubDefectComments.find(x => x.defCommentId == subDefectCommentId) != undefined;
  }
  onSelectSubDefectComment(subDefectComment) {
    let subDefectCommentIndex;
    if (this.isDefectCommentSelected(subDefectComment.defCommentId)) {
      subDefectComment.selected = false;
      subDefectCommentIndex = this.selectedSubDefectComments.findIndex(x => x.defCommentId = subDefectComment.defCommentId);
      this.selectedSubDefectComments.splice(subDefectCommentIndex, 1);
      this.defDetailsAdd.splice(subDefectCommentIndex, 1);
      this.saveSubDefectComments.splice(subDefectCommentIndex, 1);
      this.isDefectCountSelected = false;
      //this.deleteDefectComment(subDefectCommentIndex, this.currentDef);
    } else {
      subDefectCommentIndex = this.selectedSubDefectComments.findIndex(x => x.defCommentId = subDefectComment.defCommentId);
      subDefectComment.selected = true;
      this.selectedSubDefectComments.push(subDefectComment);
      this.selectedSubDefCmnt = subDefectComment.descriptionEn;
      //  if (Object.values(subDefectComment.defectLocation).every(value => value === false)) {
      this.selectedDefCmnt(subDefectComment, subDefectCommentIndex + 1, 1);
      // this.selectSingleDefCmnt(subDefectComment);
      const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
      this.renderer.addClass(carImagePopModal, 'show');
      this.renderer.setStyle(carImagePopModal, 'display', 'block');
      // }
      // else {
      //   console.log("subbb", subDefectComment);
      //   this.selectedDefCmnt(subDefectComment, subDefectCommentIndex + 1, 1);
      // }
    }
  }

  navigateBackToMainDefects() {
    this.changeCategory.emit(true);
  }
  navigateBackToSubDefects() {
    this.changeSubCategory.emit(true);
  }
  updateLetterCount() {
    this.letterCount = this.remarkCmnt.length;
    if (this.remarkCmnt != '') {
      this.canClosePopup = true;
    } else {
      this.canClosePopup = false;
    }
    this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt : this.selectedDefectsPrevList[this.defectCommentIndex].remarks = this.remarkCmnt;
    console.log(this.saveSubDefectComments[this.defectCommentIndex]);
    //this.saveSubDefectComments[this.defectCommentIndex].remarks = this.remarkCmnt;
  }

  insertVin() {
    let vin;
    this.sharedData.vinNo$.subscribe(vinNo => {
      console.log(vinNo);
      vin = vinNo;
      this.remarkCmnt += vin;
      this.updateLetterCount();
    });
  }
  selectedDefCmnt(defectCmnt, index, defSource) {
    this.isRemarkRequired = defectCmnt.isRemarkRequired;
    console.log(defectCmnt);
    this.selectedDefItemLocation = defectCmnt.defectLocation;
    this.defectCommentValue = defectCmnt;
    this.selectedSubDefCmnt = defectCmnt.descriptionEn;
    if (!this.isDefectCountSelected) {
      this.uncheckLoc = true;
      this.disableDef = false;
      console.log(index);
      this.selectedCommentIndex = index;
      //this.selectedDefectValues = 0;
      //this.resetCheckboxes();
      this.selectedDefLocArray = [];
      this.remarkCmnt = '';
      this.defectCommentIndex = index;
      if (defectCmnt.commentType == src_app_core_utilities_enums_defect_comments_type__WEBPACK_IMPORTED_MODULE_1__.DefectCommentType.InspectorDecides && !this.isDefectCountSelected) {
        this.isReadOnlyEvaluation = false;
        this.selectedEvaluation = '';
        this.canClosePopup = false;
      } else {
        console.log(this.evaluationList);
        console.log(defectCmnt.commentType);
        this.selectedEvaluation = this.evaluationList.find(evaluation => evaluation.lkCodeValue == defectCmnt.commentType).lkValueEname;
        this.isReadOnlyEvaluation = true;
        this.canClosePopup = true;
      }
      if (this.isRemarkRequired) {
        if (this.remarkCmnt != '') {
          this.canClosePopup = true;
        } else {
          this.canClosePopup = false;
        }
      }
      if (defectCmnt.locationValue && !this.selectedDefectValues) {
        this.locationAdded = false;
      } else {
        this.locationAdded = true;
      }
      // save the selected sub defect comment in a new item
      const defectComment = {
        inspectionStepId: this.inspectionStepId,
        inspectionReqId: this.insRequestId,
        requestId: this.requestId,
        inspectionServiceId: this.insServiceId,
        sectionId: this.sectionId,
        defectMode: defectCmnt.mode,
        defectsCommentId: defectCmnt.defCommentId,
        defectClassification: defectCmnt.defectClassification,
        remarks: this.remarkCmnt,
        status: 1,
        defectSource: defectCmnt.defectSource,
        evalutionId: defectCmnt.commentType != 1 ? defectCmnt.commentType : this.selectedEvaluationCode,
        locations: this.selectedDefLocArray,
        axle: 0,
        createdBy: this.userId
      };
      console.log("SAVED DEF", this.saveSubDefectComments);
      const isSaveDefectAlreadyAdded = this.saveSubDefectComments.some(def => def?.defectsCommentId == this.saveSubDefectComments[index]?.defectsCommentId);
      if (isSaveDefectAlreadyAdded) {
        // The defect is already in the array
        console.log('Defect already added');
      } else {
        // The defect is not in the array, so add it
        this.saveSubDefectComments[index] = new src_app_core_models_visual_defects_save_sub_defects__WEBPACK_IMPORTED_MODULE_3__.SaveSubDefectComments(defectComment);
      }
      const isDefectAlreadyAdded = this.defDetailsAdd.some(item => item.defectCmnt?.defCommentCode === this.selectedSubDefectComments[index]?.defCommentCode);
      if (!isDefectAlreadyAdded) {
        console.log("add def", this.defDetailsAdd);
        const defDetails = {
          defectCmnt: this.selectedSubDefectComments[this.defectCommentIndex]
        };
        this.defDetailsAdd.push(defDetails);
      }
      this.selectedDefectValues = 0;
      this.selectedDefLocArray = [];
    } else {
      console.log("def cmnt from popup", defectCmnt);
      this.uncheckLoc = false;
      if (defSource == 1) {
        this.disableDef = false;
        this.remarkCmnt = this.saveSubDefectComments[index]?.remarks;
        this.selectedEvaluation = this.mapEvaluationName(this.saveSubDefectComments[index]?.evalutionId);
        if (this.selectedEvaluation == "Comment") {
          this.selectedEvaluation = "OK/Comment";
        }
        this.selectedDefLocArray = this.saveSubDefectComments[index].locations;
        this.selectedEvaluationCode = this.saveSubDefectComments[index]?.evalutionId;
        console.log(this.saveSubDefectComments[index]?.locations);
      }
      if (defSource == 2) {
        this.disableDef = false;
        this.updateprev = true;
        this.sharedData.saveSubDefectComments$.subscribe(savedef => {
          this.remarkCmnt = savedef[index] ? savedef[index].remarks : null;
          this.selectedDefLocArray = savedef[index] ? savedef[index].locations : null;
          this.selectedEvaluation = this.mapEvaluationName(savedef[index] ? savedef[index].evalutionId : null);
          if (this.selectedEvaluation == "Comment") {
            this.selectedEvaluation = "OK/Comment";
          }
          this.selectedEvaluationCode = savedef[index] ? savedef[index].evalutionId : null;
          this.saveSubDefectComments = savedef;
          console.log(savedef[index]);
        });
        console.log(this.saveSubDefectComments[index]);
      }
      if (defSource == 3) {
        this.disableDef = true;
        this.remarkCmnt = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].remarks : null;
        this.selectedDefLocArray = this.selectedDefectsPrevList[index].selectedDefectLocation.toString().split(',');
        this.selectedDefectValues = this.selectedDefectsPrevList[index].locationValue ? this.selectedDefectsPrevList[index].locationValue : 0;
        this.selectedEvaluation = this.mapEvaluationName(this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null);
        if (this.selectedEvaluation == "Comment") {
          this.selectedEvaluation = "OK/Comment";
        }
        this.selectedEvaluationCode = this.selectedDefectsPrevList[index] ? this.selectedDefectsPrevList[index].commentType : null;
      }
      // this.resetCheckboxes();
      //  this.selectedDefItemLocation = defectCmnt.defectLocation;
      this.defectCommentIndex = index;
      //this.isCheckboxDisable = defectCmnt.locationValue ? true : false;
      this.isReadOnlyEvaluation = true;
      this.canClosePopup = true;
      console.log(this.selectedDefLocArray);
      if (this.isRemarkRequired) {
        if (this.remarkCmnt != '') {
          this.canClosePopup = true;
        } else {
          this.canClosePopup = false;
        }
      }
      console.log(this.selectedDefectValues);
    }
  }
  updateSelectedValues(value, event, loc) {
    const isChecked = event.target.checked;
    if (isChecked) {
      this.selectedDefectValues += value;
      console.log(loc);
      console.log(this.selectedDefLocArray);
      this.selectedDefLocArray.push(loc.toUpperCase());
      console.log(this.selectedDefLocArray);
      this.checkDefectLocation(loc);
      this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray;
      this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray : this.selectedDefectsPrevList[this.defectCommentIndex].selectedDefectLocation = this.selectedDefLocArray;
      if (this.isDefectCountSelected) {
        this.sharedData.setSaveSubDefectComments(this.saveSubDefectComments);
      }
    } else {
      this.selectedDefectValues -= value;
      const locIndex = this.selectedDefLocArray.indexOf(loc.toUpperCase());
      console.log(this.selectedDefectValues);
      console.log(loc);
      console.log(this.selectedDefLocArray);
      if (locIndex !== -1) {
        this.selectedDefLocArray.splice(locIndex, 1);
      }
      this.saveSubDefectComments[this.defectCommentIndex] ? this.saveSubDefectComments[this.defectCommentIndex].locations = this.selectedDefLocArray : this.selectedDefectsPrevList[this.defectCommentIndex].selectedDefectLocation = this.selectedDefLocArray;
    }
    if (this.selectedDefectValues) {
      this.locationAdded = true;
    } else {
      this.locationAdded = false;
    }
  }
  mapEvaluationName(evId) {
    return evId == 3 ? "Major" : evId == 4 ? "Minor" : evId == 1 ? "Inspector Decides" : "Comment";
  }
  checkDefectLocation(loc) {
    const defectLoc = this.selectedSubDefectComments[this.defectCommentIndex].defectLocation;
    switch (loc) {
      case 'fl':
        defectLoc.fl = true;
        break;
      case 'fc':
        defectLoc.fc = true;
        break;
      case 'fr':
        defectLoc.fr = true;
        break;
      case 'cl':
        defectLoc.cl = true;
        break;
      case 'cc':
        defectLoc.cc = true;
        break;
      case 'cr':
        defectLoc.cr = true;
        break;
      case 'axle1':
        defectLoc.axle1 = true;
        break;
      case 'axle2':
        defectLoc.axle2 = true;
        break;
      case 'axle3':
        defectLoc.axle3 = true;
        break;
      case 'axle4':
        defectLoc.axle4 = true;
        break;
      case 'axle5':
        defectLoc.axle5 = true;
        break;
      case 'axle6':
        defectLoc.axle6 = true;
        break;
      case 'axle7':
        defectLoc.axle7 = true;
        break;
      case 'axle8':
        defectLoc.axle8 = true;
        break;
      case 'axle9':
        defectLoc.axle9 = true;
        break;
      case 'rl':
        defectLoc.rl = true;
        break;
      case 'rr':
        defectLoc.rr = true;
        break;
      case 'rc':
        defectLoc.rc = true;
        break;
      default:
        break;
    }
    this.selectedDefItemLocation = defectLoc;
  }
  selectEvaluation(index, evaluationCode) {
    this.selectedEvaluationCode = evaluationCode;
    this.canClosePopup = true;
    this.saveSubDefectComments[this.selectedCommentIndex].evalutionId = this.selectedEvaluationCode;
  }
  resetCheckboxes() {
    for (const key in this.checkboxStates) {
      if (this.checkboxStates.hasOwnProperty(key)) {
        this.checkboxStates[key] = false;
      }
    }
  }
  checkDeleteDef(index, sourcenb) {
    this.defectDelIndex = index;
    //this.confirmEval = 
    this.delSource = sourcenb;
  }
  deleteDefectComment(index, source) {
    this.remarkCmnt = '';
    if (source == this.savedDef) {
      this.selectedDefectsPrevList.splice(index, 1);
      this.sharedData.deleteDefectCmnt(this.selectedDefectsPrevList[index].defCommentId);
      const deleteDef = {
        inspectionReqId: this.insRequestId,
        defectsCommentId: this.selectedDefectsPrevList[0].defCommentId
      };
      console.log(deleteDef);
      this.inspectionService.deleteInspectionDefect(deleteDef).subscribe(response => {});
    }
    if (source == this.currentDef) {
      console.log("cuurent def del");
      this.selectedSubDefectComments.splice(index, 1);
      this.saveSubDefectComments.splice(index, 1);
      this.defDetailsAdd.splice(index, 1);
      console.log(this.selectedSubDefectComments);
      console.log(this.saveSubDefectComments);
    }
    if (source == this.prevDef) {
      this.sharedData.deleteSaveSubDefectComment(this.prevSavedDefects[index].defectCmnt.defCommentId);
      this.prevSavedDefects.splice(index, 1);
      this.deletionTrigger = true;
      this.sharedData.setDeleteDefCmnt();
    }
    if (!this.isDefectCountSelected && this.selectedSubDefectComments.length == 0) {
      this.closeVehicleImage();
    }
    if (this.isDefectCountSelected && this.selectedSubDefectComments.length + this.prevSavedDefects.length + this.selectedDefectsPrevList.length == 0) {
      this.closeVehicleImage();
    }
  }
  onFileUploadModalHidden() {
    const fileUploadModal = this.el.nativeElement.querySelector('#fileUploadModal');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
  }
  closeVehicleImage() {
    const fileUploadModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    this.saveChanges();
  }
  openFileModal() {
    const fileUploadModal = this.el.nativeElement.querySelector('#fileUploadModal');
    this.renderer.addClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'block');
  }
  onClickFile(defId) {
    this.openFileModal();
    this.selectedFileDefId = defId;
  }
  onFileUploadData(fInfo) {
    this.fileInfo.push({
      defId: this.selectedFileDefId,
      fileInfo: fInfo
    });
    console.log(this.fileInfo);
    const fileInfoArray = this.fileService.getFileData();
    for (const fileInfo of fileInfoArray) {
      if (fileInfo) {
        const formData = new FormData();
        formData.append('requestId', this.requestId.toString());
        formData.append('sectionId', this.sectionId.toString());
        formData.append('defectId', this.selectedFileDefId.toString());
        formData.append('serviceTypeId', '');
        formData.append('serviceId', '');
        formData.append('mimeType', fileInfo.mimeType);
        formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.InspectionImages.toString());
        formData.append('createdBy', this.userId.toString());
        formData.append('fileData', fileInfo.fileData, fileInfo.filename);
        this.formDataArray.push(formData);
        this.sharedData.setFormData(this.formDataArray);
      }
    }
    this.onFileUploadModalHidden();
  }
  calculateBinaryDecomposition() {
    /*
    if (this.showDefectVehicle) {
      let number = this.decimalValue;
            while (number > 0) {
        const power = Math.floor(Math.log2(number));
        const powerValue = Math.pow(2, power);
              this.binaryDecomposition.push(powerValue);
        number -= powerValue;
      }
            this.carPopup.forEach((popup) => {
        popup.flag = this.binaryDecomposition.includes(popup.decimal);
      });
    }
          if (this.showDefectTruck) {
      let n2 = this.decimalValue2;
            while (n2 > 0) {
        const power = Math.floor(Math.log2(n2));
        const powerValue = Math.pow(2, power);
        this.binaryDecomposition.push(powerValue);
        n2 -= powerValue;
      }
      this.truckPopup.forEach((popup) => {
        popup.flag = this.binaryDecomposition.includes(popup.decimal);
      });
    }
    */
  }
  cancelChanges() {
    const fileUploadModal = this.el.nativeElement.querySelector('#CarImagePop');
    this.renderer.removeClass(fileUploadModal, 'show');
    this.renderer.setStyle(fileUploadModal, 'display', 'none');
    if (!this.isDefectCountSelected) {
      this.onSelectSubDefectComment(this.selectedSubDefectComments[this.defectCommentIndex]);
      this.deleteDefectComment(this.defectCommentIndex, this.currentDef);
    }
    this.isDefectCountSelected = false;
  }
  saveChanges() {
    console.log("CLICK ON SAVE CHANGES");
    if (this.selectedEvaluation && !this.isRemarkRequired || this.selectedEvaluation && this.isRemarkRequired && this.remarkCmnt != '') {
      if (!this.isDefectCountSelected) {
        // save the defect comments in a behavior subject
        const cleanSaveSubDefCmnt = [...new Set(this.saveSubDefectComments)];
        this.sharedData.setSaveSubDefectComments(cleanSaveSubDefCmnt);
        let cleanDefDetailsAdd = this.defDetailsAdd;
        if (this.defDetailsAdd.length > 1) {
          // Keep only the last item
          cleanDefDetailsAdd = [this.defDetailsAdd[this.defDetailsAdd.length - 1]];
        }
        this.sharedData.setDefectCmnt(cleanDefDetailsAdd);
        console.log(this.defDetailsAdd);
        console.log(this.saveSubDefectComments);
      }
      const modalElement = document.getElementById('CarImagePop');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        this.canClosePopup = false;
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
    this.navigateBackToSubDefects();
    this.isDefectCountSelected = false;
  }
  static #_ = this.ɵfac = function SubVisualDefectCommentsComponent_Factory(t) {
    return new (t || SubVisualDefectCommentsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_5__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_6__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_7__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_8__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_9__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_10__.InspectionServiceService), _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_13__.NgZone));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵdefineComponent"]({
    type: SubVisualDefectCommentsComponent,
    selectors: [["sub-visual-defect-comments"]],
    inputs: {
      isOkComments: "isOkComments",
      selectedMainDefect: "selectedMainDefect",
      selectedSubDefect: "selectedSubDefect",
      vehicleCategory: "vehicleCategory",
      defectListSaved: "defectListSaved"
    },
    outputs: {
      selectedComment: "selectedComment",
      changeCategory: "changeCategory",
      changeSubCategory: "changeSubCategory",
      openModalEvent: "openModalEvent",
      selectedDefect: "selectedDefect"
    },
    decls: 107,
    vars: 33,
    consts: [[1, "vd-content-hld"], [1, "chnage-cat-section"], [1, "row", "mb-2"], [1, "col-lg-6"], [1, "row"], [1, "col-lg-12", "mb-4"], ["id", "btGray", 1, "btn-outline-gray"], [1, "btn-orange-outline", 3, "click"], [1, "bi", "bi-pencil-fill"], ["class", "row", 4, "ngIf"], [1, "df-counter"], ["data-bs-toggle", "modal", "data-bs-target", "#CarImagePop", 3, "click"], [1, "counter-btn"], [1, "vd-title"], [1, "col-lg-4"], [1, "search-fld"], [1, "bi", "bi-search"], ["type", "text", "placeholder", "Search Defects", "value", "", 1, "form-control", 2, "padding-left", "45px", 3, "ngModel", "ngModelChange"], [1, "mt-0"], [1, "sort-hold"], [1, "row", "justify-content-end"], [1, "col-auto"], ["data-toggle", "tooltip", "data-placement", "top", "title", "Sort By Frequently Used", 1, "sort-icon-item", 3, "ngClass", "click"], [3, "src"], ["data-toggle", "tooltip", "data-placement", "top", "title", "Sort Alphabetically", 1, "sort-icon-item", 3, "ngClass", "click"], ["data-toggle", "tooltip", "data-placement", "top", "title", "Sort By Defect ID", 1, "sort-icon-item", 3, "ngClass", "click"], [1, "row", 2, "--bs-gutter-y", "1.5rem"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], ["id", "endbtns", 1, "row"], [1, "col-12", "end-btns"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], [3, "deletionTrigger"], ["data-bs-priority", "2000", "data-bs-backdrop", "static", "id", "CarImagePop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-xl", "Car-dialog"], [1, "modal-content"], [1, "modal-header"], ["class", "df-counter", 4, "ngIf"], [1, "modal-body"], [1, "pop-content"], ["class", "row form-fields", 4, "ngIf"], [1, "col-12"], [1, "st-label"], [4, "ngIf"], [1, "txtarea", "w-100", 3, "ngModel", "disabled", "ngModelChange", "input"], ["id", "letterCount", 1, "row"], [1, "shortcut"], ["id", "btnshort", 1, "btn-orange-outline", 3, "disabled", "click"], ["class", "st-label", 4, "ngIf"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], ["class", "col-lg-6", 4, "ngIf"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", 1, "btn", "btn-orange", 3, "disabled", "click"], ["id", "confirmationModalDel", "tabindex", "-1", "role", "dialog", "aria-labelledby", "exampleModalLabeldel", "aria-hidden", "true", 1, "modal", "fade"], ["role", "document", 1, "modal-dialog", "modal-dialog-centered"], ["id", "contentconfirm", 1, "modal-content"], ["src", "./assets/img/red-question.svg", "width", "40px"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0"], ["src", "./assets/img/red-x-icon.svg"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-secondary", "border-0", 3, "click"], ["src", "./assets/img/Check circle.svg"], ["id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "fileUploadModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop", 3, "hidden.bs.modal"], [1, "modal-dialog", "modal-dialog-centered"], [3, "fileUploaded"], [1, "card-link", 3, "click"], [1, "vd-card", 3, "ngClass"], ["data-toggle", "tooltip", "data-placement", "top", 1, "status-icon", 3, "src", "title"], [1, "vd-card-title"], [1, "counter-btn", "p-0", 2, "padding", "0px!important"], ["class", "error-message", 4, "ngIf"], [1, "error-message"], [1, "row", "form-fields"], [1, "col-lg-12", "mb-2"], [1, "outline-radio-container"], [1, "outline-radio", "d-flex", "align-items-center"], ["type", "radio", "name", "selectedSubDefectComments[selectedSubDefectComments.length - 1]?.defCommentCode", 3, "id", "value", "ngModel", "ngModelChange"], [3, "for"], [3, "click"], [1, "bi", "bi-trash-fill", "poptrash"], ["data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", "id", "attachA", 3, "click"], [1, "bi", "bi-paperclip"], ["class", "col-lg-12 mb-2", 4, "ngFor", "ngForOf"], [1, "defect-evaluation-classification-coloir"], ["data-toggle", "tooltip", "data-placement", "top", 2, "height", "33px", 3, "src", "title"], ["type", "radio", 3, "id", "value", "ngModel", "ngModelChange"], ["id", "labelPop", 3, "for"], ["data-bs-toggle", "modal", "data-bs-target", "#confirmationModalDel", 3, "click"], [1, "bi", "bi-paperclip", 2, "display", "inline-block"], [1, "btn-radio"], ["type", "radio", "name", "ev.lkValueEname", 3, "id", "value", "ngModel", "ngModelChange", "change"], [1, "car-img-wrap"], [1, "car-img-hold"], [1, "top-chkboxes"], [1, "fc", "chkbx"], ["class", "form-check", 4, "ngIf"], [1, "fl", "chkbx"], [1, "fr", "chkbx"], [1, "left-chkboxes"], [1, "b1", "chkbx"], [1, "cl", "chkbx"], [1, "b2", "chkbx"], [1, "center-chkboxes"], [1, "c", "chkbx"], [1, "right-chkboxes"], [1, "bottom-chkboxes"], ["src", " ./assets/img/car_outline.svg", 1, "car-img"], [1, "form-check"], ["type", "checkbox", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fc", 1, "form-check-label"], ["type", "checkbox", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fl", 1, "form-check-label"], ["type", "checkbox", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "fr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b1", 1, "form-check-label"], ["type", "checkbox", "id", "cl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "b2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "b2", 1, "form-check-label"], ["type", "checkbox", "id", "c", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "c", 1, "form-check-label"], ["type", "checkbox", "id", "cr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "cr", 1, "form-check-label"], ["type", "checkbox", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rc", 1, "form-check-label"], ["type", "checkbox", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "fr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], [1, "truck-left-chkboxes"], [1, "t1", "chkbx"], [1, "t2", "chkbx"], [1, "t3", "chkbx"], [1, "t4", "chkbx"], [1, "tcl", "chkbx"], [1, "t5", "chkbx"], [1, "t6", "chkbx"], [1, "t7", "chkbx"], [1, "t8", "chkbx"], [1, "t9", "chkbx"], [1, "c-truck", "chkbx"], [1, "truck-right-chkboxes"], [1, "tcr", "chkbx"], ["src", "./assets/img/truck-outline.svg", 1, "car-img"], ["type", "checkbox", "value", "", "id", "fc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "fl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t1", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t1", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t2", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t2", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t3", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t3", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t4", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t4", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcl", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t5", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t6", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "t7", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t7", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t8", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t8", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "t9", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "t9", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "tcr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "tcr", 1, "form-check-label"], ["type", "checkbox", "value", "", "id", "rc", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rl", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["type", "checkbox", "value", "", "id", "rr", 1, "form-check-input", "carchkbx", 3, "checked", "disabled", "change"], ["for", "rr", 1, "form-check-label"]],
    template: function SubVisualDefectCommentsComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5)(6, "span", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](8, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_8_listener() {
          return ctx.navigateBackToMainDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](9, "i", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](10, " Change Category ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](11, SubVisualDefectCommentsComponent_div_11_Template, 7, 1, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](12, "div", 3)(13, "div", 10)(14, "a", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_14_listener() {
          ctx.isDefectCountSelected = true;
          return ctx.selectedDefCmnt(ctx.selectedSubDefectComments[ctx.selectedSubDefectComments.length - 1], ctx.selectedSubDefectComments.length - 1, 1);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](15, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](16, " Defects ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](17, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](19, "div", 13)(20, "div", 4)(21, "div", 14)(22, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](23, "i", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](24, "input", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_Template_input_ngModelChange_24_listener($event) {
          return ctx.defectCommentRequestDto.descriptionEn = $event;
        })("ngModelChange", function SubVisualDefectCommentsComponent_Template_input_ngModelChange_24_listener() {
          return ctx.filterOnDescription();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](25, "div", 14)(26, "h2", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](27, " Visual Defects Selection");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](28, "div", 14)(29, "div", 19)(30, "div", 20)(31, "div", 21)(32, "span");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](33, " Sort ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](34, "div", 21)(35, "a", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_35_listener() {
          return ctx.toggleRecentFilter();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](36, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](37, "div", 21)(38, "a", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_38_listener() {
          return ctx.toggleOrderByDescription();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](39, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](40, "div", 21)(41, "a", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_a_click_41_listener() {
          return ctx.toggleOrderByCommentId();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](42, "img", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](43, "div", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](44, SubVisualDefectCommentsComponent_div_44_Template, 9, 12, "div", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](45, "div", 28)(46, "div", 29)(47, "button", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_47_listener() {
          return ctx.navigateBackToSubDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](48, "Back");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](49, "app-confirm-defects", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](50, "div", 32)(51, "div", 33)(52, "div", 34)(53, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](54, SubVisualDefectCommentsComponent_div_54_Template, 6, 2, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](55, SubVisualDefectCommentsComponent_div_55_Template, 4, 1, "div", 36);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](56, "div", 37)(57, "div", 38)(58, "div", 4)(59, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](60, SubVisualDefectCommentsComponent_div_60_Template, 3, 2, "div", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](61, "div", 4)(62, "div", 40)(63, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](64, " Remarks ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](65, SubVisualDefectCommentsComponent_span_65_Template, 2, 0, "span", 42);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](66, "textarea", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("ngModelChange", function SubVisualDefectCommentsComponent_Template_textarea_ngModelChange_66_listener($event) {
          return ctx.remarkCmnt = $event;
        })("input", function SubVisualDefectCommentsComponent_Template_textarea_input_66_listener() {
          return ctx.updateLetterCount();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](67, "div", 44)(68, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](69);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](70, "div", 45)(71, "button", 46);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_71_listener() {
          return ctx.insertVin();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](72, "Vin No");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](73, "div", 4)(74, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](75, SubVisualDefectCommentsComponent_label_75_Template, 2, 0, "label", 47);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](76, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](77, SubVisualDefectCommentsComponent_div_77_Template, 2, 1, "div", 48);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](78, SubVisualDefectCommentsComponent_div_78_Template, 31, 11, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtemplate"](79, SubVisualDefectCommentsComponent_div_79_Template, 45, 18, "div", 49);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](80, "div", 50)(81, "button", 51);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_81_listener() {
          return ctx.cancelChanges();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](82, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](83, "button", 52);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_83_listener() {
          return ctx.saveChanges();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](84, "Save");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](85, "div", 53)(86, "div", 54)(87, "div", 55);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](88, "div", 35);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](89, "div", 37)(90, "div", 4)(91, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](92, "img", 56);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](93, "div", 40);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](94, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](95, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtext"](96, " Are you sure you want to delete this defect ? ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](97, "br")(98, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](99, "button", 57);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](100, "img", 58);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](101, "button", 59);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("click", function SubVisualDefectCommentsComponent_Template_button_click_101_listener() {
          return ctx.deleteDefectComment(ctx.defectDelIndex, ctx.delSource);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelement"](102, "img", 60);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](103, "div", 61);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("hidden.bs.modal", function SubVisualDefectCommentsComponent_Template_div_hidden_bs_modal_103_listener() {
          return ctx.onFileUploadModalHidden();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementStart"](104, "div", 62)(105, "div", 34)(106, "app-file-uploads", 63);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵlistener"]("fileUploaded", function SubVisualDefectCommentsComponent_Template_app_file_uploads_fileUploaded_106_listener($event) {
          return ctx.onFileUploadData($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"]("", ctx.isOkComments ? "Comment" : ctx.selectedMainDefect.defectNameEn, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isOkComments);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵstyleProp"]("pointer-events", (ctx.selectedSubDefectComments == null ? null : ctx.selectedSubDefectComments.length) + (ctx.prevSavedDefects == null ? null : ctx.prevSavedDefects.length) + (ctx.selectedDefectsPrevList == null ? null : ctx.selectedDefectsPrevList.length) == 0 ? "none" : "auto");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" ", (ctx.selectedSubDefectComments == null ? null : ctx.selectedSubDefectComments.length) + (ctx.prevSavedDefects == null ? null : ctx.prevSavedDefects.length) + (ctx.selectedDefectsPrevList == null ? null : ctx.selectedDefectsPrevList.length), " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.defectCommentRequestDto.descriptionEn);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](27, _c2, ctx.defectCommentRequestDto.recent == undefined));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx.defectCommentRequestDto.recent == undefined ? "./assets/img/defects-icon/time_filter.svg" : "./assets/img/defects-icon/time_filter_white.svg", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](29, _c2, ctx.defectCommentRequestDto.orderByDescription == undefined));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx.defectCommentRequestDto.orderByDescription == undefined ? "./assets/img/defects-icon/letter_filter.svg" : "./assets/img/defects-icon/letter_filter_white.svg", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵpureFunction1"](31, _c2, ctx.defectCommentRequestDto.orderByCommentId == undefined));
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("src", ctx.defectCommentRequestDto.orderByCommentId == undefined ? "./assets/img/defects-icon/number_filter_orange.svg" : "./assets/img/defects-icon/number_filter.svg", _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵsanitizeUrl"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.subDefectCommentsList);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("deletionTrigger", ctx.deletionTrigger);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isDefectCountSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isDefectCountSelected);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isDefectSaved);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.isRemarkRequired);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngModel", ctx.remarkCmnt)("disabled", ctx.disableDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵtextInterpolate1"](" length: ", ctx.letterCount, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", ctx.disableDef);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", !ctx.isReadOnlyEvaluation);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngForOf", ctx.evaluationList.slice().reverse());
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.showDefectVehicle);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("ngIf", ctx.showDefectTruck);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_13__["ɵɵproperty"]("disabled", !ctx.canClosePopup || !ctx.locationAdded);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_15__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.NgModel, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_11__.FileUploadsComponent, _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_12__.ConfirmDefectsComponent],
    styles: [".outline-radio-container[_ngcontent-%COMP%]:hover   .bi[_ngcontent-%COMP%] {\r\n    color: #fb8d0d;\r\n    cursor: pointer;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n    background-color: #ef9c3d;\r\n    color: #ffff;\r\n}\r\n\r\n\r\n#fileUploadModal[_ngcontent-%COMP%] {\r\n    z-index: 2000;\r\n}\r\n\r\n#btGray[_ngcontent-%COMP%] {\r\n    background: #d5d7da;\r\n    color: #62656c;\r\n    font-weight: bold;\r\n}\r\n\r\n#btnshort[_ngcontent-%COMP%] {\r\n    font-size: small;\r\n    border-radius: 10px;\r\n    width: 30px;\r\n}\r\n\r\n#letterCount[_ngcontent-%COMP%] {\r\n    font-style: italic;\r\n    font-size: smaller;\r\n}\r\n\r\n.shortcut[_ngcontent-%COMP%] {\r\n    float: right;\r\n}\r\n\r\n\r\nlabel.shrink-text[_ngcontent-%COMP%] {\r\n    max-width: 100%;\r\n    overflow: hidden;\r\n    text-overflow: ellipsis;\r\n    white-space: nowrap;\r\n    display: flex;\r\n    flex-wrap: nowrap;\r\n    justify-content: flex-start;\r\n    align-items: center;\r\n}\r\n\r\n#endbtns[_ngcontent-%COMP%] {\r\n    margin-top: 10px;\r\n}\r\n\r\n#fi[_ngcontent-%COMP%] {\r\n    font-size: 13px;\r\n    font-style: italic;\r\n}\r\n\r\n#attachA[_ngcontent-%COMP%] {\r\n    flex: none;\r\n    display: inline-block;\r\n}\r\n\r\n#contentconfirm[_ngcontent-%COMP%] {\r\n    width: 60%;\r\n    text-align: center;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9zdWItdmlzdWFsLWRlZmVjdC1jb21tZW50cy9zdWItdmlzdWFsLWRlZmVjdC1jb21tZW50cy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsWUFBWTtBQUNoQjs7O0FBR0E7SUFDSSxhQUFhO0FBQ2pCOztBQUVBO0lBQ0ksbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLFdBQVc7QUFDZjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxZQUFZO0FBQ2hCOzs7QUFHQTtJQUNJLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixhQUFhO0lBQ2IsaUJBQWlCO0lBQ2pCLDJCQUEyQjtJQUMzQixtQkFBbUI7QUFDdkI7O0FBRUE7SUFDSSxnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxlQUFlO0lBQ2Ysa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksVUFBVTtJQUNWLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLFVBQVU7SUFDVixrQkFBa0I7QUFDdEIiLCJzb3VyY2VzQ29udGVudCI6WyIub3V0bGluZS1yYWRpby1jb250YWluZXI6aG92ZXIgLmJpIHtcclxuICAgIGNvbG9yOiAjZmI4ZDBkO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uYnRuLW9yYW5nZTpkaXNhYmxlZCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gICAgY29sb3I6ICNmZmZmO1xyXG59XHJcblxyXG5cclxuI2ZpbGVVcGxvYWRNb2RhbCB7XHJcbiAgICB6LWluZGV4OiAyMDAwO1xyXG59XHJcblxyXG4jYnRHcmF5IHtcclxuICAgIGJhY2tncm91bmQ6ICNkNWQ3ZGE7XHJcbiAgICBjb2xvcjogIzYyNjU2YztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4jYnRuc2hvcnQge1xyXG4gICAgZm9udC1zaXplOiBzbWFsbDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB3aWR0aDogMzBweDtcclxufVxyXG5cclxuI2xldHRlckNvdW50IHtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICAgIGZvbnQtc2l6ZTogc21hbGxlcjtcclxufVxyXG5cclxuLnNob3J0Y3V0IHtcclxuICAgIGZsb2F0OiByaWdodDtcclxufVxyXG5cclxuXHJcbmxhYmVsLnNocmluay10ZXh0IHtcclxuICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC13cmFwOiBub3dyYXA7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4jZW5kYnRucyB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4jZmkge1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59XHJcblxyXG4jYXR0YWNoQSB7XHJcbiAgICBmbGV4OiBub25lO1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4jY29udGVudGNvbmZpcm0ge1xyXG4gICAgd2lkdGg6IDYwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 39481:
/*!********************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/sub-visual-defect/sub-visual-defect.component.ts ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubVisualDefectComponent": () => (/* binding */ SubVisualDefectComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/visual-defects.service */ 92498);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../confirm-defects/confirm-defects.component */ 17767);







function SubVisualDefectComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 10)(1, "a", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SubVisualDefectComponent_div_22_Template_a_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r3);
      const subDefect_r1 = restoredCtx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r2.onSelectDefect(subDefect_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 22)(3, "div", 23)(4, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const subDefect_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", subDefect_r1.subDefectId, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", subDefect_r1.descriptionEn, "");
  }
}
class SubVisualDefectComponent {
  constructor(visualDefectService, sharedData) {
    this.visualDefectService = visualDefectService;
    this.sharedData = sharedData;
    this.selectedDefect = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    this.subDefectFilter = '';
  }
  ngOnInit() {
    this.getSubVisualDefects();
    this.sharedData.isDeleteDefCmnt$.subscribe(def => {
      this.deletionTrigger = def;
    });
  }
  getSubVisualDefects() {
    this.visualDefectService.getSubVisualDefects({
      mainDefectId: this.selectedMainDefect.mainDefectId,
      descriptionEn: this.subDefectFilter == '' ? undefined : this.subDefectFilter
    }).subscribe(res => {
      this.subDefectList = res.items;
    });
  }
  onSelectDefect(SubDefect) {
    this.selectedDefect.emit(SubDefect);
  }
  navigateBackToMainDefects() {
    this.selectedDefect.emit(undefined);
  }
  static #_ = this.ɵfac = function SubVisualDefectComponent_Factory(t) {
    return new (t || SubVisualDefectComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_visual_defects_service__WEBPACK_IMPORTED_MODULE_0__.VisualDefectService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: SubVisualDefectComponent,
    selectors: [["sub-visual-defect"]],
    inputs: {
      selectedMainDefect: "selectedMainDefect"
    },
    outputs: {
      selectedDefect: "selectedDefect"
    },
    decls: 28,
    vars: 4,
    consts: [[1, "vd-content-hld"], [1, "chnage-cat-section"], [1, "row"], [1, "col-lg-6"], [1, "col-lg-12", "mb-4"], ["id", "btGray", 1, "btn-outline-gray"], [1, "btn-orange-outline", 3, "click"], [1, "bi", "bi-pencil-fill"], [1, "collg-6"], [1, "vd-title"], [1, "col-lg-4"], [1, "search-fld"], [1, "bi", "bi-search"], ["type", "text", "placeholder", "Search Sub Visual Defects", "value", "", 1, "form-control", 2, "padding-left", "45px", 3, "ngModel", "ngModelChange"], [1, "col-lg-12"], [1, "row", 2, "--bs-gutter-y", "1.5rem"], ["class", "col-lg-4", 4, "ngFor", "ngForOf"], ["id", "backBtn", 1, "row"], [1, "col-12", "end-btns", "mt-4"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], [3, "deletionTrigger"], [1, "card-link", 3, "click"], [1, "vd-card", "blue-card"], [1, "vd-card-title"]],
    template: function SubVisualDefectComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 2)(5, "div", 4)(6, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "a", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SubVisualDefectComponent_Template_a_click_8_listener() {
          return ctx.navigateBackToMainDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "i", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, " Change Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](11, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "div", 9)(13, "div", 2)(14, "div", 10)(15, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](16, "i", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "input", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function SubVisualDefectComponent_Template_input_ngModelChange_17_listener($event) {
          return ctx.subDefectFilter = $event;
        })("ngModelChange", function SubVisualDefectComponent_Template_input_ngModelChange_17_listener() {
          return ctx.getSubVisualDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 14)(19, "h2");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Visual Defect Sub Category");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "div", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](22, SubVisualDefectComponent_div_22_Template, 8, 2, "div", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "div", 17)(24, "div", 18)(25, "button", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SubVisualDefectComponent_Template_button_click_25_listener() {
          return ctx.navigateBackToMainDefects();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](26, " Back");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](27, "app-confirm-defects", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](ctx.selectedMainDefect.defectNameEn);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx.subDefectFilter);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.subDefectList);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("deletionTrigger", ctx.deletionTrigger);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgModel, _confirm_defects_confirm_defects_component__WEBPACK_IMPORTED_MODULE_2__.ConfirmDefectsComponent],
    styles: ["#btGray[_ngcontent-%COMP%] {\r\n    background: #d5d7da;\r\n    color: #62656c;\r\n    font-weight: bold;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC9zdWItdmlzdWFsLWRlZmVjdC9zdWItdmlzdWFsLWRlZmVjdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCxpQkFBaUI7QUFDckIiLCJzb3VyY2VzQ29udGVudCI6WyIjYnRHcmF5IHtcclxuICAgIGJhY2tncm91bmQ6ICNkNWQ3ZGE7XHJcbiAgICBjb2xvcjogIzYyNjU2YztcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 12207:
/*!**********************************************************************************************************!*\
  !*** ./src/app/modules/inspection/pages/visualDefect/visual-defect-list/visual-defect-list.component.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VisualDefectListComponent": () => (/* binding */ VisualDefectListComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 26562);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 68951);
/* harmony import */ var src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/utilities/enums/defect-selection */ 81295);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../main-visual-defect/main-visual-defect.component */ 26591);
/* harmony import */ var _sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../sub-visual-defect/sub-visual-defect.component */ 39481);
/* harmony import */ var _sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../sub-visual-defect-comments/sub-visual-defect-comments.component */ 97226);
/* harmony import */ var _popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../popup-defect/popup-defect.component */ 92961);









function VisualDefectListComponent_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "div", 1)(2, "div", 2)(3, "a", 3)(4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5, " Defects ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](8, "div", 5)(9, "div", 6)(10, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](11, "app-popup-defect");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", (ctx_r0.prevSavedDefects == null ? null : ctx_r0.prevSavedDefects.length) + (ctx_r0.selectedDefectsPrevList == null ? null : ctx_r0.selectedDefectsPrevList.length), " ");
  }
}
function VisualDefectListComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "main-visual-defect", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("isOkComments", function VisualDefectListComponent_ng_container_1_Template_main_visual_defect_isOkComments_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r5);
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r4.setSelectedOnlyComments());
    })("selectedDefect", function VisualDefectListComponent_ng_container_1_Template_main_visual_defect_selectedDefect_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r5);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r6.setSelecetdMainDefect($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
}
function VisualDefectListComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "sub-visual-defect", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("selectedDefect", function VisualDefectListComponent_ng_container_2_Template_sub_visual_defect_selectedDefect_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r8);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r7.setSelecetdSubDefect($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("selectedMainDefect", ctx_r2.selectedMainDefect);
  }
}
function VisualDefectListComponent_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "sub-visual-defect-comments", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("changeCategory", function VisualDefectListComponent_ng_container_3_Template_sub_visual_defect_comments_changeCategory_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r9.clearAllSelectedDefects());
    })("openModalEvent", function VisualDefectListComponent_ng_container_3_Template_sub_visual_defect_comments_openModalEvent_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r11.openModal());
    })("changeSubCategory", function VisualDefectListComponent_ng_container_3_Template_sub_visual_defect_comments_changeSubCategory_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r10);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r12.clearSubSelectedDefects());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("isOkComments", ctx_r3.isOkComments)("selectedMainDefect", ctx_r3.selectedMainDefect)("selectedSubDefect", ctx_r3.selectedSubDefect);
  }
}
class VisualDefectListComponent {
  constructor(el, renderer, sharedData) {
    this.el = el;
    this.renderer = renderer;
    this.sharedData = sharedData;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Main;
    this.defectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode;
    this.isOkComments = false;
    this.prevSavedDefects = [];
    this.unsubscribe$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__.Subject();
    console.log("test const");
  }
  ngOnInit() {
    console.log("test visual main");
    (0,rxjs__WEBPACK_IMPORTED_MODULE_8__.combineLatest)([this.sharedData.selectedDefectsPrevList$, this.sharedData.defectCommentList$]).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_9__.takeUntil)(this.unsubscribe$)).subscribe(([selectedDefectsPrevList, defectCommentList]) => {
      this.selectedDefectsPrevList = selectedDefectsPrevList;
      this.prevSavedDefects = defectCommentList;
      const defectCount = this.selectedDefectsPrevList.length + this.prevSavedDefects?.length;
      console.log('Defect count:', defectCount);
      // Perform any actions based on the defect count here
    });
    // this.sharedData.backMainDefects$.subscribe(
    //   (back) => {
    //     if (back) {
    //       this.clearAllSelectedDefects();
    //     }
    //   }
    // )
  }

  openModalFromChild() {
    // You can add any logic here if needed before opening the modal
    this.openModal();
  }
  openModal() {
    const carImagePopModal = this.el.nativeElement.querySelector('#CarImagePop');
    console.log(carImagePopModal);
    this.renderer.addClass(carImagePopModal, 'show');
    this.renderer.setStyle(carImagePopModal, 'display', 'block');
  }
  setSelecetdMainDefect(mainDefect) {
    this.selectedMainDefect = mainDefect;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Sub;
  }
  setSelecetdSubDefect(subDefect) {
    //If user click back , hide sub section and show the main section:
    if (subDefect == undefined) {
      this.selectedMainDefect = undefined;
      this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Main;
    } else {
      this.selectedSubDefect = subDefect;
      this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Comments;
    }
  }
  setSelectedOnlyComments() {
    this.isOkComments = true;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Comments;
  }
  clearAllSelectedDefects() {
    this.isOkComments = false;
    this.selectedMainDefect = undefined;
    this.selectedSubDefect = undefined;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Main;
  }
  clearSubSelectedDefects() {
    this.isOkComments = false;
    this.selectedSubDefect = undefined;
    this.selectedDefectSelectionMode = src_app_core_utilities_enums_defect_selection__WEBPACK_IMPORTED_MODULE_0__.DefectSelectionMode.Sub;
  }
  static #_ = this.ɵfac = function VisualDefectListComponent_Factory(t) {
    return new (t || VisualDefectListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_1__.SharedDataService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
    type: VisualDefectListComponent,
    selectors: [["visual-defect-list"]],
    decls: 4,
    vars: 4,
    consts: [[4, "ngIf"], ["id", "counterDef", 1, "col-lg-6"], [1, "df-counter"], ["data-bs-toggle", "modal", "data-bs-target", "#CarImagePop"], [1, "counter-btn"], ["data-bs-priority", "2000", "data-bs-backdrop", "static", "id", "CarImagePop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade"], [1, "modal-dialog", "modal-xl", "Car-dialog"], [1, "modal-content"], [3, "isOkComments", "selectedDefect"], [3, "selectedMainDefect", "selectedDefect"], [3, "isOkComments", "selectedMainDefect", "selectedSubDefect", "changeCategory", "openModalEvent", "changeSubCategory"]],
    template: function VisualDefectListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](0, VisualDefectListComponent_ng_container_0_Template, 12, 1, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](1, VisualDefectListComponent_ng_container_1_Template, 2, 0, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](2, VisualDefectListComponent_ng_container_2_Template, 2, 1, "ng-container", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](3, VisualDefectListComponent_ng_container_3_Template, 2, 3, "ng-container", 0);
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Main || ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Sub);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Main);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Sub);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.selectedDefectSelectionMode == ctx.defectSelectionMode.Comments);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _main_visual_defect_main_visual_defect_component__WEBPACK_IMPORTED_MODULE_2__.MainVisualDefectComponent, _sub_visual_defect_sub_visual_defect_component__WEBPACK_IMPORTED_MODULE_3__.SubVisualDefectComponent, _sub_visual_defect_comments_sub_visual_defect_comments_component__WEBPACK_IMPORTED_MODULE_4__.SubVisualDefectCommentsComponent, _popup_defect_popup_defect_component__WEBPACK_IMPORTED_MODULE_5__.PopupDefectComponent],
    styles: ["#counterDef[_ngcontent-%COMP%] {\r\n    float: right;\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9pbnNwZWN0aW9uL3BhZ2VzL3Zpc3VhbERlZmVjdC92aXN1YWwtZGVmZWN0LWxpc3QvdmlzdWFsLWRlZmVjdC1saXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxZQUFZO0FBQ2hCIiwic291cmNlc0NvbnRlbnQiOlsiI2NvdW50ZXJEZWYge1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 52381:
/*!*********************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-badge.mjs ***!
  \*********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Badge": () => (/* binding */ Badge),
/* harmony export */   "BadgeDirective": () => (/* binding */ BadgeDirective),
/* harmony export */   "BadgeModule": () => (/* binding */ BadgeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var primeng_api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/api */ 14356);
/* harmony import */ var primeng_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/dom */ 71420);
/* harmony import */ var primeng_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/utils */ 68549);







function Badge_span_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "span", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r0.styleClass);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngClass", ctx_r0.containerClass())("ngStyle", ctx_r0.style);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](ctx_r0.value);
  }
}
class BadgeDirective {
  constructor(document, el, renderer) {
    this.document = document;
    this.el = el;
    this.renderer = renderer;
    this.iconPos = 'left';
    this._disabled = false;
  }
  get disabled() {
    return this._disabled;
  }
  set disabled(val) {
    this._disabled = val;
  }
  get size() {
    return this._size;
  }
  set size(val) {
    this._size = val;
    if (this.initialized) {
      this.setSizeClasses();
    }
  }
  ngAfterViewInit() {
    this.id = (0,primeng_utils__WEBPACK_IMPORTED_MODULE_1__.UniqueComponentId)() + '_badge';
    let el = this.el.nativeElement.nodeName.indexOf('-') != -1 ? this.el.nativeElement.firstChild : this.el.nativeElement;
    if (this._disabled) {
      return null;
    }
    let badge = this.document.createElement('span');
    badge.id = this.id;
    badge.className = 'p-badge p-component';
    if (this.severity) {
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-' + this.severity);
    }
    this.setSizeClasses(badge);
    if (this.value != null) {
      this.renderer.appendChild(badge, this.document.createTextNode(this.value));
      if (String(this.value).length === 1) {
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-no-gutter');
      }
    } else {
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-dot');
    }
    primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(el, 'p-overlay-badge');
    this.renderer.appendChild(el, badge);
    this.initialized = true;
  }
  get value() {
    return this._value;
  }
  set value(val) {
    if (val !== this._value) {
      this._value = val;
      if (this.initialized) {
        let badge = document.getElementById(this.id);
        if (this._value) {
          if (primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.hasClass(badge, 'p-badge-dot')) primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-dot');
          if (String(this._value).length === 1) {
            primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-no-gutter');
          } else {
            primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-no-gutter');
          }
        } else if (!this._value && !primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.hasClass(badge, 'p-badge-dot')) {
          primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-dot');
        }
        badge.innerHTML = '';
        this.renderer.appendChild(badge, document.createTextNode(this._value));
      }
    }
  }
  setSizeClasses(element) {
    const badge = element ?? this.document.getElementById(this.id);
    if (!badge) {
      return;
    }
    if (this._size) {
      if (this._size === 'large') {
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-lg');
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-xl');
      }
      if (this._size === 'xlarge') {
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.addClass(badge, 'p-badge-xl');
        primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-lg');
      }
    } else {
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-lg');
      primeng_dom__WEBPACK_IMPORTED_MODULE_2__.DomHandler.removeClass(badge, 'p-badge-xl');
    }
  }
  ngOnDestroy() {
    this.initialized = false;
  }
}
BadgeDirective.ɵfac = function BadgeDirective_Factory(t) {
  return new (t || BadgeDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2));
};
BadgeDirective.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: BadgeDirective,
  selectors: [["", "pBadge", ""]],
  hostAttrs: [1, "p-element"],
  inputs: {
    iconPos: "iconPos",
    disabled: ["badgeDisabled", "disabled"],
    size: "size",
    value: "value",
    severity: "severity"
  }
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BadgeDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[pBadge]',
      host: {
        class: 'p-element'
      }
    }]
  }], function () {
    return [{
      type: Document,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Inject,
        args: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT]
      }]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Renderer2
    }];
  }, {
    iconPos: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    disabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['badgeDisabled']
    }],
    size: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    severity: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class Badge {
  constructor() {
    this.badgeDisabled = false;
  }
  containerClass() {
    return {
      'p-badge p-component': true,
      'p-badge-no-gutter': this.value != undefined && String(this.value).length === 1,
      'p-badge-lg': this.size === 'large',
      'p-badge-xl': this.size === 'xlarge',
      'p-badge-info': this.severity === 'info',
      'p-badge-success': this.severity === 'success',
      'p-badge-warning': this.severity === 'warning',
      'p-badge-danger': this.severity === 'danger'
    };
  }
}
Badge.ɵfac = function Badge_Factory(t) {
  return new (t || Badge)();
};
Badge.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: Badge,
  selectors: [["p-badge"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    styleClass: "styleClass",
    style: "style",
    size: "size",
    severity: "severity",
    value: "value",
    badgeDisabled: "badgeDisabled"
  },
  decls: 1,
  vars: 1,
  consts: [[3, "ngClass", "class", "ngStyle", 4, "ngIf"], [3, "ngClass", "ngStyle"]],
  template: function Badge_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, Badge_span_0_Template, 2, 5, "span", 0);
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.badgeDisabled);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgStyle],
  styles: [".p-badge{display:inline-block;border-radius:10px;text-align:center;padding:0 .5rem}.p-overlay-badge{position:relative}.p-overlay-badge .p-badge{position:absolute;top:0;right:0;transform:translate(50%,-50%);transform-origin:100% 0;margin:0}.p-badge-dot{width:.5rem;min-width:.5rem;height:.5rem;border-radius:50%;padding:0}.p-badge-no-gutter{padding:0;border-radius:50%}\n"],
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](Badge, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-badge',
      template: ` <span *ngIf="!badgeDisabled" [ngClass]="containerClass()" [class]="styleClass" [ngStyle]="style">{{ value }}</span> `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-badge{display:inline-block;border-radius:10px;text-align:center;padding:0 .5rem}.p-overlay-badge{position:relative}.p-overlay-badge .p-badge{position:absolute;top:0;right:0;transform:translate(50%,-50%);transform-origin:100% 0;margin:0}.p-badge-dot{width:.5rem;min-width:.5rem;height:.5rem;border-radius:50%;padding:0}.p-badge-no-gutter{padding:0;border-radius:50%}\n"]
    }]
  }], null, {
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    size: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    severity: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    badgeDisabled: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class BadgeModule {}
BadgeModule.ɵfac = function BadgeModule_Factory(t) {
  return new (t || BadgeModule)();
};
BadgeModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: BadgeModule
});
BadgeModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](BadgeModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule],
      exports: [Badge, BadgeDirective, primeng_api__WEBPACK_IMPORTED_MODULE_4__.SharedModule],
      declarations: [Badge, BadgeDirective]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-badge.mjs.map

/***/ }),

/***/ 88395:
/*!***************************************************************!*\
  !*** ./node_modules/primeng/fesm2020/primeng-progressbar.mjs ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgressBar": () => (/* binding */ ProgressBar),
/* harmony export */   "ProgressBarModule": () => (/* binding */ ProgressBarModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);




function ProgressBar_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("display", ctx_r2.value != null && ctx_r2.value !== 0 ? "flex" : "none");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate2"]("", ctx_r2.value, "", ctx_r2.unit, "");
  }
}
function ProgressBar_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ProgressBar_div_1_div_1_Template, 2, 4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("width", ctx_r0.value + "%")("background", ctx_r0.color);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx_r0.showValue);
  }
}
function ProgressBar_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵstyleProp"]("background", ctx_r1.color);
  }
}
const _c0 = function (a1, a2) {
  return {
    "p-progressbar p-component": true,
    "p-progressbar-determinate": a1,
    "p-progressbar-indeterminate": a2
  };
};
class ProgressBar {
  constructor() {
    this.showValue = true;
    this.unit = '%';
    this.mode = 'determinate';
  }
}
ProgressBar.ɵfac = function ProgressBar_Factory(t) {
  return new (t || ProgressBar)();
};
ProgressBar.ɵcmp = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: ProgressBar,
  selectors: [["p-progressBar"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    value: "value",
    showValue: "showValue",
    style: "style",
    styleClass: "styleClass",
    unit: "unit",
    mode: "mode",
    color: "color"
  },
  decls: 3,
  vars: 10,
  consts: [["role", "progressbar", "aria-valuemin", "0", "aria-valuemax", "100", 3, "ngStyle", "ngClass"], ["class", "p-progressbar-value p-progressbar-value-animate", "style", "display:flex", 3, "width", "background", 4, "ngIf"], ["class", "p-progressbar-indeterminate-container", 4, "ngIf"], [1, "p-progressbar-value", "p-progressbar-value-animate", 2, "display", "flex"], ["class", "p-progressbar-label", 3, "display", 4, "ngIf"], [1, "p-progressbar-label"], [1, "p-progressbar-indeterminate-container"], [1, "p-progressbar-value", "p-progressbar-value-animate"]],
  template: function ProgressBar_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, ProgressBar_div_1_Template, 2, 5, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, ProgressBar_div_2_Template, 2, 2, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx.styleClass);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngStyle", ctx.style)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction2"](7, _c0, ctx.mode === "determinate", ctx.mode === "indeterminate"));
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("aria-valuenow", ctx.value);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.mode === "determinate");
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.mode === "indeterminate");
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgStyle],
  styles: [".p-progressbar{position:relative;overflow:hidden}.p-progressbar-determinate .p-progressbar-value{height:100%;width:0%;position:absolute;display:none;border:0 none;display:flex;align-items:center;justify-content:center;overflow:hidden}.p-progressbar-determinate .p-progressbar-label{display:inline-flex}.p-progressbar-determinate .p-progressbar-value-animate{transition:width 1s ease-in-out}.p-progressbar-indeterminate .p-progressbar-value:before{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim 2.1s cubic-bezier(.65,.815,.735,.395) infinite}.p-progressbar-indeterminate .p-progressbar-value:after{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(.165,.84,.44,1) infinite;animation-delay:1.15s}@keyframes p-progressbar-indeterminate-anim{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes p-progressbar-indeterminate-anim-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}\n"],
  encapsulation: 2,
  changeDetection: 0
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ProgressBar, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Component,
    args: [{
      selector: 'p-progressBar',
      template: `
        <div
            [class]="styleClass"
            [ngStyle]="style"
            role="progressbar"
            aria-valuemin="0"
            [attr.aria-valuenow]="value"
            aria-valuemax="100"
            [ngClass]="{ 'p-progressbar p-component': true, 'p-progressbar-determinate': mode === 'determinate', 'p-progressbar-indeterminate': mode === 'indeterminate' }"
        >
            <div *ngIf="mode === 'determinate'" class="p-progressbar-value p-progressbar-value-animate" [style.width]="value + '%'" style="display:flex" [style.background]="color">
                <div *ngIf="showValue" class="p-progressbar-label" [style.display]="value != null && value !== 0 ? 'flex' : 'none'">{{ value }}{{ unit }}</div>
            </div>
            <div *ngIf="mode === 'indeterminate'" class="p-progressbar-indeterminate-container">
                <div class="p-progressbar-value p-progressbar-value-animate" [style.background]="color"></div>
            </div>
        </div>
    `,
      changeDetection: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ChangeDetectionStrategy.OnPush,
      encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewEncapsulation.None,
      host: {
        class: 'p-element'
      },
      styles: [".p-progressbar{position:relative;overflow:hidden}.p-progressbar-determinate .p-progressbar-value{height:100%;width:0%;position:absolute;display:none;border:0 none;display:flex;align-items:center;justify-content:center;overflow:hidden}.p-progressbar-determinate .p-progressbar-label{display:inline-flex}.p-progressbar-determinate .p-progressbar-value-animate{transition:width 1s ease-in-out}.p-progressbar-indeterminate .p-progressbar-value:before{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim 2.1s cubic-bezier(.65,.815,.735,.395) infinite}.p-progressbar-indeterminate .p-progressbar-value:after{content:\"\";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(.165,.84,.44,1) infinite;animation-delay:1.15s}@keyframes p-progressbar-indeterminate-anim{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes p-progressbar-indeterminate-anim-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}\n"]
    }]
  }], null, {
    value: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    showValue: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    style: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    styleClass: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    unit: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    mode: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    color: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }]
  });
})();
class ProgressBarModule {}
ProgressBarModule.ɵfac = function ProgressBarModule_Factory(t) {
  return new (t || ProgressBarModule)();
};
ProgressBarModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: ProgressBarModule
});
ProgressBarModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule]
});
(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](ProgressBarModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule],
      exports: [ProgressBar],
      declarations: [ProgressBar]
    }]
  }], null, null);
})();

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=primeng-progressbar.mjs.map

/***/ })

}]);
//# sourceMappingURL=473.53bc8ea6039597ee.js.map