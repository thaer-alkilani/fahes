"use strict";
(self["webpackChunkFahes"] = self["webpackChunkFahes"] || []).push([[792],{

/***/ 35432:
/*!***********************************************************!*\
  !*** ./src/app/core/utilities/enums/service-type.enum.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServiceTypes": () => (/* binding */ ServiceTypes)
/* harmony export */ });
var ServiceTypes;
(function (ServiceTypes) {
  ServiceTypes[ServiceTypes["NormalInspection"] = 1] = "NormalInspection";
  ServiceTypes[ServiceTypes["VinStamping"] = 2] = "VinStamping";
  ServiceTypes[ServiceTypes["TankerCertificate"] = 3] = "TankerCertificate";
})(ServiceTypes || (ServiceTypes = {}));

/***/ }),

/***/ 49103:
/*!****************************************************************************************!*\
  !*** ./src/app/modules/registration/components/landing-page/landing-page.component.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LandingPageComponent": () => (/* binding */ LandingPageComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_mobile_booking_requests_mobile_booking_requests_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../shared/mobile-booking-requests/mobile-booking-requests.component */ 23985);








const _c0 = ["barCode"];
function LandingPageComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "a", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LandingPageComponent_div_9_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r3.startMb = false);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, " \u2190 Back ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
}
function LandingPageComponent_app_mobile_booking_requests_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "app-mobile-booking-requests", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("startMbRequest", function LandingPageComponent_app_mobile_booking_requests_10_Template_app_mobile_booking_requests_startMbRequest_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.startMobileRequest($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_11_div_30_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Invalid Istimara Format ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_11_div_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Please, click Enter to proceed ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
function LandingPageComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div")(1, "div", 9)(2, "div", 10)(3, "h3");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, " Read Vehicle Details ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, " Choose the preferred option ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 11)(8, "a", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LandingPageComponent_div_11_Template_a_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r10.getBarCode());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "img", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](11, "Scan Istimara");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "a");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](13, "img", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Capture Plate No");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "a", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](17, "img", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "Manual Entry");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "div", 17)(21, "div", 18)(22, "div", 19)(23, "div", 20)(24, "h1", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](25, "img", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](26, " Istimara Bar Code ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "div", 23)(28, "input", 24, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("keyup.enter", function LandingPageComponent_div_11_Template_input_keyup_enter_28_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r11);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r12.onBarcodeInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](30, LandingPageComponent_div_11_div_30_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](31, LandingPageComponent_div_11_div_31_Template, 2, 0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.registerForm.get("displayBarCode").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.registerForm.valid);
  }
}
class LandingPageComponent {
  constructor(formBuilder, router, sharedDataService, sideNav, renderer, el, route) {
    this.formBuilder = formBuilder;
    this.router = router;
    this.sharedDataService = sharedDataService;
    this.sideNav = sideNav;
    this.renderer = renderer;
    this.el = el;
    this.route = route;
    this.isMobileStation = false;
    this.submitted = false;
    this.offers = [];
    this.registerForm = formBuilder.group({
      displayBarCode: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.pattern(/^.{3,8}$/)]]
    });
  }
  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.startMb = params['startMb'];
    });
    this.sideNav.setHeaderValue(false, true);
    this.sideNav.setActiveEnt(1, 1);
    this.sharedDataService.setText('');
    setTimeout(() => {
      this.renderer.selectRootElement(this.barCode.nativeElement).focus();
    }, 200);
    this.stationClass = localStorage.getItem('stationClassification');
    if (parseInt(this.stationClass) == 2) {
      this.isMobileStation = true;
    }
    /*
    this.hubConnectionBuilder = new HubConnectionBuilder().withUrl('http://localhost:5125/CaptuerVehicleDetailsHub')
      .configureLogging(LogLevel.Information)
      .build();
          this.hubConnectionBuilder.start()
      .then(() => console.log('Connection started.......!'))
      .catch(err => console.log('Error while connect with server'));
          this.hubConnectionBuilder.on('sentVehicleDetails', (result: any) => {
      this.sharedDataService.scannedVehicleDetails.next(result);
      this.router.navigate(['registration/landing/manual-registration']);
    });
    */
  }

  startMobileRequest(value) {
    this.startMb = value;
  }
  getBarCode() {
    setTimeout(() => {
      const myInput = this.el.nativeElement.querySelector('#barCode');
      if (myInput) {
        myInput.focus();
      }
    }, 300);
  }
  onBarcodeInput(event) {
    const newValue = event.target.value.replace(/[^0-9]/g, '');
    const barcodeValue = newValue;
    this.displayBarCode = barcodeValue;
    this.readBarCode();
  }
  readBarCode() {
    if (this.registerForm.valid) {
      this.sharedDataService.setText(this.displayBarCode);
      //this.enterButton.nativeElement.click();
      this.router.navigate(['registration/landing/manual-registration']);
      const modalElement = document.getElementById('istimaraCode');
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
    }
  }
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
  }
  onReset() {
    this.submitted = false;
    this.registerForm.reset();
  }
  ngOnDestroy() {}
  static #_ = this.ɵfac = function LandingPageComponent_Factory(t) {
    return new (t || LandingPageComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_0__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_1__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
    type: LandingPageComponent,
    selectors: [["landing-page"]],
    viewQuery: function LandingPageComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.barCode = _t.first);
      }
    },
    decls: 12,
    vars: 4,
    consts: [["lang", "en"], ["charset", "utf-8"], ["content", "width=device-width, initial-scale=1.0", "name", "viewport"], ["href", "./assets/img/favicon.png", "rel", "icon"], [3, "formGroup"], [4, "ngIf"], [3, "startMbRequest", 4, "ngIf"], ["id", "back", 3, "click"], [3, "startMbRequest"], [1, "main-container-wrap"], [1, "rvd"], [1, "rvd-links"], ["id", "scode", "data-bs-toggle", "modal", "data-bs-target", "#istimaraCode", 3, "click"], ["src", "./assets/img/scan.svg"], ["src", "./assets/img/camera.svg"], ["routerLink", "./manual-registration", 1, "btn", "btn-link"], ["src", "./assets/img/keyboard.svg"], ["id", "istimaraCode", "aria-labelledby", "exampleModalLabel", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], [1, "modal-title"], ["src", "./assets/img/scan.svg", "width", "50px"], [1, "modal-body"], ["type", "text", "id", "barCode", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "displayBarCode", "onblur", "this.focus()", "autofocus", "", 1, "form-control", 3, "keyup.enter"], ["barCode", ""], ["class", "error-message", 4, "ngIf"], ["class", "info-msg", 4, "ngIf"], [1, "error-message"], [1, "info-msg"]],
    template: function LandingPageComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "html", 0)(1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "meta", 1)(3, "meta", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "title");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5, "FAHES ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "link", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "body")(8, "form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, LandingPageComponent_div_9_Template, 3, 0, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, LandingPageComponent_app_mobile_booking_requests_10_Template, 1, 0, "app-mobile-booking-requests", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, LandingPageComponent_div_11_Template, 32, 2, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx.registerForm);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isMobileStation && ctx.startMb);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.isMobileStation && !ctx.startMb);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.isMobileStation || ctx.startMb);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterLink, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName, _shared_mobile_booking_requests_mobile_booking_requests_component__WEBPACK_IMPORTED_MODULE_2__.MobileBookingRequestsComponent],
    styles: [".rvd[_ngcontent-%COMP%] {\r\n    margin-top: 3%;\r\n    margin-bottom: 5%;\r\n    text-align: center;\r\n}\r\n\r\n.rvd[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\r\n    font-size: 24px;\r\n    font-weight: 800;\r\n}\r\n\r\n.rvd[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\r\n    color: #87898D;\r\n    font-size: 20px;\r\n}\r\n\r\n.rvd-links[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    justify-content: center;\r\n    align-items: center;\r\n    gap: 40px;\r\n}\r\n\r\n.rvd-links[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n    width: 240px;\r\n    height: 180px;\r\n    padding: 25px;\r\n    display: flex;\r\n    align-items: center;\r\n    flex-direction: column;\r\n    justify-content: center;\r\n    border-radius: 10px;\r\n    background: #FFF;\r\n    box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, 0.23);\r\n    transition: all 0.5s ease;\r\n    text-decoration: none;\r\n}\r\n\r\n.rvd-links[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\r\n    color: #34312D;\r\n    font-size: 21px;\r\n    font-weight: 600;\r\n    margin-bottom: 0;\r\n    margin-top: 15px;\r\n}\r\n\r\n.rvd-links[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\r\n    transition: all 0.5s ease;\r\n    transform: translateY(-10px);\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n    padding-top: 10px;\r\n    color: red;\r\n    font-style: italic;\r\n}\r\n\r\n.info-msg[_ngcontent-%COMP%] {\r\n    padding-top: 10px;\r\n    color: grey;\r\n    font-style: italic;\r\n}\r\n\r\n@media(max-width:992px) {\r\n    .rvd-links[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n        padding: 25px 10px;\r\n    }\r\n}\r\n\r\n@media(max-width:480px) {\r\n    .rvd-links[_ngcontent-%COMP%] {\r\n        flex-wrap: wrap;\r\n        gap: 25px;\r\n    }\r\n\r\n    .rvd-links[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n        width: 100%;\r\n    }\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hc3NldHMvc3R5bGVzL2xhbmRpbmcuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGlCQUFpQjtJQUNqQixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxlQUFlO0lBQ2YsZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksY0FBYztJQUNkLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSxhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQixTQUFTO0FBQ2I7O0FBRUE7SUFDSSxZQUFZO0lBQ1osYUFBYTtJQUNiLGFBQWE7SUFDYixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLHNCQUFzQjtJQUN0Qix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLGdCQUFnQjtJQUNoQiwrQ0FBK0M7SUFDL0MseUJBQXlCO0lBQ3pCLHFCQUFxQjtBQUN6Qjs7QUFFQTtJQUNJLGNBQWM7SUFDZCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUNoQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSx5QkFBeUI7SUFDekIsNEJBQTRCO0FBQ2hDOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLFVBQVU7SUFDVixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsV0FBVztJQUNYLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJO1FBQ0ksa0JBQWtCO0lBQ3RCO0FBQ0o7O0FBRUE7SUFDSTtRQUNJLGVBQWU7UUFDZixTQUFTO0lBQ2I7O0lBRUE7UUFDSSxXQUFXO0lBQ2Y7QUFDSiIsInNvdXJjZXNDb250ZW50IjpbIi5ydmQge1xyXG4gICAgbWFyZ2luLXRvcDogMyU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1JTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnJ2ZCBoMyB7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgICBmb250LXdlaWdodDogODAwO1xyXG59XHJcblxyXG4ucnZkIHAge1xyXG4gICAgY29sb3I6ICM4Nzg5OEQ7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbn1cclxuXHJcbi5ydmQtbGlua3Mge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGdhcDogNDBweDtcclxufVxyXG5cclxuLnJ2ZC1saW5rcyBhIHtcclxuICAgIHdpZHRoOiAyNDBweDtcclxuICAgIGhlaWdodDogMTgwcHg7XHJcbiAgICBwYWRkaW5nOiAyNXB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZDogI0ZGRjtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggNHB4IDBweCByZ2JhKDAsIDAsIDAsIDAuMjMpO1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuNXMgZWFzZTtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG5cclxuLnJ2ZC1saW5rcyBhIHAge1xyXG4gICAgY29sb3I6ICMzNDMxMkQ7XHJcbiAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbn1cclxuXHJcbi5ydmQtbGlua3MgYTpob3ZlciB7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC41cyBlYXNlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xMHB4KTtcclxufVxyXG5cclxuLmVycm9yLW1lc3NhZ2Uge1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59XHJcblxyXG4uaW5mby1tc2cge1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBjb2xvcjogZ3JleTtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxufVxyXG5cclxuQG1lZGlhKG1heC13aWR0aDo5OTJweCkge1xyXG4gICAgLnJ2ZC1saW5rcyBhIHtcclxuICAgICAgICBwYWRkaW5nOiAyNXB4IDEwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBtZWRpYShtYXgtd2lkdGg6NDgwcHgpIHtcclxuICAgIC5ydmQtbGlua3Mge1xyXG4gICAgICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgICAgICBnYXA6IDI1cHg7XHJcbiAgICB9XHJcblxyXG4gICAgLnJ2ZC1saW5rcyBhIHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgIH1cclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 82325:
/*!******************************************************************************************************!*\
  !*** ./src/app/modules/registration/components/manual-registration/manual-registration.component.ts ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ManualRegistrationComponent": () => (/* binding */ ManualRegistrationComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! rxjs */ 19337);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! rxjs */ 50635);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! rxjs */ 87580);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! rxjs */ 53158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! rxjs */ 59346);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! rxjs */ 63853);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! rxjs */ 32673);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! rxjs */ 91640);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/models/register-vehicle */ 54611);
/* harmony import */ var src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/models/service-request */ 84908);
/* harmony import */ var src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/utilities/enums/payment-methods.enum */ 81386);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-codes */ 14726);
/* harmony import */ var src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/core/utilities/enums/system-lookup-value-codes */ 53805);
/* harmony import */ var src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/core/utilities/enums/inspectionServiceTypes */ 43327);
/* harmony import */ var src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/core/utilities/enums/print-ssrs.enum */ 64746);
/* harmony import */ var src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/core/utilities/enums/module-source-enum */ 9802);
/* harmony import */ var src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/core/utilities/enums/report-type.enum */ 76622);
/* harmony import */ var src_app_core_utilities_enums_service_type_enum__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/core/utilities/enums/service-type.enum */ 35432);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/core/services/lookup-values.service */ 31523);
/* harmony import */ var src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/core/services/vehicle-details.service */ 13641);
/* harmony import */ var src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/core/services/file.service */ 75349);
/* harmony import */ var src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/core/services/purchase.service */ 87010);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/core/services/shared-data.service */ 63935);
/* harmony import */ var src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/core/services/shared-lookup.service */ 35022);
/* harmony import */ var src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! src/app/core/services/sidenav.service */ 65837);
/* harmony import */ var src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! src/app/core/services/payment.service */ 86074);
/* harmony import */ var src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! src/app/core/services/global-config.service */ 83669);
/* harmony import */ var src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! src/app/core/services/ssrs-print.service */ 64795);
/* harmony import */ var src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! src/app/core/services/thousand-separator.service */ 27476);
/* harmony import */ var src_app_core_services_booked_requests_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! src/app/core/services/booked-requests.service */ 45487);
/* harmony import */ var src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! src/app/core/services/inspection-service.service */ 11428);
/* harmony import */ var _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../../../shared/file-uploads/file-uploads.component */ 19465);
/* harmony import */ var _shared_thousand_separator_directive__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../../../shared/thousand-separator.directive */ 59903);
/* harmony import */ var _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../../../shared/payments-popups/payment-transaction-status-modal/payment-transaction-status-modal.component */ 69786);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);


































function ManualRegistrationComponent_div_15_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * This Vehicle is Not Registered in MOI ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * This Vehicle Has Active Service Already ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r15.errorMessage, " ");
  }
}
function ManualRegistrationComponent_div_15_div_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * This Vehicle is Blacklisted ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_option_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const pt_r69 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", pt_r69.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", pt_r69.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_15_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_select_21_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vc_r71 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", vc_r71.categoryId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", vc_r71.descriptionEn, " ");
  }
}
function ManualRegistrationComponent_div_15_select_21_Template(rf, ctx) {
  if (rf & 1) {
    const _r73 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "select", 85);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("ngModelChange", function ManualRegistrationComponent_div_15_select_21_Template_select_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r73);
      const ctx_r72 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r72.checkVehicleServices());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_15_select_21_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r19.manualReg.get("vehicleCategories").value);
  }
}
function ManualRegistrationComponent_div_15_input_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 86);
  }
  if (rf & 2) {
    const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("readonly", ctx_r20.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_select_26_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ot_r75 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ot_r75.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ot_r75.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_15_select_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r77 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "select", 87);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("ngModelChange", function ManualRegistrationComponent_div_15_select_26_Template_select_ngModelChange_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r77);
      const ctx_r76 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r76.updateOwnerType());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_15_select_26_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r21.manualReg.get("ownerTypes").value);
  }
}
function ManualRegistrationComponent_div_15_div_27_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Owner not a staff ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_28_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 88);
  }
  if (rf & 2) {
    const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("readonly", !ctx_r23.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 89);
  }
  if (rf & 2) {
    const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r24.manualReg.get("vdetails").value.ownerPID ? ctx_r24.manualReg.get("vdetails").value.ownerPID : "");
  }
}
function ManualRegistrationComponent_div_15_input_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r79 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "input", 90);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("input", function ManualRegistrationComponent_div_15_input_33_Template_input_input_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r79);
      const ctx_r78 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r78.formatPidInput($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_35_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Enter a valid Owner PID ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r28.manualReg.get("vdetails").value.ownerName ? ctx_r28.manualReg.get("vdetails").value.ownerName : "")("readonly", !ctx_r28.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_40_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 92);
  }
}
function ManualRegistrationComponent_div_15_div_41_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Enter a valid Owner Name ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_span_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "*");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 93);
  }
  if (rf & 2) {
    const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r32.manualReg.get("expDate").value);
  }
}
function ManualRegistrationComponent_div_15_input_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r33.manualReg.get("formatExpDate").value ? ctx_r33.manualReg.get("formatExpDate").value : "")("readonly", ctx_r33.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_div_48_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Invalid date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_49_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const nq_r81 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", nq_r81.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", nq_r81.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_15_div_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 19)(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2, " GCC ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](3, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4, "Non Qatari");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](5, " Countries * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](6, "select", 94);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](7, ManualRegistrationComponent_div_15_div_49_option_7_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r35.nonQatariList);
  }
}
function ManualRegistrationComponent_div_15_input_55_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 95);
  }
  if (rf & 2) {
    const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r36.manualReg.get("vdetails").value.vinNo ? ctx_r36.manualReg.get("vdetails").value.vinNo : "")("readonly", !ctx_r36.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_57_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "input", 96);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("input", function ManualRegistrationComponent_div_15_input_57_Template_input_input_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r83);
      const ctx_r82 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r82.updateLetterCount(ctx_r82.manualReg.get("inputVinNo").value, "vin"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_58_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 97);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r38.vinCount, " ");
  }
}
function ManualRegistrationComponent_div_15_ng_select_62_ng_option_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "ng-option", 102)(1, "div", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const m_r85 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", m_r85.manufacturersId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", m_r85.manufacturersEname, " ");
  }
}
function ManualRegistrationComponent_div_15_ng_select_62_Template(rf, ctx) {
  if (rf & 1) {
    const _r87 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "ng-select", 98);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("clear", function ManualRegistrationComponent_div_15_ng_select_62_Template_ng_select_clear_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r87);
      const ctx_r86 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r86.onClearManfSearch($event));
    })("change", function ManualRegistrationComponent_div_15_ng_select_62_Template_ng_select_change_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r87);
      const ctx_r88 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r88.getModelTypes($event));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](1, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerStart"](2, 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](3, "ng-option", 100);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](4, ManualRegistrationComponent_div_15_ng_select_62_ng_option_4_Template, 3, 2, "ng-option", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("minTermLength", 3)("closeOnSelect", true)("clearSearchOnAdd", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r39.manualReg.get("manufacturerTypes").value);
  }
}
function ManualRegistrationComponent_div_15_div_63_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_64_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r41.manualReg.get("vdetails").value.manufacturersEname ? ctx_r41.manualReg.get("vdetails").value.manufacturersEname : "")("readonly", ctx_r41.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_ng_select_68_ng_option_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "ng-option", 84)(1, "div", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const m_r90 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", m_r90.modelId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", m_r90.modelEname, " ");
  }
}
function ManualRegistrationComponent_div_15_ng_select_68_Template(rf, ctx) {
  if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "ng-select", 104);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("clear", function ManualRegistrationComponent_div_15_ng_select_68_Template_ng_select_clear_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r92);
      const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r91.onClearModelSearch());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](1, "div", 105);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_15_ng_select_68_ng_option_2_Template, 3, 2, "ng-option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("minTermLength", 0)("closeOnSelect", true)("clearSearchOnAdd", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r42.manualReg.get("modelTypes").value);
  }
}
function ManualRegistrationComponent_div_15_input_69_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r43.manualReg.get("vdetails").value.modelEname ? ctx_r43.manualReg.get("vdetails").value.modelEname : "")("readonly", ctx_r43.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_input_73_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 89);
  }
  if (rf & 2) {
    const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r44.manualReg.get("vdetails").value.manufacturerYear ? ctx_r44.manualReg.get("vdetails").value.manufacturerYear : "");
  }
}
function ManualRegistrationComponent_div_15_select_74_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const year_r94 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", year_r94);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate"](year_r94);
  }
}
function ManualRegistrationComponent_div_15_select_74_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "select", 106);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_15_select_74_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r45.getYearRange());
  }
}
function ManualRegistrationComponent_div_15_div_75_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Enter a valid year");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_79_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r47 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r47.manualReg.get("vdetails").value.cylinders ? ctx_r47.manualReg.get("vdetails").value.cylinders : "")("readonly", !ctx_r47.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_80_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 107);
  }
}
function ManualRegistrationComponent_div_15_div_81_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Enter a valid vehicle cylinders ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_82_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_86_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 108);
  }
  if (rf & 2) {
    const ctx_r51 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r51.manualReg.get("vdetails").value.weight ? ctx_r51.manualReg.get("vdetails").value.weight : "")("readonly", !ctx_r51.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_87_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 109);
  }
  if (rf & 2) {
    const ctx_r52 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("readonly", ctx_r52.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_div_88_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Enter a valid weight");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_92_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 108);
  }
  if (rf & 2) {
    const ctx_r54 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r54.manualReg.get("vdetails").value.payloadWeight ? ctx_r54.manualReg.get("vdetails").value.payloadWeight : "")("readonly", !ctx_r54.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_93_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 110);
  }
  if (rf & 2) {
    const ctx_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("readonly", ctx_r55.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_div_94_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Enter a valid payload weight ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_select_98_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r96 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", color_r96.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", color_r96.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_15_select_98_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "select", 111);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_15_select_98_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r57.manualReg.get("colorList").value);
  }
}
function ManualRegistrationComponent_div_15_div_99_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_input_100_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 112);
  }
  if (rf & 2) {
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("readonly", ctx_r59.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_select_104_option_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const color_r98 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", color_r98.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", color_r98.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_15_select_104_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "select", 113);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_15_select_104_option_1_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r60.manualReg.get("colorList").value);
  }
}
function ManualRegistrationComponent_div_15_input_105_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r61.manualReg.get("subclr").value)("readonly", ctx_r61.manualReg.get("nonEditable").value);
  }
}
function ManualRegistrationComponent_div_15_input_109_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 91);
  }
  if (rf & 2) {
    const ctx_r62 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", ctx_r62.manualReg.get("vdetails").value.noOfSeat ? ctx_r62.manualReg.get("vdetails").value.noOfSeat : "")("readonly", !ctx_r62.isManualEntry);
  }
}
function ManualRegistrationComponent_div_15_input_110_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "input", 114);
  }
}
function ManualRegistrationComponent_div_15_div_111_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Enter a valid No of seats ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_15_div_113_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r99 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" Reinspection ", ctx_r99.manualReg.get("noOfReinspections").value, "");
  }
}
function ManualRegistrationComponent_div_15_div_113_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 115);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](1, "div", 116);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_15_div_113_span_2_Template, 2, 1, "span", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r65 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r65.manualReg.get("isReinspection").value);
  }
}
function ManualRegistrationComponent_div_15_div_114_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 117);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](1, "div", 118);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3, " Woqod Vehicle ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
}
function ManualRegistrationComponent_div_15_div_115_Template(rf, ctx) {
  if (rf & 1) {
    const _r101 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 119)(1, "label", 120)(2, "input", 121);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("change", function ManualRegistrationComponent_div_15_div_115_Template_input_change_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r101);
      const ctx_r100 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r100.staffRateChanges());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](3, "span", 122);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](4, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](5, "Apply Staff Rate");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r67 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("checked", ctx_r67.manualReg.get("isStaffRate").value);
  }
}
function ManualRegistrationComponent_div_15_span_119_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 123);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r68 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" (", ctx_r68.fileName, ") ");
  }
}
function ManualRegistrationComponent_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 44)(1, "div", 17)(2, "div", 18)(3, "div", 19)(4, "label", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](5, " License Plate No *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](6, "input", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](7, ManualRegistrationComponent_div_15_div_7_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](8, ManualRegistrationComponent_div_15_div_8_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](9, ManualRegistrationComponent_div_15_div_9_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](10, ManualRegistrationComponent_div_15_div_10_Template, 2, 1, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](11, ManualRegistrationComponent_div_15_div_11_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](12, "div", 19)(13, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](14, " License Plate Type *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](15, "select", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](16, ManualRegistrationComponent_div_15_option_16_Template, 2, 2, "option", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](17, ManualRegistrationComponent_div_15_div_17_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](18, "div", 19)(19, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](20, "Vehicle Category *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](21, ManualRegistrationComponent_div_15_select_21_Template, 2, 1, "select", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](22, ManualRegistrationComponent_div_15_input_22_Template, 1, 1, "input", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](23, "div", 19)(24, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](25, "Owner PID Type *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](26, ManualRegistrationComponent_div_15_select_26_Template, 2, 1, "select", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](27, ManualRegistrationComponent_div_15_div_27_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](28, ManualRegistrationComponent_div_15_input_28_Template, 1, 1, "input", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](29, "div", 19)(30, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](31, "Owner PID *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](32, ManualRegistrationComponent_div_15_input_32_Template, 1, 1, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](33, ManualRegistrationComponent_div_15_input_33_Template, 1, 0, "input", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](34, ManualRegistrationComponent_div_15_div_34_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](35, ManualRegistrationComponent_div_15_div_35_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](36, "div", 19)(37, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](38, "Owner Name");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](39, ManualRegistrationComponent_div_15_input_39_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](40, ManualRegistrationComponent_div_15_input_40_Template, 1, 0, "input", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](41, ManualRegistrationComponent_div_15_div_41_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](42, "div", 19)(43, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](44, "Istimara Expiry Date ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](45, ManualRegistrationComponent_div_15_span_45_Template, 2, 0, "span", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](46, ManualRegistrationComponent_div_15_input_46_Template, 1, 1, "input", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](47, ManualRegistrationComponent_div_15_input_47_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](48, ManualRegistrationComponent_div_15_div_48_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](49, ManualRegistrationComponent_div_15_div_49_Template, 8, 1, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](50, "div", 60)(51, "div", 18)(52, "div", 19)(53, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](54, "VIN No *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](55, ManualRegistrationComponent_div_15_input_55_Template, 1, 2, "input", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](56, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](57, ManualRegistrationComponent_div_15_input_57_Template, 1, 0, "input", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](58, ManualRegistrationComponent_div_15_div_58_Template, 2, 1, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](59, "div", 19)(60, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](61, "Manufacturer *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](62, ManualRegistrationComponent_div_15_ng_select_62_Template, 5, 4, "ng-select", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](63, ManualRegistrationComponent_div_15_div_63_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](64, ManualRegistrationComponent_div_15_input_64_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](65, "div", 19)(66, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](67, "Model");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](68, ManualRegistrationComponent_div_15_ng_select_68_Template, 3, 4, "ng-select", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](69, ManualRegistrationComponent_div_15_input_69_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](70, "div", 19)(71, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](72, "Manufacturing Year *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](73, ManualRegistrationComponent_div_15_input_73_Template, 1, 1, "input", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](74, ManualRegistrationComponent_div_15_select_74_Template, 2, 1, "select", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](75, ManualRegistrationComponent_div_15_div_75_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](76, "div", 19)(77, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](78, "Cylinders *");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](79, ManualRegistrationComponent_div_15_input_79_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](80, ManualRegistrationComponent_div_15_input_80_Template, 1, 0, "input", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](81, ManualRegistrationComponent_div_15_div_81_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](82, ManualRegistrationComponent_div_15_div_82_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](83, "div", 19)(84, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](85, "Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](86, ManualRegistrationComponent_div_15_input_86_Template, 1, 2, "input", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](87, ManualRegistrationComponent_div_15_input_87_Template, 1, 1, "input", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](88, ManualRegistrationComponent_div_15_div_88_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](89, "div", 19)(90, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](91, "Payload Weight (kg)");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](92, ManualRegistrationComponent_div_15_input_92_Template, 1, 2, "input", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](93, ManualRegistrationComponent_div_15_input_93_Template, 1, 1, "input", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](94, ManualRegistrationComponent_div_15_div_94_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](95, "div", 19)(96, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](97, "Color * ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](98, ManualRegistrationComponent_div_15_select_98_Template, 2, 1, "select", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](99, ManualRegistrationComponent_div_15_div_99_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](100, ManualRegistrationComponent_div_15_input_100_Template, 1, 1, "input", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](101, "div", 19)(102, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](103, "Sub Color");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](104, ManualRegistrationComponent_div_15_select_104_Template, 2, 1, "select", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](105, ManualRegistrationComponent_div_15_input_105_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](106, "div", 19)(107, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](108, "Seats");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](109, ManualRegistrationComponent_div_15_input_109_Template, 1, 2, "input", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](110, ManualRegistrationComponent_div_15_input_110_Template, 1, 0, "input", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](111, ManualRegistrationComponent_div_15_div_111_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](112, "div", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](113, ManualRegistrationComponent_div_15_div_113_Template, 3, 1, "div", 77);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](114, ManualRegistrationComponent_div_15_div_114_Template, 4, 0, "div", 78);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](115, ManualRegistrationComponent_div_15_div_115_Template, 6, 1, "div", 79);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](116, "button", 80);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](117, "span", 81);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](118, " Attachement ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](119, ManualRegistrationComponent_div_15_span_119_Template, 2, 1, "span", 82);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputPlateNo").invalid && ctx_r0.manualReg.get("inputPlateNo").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("showMoiError").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.isActiveIns || ctx_r0.isActiveVin || ctx_r0.isActiveTanker);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.errorMessage);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.isBlacklist);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r0.manualReg.get("plateTypes").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputPlateType").invalid && ctx_r0.manualReg.get("inputPlateType").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value || ctx_r0.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value && !ctx_r0.enableCategorySelection);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.isValidType);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.manualReg.get("inputPid").hasError("required") && ctx_r0.manualReg.get("inputPid").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.manualReg.get("inputPid").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.manualReg.get("inputOwnerName").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.isIstimaraDate);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("expDate").hasError("InvalidDate") && ctx_r0.manualReg.get("expDate").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.allowNonQatariList);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.vinCount);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.manualReg.get("selectedManufacturer").hasError("required") && ctx_r0.manualReg.get("selectedManufacturer").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputManfYear").touched && (ctx_r0.manualReg.get("inputManfYear").hasError("pattern") || ctx_r0.manualReg.get("inputManfYear").hasError("invalidYear")));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputCylinders").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.manualReg.get("inputCylinders").hasError("required") && ctx_r0.manualReg.get("inputCylinders").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputWeight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputPayloadweight").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value && ctx_r0.manualReg.get("selectedColor").hasError("required") && ctx_r0.manualReg.get("selectedColor").touched);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r0.manualReg.get("nonEditable").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("inputNbSeats").hasError("pattern"));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("isReinspection").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.isWoqodVehicle);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.manualReg.get("isStaffRateValue").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r0.fileName);
  }
}
function ManualRegistrationComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Required field ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_34_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * Please enter a valid phone number ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_39_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " * PID shouldn't be more than 20 characters ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_44_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Enter a valid email");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_ng_container_12_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r112 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](1, "div", 19)(2, "div", 130)(3, "input", 131);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("change", function ManualRegistrationComponent_div_45_ng_container_12_ng_container_1_Template_input_change_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r112);
      const ctx_r111 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r111.selectService());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](4, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](5, "img", 133);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const services_r108 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", services_r108.lkCodeValue)("value", services_r108.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", services_r108.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("src", "./assets/img/st-img-" + services_r108.lkCodeValue + ".svg", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", services_r108.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_45_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_45_ng_container_12_ng_container_1_Template, 7, 5, "ng-container", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const services_r108 = ctx.$implicit;
    const i_r109 = ctx.index;
    const ctx_r102 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", (ctx_r102.serviceFlags[i_r109] == null ? null : ctx_r102.serviceFlags[i_r109].id) == services_r108.lkCodeValue && ctx_r102.serviceFlags[i_r109].value == true);
  }
}
function ManualRegistrationComponent_div_45_div_13_div_6_div_1_span_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r123 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_45_div_13_div_6_div_1_span_4_Template_span_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r123);
      const ins_r117 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2).$implicit;
      const ctx_r121 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r121.clearServices(1, ins_r117.serviceId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
const _c0 = function (a0, a1) {
  return {
    serviceName: a0,
    serviceId: a1
  };
};
function ManualRegistrationComponent_div_45_div_13_div_6_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r125 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div")(1, "input", 138);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("ngModelChange", function ManualRegistrationComponent_div_45_div_13_div_6_div_1_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r125);
      const ctx_r124 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r124.onSelectServiceSubType(1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](4, ManualRegistrationComponent_div_45_div_13_div_6_div_1_span_4_Template, 1, 0, "span", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ins_r117 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    const ctx_r118 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "br" + ins_r117.serviceId)("value", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵpureFunction2"](8, _c0, ins_r117.serviceName, ins_r117.serviceId));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", ctx_r118.isManualEntry && !ctx_r118.manualReg.get("inputWeight").value && !ctx_r118.manualReg.get("inputNbSeats").value ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵstyleProp"]("background-color", ins_r117.isDefault && ctx_r118.isDefaultUnselected(ins_r117.serviceId) ? "#F89828" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "br" + ins_r117.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ins_r117.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r118.manualReg.get("selectedInsSubType").value && ctx_r118.manualReg.get("selectedInsSubType").value.serviceId == ins_r117.serviceId && ctx_r118.manualReg.get("selectedServIns").value);
  }
}
function ManualRegistrationComponent_div_45_div_13_div_6_div_2_span_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r130 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_45_div_13_div_6_div_2_span_4_Template_span_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r130);
      const ins_r117 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2).$implicit;
      const ctx_r128 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r128.clearServices(1, ins_r117.serviceId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_div_13_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](1, "input", 141);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](4, ManualRegistrationComponent_div_45_div_13_div_6_div_2_span_4_Template, 1, 0, "span", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ins_r117 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    const ctx_r119 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "brd" + ins_r117.serviceId)("value", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵpureFunction2"](7, _c0, ins_r117.serviceName, ins_r117.serviceId))("checked", ctx_r119.activeIns === ins_r117.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "brd" + ins_r117.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ins_r117.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r119.manualReg.get("selectedInsSubType").value && ctx_r119.manualReg.get("selectedInsSubType").value.serviceId == ins_r117.serviceId && ctx_r119.manualReg.get("selectedServIns").value);
  }
}
function ManualRegistrationComponent_div_45_div_13_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 137);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_45_div_13_div_6_div_1_Template, 5, 11, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_45_div_13_div_6_div_2_Template, 5, 10, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r114 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r114.isActiveIns);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r114.isActiveIns);
  }
}
function ManualRegistrationComponent_div_45_div_13_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r115 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" Inspection Services Fees: ", ctx_r115.inspectionFees, " ");
  }
}
function ManualRegistrationComponent_div_45_div_13_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " License Expiry Date is more than 30 days ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_div_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div")(1, "div", 134)(2, "div", 4)(3, "label", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4, "Inspection Service Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](6, ManualRegistrationComponent_div_45_div_13_div_6_Template, 3, 2, "div", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](7, ManualRegistrationComponent_div_45_div_13_div_7_Template, 2, 1, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](8, ManualRegistrationComponent_div_45_div_13_div_8_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r103 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r103.vehicleServices.inspectionServices);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r103.inspectionFees != null && ctx_r103.inspectionFees != 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r103.normalInsDisable);
  }
}
function ManualRegistrationComponent_div_45_div_14_div_6_div_1_span_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r141 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_45_div_14_div_6_div_1_span_4_Template_span_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r141);
      const vin_r135 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2).$implicit;
      const ctx_r139 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r139.clearServices(2, vin_r135.serviceId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_div_14_div_6_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r143 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div")(1, "input", 144);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("ngModelChange", function ManualRegistrationComponent_div_45_div_14_div_6_div_1_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r143);
      const ctx_r142 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r142.onSelectServiceSubType(2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](4, ManualRegistrationComponent_div_45_div_14_div_6_div_1_span_4_Template, 1, 0, "span", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vin_r135 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    const ctx_r136 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "brv" + vin_r135.serviceId)("value", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵpureFunction2"](6, _c0, vin_r135.serviceName, vin_r135.serviceId));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", ctx_r136.isManualEntry && !ctx_r136.manualReg.get("inputWeight").value && !ctx_r136.manualReg.get("inputNbSeats").value ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "brv" + vin_r135.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", vin_r135.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r136.manualReg.get("selectedVinStamping").value && ctx_r136.manualReg.get("selectedVinStamping").value.serviceId == vin_r135.serviceId && ctx_r136.manualReg.get("selectedServVin").value);
  }
}
function ManualRegistrationComponent_div_45_div_14_div_6_div_2_span_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r148 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_45_div_14_div_6_div_2_span_4_Template_span_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r148);
      const vin_r135 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2).$implicit;
      const ctx_r146 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r146.clearServices(2, vin_r135.serviceId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_div_14_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](1, "input", 145);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](4, ManualRegistrationComponent_div_45_div_14_div_6_div_2_span_4_Template, 1, 0, "span", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const vin_r135 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    const ctx_r137 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "brv2" + vin_r135.serviceId)("value", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵpureFunction2"](7, _c0, vin_r135.serviceName, vin_r135.serviceId))("checked", vin_r135.serviceId == ctx_r137.activeVin);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "brv2" + vin_r135.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", vin_r135.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r137.manualReg.get("selectedVinStamping").value && ctx_r137.manualReg.get("selectedVinStamping").value.serviceId == vin_r135.serviceId && ctx_r137.manualReg.get("selectedServVin").value);
  }
}
function ManualRegistrationComponent_div_45_div_14_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 137);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_45_div_14_div_6_div_1_Template, 5, 9, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_45_div_14_div_6_div_2_Template, 5, 10, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r132 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r132.isActiveVin);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r132.isActiveVin);
  }
}
function ManualRegistrationComponent_div_45_div_14_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 146)(1, "i");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](3, "br")(4, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r133 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" Available VIN Sequences: ", ctx_r133.vinSeqs, " ");
  }
}
function ManualRegistrationComponent_div_45_div_14_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r134 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" VIN Services Fees: ", ctx_r134.vinFees, " ");
  }
}
function ManualRegistrationComponent_div_45_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div")(1, "div", 134)(2, "div", 4)(3, "label", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4, "VIN Services Type");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](6, ManualRegistrationComponent_div_45_div_14_div_6_Template, 3, 2, "div", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](7, ManualRegistrationComponent_div_45_div_14_div_7_Template, 5, 1, "div", 143);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](8, ManualRegistrationComponent_div_45_div_14_div_8_Template, 2, 1, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r104 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r104.vehicleServices.vinStampingServices);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", (ctx_r104.manualReg.get("selectedVinStamping").value == null ? null : ctx_r104.manualReg.get("selectedVinStamping").value.serviceId) == 1 && ctx_r104.vinSeqs != undefined);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r104.vinFees != null && ctx_r104.vinFees != 0);
  }
}
function ManualRegistrationComponent_div_45_div_15_div_6_div_1_span_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r158 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 140);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_45_div_15_div_6_div_1_span_4_Template_span_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r158);
      const tank_r152 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2).$implicit;
      const ctx_r156 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r156.clearServices(3, tank_r152.serviceId));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_div_15_div_6_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r160 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div")(1, "input", 147);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("ngModelChange", function ManualRegistrationComponent_div_45_div_15_div_6_div_1_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r160);
      const ctx_r159 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](4);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r159.onSelectServiceSubType(3));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](4, ManualRegistrationComponent_div_45_div_15_div_6_div_1_span_4_Template, 1, 0, "span", 139);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const tank_r152 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    const ctx_r153 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "brt" + tank_r152.serviceId)("value", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵpureFunction2"](6, _c0, tank_r152.serviceName, tank_r152.serviceId));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", ctx_r153.isManualEntry && !ctx_r153.manualReg.get("inputWeight").value && !ctx_r153.manualReg.get("inputNbSeats").value ? true : null);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "brt" + tank_r152.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate"](tank_r152.serviceName);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r153.manualReg.get("selectedTanker").value && ctx_r153.manualReg.get("selectedTanker").value.serviceId == tank_r152.serviceId && ctx_r153.manualReg.get("selectedTanker").value);
  }
}
function ManualRegistrationComponent_div_45_div_15_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](1, "input", 148);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const tank_r152 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]().$implicit;
    const ctx_r154 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "brt" + tank_r152.serviceId)("value", _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵpureFunction2"](6, _c0, tank_r152.serviceName, tank_r152.serviceId))("checked", tank_r152.serviceId == ctx_r154.activeTanker);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "brt" + tank_r152.serviceId);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate"](tank_r152.serviceName);
  }
}
function ManualRegistrationComponent_div_45_div_15_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 137);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_45_div_15_div_6_div_1_Template, 5, 9, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_45_div_15_div_6_div_2_Template, 4, 9, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r150 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r150.isActiveTanker);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r150.isActiveTanker);
  }
}
function ManualRegistrationComponent_div_45_div_15_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 142);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r151 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" Tanker Certificate Fees: ", ctx_r151.tankerFees, " ");
  }
}
function ManualRegistrationComponent_div_45_div_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div")(1, "div", 134)(2, "div", 4)(3, "label", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4, " Tanker Code ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](6, ManualRegistrationComponent_div_45_div_15_div_6_Template, 3, 2, "div", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](7, ManualRegistrationComponent_div_45_div_15_div_7_Template, 2, 1, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r105 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r105.vehicleServices.tankerCertServices);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r105.tankerFees != null && ctx_r105.tankerFees != 0);
  }
}
function ManualRegistrationComponent_div_45_div_16_label_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "label", 135);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " Total Amount: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_div_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 142)(1, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_45_div_16_label_2_Template, 2, 0, "label", 149);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r106 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r106.totalInsFees != null);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r106.totalAmountTh, " ");
  }
}
function ManualRegistrationComponent_div_45_div_17_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 83);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " *Please Enter Vehicle Weight and Seat's No. to Select a Service ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_div_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 2)(1, "div", 4)(2, "div", 12)(3, "div", 6)(4, "div", 124)(5, "div", 8)(6, "h2", 125)(7, "button", 126);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](8, " Service Type ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](9, "div", 127)(10, "div", 17)(11, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](12, ManualRegistrationComponent_div_45_ng_container_12_Template, 2, 1, "ng-container", 128);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](13, ManualRegistrationComponent_div_45_div_13_Template, 9, 3, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](14, ManualRegistrationComponent_div_45_div_14_Template, 9, 3, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](15, ManualRegistrationComponent_div_45_div_15_Template, 8, 2, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](16, ManualRegistrationComponent_div_45_div_16_Template, 4, 2, "div", 129);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](17, ManualRegistrationComponent_div_45_div_17_Template, 2, 0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()()()()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r5.manualReg.get("serviceTypeList").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r5.manualReg.get("selectedServiceType").value == 1 || ctx_r5.selectedMainService.includes(1));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r5.manualReg.get("selectedServiceType").value == 2 || ctx_r5.selectedMainService.includes(2));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r5.manualReg.get("selectedServiceType").value == 3 || ctx_r5.selectedMainService.includes(3));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r5.inspectionFees || ctx_r5.vinFees || ctx_r5.tankerFees);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r5.isManualEntry && !ctx_r5.manualReg.get("inputWeight").value && !ctx_r5.manualReg.get("inputNbSeats").value ? true : null);
  }
}
function ManualRegistrationComponent_div_46_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r164 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" Remaining Amount: ", ctx_r164.convertToThousand(ctx_r164.remainingMb), " ");
  }
}
function ManualRegistrationComponent_div_46_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](1, ManualRegistrationComponent_div_46_div_1_Template, 2, 1, "div", 150);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r6.remainingMb != null);
  }
}
function ManualRegistrationComponent_span_49_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "span", 151);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " Mobile Inspection Request ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
}
function ManualRegistrationComponent_button_52_Template(rf, ctx) {
  if (rf & 1) {
    const _r166 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "button", 152);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_button_52_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r166);
      const ctx_r165 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r165.submitForm());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, "Payment");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("disabled", !ctx_r8.manualReg.get("isFormValid").value || !ctx_r8.manualReg.valid || !ctx_r8.isValidType);
  }
}
function ManualRegistrationComponent_button_53_Template(rf, ctx) {
  if (rf & 1) {
    const _r168 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "button", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_button_53_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r168);
      const ctx_r167 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r167.continueReceipt());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("disabled", !ctx_r9.manualReg.get("isFormValid").value || !ctx_r9.manualReg.valid || !ctx_r9.isValidType);
  }
}
function ManualRegistrationComponent_button_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r170 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "button", 153);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_button_54_Template_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r170);
      const ctx_r169 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r169.continueGenerateNewReceipt());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](1, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("disabled", !ctx_r10.manualReg.get("isFormValid").value || !ctx_r10.manualReg.valid || !ctx_r10.isValidType);
  }
}
function ManualRegistrationComponent_div_56_div_6_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r179 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 137)(1, "input", 165);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("ngModelChange", function ManualRegistrationComponent_div_56_div_6_div_2_Template_input_ngModelChange_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r179);
      const ctx_r178 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r178.onSelectPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](2, "label", 132);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const pt_r177 = ctx.$implicit;
    const ctx_r176 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("id", "pt" + pt_r177.lkCodeValue)("value", pt_r177.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵattribute"]("disabled", (ctx_r176.manualReg.get("isStaffRate").value && pt_r177.lkCodeValue == 4 ? true : null) || (!ctx_r176.enableCashMethodSetting && pt_r177.lkCodeValue == 1 ? true : null));
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("for", "pt" + pt_r177.lkCodeValue);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", pt_r177.lkValueEname, " ");
  }
}
function ManualRegistrationComponent_div_56_div_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 163)(1, "div", 164);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](2, ManualRegistrationComponent_div_56_div_6_div_2_Template, 4, 5, "div", 136);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r171 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r171.manualReg.get("paymentTypes").value);
  }
}
function ManualRegistrationComponent_div_56_div_8_ng_option_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "ng-option", 102)(1, "div", 103);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const c_r181 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", c_r181.siteNo);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", c_r181.customerName, " ");
  }
}
function ManualRegistrationComponent_div_56_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r183 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 166)(1, "div", 167)(2, "label", 168);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](3, "Select Customer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](4, "ng-select", 169);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("change", function ManualRegistrationComponent_div_56_div_8_Template_ng_select_change_4_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r183);
      const ctx_r182 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r182.isPaymentValid = true);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerStart"](5, 99);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](6, "ng-option", 84);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](7, ManualRegistrationComponent_div_56_div_8_ng_option_7_Template, 3, 2, "ng-option", 101);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r172 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("clearSearchOnAdd", true)("minTermLength", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("value", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngForOf", ctx_r172.creditCustomerList);
  }
}
function ManualRegistrationComponent_div_56_tr_23_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r173 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r173.manualReg.get("selectedInsSubType").value.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r173.manualReg.get("feesIns").value || 0, " ");
  }
}
function ManualRegistrationComponent_div_56_tr_24_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r174 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r174.manualReg.get("selectedVinStamping").value.serviceName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r174.manualReg.get("feesVin").value || 0, " ");
  }
}
function ManualRegistrationComponent_div_56_tr_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "tr")(1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](2, " Tanker Certificate ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r175 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r175.manualReg.get("feesTanker").value || 0, " ");
  }
}
function ManualRegistrationComponent_div_56_Template(rf, ctx) {
  if (rf & 1) {
    const _r185 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](0, "div", 34)(1, "div", 35)(2, "div", 36)(3, "h1", 154);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](4, "Payment Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](5, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](6, ManualRegistrationComponent_div_56_div_6_Template, 3, 1, "div", 155);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](7, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](8, ManualRegistrationComponent_div_56_div_8_Template, 8, 4, "div", 156);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](9, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](10, "div", 157)(11, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](12, "Summary Details");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](13, "div", 2)(14, "div", 158)(15, "table", 159)(16, "thead")(17, "tr")(18, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](19, "Service");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](20, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](21, "Fees");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](22, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](23, ManualRegistrationComponent_div_56_tr_23_Template, 5, 2, "tr", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](24, ManualRegistrationComponent_div_56_tr_24_Template, 5, 2, "tr", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](25, ManualRegistrationComponent_div_56_tr_25_Template, 5, 1, "tr", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](26, "tfoot")(27, "tr")(28, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](29, "Total");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](30, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](31);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](32, "div", 160)(33, "button", 161);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_56_Template_button_click_33_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r185);
      const ctx_r184 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r184.cancelPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](34, "Cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](35, "button", 162);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_div_56_Template_button_click_35_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵrestoreView"](_r185);
      const ctx_r186 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵresetView"](ctx_r186.submitPayment());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](36, "Submit");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx_r11.noPaymentRequired);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r11.manualReg.get("showCredit").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r11.manualReg.get("selectedInsSubType").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r11.manualReg.get("selectedVinStamping").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx_r11.manualReg.get("selectedTanker").value);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtextInterpolate1"](" ", ctx_r11.totalAmountTh || 0, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("disabled", !ctx_r11.isPaymentValid);
  }
}
class ManualRegistrationComponent {
  constructor(lookupServ, vehicleService, fileService, render, fb, location, purchase, route, router, sharedDataService, changeDetector, sharedLookup, sideNav, ngZone, paymentService, globalServ, ssrsPrintServ, thousandSeparator, bookingService, inspectionService) {
    this.lookupServ = lookupServ;
    this.vehicleService = vehicleService;
    this.fileService = fileService;
    this.render = render;
    this.fb = fb;
    this.location = location;
    this.purchase = purchase;
    this.route = route;
    this.router = router;
    this.sharedDataService = sharedDataService;
    this.changeDetector = changeDetector;
    this.sharedLookup = sharedLookup;
    this.sideNav = sideNav;
    this.ngZone = ngZone;
    this.paymentService = paymentService;
    this.globalServ = globalServ;
    this.ssrsPrintServ = ssrsPrintServ;
    this.thousandSeparator = thousandSeparator;
    this.bookingService = bookingService;
    this.inspectionService = inspectionService;
    this.selectedFiles = [];
    this.serviceFlags = {};
    this.creditCustomerList = [];
    this.paymentName = 'Card';
    this.isSuccess = false;
    this.isPayCanceled = false;
    this.isNotReachable = false;
    this.isPaymentStarted = false;
    this.requestRefId = 0;
    this.printReceiptDirectly = false;
    this.selectedMainService = [];
    this.showClear = false;
    this.feesDetails = [];
    this.fees = [];
    this.normalInsDisable = false;
    this.isValidType = true;
    this.enableCashMethodSetting = true;
    this.isPaymentValid = true;
    this.feesInsChecked = false;
    this.inspectionFees = null;
    this.vinFees = null;
    this.tankerFees = null;
    this.remainingMb = 0;
    this.totalInsFees = 0;
    this.vinCount = 0;
    this.previousVinValue = '';
    this.vinSeqs = undefined;
    this.vehicleServices = {
      inspectionServices: [],
      vinStampingServices: [],
      tankerCertServices: []
    };
    this.isActiveIns = false;
    this.isAtiveReinspection = false;
    this.isActiveVin = false;
    this.isActiveTanker = false;
    this.isScan = false;
    this.manualReg = this.fb.group({
      inputPlateType: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required],
      inputPlateNo: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required],
      selectedPayment: [],
      selectedOwnerType: [' ', _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required],
      selectedServType: [''],
      selectedManufacturer: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required],
      selectedModel: [],
      selectedVehicleCategory: null,
      selectedColor: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required],
      selectedSubColor: [''],
      selectedArea: [''],
      selectedLocation: [''],
      selectedServiceType: [],
      selectedSubService: [null],
      selectedServIns: false,
      selectedServVin: false,
      selectedServTanker: false,
      selectedInsSubType: [],
      selectedVinStamping: [],
      selectedTanker: [],
      selectedCust: [],
      checkAllContact: [false],
      checkAllLocation: [false],
      nonEditable: [true],
      isStaffRate: [false],
      isStaffRateValue: [false],
      showCredit: [false],
      showErrorPopup: [true],
      showScreen: [true],
      vdetails: [{}],
      colorList: [[]],
      ownerTypes: [[]],
      plateTypes: [[]],
      manufacturerTypes: [[]],
      modelTypes: [[]],
      vehicleCategories: [[]],
      lookupValues: [{}],
      serviceTypeList: [[]],
      expDate: [new Date()],
      pidValue: [''],
      colorValue: [''],
      subclr: [' '],
      vcategory: [''],
      feesIns: [0],
      feesVin: [0],
      feesTanker: [0],
      feesDiscount: [],
      amount: [0],
      inputOwnerType: [''],
      inputPid: [' ', [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{11}$/)]],
      inputOwnerName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,50}$/)],
      inputVinNo: [' ', [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required]],
      inputManfYear: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern('^[0-9]*$')]],
      inputCylinders: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,2}$/)]],
      inputWeight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,9}$/)],
      inputPayloadweight: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,9}$/)],
      inputNbSeats: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,3}$/)],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^[34567]\d{7}$/)]],
      pid: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,20}$/)]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.email, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{1,60}$/)]],
      displayServiceType: [false],
      vehicleCategoryValue: null,
      isFormValid: [false],
      vcategoryType: [],
      paymentTypes: [[]],
      isReinspection: [false],
      noOfReinspections: [0],
      formatExpDate: [],
      showMoiError: [false],
      nonQatari: [null]
    });
  }
  dateValidator(control) {
    const selectedDate = new Date(control.value);
    const currentDate = new Date();
    const minDate = new Date(currentDate);
    minDate.setDate(currentDate.getDate() + 30);
    if (isNaN(selectedDate.getTime())) {
      return {
        invalidDate: true
      };
    }
    if (selectedDate < minDate) {
      return {
        futureDate: true
      };
    }
    return null;
  }
  validManfYear(control) {
    const year = control.value;
    const currentYear = new Date().getFullYear();
    const minYear = 1900; // min allowed vehicle year
    const maxYear = currentYear + 1;
    if (year < minYear || year > maxYear) {
      return {
        'invalidYear': true
      };
    }
    return null;
  }
  getYearRange() {
    const startYear = 1900;
    const currentYear = new Date().getFullYear();
    const yearRange = [];
    for (let year = currentYear + 1; year >= startYear; year--) {
      yearRange.push(year);
    }
    return yearRange;
  }
  onKeydown(event) {
    if (event.target instanceof HTMLInputElement && event.target.type === 'number') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault();
      }
    }
  }
  ngOnInit() {
    this.sideNav.setActiveEnt(1, 1);
    this.stationId = parseInt(localStorage.getItem("stationId"));
    this.stationClass = localStorage.getItem('stationClassification');
    if (parseInt(this.stationClass) == 2) {
      this.isMobileStation = true;
    }
    /*  this.sharedDataService.userId$.subscribe((userId) => {
        this.userId = userId;
      });
      */
    this.userId = parseInt(localStorage.getItem('userId'));
    this.sharedLookup.colorList$.subscribe(data => {
      this.manualReg.get('colorList').setValue(data);
    });
    this.sharedLookup.serviceTypeList$.subscribe(data => {
      this.manualReg.get('serviceTypeList').setValue(data);
    });
    this.sharedLookup.ownerTypes$.subscribe(data => {
      this.manualReg.get('ownerTypes').setValue(data);
    });
    this.sharedLookup.vehicleCategories$.subscribe(data => {
      this.manualReg.get('vehicleCategories').setValue(data);
    });
    this.sharedLookup.manufacturerTypes$.subscribe(data => {
      this.manualReg.get('manufacturerTypes').setValue(data);
    });
    this.sharedLookup.plateTypes$.subscribe(data => {
      this.manualReg.get('plateTypes').setValue(data);
    });
    this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.paymentMethods).subscribe(data => {
      this.manualReg.get('paymentTypes').setValue(data.items);
      const firstPaymentType = data.items.find(item => item.lkCodeValue === src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Card).lkCodeValue;
      this.manualReg.get('selectedPayment').setValue(firstPaymentType);
    });
    this.sharedDataService.scannedVehicleDetails.subscribe(res => {
      if (res == null || res == undefined) return;
      this.manualReg.get('inputPlateNo').setValue(res.plateNumber);
      this.manualReg.get('inputPlateType').setValue(res.plateType);
      this.getVehicleDetails();
    });
    this.subscription = this.sharedDataService.text$.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_28__.tap)(text => {
      const plateType = parseInt(text.substring(0, 2));
      const plateNo = parseInt(text.substring(2));
      if (plateNo) {
        this.isScan = true;
        this.ngZone.run(() => {
          this.manualReg.patchValue({
            inputPlateNo: plateNo,
            inputPlateType: plateType
          });
        });
        this.getVehicleDetails();
      }
    })).subscribe();
    if (!this.isScan) {
      this.manualReg.get('inputPlateNo').valueChanges.subscribe(value => {
        if (this.manualReg.get('inputPlateNo').valueChanges) {
          this.manualReg.get('inputPlateType').setValue('');
          this.clearContact();
          this.resetInfo();
        }
      });
      this.manualReg.get('inputPlateType').valueChanges.subscribe(value => {
        this.getVehicleDetails();
        this.clearContact();
        this.resetInfo();
      });
    }
    this.manualReg.statusChanges.subscribe(status => {
      // Check if the form is valid
      if (status === 'VALID' && !this.manualReg.get('nonEditable').value && (this.manualReg.get('selectedServIns').value || this.manualReg.get('selectedServVin').value || this.manualReg.get('selectedServTanker').value)) {
        this.validStaffType(this.manualReg.get('selectedOwnerType').value);
      }
    });
    this.manualReg.get('inputPid').valueChanges.subscribe(value => {
      // Check validity and log "test" if it's valid
      if (this.manualReg.get('inputPid').value && this.manualReg.get('inputPid').valid) {
        this.vehicleService.getOwnerNameByPid(this.manualReg.get('inputPid').value.toString()).subscribe(response => {
          this.manualReg.get('inputOwnerName').setValue(response.items);
        });
      }
    });
    this.manualReg.get('inputWeight').valueChanges.subscribe(value => {
      this.isAllowServiceFees = true;
    });
    this.sharedDataService.stationSetting$.subscribe(res => {
      const checkCashMethod = res.find(item => item.key === "EnableCashMethod" && item.value === "True");
      if (checkCashMethod != undefined) {
        this.enableCashMethodSetting = checkCashMethod;
      }
    });
    this.checkMobileRemaining();
    this.manualReg.get('inputWeight').valueChanges.subscribe(value => {
      if (this.isManualEntry) {
        this.vehicleService.getServiceFeesAmount([{
          vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
          serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection,
          serviceId: this.manualReg.get("selectedInsSubType").value.serviceId,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        }]).subscribe(response => {
          if (response.items) {
            this.inspectionFees = response.items[0].feesAmount;
          } else {
            this.inspectionFees = 0;
          }
          this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
          this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
          this.feesDetails = [];
        });
      }
    });
    this.manualReg.get('inputNbSeats').valueChanges.subscribe(value => {
      if (this.isManualEntry) {
        this.vehicleService.getServiceFeesAmount([{
          vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
          serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection,
          serviceId: this.manualReg.get("selectedInsSubType").value.serviceId,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        }]).subscribe(response => {
          if (response.items) {
            this.inspectionFees = response.items[0].feesAmount;
          } else {
            this.inspectionFees = 0;
          }
          this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
          this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
          this.feesDetails = [];
        });
      }
    });
  }
  onFileUploaded(filename) {
    this.fileName = filename;
  }
  getModelTypes(event) {
    this.onClearModelSearch();
    this.vehicleService.getModelsByManufacturerId(this.manualReg.get('selectedManufacturer').value).subscribe(data => {
      this.manualReg.get('modelTypes').setValue(data.items);
    });
  }
  onSearchManf(term) {
    const lowerCaseTerm = term.toLowerCase();
    if (lowerCaseTerm.length < 3) {
      return;
    }
  }
  onClearModelSearch() {
    this.manualReg.get('selectedModel').setValue('');
  }
  onClearManfSearch(event) {
    this.manualReg.get('selectedManufacturer').setValue('0');
    this.getModelTypes(event);
    this.manualReg.get('selectedManufacturer').setValue('0');
    this.onClearModelSearch();
  }
  checkVinSeq(categId) {
    this.inspectionService.getVINSequences({
      categoryId: categId
    }).subscribe(response => {
      if (response.items[0].availableSeqCount <= 10) {
        this.vinSeqs = response.items[0].availableSeqCount;
      }
    });
  }
  getVehicleDetails() {
    this.manualReg.get("showMoiError").setValue(false);
    this.errorMessage = '';
    if (this.manualReg.get('inputPlateType').value) {
      const vehDetails = {
        plateNo: parseInt(this.manualReg.get('inputPlateNo').value),
        plateType: parseInt(this.manualReg.get('inputPlateType').value),
        stationId: this.stationId
      };
      this.vehicleService.getVehicleDetails(vehDetails).subscribe(response => {
        this.isBlacklist = response.isBlacklist;
        this.manualReg.get('vdetails').setValue(response.items);
        if (this.manualReg.get('vdetails').value) {
          const vehicleSer = {
            categoryId: this.manualReg.get('vdetails').value.categoryId,
            stationId: this.stationId,
            plateNo: this.manualReg.get('inputPlateNo').value,
            plateType: parseInt(this.manualReg.get('inputPlateType').value)
          };
          if (!this.manualReg.get('vdetails').value.isBlacklist) {
            if (this.manualReg.get('vdetails').value.categoryId) {
              this.vehicleService.getVehicleServices(vehicleSer).subscribe(response => {
                this.vehicleServices = response.items;
                this.getServiceTypes();
                this.checkActiveServices();
              });
              this.enableCategorySelection = false;
              this.manualReg.get('vcategory').setValue(this.manualReg.get('vehicleCategories').value.find(category => category.categoryId == this.manualReg.get('vdetails').value.categoryId).descriptionEn);
            } else {
              this.enableCategorySelection = true;
            }
            this.isManualEntry = this.manualReg.get('vdetails').value.isManualEntryEnabled;
            if (this.isManualEntry && this.manualReg.get('inputPlateType').value == 21) {
              this.lookupServ.getLookupValuesByCode(src_app_core_utilities_enums_system_lookup_codes__WEBPACK_IMPORTED_MODULE_3__.SystemLookupCodes.nonQatari).subscribe(response => {
                this.nonQatariList = response.items;
                this.allowNonQatariList = true;
                this.manualReg.get('nonQatari').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.required);
                this.manualReg.get('nonQatari').updateValueAndValidity();
              });
            }
            this.manualReg.get('nonEditable').setValue(!this.manualReg.get('vdetails').value.isManualEntryEnabled);
            this.isIstimaraDate = this.manualReg.get('vdetails').value.istimaraExpiryDateRequired;
            if (!this.isIstimaraDate) {
              this.manualReg.get('expDate').clearValidators();
              this.manualReg.get('expDate').updateValueAndValidity();
            }
            const color = this.manualReg.get('colorList').value.find(color => color.lkCodeValue == this.manualReg.get('vdetails').value.colorId);
            this.manualReg.get('colorValue').setValue(color.lkValueEname);
            this.manualReg.get('pidValue').setValue(this.manualReg.get('ownerTypes').value.find(pid => pid.lkCodeValue == this.manualReg.get('vdetails').value.ownerPidType).lkValueEname);
            this.manualReg.get('isStaffRate').setValue(this.manualReg.get('vdetails').value.isStaffVehicle);
            this.manualReg.get('isStaffRateValue').setValue(this.manualReg.get('vdetails').value.isStaffVehicle);
            this.manualReg.get('isStaffRateValue').value ? this.manualReg.get('isStaffRate').setValue(false) : this.manualReg.get('isStaffRate').setValue(false);
            this.isWoqodVehicle = this.manualReg.get('vdetails').value.isWaqodVehicle;
            if (this.isMobileStation) {
              this.manualReg.get('isStaffRate').setValue(false);
              this.manualReg.get('isStaffRateValue').setValue(false);
              this.isWoqodVehicle = false;
            }
            const isoDate = new Date(this.manualReg.get('vdetails').value.licenseExpiryDate);
            const dateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(isoDate, 'MM-dd-yyyy');
            this.manualReg.get('formatExpDate').setValue(dateFormat);
            const dateInput = new Date(this.manualReg.get('formatExpDate').value);
            this.manualReg.get('formatExpDate').setValue((0,_angular_common__WEBPACK_IMPORTED_MODULE_29__.formatDate)(this.manualReg.get('formatExpDate').value, 'dd-MM-yyyy', 'en'));
            this.checkDateThirtyDays();
            if (this.manualReg.get('vdetails').value.isManualEntryEnabled) {
              this.isAllowServiceFees = false;
              this.manualReg.get('selectedVehicleCategory').setValue(this.manualReg.get('vdetails').value.categoryId);
              this.manualReg.get('selectedOwnerType').setValue(this.manualReg.get('vdetails').value.ownerPidType);
              this.manualReg.get('inputPid').setValue(this.manualReg.get('vdetails').value.ownerPID);
              this.validateOwnerPid();
              this.manualReg.get('inputOwnerName').setValue(this.manualReg.get('vdetails').value.ownerName);
              this.manualReg.get('inputVinNo').setValue(this.manualReg.get('vdetails').value.vinNo);
              this.manualReg.get('selectedManufacturer').setValue(this.manualReg.get('vdetails').value.manufacturerId);
              this.manualReg.get('selectedModel').setValue(this.manualReg.get('vdetails').value.vehicleModelId);
              this.getModelTypes(event);
              let expDate = '';
              try {
                expDate = (0,_angular_common__WEBPACK_IMPORTED_MODULE_29__.formatDate)(this.manualReg.get('formatExpDate').value, 'yyyy-MM-dd', 'en');
              } catch {}
              this.manualReg.get('expDate').setValue(expDate);
              this.manualReg.get('inputManfYear').setValue(this.manualReg.get('vdetails').value.manufacturerYear);
              this.manualReg.get('inputCylinders').setValue(this.manualReg.get('vdetails').value.cylinders);
              this.manualReg.get('inputWeight').setValue(this.manualReg.get('vdetails').value.weight);
              this.manualReg.get('inputPayloadweight').setValue(this.manualReg.get('vdetails').value.payloadWeight);
              this.manualReg.get('selectedColor').setValue(this.manualReg.get('vdetails').value.colorId);
              this.manualReg.get('selectedSubColor').setValue(this.manualReg.get('vdetails').value.subColorId);
              this.manualReg.get('inputNbSeats').setValue(this.manualReg.get('vdetails').value.noOfSeat);
            } else {
              this.isAllowServiceFees = true;
              this.manualReg.get('inputVinNo').clearValidators();
              this.manualReg.get('inputPid').clearValidators();
              this.manualReg.get('inputVinNo').updateValueAndValidity();
              this.manualReg.get('inputPid').updateValueAndValidity();
              this.manualReg.get('inputManfYear').setValidators(null);
              this.manualReg.get('inputManfYear').updateValueAndValidity();
              this.manualReg.get('inputCylinders').setValidators(null);
              this.manualReg.get('inputCylinders').updateValueAndValidity();
              this.manualReg.get('inputNbSeats').setValidators(null);
              this.manualReg.get('inputOwnerName').setValidators(null);
              this.manualReg.get('selectedManufacturer').setValidators(null);
              this.manualReg.get('selectedColor').setValidators(null);
              this.manualReg.get('selectedManufacturer').updateValueAndValidity();
              this.manualReg.get('selectedColor').updateValueAndValidity();
              this.manualReg.get('expDate').setValidators(null);
              this.manualReg.get('expDate').updateValueAndValidity();
              this.manualReg.updateValueAndValidity();
            }
            this.manualReg.get('displayServiceType').setValue(true);
            this.manualReg.get('isReinspection').setValue(this.manualReg.get('vdetails').value.isReinspection);
            this.manualReg.get('noOfReinspections').setValue(this.manualReg.get('vdetails').value.noOfReinspections);
            this.manualReg.get('showMoiError').setValue(false);
            this.manualReg.get('phone').setValue(this.manualReg.get('vdetails').value.contactPersonPhone);
            this.manualReg.get('email').setValue(this.manualReg.get('vdetails').value.contactPersonEmail);
            this.manualReg.get('pid').setValue(this.manualReg.get('vdetails').value.contactPersonPID);
            const subColorId = this.manualReg.get('vdetails').value.subColorId;
            const colorList = this.manualReg.get('colorList').value;
            const matchingColor = colorList.find(color => color.lkCodeValue === subColorId);
            if (matchingColor) {
              const subclrValue = matchingColor.lkValueEname;
              this.manualReg.get('subclr').setValue(subclrValue || '');
            } else {
              this.manualReg.get('subclr').setValue('');
            }
          }
        }
      });
    }
    this.manualReg.get('vdetails').setValue({});
    this.manualReg.get('vcategory').setValue('');
    this.manualReg.get('pidValue').setValue('');
    this.manualReg.get('colorValue').setValue('');
    this.manualReg.get('subclr').setValue('');
    this.manualReg.get('isStaffRate').setValue(false);
    this.isScan = false;
  }
  checkDateThirtyDays() {
    const currentDate = new Date();
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(currentDate.getDate() + 30);
    const isoDate = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(this.manualReg.get('vdetails').value.licenseExpiryDate, 'yyyy-MM-dd');
    const expDateValue = new Date(isoDate);
    if (expDateValue > thirtyDaysFromNow) {
      this.normalInsDisable = true;
    } else {
      this.normalInsDisable = false;
    }
  }
  checkVehicleServices() {
    const vehicleSer = {
      categoryId: this.manualReg.get('selectedVehicleCategory').value,
      stationId: this.stationId,
      plateNo: this.manualReg.get('inputPlateNo').value,
      plateType: parseInt(this.manualReg.get('inputPlateType').value)
    };
    if (this.manualReg.get('inputPlateType').value) {
      this.vehicleService.getVehicleServices(vehicleSer).subscribe(response => {
        this.vehicleServices = response.items;
        this.getServiceTypes();
        this.selectedMainService = [];
        this.manualReg.get('selectedServiceType').setValue(null);
        this.manualReg.get('selectedInsSubType').setValue(null);
        this.manualReg.get('selectedVinStamping').setValue(null);
        this.manualReg.get('selectedTanker').setValue(null);
        this.cancelPayment();
      });
      this.manualReg.get('displayServiceType').setValue(true);
      this.inspectionFees = null;
      this.vinFees = null;
      this.tankerFees = null;
      this.totalAmountTh = '';
      this.totalInsFees = null;
    }
  }
  isDefaultUnselected(serviceId) {
    console.log();
    if (serviceId != this.manualReg.get('selectedInsSubType').value.serviceId || this.manualReg.get('selectedInsSubType').value == undefined) return false;
    return true;
  }
  checkActiveServices() {
    let isVehicleHaveActiveService = this.vehicleServices.inspectionServices.find(x => x.isActive);
    this.vehicleServices.inspectionServices.forEach(ins => {
      if (ins.isActive) {
        this.isActiveIns = true;
        this.activeIns = ins.serviceId;
        this.activeInsName = ins.serviceName;
        this.isPaidIns = ins.isPaid;
        this.manualReg.get('selectedServiceType').setValue(src_app_core_utilities_enums_service_type_enum__WEBPACK_IMPORTED_MODULE_9__.ServiceTypes.NormalInspection);
        if (ins.isActiveReInspection) {
          this.isAtiveReinspection = true;
          console.log("active reins");
          this.vehicleService.getServiceFeesAmount([{
            vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
            serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection,
            serviceId: 1,
            vehicleCategoryId: this.manualReg.get('vdetails').value.categoryId,
            isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
            noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
            weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
          }]).subscribe(response => {
            if (response.items) {
              this.inspectionFees = response.items[0].feesAmount;
            } else {
              this.inspectionFees = 0;
            }
            this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
            this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
            this.feesDetails = [];
          });
        }
        if (ins.isActiveReInspection && this.isPaidIns) {
          this.isAtiveReinspection = true;
          this.manualReg.get('selectedInsSubType').setValue({
            serviceName: ins.serviceName,
            serviceId: ins.serviceId
          });
        }
        if (!this.isPaidIns) {
          this.manualReg.get('selectedInsSubType').setValue({
            serviceName: ins.serviceName,
            serviceId: ins.serviceId
          });
        }
        this.manualReg.get('isFormValid').setValue(true);
      }
      if (isVehicleHaveActiveService == undefined && ins.isDefault) {
        this.manualReg.get('selectedServiceType').setValue(src_app_core_utilities_enums_service_type_enum__WEBPACK_IMPORTED_MODULE_9__.ServiceTypes.NormalInspection);
        this.manualReg.get('selectedInsSubType').setValue({
          serviceName: ins.serviceName,
          serviceId: ins.serviceId
        });
        this.manualReg.get('isFormValid').setValue(true);
        this.onSelectServiceSubType(1);
      }
    });
    this.vehicleServices.vinStampingServices.forEach(vin => {
      if (vin.isActive) {
        this.isActiveVin = true;
        this.activeVin = vin.serviceId;
        this.activeVinName = vin.serviceName;
        this.isPaidVin = vin.isPaid;
        if (!this.isPaidVin) {
          this.manualReg.get('selectedVinStamping').setValue({
            serviceName: vin.serviceName,
            serviceId: vin.serviceId
          });
        }
        this.manualReg.get('isFormValid').setValue(true);
      }
    });
    this.vehicleServices.tankerCertServices.forEach(tank => {
      if (tank.isActive) {
        this.isActiveTanker = true;
        this.activeTanker = tank.serviceId;
        this.activeTankName = tank.serviceName;
        this.isPaidTanker = tank.isPaid;
        if (!this.isPaidTanker) {
          this.manualReg.get('selectedTanker').setValue({
            serviceName: tank.serviceName,
            serviceId: tank.serviceId
          });
        }
        this.manualReg.get('isFormValid').setValue(true);
      }
    });
  }
  validStaffType(pid) {
    if (!this.manualReg.get('nonEditable').value && this.manualReg.get('selectedOwnerType').value == 3) {
      this.vehicleService.validateStaffOwnerType(this.manualReg.get('inputPid').value).subscribe(response => {
        this.isValidType = response.items;
      });
    } else {
      this.isValidType = true;
    }
    return this.isValidType;
  }
  formatPidInput(event) {
    let value = event.target.value;
    // Remove non-digit characters
    value = value.replace(/\D/g, '');
    if (this.manualReg.get("selectedOwnerType").value == 2) {
      let formattedValue = '';
      for (let i = 0; i < value.length; i++) {
        if (i === 2 || i === 6) {
          formattedValue += '-';
        }
        formattedValue += value[i];
      }
      event.target.value = formattedValue;
    }
  }
  validateOwnerPid() {
    if (this.manualReg.get("selectedOwnerType").value == 2) {
      this.manualReg.get('inputPid').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^\d{2}-\d{4}-\d{2}$/));
      this.manualReg.get('inputPid').updateValueAndValidity();
    } else {
      this.manualReg.get('inputPid').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_27__.Validators.pattern(/^.{11}$/));
      this.manualReg.get('inputPid').updateValueAndValidity();
    }
  }
  updateOwnerType() {
    this.validateOwnerPid();
    if (!this.manualReg.get('nonEditable').value && this.manualReg.get('inputPid').value) {
      this.validStaffType(this.manualReg.get('selectedOwnerType').value);
    } else {
      this.isValidType = true;
    }
  }
  getServiceTypes() {
    let counter = 1;
    for (const [index, key] of Object.keys(this.vehicleServices).entries()) {
      if (this.vehicleServices.hasOwnProperty(key)) {
        this.serviceFlags[index] = {
          value: this.vehicleServices[key].length > 0,
          id: counter++
        };
      }
    }
    //return this.vehicleServices ? Object.keys(this.vehicleServices) : [];
  }

  selectService() {
    this.showClear = true;
  }
  convertToThousand(value) {
    return this.thousandSeparator.addThousandSeparator(value.toString());
  }
  onSelectServiceSubType(value) {
    if (!this.manualReg.get('nonEditable').value || this.enableCategorySelection) {
      this.manualReg.get('vcategoryType').setValue(this.manualReg.get('selectedVehicleCategory').value);
    } else {
      this.manualReg.get('vcategoryType').setValue(this.manualReg.get('vehicleCategories').value.find(category => category.categoryId == this.manualReg.get('vdetails').value.categoryId).categoryId);
    }
    this.feesDetails = [];
    if (value == 1) {
      this.feesDetails = [];
      this.inspectionFees = 0;
      this.manualReg.get('selectedServIns').setValue(true);
      if (this.manualReg.get('isStaffRate').value && this.manualReg.get("selectedInsSubType").value.serviceId == src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_5__.InspectionServiceTypes.NormalInspection || this.manualReg.get('isReinspection').value) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
          serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection,
          serviceId: this.manualReg.get("selectedInsSubType").value.serviceId,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        });
        this.feesInsChecked = true;
        this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_30__.map)(data => data.items)).subscribe(items => {
          for (let fee of items) {
            if (fee.serviceTypeId == 1) {
              this.manualReg.get("feesIns").setValue(fee.feesAmount);
              this.manualReg.get("feesDiscount").setValue(fee.feesDiscount);
              if (fee.feesAmount != 0) {
                this.subInsId = false;
                this.inspectionFees = fee.feesAmount;
                this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
                this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
              } else {
                this.subInsId = true;
                this.manualReg.get('selectedPayment').setValue(src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Cash);
              }
            }
          }
        });
      }
      console.log(this.manualReg.get('inputWeight').value);
      this.feesDetails.push({
        vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection,
        serviceId: this.manualReg.get("selectedInsSubType").value.serviceId,
        vehicleCategoryId: this.manualReg.get('vcategoryType').value,
        isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
        noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
        weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).subscribe(response => {
        if (response.items) {
          this.inspectionFees = response.items[0].feesAmount;
          this.checkMobilePayment();
        } else {
          this.inspectionFees = 0;
        }
        this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
      });
    }
    if (value == 2) {
      if (this.manualReg.get("selectedVinStamping").value.serviceId == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.NewStamping) {
        this.checkVinSeq(this.manualReg.get('vcategoryType').value);
      }
      this.feesDetails = [];
      this.vinFees = 0;
      this.manualReg.get('selectedServVin').setValue(true);
      this.subInsId = false;
      this.feesDetails.push({
        vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.VINStamping,
        serviceId: this.manualReg.get("selectedVinStamping").value.serviceId,
        vehicleCategoryId: this.manualReg.get('vcategoryType').value,
        isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
        noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
        weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).subscribe(response => {
        if (response.items) {
          this.vinFees = response.items[0].feesAmount;
          this.checkMobilePayment();
        } else {
          this.vinFees = 0;
        }
        this.totalInsFees = this.vinFees + this.inspectionFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
        console.log(this.totalInsFees);
      });
    }
    if (value == 3) {
      this.feesDetails = [];
      this.tankerFees = 0;
      this.manualReg.get('selectedServTanker').setValue(true);
      this.subInsId = false;
      this.feesDetails.push({
        vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
        serviceTypeId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.TankerCertificate,
        serviceId: this.manualReg.get("selectedTanker").value.serviceId,
        vehicleCategoryId: this.manualReg.get('vcategoryType').value,
        isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
        noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
        weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
      });
      this.vehicleService.getServiceFeesAmount(this.feesDetails).subscribe(response => {
        if (response.items) {
          this.tankerFees = response.items[0].feesAmount;
          this.checkMobilePayment();
        } else {
          this.tankerFees = 0;
        }
        this.totalInsFees = this.vinFees + this.inspectionFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
      });
    }
    if (this.manualReg.get("selectedInsSubType").value || this.manualReg.get("selectedVinStamping").value || this.manualReg.get("selectedTanker").value) {
      this.manualReg.get('isFormValid').setValue(true);
      const mainServiceId = this.manualReg.get("selectedServiceType").value;
      this.selectedMainService.push(mainServiceId);
    } else {
      this.manualReg.get("isFormValid").setValue(false);
      this.showClear = false;
    }
    if (this.manualReg.get("selectedVinStamping").value == "") {
      this.selectedMainService = this.selectedMainService.filter(id => id !== 2);
      //this.manualReg.get("selectedVinStamping").setValue(null);
    }

    if (this.manualReg.get("selectedTanker").value == "") {
      this.selectedMainService = this.selectedMainService.filter(id => id !== 3);
    }
    //const formControls = this.manualReg.controls;
    // Iterate through the form controls and check if any are invalid
    /*for (const controlName in formControls) {
      if (formControls.hasOwnProperty(controlName)) {
        const control = formControls[controlName];
               // Check if the control is invalid
        if (control.invalid) {
          console.log(`${controlName} is invalid`);
        }
      }
    }
    */
    if (this.manualReg.get('selectedInsSubType').value && this.manualReg.get('selectedInsSubType').value.serviceId == src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_5__.InspectionServiceTypes.NormalInspection && !this.selectedMainService.includes(2) && !this.selectedMainService.includes(3)) {
      this.subInsId = true;
    } else {
      this.subInsId = false;
    }
  }
  clearServices(serviceType, serviceId) {
    this.manualReg.get('isFormValid').setValue(false);
    console.log(this.selectedMainService);
    console.log(this.manualReg.get('selectedInsSubType').value);
    if (serviceType == 1 && this.manualReg.get('selectedInsSubType').value && serviceId == this.manualReg.get('selectedInsSubType').value.serviceId) {
      this.manualReg.get('selectedInsSubType').setValue(null);
      this.manualReg.get('selectedServIns').setValue(false);
      if (this.manualReg.get('selectedInsSubType').value) {
        this.subInsId = this.manualReg.get('selectedInsSubType').value.serviceId != src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_5__.InspectionServiceTypes.NormalInspection ? false : true;
      }
      this.selectedMainService = this.selectedMainService.filter(id => id !== 1);
      this.checkMobilePayment();
      this.inspectionFees = null;
      if (this.selectedMainService.length > 0) {
        this.manualReg.get("isFormValid").setValue(true);
      }
      this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
      this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
    } else {
      if (serviceType == 2 && this.manualReg.get('selectedVinStamping').value && serviceId == this.manualReg.get('selectedVinStamping').value.serviceId) {
        this.manualReg.get('selectedVinStamping').setValue(null);
        this.manualReg.get('selectedServVin').setValue(false);
        this.selectedMainService = this.selectedMainService.filter(id => id !== 2);
        this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
        this.checkMobilePayment();
        this.vinFees = null;
        if (this.selectedMainService.length > 0) {
          this.manualReg.get("isFormValid").setValue(true);
        }
        this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
      } else {
        this.manualReg.get('selectedTanker').setValue(null);
        this.manualReg.get('selectedServTanker').setValue(false);
        this.selectedMainService = this.selectedMainService.filter(id => id !== 3);
        this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
        this.checkMobilePayment();
        this.tankerFees = null;
        if (this.selectedMainService.length > 0) {
          this.manualReg.get("isFormValid").setValue(true);
        }
        this.totalInsFees = this.inspectionFees + this.vinFees + this.tankerFees;
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.totalInsFees.toString());
      }
    }
    if (this.selectedMainService.includes(1)) {
      //this.onSelectServiceSubType(1);
    }
    if (this.manualReg.get('selectedInsSubType').value && this.manualReg.get('selectedInsSubType').value.serviceId == src_app_core_utilities_enums_inspectionServiceTypes__WEBPACK_IMPORTED_MODULE_5__.InspectionServiceTypes.NormalInspection && !(this.selectedMainService.includes(2) || this.selectedMainService.includes(3))) {
      this.subInsId = true;
    } else {
      this.subInsId = false;
    }
    let hasActiveIns = this.vehicleServices.inspectionServices.find(x => x.isActive);
    let hasActiveVin = this.vehicleServices.vinStampingServices.find(x => x.isActive);
    let hasActiveTank = this.vehicleServices.tankerCertServices.find(x => x.isActive);
    if (hasActiveIns || hasActiveVin || hasActiveTank) {
      this.manualReg.get("isFormValid").setValue(true);
    }
  }
  onSelectPayment() {
    if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.CreditCustomer) {
      this.manualReg.get('showCredit').setValue(true);
      this.vehicleService.getCreditCustomer(this.manualReg.get('selectedCust').value).subscribe(data => {
        this.creditCustomerList = data.items;
      });
      this.isPaymentValid = this.manualReg.get('selectedCust').value ? true : false;
    } else {
      this.manualReg.get('showCredit').setValue(false);
      this.isPaymentValid = true;
    }
    this.paymentName = this.manualReg.get('paymentTypes').value.find(payId => payId.lkCodeValue == this.manualReg.get('selectedPayment').value).lkValueEname;
  }
  cancel() {
    this.sharedDataService.setText('');
    this.manualReg.get('inputPlateType').setValue('');
    this.manualReg.get('inputPlateNo').setValue('');
    this.isPaymentStarted = false;
    if (this.isMobileStation) {
      this.router.navigate(['/registration/landing'], {
        queryParams: {
          startMb: true
        }
      });
    } else {
      this.location.back();
    }
  }
  cancelFailed() {
    this.isNotReachable = false;
    this.isPayCanceled = false;
    this.isSuccess = false;
    this.cardStatus = '';
    this.isPaymentStarted = false;
  }
  staffRateChanges() {
    /*if (!this.manualReg.get('isStaffRate').value && this.selectedMainService.includes(1) && !this.selectedMainService.includes(2) && !this.selectedMainService.includes(3)) {
      this.onSelectServiceSubType(1);
    }
    */
    this.onSelectServiceSubType(1);
  }
  submitForm() {
    this.feesDetails = [];
    const date = new Date();
    this.currentDateFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(date, 'dd MMM yyyy');
    this.currentTimeFormat = new _angular_common__WEBPACK_IMPORTED_MODULE_29__.DatePipe('en-US').transform(date, 'h:mm a');
    this.globalServ.getStationPaymentMethods(this.stationId).subscribe(response => {
      this.manualReg.get('paymentTypes').setValue(response.items);
    });
    if (this.manualReg.get('isFormValid').value) {
      const currentDate = new Date();
      if (!this.manualReg.get('nonEditable').value || this.enableCategorySelection) {
        this.manualReg.get('vcategoryType').setValue(this.manualReg.get('selectedVehicleCategory').value);
      } else {
        this.manualReg.get('vcategoryType').setValue(this.manualReg.get('vehicleCategories').value.find(category => category.categoryId == this.manualReg.get('vdetails').value.categoryId).categoryId);
      }
      this.selectedServTypeValue = this.manualReg.get('selectedServiceType').value;
      if (this.selectedMainService.includes(1) && this.manualReg.get("selectedInsSubType").value && !(this.manualReg.get('isStaffRate').value && this.feesInsChecked && this.subInsId)) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          serviceTypeId: 1,
          serviceId: this.manualReg.get("selectedInsSubType").value.serviceId,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        });
      }
      if (this.selectedMainService.includes(2) && this.manualReg.get("selectedVinStamping").value) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          serviceTypeId: 2,
          serviceId: this.manualReg.get("selectedVinStamping").value.serviceId,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        });
      }
      if (this.selectedMainService.includes(3) && this.manualReg.get("selectedTanker").value) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          serviceTypeId: 3,
          serviceId: this.manualReg.get("selectedTanker").value.serviceId,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false
        });
      }
      if (this.isActiveIns && !this.isPaidIns) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          serviceTypeId: 1,
          serviceId: this.activeIns,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        });
      }
      if (this.isActiveVin && !this.isPaidVin) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          serviceTypeId: 2,
          serviceId: this.activeVin,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        });
      }
      if (this.isActiveTanker && !this.isPaidTanker) {
        this.feesDetails.push({
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          serviceTypeId: 3,
          serviceId: this.activeTanker,
          vehicleCategoryId: this.manualReg.get('vcategoryType').value,
          isStaffRate: this.manualReg.get('isStaffRate').value ? true : false,
          noOfSeats: this.isManualEntry ? this.manualReg.get('inputNbSeats').value : null,
          weight: this.isManualEntry ? this.manualReg.get('inputWeight').value : null
        });
      }
      this.vehicleService.getServiceFeesAmount(this.feesDetails).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_30__.map)(data => data.items)).subscribe(items => {
        for (let fee of items) {
          if (fee.serviceTypeId == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection) {
            if (this.isMobileStation && this.payMobile) {
              const mobileInsFee = fee.feesAmount - this.remainingMb;
              this.manualReg.get("feesIns").setValue(mobileInsFee);
            } else {
              this.manualReg.get("feesIns").setValue(fee.feesAmount);
            }
          }
          if (fee.serviceTypeId == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.VINStamping) {
            this.manualReg.get("feesVin").setValue(fee.feesAmount);
          }
          if (fee.serviceTypeId == src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.TankerCertificate) {
            this.manualReg.get("feesTanker").setValue(fee.feesAmount);
          }
          this.manualReg.get("feesDiscount").setValue(fee.feesDiscount);
        }
        const fee1 = this.manualReg.get('feesIns').value || 0;
        const fee2 = this.manualReg.get('feesVin').value || 0;
        const fee3 = this.manualReg.get('feesTanker').value || 0;
        const totalAmount = fee1 + fee2 + fee3;
        this.manualReg.get("amount").setValue(totalAmount);
        this.totalAmountTh = this.thousandSeparator.addThousandSeparator(this.manualReg.get("amount").value.toString());
      });
    } else {
      this.markFormGroupTouched(this.manualReg);
    }
  }
  cancelPayment() {
    this.feesDetails = [];
    this.manualReg.get("selectedCust").setValue('');
    this.manualReg.get("amount").setValue(null);
    this.manualReg.get("feesIns").setValue(null);
    this.manualReg.get("feesVin").setValue(null);
    this.manualReg.get("feesTanker").setValue(null);
  }
  markFormGroupTouched(formGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
  continueGenerateNewReceipt() {
    let activeServicesRequestId = {
      plateType: parseInt(this.manualReg.get('inputPlateType').value),
      plateNo: this.manualReg.get('inputPlateNo').value
    };
    this.vehicleService.generateNewReceiptNoForUntakedRequest(activeServicesRequestId).subscribe(res => {
      let customerReportDto = {
        requestId: this.requestRefId,
        isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
        moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
        reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
      };
      let inspectorReportDto = {
        requestId: this.requestRefId,
        isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
        moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
        reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
      };
      let reports = [customerReportDto, inspectorReportDto];
      this.ssrsPrintServ.printReports(reports);
      const modalElement = document.getElementById('PrintReceipt');
      setTimeout(() => {
        if (modalElement) {
          modalElement.classList.remove('show');
          modalElement.style.display = 'none';
          document.body.classList.remove('modal-open');
          const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
          if (modalBackdrop) {
            modalBackdrop.remove();
          }
          document.body.style.overflow = 'auto';
        }
        this.cancel();
      }, 3000);
    });
  }
  continueReceipt() {
    this.printReceiptDirectly = true;
    this.manualReg.get('selectedPayment').setValue(src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Cash);
    this.submitForm();
    const modalElement = document.getElementById('PrintReceipt');
    this.submitPayment();
    setTimeout(() => {
      if (modalElement) {
        modalElement.classList.remove('show');
        modalElement.style.display = 'none';
        document.body.classList.remove('modal-open');
        const modalBackdrop = document.getElementsByClassName('modal-backdrop')[0];
        if (modalBackdrop) {
          modalBackdrop.remove();
        }
        document.body.style.overflow = 'auto';
      }
      this.cancel();
    }, 3000);
  }
  checkMobilePayment() {
    console.log(this.remainingMb);
    if (this.isMobileStation || this.remainingMb == null && this.remainingMb >= this.totalInsFees) {
      this.payMobile = false;
    } else {
      this.payMobile = true;
    }
  }
  checkMobileRemaining() {
    if (this.isMobileStation) {
      this.payMobile = false;
      this.bookingService.getRemainginBalanceOfMobileBookingRequest(this.stationId).subscribe(response => {
        this.remainingMb = response.items;
      });
    }
  }
  updateLetterCount(value, identifier) {
    if (value.length > this.previousVinValue.length) {
      // Letter added
      this.vinCount = value.length;
    } else if (value.length < this.previousVinValue.length) {
      // Letter removed
      this.vinCount = value.length;
    }
    // Update the previous value for the next comparison
    this.previousVinValue = value;
  }
  submitPayment() {
    const currentDate = new Date();
    if (this.isActiveIns && !this.isPaidIns) {
      this.selectedMainService.push(1);
    }
    if (this.isActiveIns && this.isAtiveReinspection && this.isPaidIns) {
      this.selectedMainService.push(1);
    }
    if (this.isActiveVin && !this.isPaidVin) {
      this.selectedMainService.push(2);
    }
    if (this.isActiveTanker && !this.isPaidTanker) {
      this.selectedMainService.push(3);
    }
    const servicesValues = new Set(this.selectedMainService);
    const selectedService = servicesValues.has(1) ? src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Inspection : servicesValues.has(2) ? src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.VINStamping : src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.TankerCertificate;
    const selectedSubType = servicesValues.has(1) ? this.manualReg.get('selectedInsSubType').value.serviceId : servicesValues.has(2) ? this.manualReg.get('selectedVinStamping').value.serviceId : this.manualReg.get('selectedTanker').value.serviceId;
    let paymentResult;
    if (servicesValues.size === 1) {
      const totalServiceFees = this.inspectionFees + this.vinFees + this.tankerFees;
      if (this.isMobileStation || this.remainingMb == null && this.remainingMb > totalServiceFees) {
        const mobileSubmit = {
          stationId: this.stationId,
          contactType: this.manualReg.get('vdetails').value.ownerPidType ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
          contactPersonName: '',
          contactPersonEmail: this.manualReg.get('email').value,
          contactPersonPhone: this.manualReg.get('phone').value.toString(),
          registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Booth,
          boothId: 1,
          posId: 1,
          requestRefId: 0,
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          plateType: parseInt(this.manualReg.get('inputPlateType').value),
          plateNo: this.manualReg.get('inputPlateNo').value,
          colorId: this.manualReg.get('vdetails').value.colorId,
          subColorId: this.manualReg.get('vdetails').value.subColorId,
          categoryId: this.manualReg.get('vcategoryType').value,
          vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId,
          manufacturerId: this.manualReg.get('vdetails').value.manufacturerId,
          manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear,
          moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
          cylinders: this.manualReg.get('vdetails').value.cylinders,
          weight: this.manualReg.get('vdetails').value.weight,
          payloadWeight: this.manualReg.get('vdetails').value.payloadWeight,
          shapeCode: this.manualReg.get('vdetails').value.shapeCode,
          descriptionEn: '',
          descriptionAr: '',
          noOfSeat: this.manualReg.get('vdetails').value.noOfSeat,
          licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : null,
          ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType),
          contactPersonPid: this.manualReg.get('pid').value,
          ownerId: '0',
          ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString(),
          ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
          ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
          mobileStationInpsectionServicesDtos: [{
            serviceType: selectedService,
            serviceId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.MobileInspection,
            feesAmount: totalServiceFees
          }]
        };
        this.bookingService.submitRegistrationMobileStation(mobileSubmit).subscribe(response => {
          let customerReportDto = {
            requestId: response.items,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
          };
          let inspectorReportDto = {
            requestId: response.items,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
          };
          let reports = [customerReportDto, inspectorReportDto];
          this.ssrsPrintServ.printReports(reports);
        });
      } else {
        this.payMobile = this.isMobileStation ? true : false;
        const serviceRequestData = {
          stationId: this.stationId,
          serviceType: selectedService,
          serviceID: selectedSubType,
          contactType: this.manualReg.get('vdetails').value.ownerPidType ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
          contactPersonName: '',
          contactPersonEmail: this.manualReg.get('email').value,
          contactPersonPhone: this.manualReg.get('phone').value.toString(),
          status: 1,
          registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Booth,
          boothId: 1,
          posId: 1,
          remarks: '',
          requestRefId: 0,
          createdBy: this.userId,
          vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
          plateType: parseInt(this.manualReg.get('inputPlateType').value),
          plateNo: this.manualReg.get('inputPlateNo').value
        };
        this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__.ServiceRequest(serviceRequestData);
        this.vehicleService.insertServiceRequest(this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_30__.map)(data => data.items)).subscribe(items => {
          this.requestRefId = items;
          // upload attachments
          const fileInfoArray = this.fileService.getFileData();
          for (const fileInfo of fileInfoArray) {
            if (fileInfo) {
              const formData = new FormData();
              formData.append('requestId', this.requestRefId.toString());
              formData.append('sectionId', '');
              formData.append('defectId', '');
              formData.append('serviceTypeId', this.manualReg.get('selectedServiceType').value);
              formData.append('serviceId', selectedSubType);
              formData.append('mimeType', fileInfo.mimeType);
              formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.SupportDocuments.toString());
              formData.append('createdBy', this.userId.toString());
              formData.append('fileData', fileInfo.fileData, fileInfo.filename);
              this.globalServ.uploadAttachement(formData).subscribe(response => {}, error => {});
            }
          }
          if (!this.manualReg.get('vdetails').value.isManualEntryEnabled) {
            const vehicleDetails = {
              requestId: this.requestRefId,
              plateNo: this.manualReg.get('inputPlateNo').value,
              plateType: parseInt(this.manualReg.get('inputPlateType').value),
              vinNo: this.manualReg.get('vdetails').value.vinNo,
              colorId: this.manualReg.get('vdetails').value.colorId,
              subColorId: this.manualReg.get('vdetails').value.subColorId,
              categoryId: this.manualReg.get('vcategoryType').value,
              vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId,
              manufacturerId: this.manualReg.get('vdetails').value.manufacturerId,
              manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear,
              moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
              cylinders: this.manualReg.get('vdetails').value.cylinders,
              weight: this.manualReg.get('vdetails').value.weight,
              payloadWeight: this.manualReg.get('vdetails').value.payloadWeight,
              shapeCode: this.manualReg.get('vdetails').value.shapeCode,
              descriptionEn: '',
              descriptionAr: '',
              noOfSeat: this.manualReg.get('vdetails').value.noOfSeat,
              licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : null,
              ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType),
              contactPersonPid: this.manualReg.get('pid').value,
              contactPersonEmail: this.manualReg.get('email').value,
              contactPersonPhone: this.manualReg.get('phone').value.toString(),
              ownerId: '0',
              ownerPid: this.manualReg.get('vdetails').value.ownerPID,
              ownerPidType: parseInt(this.manualReg.get('vdetails').value.ownerPidType),
              ownerName: this.manualReg.get('vdetails').value.ownerName,
              departmentId: 0,
              countryId: this.allowNonQatariList ? this.manualReg.get('nonQatari').value : null,
              createdBy: this.userId
            };
            this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
            this.vehicleService.registerVehicle(this.registerVehicle).subscribe(response => {});
          } else {
            const isoDate = new Date(this.manualReg.get('expDate').value);
            const vehicleDetails = {
              requestId: this.requestRefId,
              plateNo: this.manualReg.get('inputPlateNo').value,
              plateType: parseInt(this.manualReg.get('inputPlateType').value),
              vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
              colorId: this.manualReg.get('vdetails').value.colorId ? this.manualReg.get('vdetails').value.colorId : parseInt(this.manualReg.get('selectedColor').value),
              subColorId: this.manualReg.get('vdetails').value.subColorId ? this.manualReg.get('vdetails').value.subColorId : parseInt(this.manualReg.get('selectedSubColor').value),
              categoryId: this.manualReg.get('vcategoryType').value,
              vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId ? this.manualReg.get('vdetails').value.vehicleModelId : parseInt(this.manualReg.get('selectedModel').value),
              manufacturerId: this.manualReg.get('vdetails').value.manufacturerId ? this.manualReg.get('vdetails').value.manufacturerId : parseInt(this.manualReg.get('selectedManufacturer').value),
              manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear ? this.manualReg.get('vdetails').value.manufacturerYear : parseInt(this.manualReg.get('inputManfYear').value),
              moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
              cylinders: this.manualReg.get('vdetails').value.cylinders ? this.manualReg.get('vdetails').value.cylinders : this.manualReg.get('inputCylinders').value.toString(),
              weight: this.manualReg.get('vdetails').value.weight ? this.manualReg.get('vdetails').value.weight : this.manualReg.get('inputWeight').value,
              payloadWeight: this.manualReg.get('vdetails').value.payloadWeight ? this.manualReg.get('vdetails').value.payloadWeight : this.manualReg.get('inputPayloadweight').value,
              shapeCode: this.manualReg.get('vdetails').value.shapeCode ? this.manualReg.get('vdetails').value.shapeCode : " ",
              descriptionEn: '',
              descriptionAr: '',
              noOfSeat: this.manualReg.get('vdetails').value.noOfSeat ? this.manualReg.get('vdetails').value.noOfSeat : this.manualReg.get('inputNbSeats').value,
              licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : this.manualReg.get('expDate').value ? this.manualReg.get('expDate').value : null,
              ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType) ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
              contactPersonPid: this.manualReg.get('pid').value,
              contactPersonEmail: this.manualReg.get('email').value,
              contactPersonPhone: this.manualReg.get('phone').value.toString(),
              ownerId: '0',
              ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString(),
              ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
              ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
              departmentId: 0,
              countryId: this.allowNonQatariList ? this.manualReg.get('nonQatari').value : null,
              createdBy: this.userId
            };
            // Pass the object to the RegisterVehicle constructor
            this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
            this.vehicleService.registerVehicle(this.registerVehicle).subscribe(response => {});
          }
          if (this.isMobileStation) {
            const mobileSubmit = {
              stationId: this.stationId,
              contactType: this.manualReg.get('vdetails').value.ownerPidType ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
              contactPersonName: '',
              contactPersonEmail: this.manualReg.get('email').value,
              contactPersonPhone: this.manualReg.get('phone').value.toString(),
              registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Booth,
              boothId: 1,
              posId: 1,
              requestRefId: 0,
              vinNo: this.manualReg.get('vdetails').value.vinNo,
              plateType: parseInt(this.manualReg.get('inputPlateType').value),
              plateNo: this.manualReg.get('inputPlateNo').value,
              colorId: this.manualReg.get('vdetails').value.colorId,
              subColorId: this.manualReg.get('vdetails').value.subColorId,
              categoryId: this.manualReg.get('vcategoryType').value,
              vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId,
              manufacturerId: this.manualReg.get('vdetails').value.manufacturerId,
              manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear,
              moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
              cylinders: this.manualReg.get('vdetails').value.cylinders,
              weight: this.manualReg.get('vdetails').value.weight,
              payloadWeight: this.manualReg.get('vdetails').value.payloadWeight,
              shapeCode: this.manualReg.get('vdetails').value.shapeCode,
              descriptionEn: '',
              descriptionAr: '',
              noOfSeat: this.manualReg.get('vdetails').value.noOfSeat,
              licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : null,
              ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType),
              contactPersonPid: this.manualReg.get('pid').value,
              ownerId: '0',
              ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString(),
              ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
              ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
              mobileStationInpsectionServicesDtos: [{
                serviceType: selectedService,
                serviceId: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.MobileInspection,
                feesAmount: totalServiceFees
              }]
            };
            this.bookingService.submitRegistrationMobileStation(mobileSubmit).subscribe(response => {
              let customerReportDto = {
                requestId: response.items,
                isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
              };
              let inspectorReportDto = {
                requestId: response.items,
                isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
              };
              let reports = [customerReportDto, inspectorReportDto];
              this.ssrsPrintServ.printReports(reports);
            });
          }
          let payment = {
            paymentMethodId: this.manualReg.get('selectedPayment').value,
            serviceRequestFeesDto: [{
              feesAmount: this.manualReg.get('amount').value,
              requestId: this.requestRefId,
              serviceTypeId: this.selectedServTypeValue,
              customerId: this.manualReg.get('selectedCust').value == undefined ? null : parseInt(this.manualReg.get('selectedCust').value),
              subDiscount: this.manualReg.get('feesDiscount').value
            }]
          };
          this.printReceiptDirectly ? this.isPaymentStarted = false : this.isPaymentStarted = true;
          //  this.isPaymentStarted = true;
          if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Card) {
            this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_31__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_32__.catchError)(error => {
              if (error.name === 'TimeoutError') {
                this.isNotReachable = true;
                this.displayPaymentDetails = 'block';
              }
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_33__.throwError)(error);
            })).subscribe(data => {
              paymentResult = data;
              if (data.items) {
                if (!paymentResult.items.isCanceled && !paymentResult.items.isDeviceNotReachable) {
                  this.isSuccess = true;
                  let customerReportDto = {
                    requestId: this.requestRefId,
                    isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                    moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                    reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
                  };
                  let inspectorReportDto = {
                    requestId: this.requestRefId,
                    isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                    moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                    reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
                  };
                  let reports = [customerReportDto, inspectorReportDto];
                  this.ssrsPrintServ.printReports(reports);
                  setTimeout(() => {
                    this.isPaymentStarted = false;
                    this.router.navigate(['/registration/landing']);
                  }, 3000);
                } else {
                  if (paymentResult.items.isCanceled) {
                    "pay cancel";
                    this.isPayCanceled = true;
                  }
                  if (paymentResult.items.isDeviceNotReachable) {
                    this.isNotReachable = true;
                  }
                }
              } else {
                if (paymentResult.items.isCanceled) {
                  this.isPayCanceled = true;
                }
                if (paymentResult.items.isDeviceNotReachable) {
                  this.isNotReachable = true;
                }
              }
              this.displayPaymentDetails = 'block';
            }, error => {
              this.isPaymentStarted = false;
              console.error(error);
            });
          }
          if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Cash) {
            this.paymentService.submitPayment(payment).subscribe(data => {
              if (data.items) {
                this.isSuccess = true;
                this.isNotReachable = false;
                this.isPayCanceled = false;
                let customerReportDto = {
                  requestId: this.requestRefId,
                  isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                  moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                  reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
                };
                let inspectorReportDto = {
                  requestId: this.requestRefId,
                  isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                  moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                  reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
                };
                let reports = [customerReportDto, inspectorReportDto];
                this.ssrsPrintServ.printReports(reports);
                setTimeout(() => {
                  this.isPaymentStarted = false;
                  this.router.navigate(['/registration/landing']);
                }, 3000);
              } else {
                this.isNotReachable = true;
                this.isPayCanceled = false;
                this.isSuccess = false;
              }
            }, error => {
              this.isSuccess = false;
            });
          }
          if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.CreditCustomer) {
            this.paymentService.submitPayment(payment).subscribe(data => {
              if (data.items) {
                this.isSuccess = true;
                this.isPayCanceled = false;
                this.isNotReachable = false;
                let customerReportDto = {
                  requestId: this.requestRefId,
                  isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                  moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                  reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
                };
                let inspectorReportDto = {
                  requestId: this.requestRefId,
                  isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                  moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                  reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
                };
                let reports = [customerReportDto, inspectorReportDto];
                this.ssrsPrintServ.printReports(reports);
                setTimeout(() => {
                  this.isPaymentStarted = false;
                  this.router.navigate(['/registration/landing']);
                }, 3000);
              } else {
                this.isNotReachable = true;
                this.isSuccess = false;
                this.isPayCanceled = false;
              }
            }, error => {
              this.isSuccess = false;
            });
          }
        });
      }
    } else {
      let isRegistered1 = false;
      let isRegistered2 = false;
      let isRegistered3 = false;
      let counter = 0;
      const serviceValuesArray = Array.from(servicesValues); // Convert the set to an array
      const totalServiceFees = this.inspectionFees + this.vinFees + this.tankerFees;
      if (this.isMobileStation && this.remainingMb > totalServiceFees) {
        const mobileStationInspectionServices = serviceValuesArray.map(serviceType => {
          return {
            serviceType: serviceType,
            serviceId: selectedSubType,
            feesAmount: serviceType == 1 ? this.inspectionFees : serviceType == 2 ? this.vinFees : this.tankerFees
          };
        });
        const mobileSubmit = {
          stationId: this.stationId,
          contactType: this.manualReg.get('vdetails').value.ownerPidType ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
          contactPersonName: '',
          contactPersonEmail: this.manualReg.get('email').value,
          contactPersonPhone: this.manualReg.get('phone').value.toString(),
          registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Booth,
          boothId: 1,
          posId: 1,
          requestRefId: 0,
          vinNo: this.manualReg.get('vdetails').value.vinNo,
          plateType: parseInt(this.manualReg.get('inputPlateType').value),
          plateNo: this.manualReg.get('inputPlateNo').value,
          colorId: this.manualReg.get('vdetails').value.colorId,
          subColorId: this.manualReg.get('vdetails').value.subColorId,
          categoryId: this.manualReg.get('vcategoryType').value,
          vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId,
          manufacturerId: this.manualReg.get('vdetails').value.manufacturerId,
          manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear,
          moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
          cylinders: this.manualReg.get('vdetails').value.cylinders,
          weight: this.manualReg.get('vdetails').value.weight,
          payloadWeight: this.manualReg.get('vdetails').value.payloadWeight,
          shapeCode: this.manualReg.get('vdetails').value.shapeCode,
          descriptionEn: '',
          descriptionAr: '',
          noOfSeat: this.manualReg.get('vdetails').value.noOfSeat,
          licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate,
          ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType),
          contactPersonPid: this.manualReg.get('pid').value,
          ownerId: '0',
          ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString(),
          ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
          ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
          mobileStationInpsectionServicesDtos: mobileStationInspectionServices
        };
        this.bookingService.submitRegistrationMobileStation(mobileSubmit).subscribe(response => {
          let customerReportDto = {
            requestId: response.items,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
          };
          let inspectorReportDto = {
            requestId: response.items,
            isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
            moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
            reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
          };
          let reports = [customerReportDto, inspectorReportDto];
          this.ssrsPrintServ.printReports(reports);
        });
      } else {
        this.payMobile = this.isMobileStation ? true : false;
        (0,rxjs__WEBPACK_IMPORTED_MODULE_34__.from)(serviceValuesArray).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_35__.concatMap)(service => {
          const serviceRequestData = {
            stationId: this.stationId,
            serviceType: service,
            serviceID: service == 1 ? this.manualReg.get('selectedInsSubType').value.serviceId : service == 2 ? this.manualReg.get('selectedVinStamping').value.serviceId : this.manualReg.get('selectedTanker').value.serviceId,
            contactType: this.manualReg.get('vdetails').value.ownerPidType ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
            contactPersonName: '',
            contactPersonEmail: this.manualReg.get('email').value,
            contactPersonPhone: this.manualReg.get('phone').value.toString(),
            status: 1,
            registrationSource: src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.Booth,
            boothId: 1,
            posId: 1,
            remarks: '',
            requestRefId: this.requestRefId,
            createdBy: this.userId,
            vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
            plateType: parseInt(this.manualReg.get('inputPlateType').value),
            plateNo: this.manualReg.get('inputPlateNo').value
          };
          this.serviceRequest = new src_app_core_models_service_request__WEBPACK_IMPORTED_MODULE_1__.ServiceRequest(serviceRequestData);
          return this.vehicleService.insertServiceRequest(this.serviceRequest).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_30__.map)(data => data.items));
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_36__.switchMap)(items => {
          let serviceRequestId = null;
          /*  if (servicesValues.size == 2 && this.manualReg.get('selectedTanker').value && this.manualReg.get('selectedVinStamping').value) {
              if (counter === 0) {
                this.requestIdSecondService = items;
                serviceRequestId = items;
              } else if (counter === 1) {
                this.requestIdThirdService = items;
                serviceRequestId = items;
              }
            }
            if (servicesValues.size == 2 && this.manualReg.get('selectedTanker').value && this.manualReg.get('selectedInsSubType').value) {
              if (counter === 0) {
                this.requestRefId = items;
                serviceRequestId = items;
              } else if (counter === 1) {
                this.requestIdThirdService = items;
                serviceRequestId = items;
              }
            }
            if (servicesValues.size == 3) {
              if (counter === 0) {
                this.requestRefId = items;
                serviceRequestId = items;
              } else if (counter === 1) {
                this.requestIdSecondService = items;
                serviceRequestId = items;
              } else if (counter === 2) {
                this.requestIdThirdService = items;
                serviceRequestId = items;
              }
            }
                          */
          if (counter === 0) {
            this.requestRefId = items;
            serviceRequestId = items;
          } else if (counter === 1) {
            this.requestIdSecondService = items;
            serviceRequestId = items;
          } else if (counter === 2) {
            this.requestIdThirdService = items;
            serviceRequestId = items;
          }
          counter++;
          const observables = [];
          // Register Vehicle
          if (this.requestRefId && !isRegistered1) {
            const vehicleDetails = {
              requestId: this.requestRefId,
              plateNo: this.manualReg.get('inputPlateNo').value,
              plateType: parseInt(this.manualReg.get('inputPlateType').value),
              vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
              colorId: this.manualReg.get('vdetails').value.colorId ? this.manualReg.get('vdetails').value.colorId : parseInt(this.manualReg.get('selectedColor').value),
              subColorId: this.manualReg.get('vdetails').value.subColorId ? this.manualReg.get('vdetails').value.subColorId : parseInt(this.manualReg.get('selectedSubColor').value),
              categoryId: this.manualReg.get('vcategoryType').value,
              vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId ? this.manualReg.get('vdetails').value.vehicleModelId : parseInt(this.manualReg.get('selectedModel').value),
              manufacturerId: this.manualReg.get('vdetails').value.manufacturerId ? this.manualReg.get('vdetails').value.manufacturerId : parseInt(this.manualReg.get('selectedManufacturer').value),
              manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear ? this.manualReg.get('vdetails').value.manufacturerYear : parseInt(this.manualReg.get('inputManfYear').value),
              moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
              cylinders: this.manualReg.get('vdetails').value.cylinders ? this.manualReg.get('vdetails').value.cylinders : this.manualReg.get('inputCylinders').value.toString(),
              weight: this.manualReg.get('vdetails').value.weight ? this.manualReg.get('vdetails').value.weight : this.manualReg.get('inputWeight').value,
              payloadWeight: this.manualReg.get('vdetails').value.payloadWeight ? this.manualReg.get('vdetails').value.payloadWeight : this.manualReg.get('inputPayloadweight').value,
              shapeCode: this.manualReg.get('vdetails').value.shapeCode ? this.manualReg.get('vdetails').value.shapeCode : " ",
              descriptionEn: '',
              descriptionAr: '',
              noOfSeat: this.manualReg.get('vdetails').value.noOfSeat ? this.manualReg.get('vdetails').value.noOfSeat : this.manualReg.get('inputNbSeats').value,
              licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : this.manualReg.get('expDate').value ? this.manualReg.get('expDate').value : null,
              ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType) ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
              contactPersonPid: this.manualReg.get('pid').value,
              contactPersonEmail: this.manualReg.get('email').value,
              contactPersonPhone: this.manualReg.get('phone').value.toString(),
              ownerId: '0',
              ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString(),
              ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
              ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
              departmentId: 0,
              countryId: this.allowNonQatariList ? this.manualReg.get('nonQatari').value : null,
              createdBy: this.userId
            };
            // Pass the object to the RegisterVehicle constructor
            isRegistered1 = true;
            this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
            observables.push(this.vehicleService.registerVehicle(this.registerVehicle));
          }
          if (this.requestIdSecondService && !isRegistered2) {
            const vehicleDetails = {
              requestId: this.requestIdSecondService,
              plateNo: this.manualReg.get('inputPlateNo').value,
              plateType: parseInt(this.manualReg.get('inputPlateType').value),
              vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
              colorId: this.manualReg.get('vdetails').value.colorId ? this.manualReg.get('vdetails').value.colorId : parseInt(this.manualReg.get('selectedColor').value),
              subColorId: this.manualReg.get('vdetails').value.subColorId ? this.manualReg.get('vdetails').value.subColorId : parseInt(this.manualReg.get('selectedSubColor').value),
              categoryId: this.manualReg.get('vcategoryType').value,
              vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId ? this.manualReg.get('vdetails').value.vehicleModelId : parseInt(this.manualReg.get('selectedModel').value),
              manufacturerId: this.manualReg.get('vdetails').value.manufacturerId ? this.manualReg.get('vdetails').value.manufacturerId : parseInt(this.manualReg.get('selectedManufacturer').value),
              manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear ? this.manualReg.get('vdetails').value.manufacturerYear : parseInt(this.manualReg.get('inputManfYear').value),
              moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
              cylinders: this.manualReg.get('vdetails').value.cylinders ? this.manualReg.get('vdetails').value.cylinders : this.manualReg.get('inputCylinders').value.toString(),
              weight: this.manualReg.get('vdetails').value.weight ? this.manualReg.get('vdetails').value.weight : this.manualReg.get('inputWeight').value,
              payloadWeight: this.manualReg.get('vdetails').value.payloadWeight ? this.manualReg.get('vdetails').value.payloadWeight : this.manualReg.get('inputPayloadweight').value,
              shapeCode: this.manualReg.get('vdetails').value.shapeCode ? this.manualReg.get('vdetails').value.shapeCode : " ",
              descriptionEn: '',
              descriptionAr: '',
              noOfSeat: this.manualReg.get('vdetails').value.noOfSeat ? this.manualReg.get('vdetails').value.noOfSeat : this.manualReg.get('inputNbSeats').value,
              licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : this.manualReg.get('expDate').value ? this.manualReg.get('expDate').value : null,
              ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType) ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
              contactPersonPid: this.manualReg.get('pid').value,
              contactPersonEmail: this.manualReg.get('email').value,
              contactPersonPhone: this.manualReg.get('phone').value.toString(),
              ownerId: '0',
              ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString().replace(/-/g, ''),
              ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
              ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
              departmentId: 0,
              countryId: this.allowNonQatariList ? this.manualReg.get('nonQatari').value : null,
              createdBy: this.userId
            };
            // Pass the object to the RegisterVehicle constructor
            this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
            isRegistered2 = true;
            observables.push(this.vehicleService.registerVehicle(this.registerVehicle));
          }
          if (this.requestIdThirdService && !isRegistered3) {
            const vehicleDetails = {
              requestId: this.requestIdThirdService,
              plateNo: this.manualReg.get('inputPlateNo').value,
              plateType: parseInt(this.manualReg.get('inputPlateType').value),
              vinNo: this.manualReg.get('vdetails').value.vinNo ? this.manualReg.get('vdetails').value.vinNo : this.manualReg.get('inputVinNo').value,
              colorId: this.manualReg.get('vdetails').value.colorId ? this.manualReg.get('vdetails').value.colorId : parseInt(this.manualReg.get('selectedColor').value),
              subColorId: this.manualReg.get('vdetails').value.subColorId ? this.manualReg.get('vdetails').value.subColorId : parseInt(this.manualReg.get('selectedSubColor').value),
              categoryId: this.manualReg.get('vcategoryType').value,
              vehicleModelId: this.manualReg.get('vdetails').value.vehicleModelId ? this.manualReg.get('vdetails').value.vehicleModelId : parseInt(this.manualReg.get('selectedModel').value),
              manufacturerId: this.manualReg.get('vdetails').value.manufacturerId ? this.manualReg.get('vdetails').value.manufacturerId : parseInt(this.manualReg.get('selectedManufacturer').value),
              manufacturerYear: this.manualReg.get('vdetails').value.manufacturerYear ? this.manualReg.get('vdetails').value.manufacturerYear : parseInt(this.manualReg.get('inputManfYear').value),
              moiRegistrationDate: this.manualReg.get('vdetails').value.moiRegistrationDate,
              cylinders: this.manualReg.get('vdetails').value.cylinders ? this.manualReg.get('vdetails').value.cylinders : this.manualReg.get('inputCylinders').value.toString(),
              weight: this.manualReg.get('vdetails').value.weight ? this.manualReg.get('vdetails').value.weight : this.manualReg.get('inputWeight').value,
              payloadWeight: this.manualReg.get('vdetails').value.payloadWeight ? this.manualReg.get('vdetails').value.payloadWeight : this.manualReg.get('inputPayloadweight').value,
              shapeCode: this.manualReg.get('vdetails').value.shapeCode ? this.manualReg.get('vdetails').value.shapeCode : " ",
              descriptionEn: '',
              descriptionAr: '',
              noOfSeat: this.manualReg.get('vdetails').value.noOfSeat ? this.manualReg.get('vdetails').value.noOfSeat : this.manualReg.get('inputNbSeats').value,
              licenseExpiryDate: this.manualReg.get('vdetails').value.licenseExpiryDate ? this.manualReg.get('vdetails').value.licenseExpiryDate : this.manualReg.get('expDate').value ? this.manualReg.get('expDate').value : null,
              ownerType: parseInt(this.manualReg.get('vdetails').value.ownerPidType) ? this.manualReg.get('vdetails').value.ownerPidType : this.manualReg.get('selectedOwnerType').value,
              contactPersonPid: this.manualReg.get('pid').value,
              contactPersonEmail: this.manualReg.get('email').value,
              contactPersonPhone: this.manualReg.get('phone').value.toString(),
              ownerId: '0',
              ownerPid: this.manualReg.get('vdetails').value.ownerPID ? this.manualReg.get('vdetails').value.ownerPid : this.manualReg.get('inputPid').value.toString(),
              ownerPidType: this.manualReg.get('vdetails').value.ownerPidType ? parseInt(this.manualReg.get('vdetails').value.ownerPidType) : parseInt(this.manualReg.get('selectedOwnerType').value),
              ownerName: this.manualReg.get('vdetails').value.ownerName ? this.manualReg.get('vdetails').value.ownerName : this.manualReg.get('inputOwnerName').value,
              departmentId: 0,
              countryId: this.allowNonQatariList ? this.manualReg.get('nonQatari').value : null,
              createdBy: this.userId
            };
            // Pass the object to the RegisterVehicle constructor
            this.registerVehicle = new src_app_core_models_register_vehicle__WEBPACK_IMPORTED_MODULE_0__.RegisterVehicle(vehicleDetails);
            isRegistered3 = true;
            observables.push(this.vehicleService.registerVehicle(this.registerVehicle));
          }
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_37__.forkJoin)(observables).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_30__.map)(() => items));
        }), (0,rxjs__WEBPACK_IMPORTED_MODULE_36__.switchMap)(() => {
          // Payment
          // upload attachments
          const fileInfoArray = this.fileService.getFileData();
          for (const fileInfo of fileInfoArray) {
            if (fileInfo) {
              const formData = new FormData();
              formData.append('requestId', this.requestRefId.toString());
              formData.append('sectionId', '');
              formData.append('defectId', '');
              formData.append('serviceTypeId', this.manualReg.get('selectedServiceType').value);
              formData.append('serviceId', selectedSubType);
              formData.append('mimeType', fileInfo.mimeType);
              formData.append('attachmentType', src_app_core_utilities_enums_system_lookup_value_codes__WEBPACK_IMPORTED_MODULE_4__.SystemLookupValueCodes.SupportDocuments.toString());
              formData.append('createdBy', this.userId.toString());
              formData.append('fileData', fileInfo.fileData, fileInfo.filename);
              this.globalServ.uploadAttachement(formData).subscribe(response => {}, error => {});
            }
          }
          const paymentObservables = [];
          if (this.requestRefId) {
            const paymentDto1 = {
              feesAmount: this.manualReg.get('feesIns').value || 0,
              requestId: this.requestRefId,
              serviceTypeId: serviceValuesArray[0],
              customerId: this.manualReg.get('selectedCust').value == undefined ? null : parseInt(this.manualReg.get('selectedCust').value)
            };
            paymentObservables.push(paymentDto1);
          }
          if (this.requestIdSecondService) {
            const paymentDto2 = {
              feesAmount: this.manualReg.get('feesVin').value ? this.manualReg.get('feesVin').value : this.manualReg.get('feesTanker').value,
              requestId: this.requestIdSecondService,
              serviceTypeId: this.manualReg.get("selectedVinStamping").value != undefined ? serviceValuesArray[1] : serviceValuesArray[2],
              customerId: this.manualReg.get('selectedCust').value == undefined ? null : parseInt(this.manualReg.get('selectedCust').value)
            };
            paymentObservables.push(paymentDto2);
          }
          if (this.requestIdThirdService) {
            const paymentDto3 = {
              feesAmount: this.manualReg.get('feesTanker').value,
              requestId: this.requestIdThirdService,
              serviceTypeId: serviceValuesArray[2],
              customerId: this.manualReg.get('selectedCust').value == undefined ? null : parseInt(this.manualReg.get('selectedCust').value)
            };
            paymentObservables.push(paymentDto3);
          }
          let paymentObservable;
          if (servicesValues.size == 2 && paymentObservables.length > 1 || servicesValues.size == 3 && paymentObservables.length > 2) {
            let payment = {
              paymentMethodId: this.manualReg.get('selectedPayment').value,
              serviceRequestFeesDto: paymentObservables
            };
            this.printReceiptDirectly ? this.isPaymentStarted = false : this.isPaymentStarted = true;
            // this.isPaymentStarted = true;
            if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Card) {
              paymentObservable = this.paymentService.submitPayment(payment).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_31__.timeout)(60000), (0,rxjs__WEBPACK_IMPORTED_MODULE_32__.catchError)(error => {
                if (error.name === 'TimeoutError') {
                  this.isNotReachable = true;
                  this.displayPaymentDetails = 'block';
                }
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_33__.throwError)(error);
              }));
            } else if (this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.Cash || this.manualReg.get('selectedPayment').value == src_app_core_utilities_enums_payment_methods_enum__WEBPACK_IMPORTED_MODULE_2__.PaymentMethods.CreditCustomer) {
              paymentObservable = this.paymentService.submitPayment(payment);
            } else {
              // Handle other payment methods if needed
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_33__.throwError)('Unsupported payment method');
            }
            return paymentObservable.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_28__.tap)(data => {
              paymentResult = data;
              // Handle common logic for all payment methods
              if (data.items) {
                if (!paymentResult.items.isCanceled && !paymentResult.items.isDeviceNotReachable) {
                  this.isSuccess = true;
                  const mainRef = this.requestRefId ? this.requestRefId : this.requestIdSecondService;
                  let customerReportDto = {
                    requestId: this.requestRefId,
                    isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                    moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                    reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
                  };
                  let inspectorReportDto = {
                    requestId: this.requestRefId,
                    isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                    moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                    reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
                  };
                  let reports = [customerReportDto, inspectorReportDto];
                  if (this.requestIdSecondService) {
                    reports.push({
                      requestId: this.requestIdSecondService,
                      isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                      moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                      reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
                    }, {
                      requestId: this.requestIdSecondService,
                      isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                      moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                      reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
                    });
                  }
                  if (this.requestIdThirdService) {
                    reports.push({
                      requestId: this.requestIdThirdService,
                      isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                      moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                      reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.CustomerReport
                    }, {
                      requestId: this.requestIdThirdService,
                      isPrint: src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.print,
                      moduleSource: src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration,
                      reportType: src_app_core_utilities_enums_report_type_enum__WEBPACK_IMPORTED_MODULE_8__.ReportType.InspectorReport
                    });
                  }
                  this.ssrsPrintServ.printReports(reports);
                  this.isNotReachable = false;
                  this.isPayCanceled = false;
                  setTimeout(() => {
                    this.isPaymentStarted = false;
                    this.router.navigate(['/registration/landing']);
                  }, 3000);
                } else {
                  if (paymentResult.items.isCanceled) {
                    this.isPayCanceled = true;
                  }
                  if (paymentResult.items.isDeviceNotReachable) {
                    this.isNotReachable = true;
                  }
                }
              } else {
                this.isNotReachable = true;
                this.isPayCanceled = false;
                this.isSuccess = false;
              }
            }), (0,rxjs__WEBPACK_IMPORTED_MODULE_32__.catchError)(error => {
              // Handle common error logic for all payment methods
              this.isSuccess = false;
              return (0,rxjs__WEBPACK_IMPORTED_MODULE_33__.throwError)(error);
            }));
          } else {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_38__.of)(null);
          }
        })).subscribe(data => {}, error => {});
      }
    }
  }
  resetInfo() {
    this.manualReg.get('displayServiceType').setValue(false);
    this.manualReg.get('vdetails').setValue({});
    this.manualReg.get('inputVinNo').setValue('');
    this.manualReg.get('selectedColor').setValue('');
    this.manualReg.get('selectedSubColor').setValue('');
    this.manualReg.get('selectedVehicleCategory').setValue('');
    this.manualReg.get('selectedModel').setValue('');
    this.manualReg.get('selectedManufacturer').setValue('');
    this.manualReg.get('inputOwnerName').setValue('');
    this.manualReg.get('expDate').setValue('');
    this.manualReg.get('formatExpDate').setValue('');
    this.manualReg.get('inputManfYear').setValue(null);
    this.manualReg.get('inputCylinders').setValue(null);
    this.manualReg.get('inputWeight').setValue(null);
    this.manualReg.get('inputPayloadweight').setValue(null);
    this.manualReg.get('inputNbSeats').setValue(null);
    this.manualReg.get('inputPid').setValue(null);
    this.manualReg.get('phone').setValue('');
    this.manualReg.get('email').setValue('');
    this.manualReg.get('pid').setValue('');
    this.enableCategorySelection = false;
    this.manualReg.get('isReinspection').setValue(false);
    this.isManualEntry = false;
    this.manualReg.get('nonEditable').setValue(true);
    this.isValidType = true;
    this.inspectionFees = null;
    this.vinFees = null;
    this.tankerFees = null;
    this.allowNonQatariList = false;
    this.manualReg.get('nonQatari').setValidators(null);
    this.manualReg.get('nonQatari').updateValueAndValidity();
    this.subscription.unsubscribe();
  }
  clearContact() {
    this.manualReg.get("selectedInsSubType").setValue('');
    this.manualReg.get("selectedVinStamping").setValue('');
    this.manualReg.get('selectedServiceType').setValue('');
    this.isActiveIns = false;
    this.isAtiveReinspection = false;
    this.isActiveVin = false;
    this.isActiveTanker = false;
  }
  sendPayment() {}
  downloadPayment() {
    const mainRef = this.requestRefId ? this.requestRefId : this.requestIdSecondService;
    this.ssrsPrintServ.downloadCustomerReport(mainRef, src_app_core_utilities_enums_print_ssrs_enum__WEBPACK_IMPORTED_MODULE_6__.PrintEnum.save, src_app_core_utilities_enums_module_source_enum__WEBPACK_IMPORTED_MODULE_7__.ModuleSourceEnum.registration);
  }
  ngOnDestroy() {
    this.sharedDataService.setText('');
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function ManualRegistrationComponent_Factory(t) {
    return new (t || ManualRegistrationComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_lookup_values_service__WEBPACK_IMPORTED_MODULE_10__.LookupValuesService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_vehicle_details_service__WEBPACK_IMPORTED_MODULE_11__.VehicleDetailsService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_file_service__WEBPACK_IMPORTED_MODULE_12__.FileService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_26__.Renderer2), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormBuilder), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_29__.Location), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_purchase_service__WEBPACK_IMPORTED_MODULE_13__.PurchaseService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_39__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_39__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_shared_data_service__WEBPACK_IMPORTED_MODULE_14__.SharedDataService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_26__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_shared_lookup_service__WEBPACK_IMPORTED_MODULE_15__.SharedLookupService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_sidenav_service__WEBPACK_IMPORTED_MODULE_16__.SidenavService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_26__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_payment_service__WEBPACK_IMPORTED_MODULE_17__.PaymentService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_global_config_service__WEBPACK_IMPORTED_MODULE_18__.GlobalConfigService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_ssrs_print_service__WEBPACK_IMPORTED_MODULE_19__.SsrsPrintService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_thousand_separator_service__WEBPACK_IMPORTED_MODULE_20__.ThousandSeparatorService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_booked_requests_service__WEBPACK_IMPORTED_MODULE_21__.BookedRequestsService), _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdirectiveInject"](src_app_core_services_inspection_service_service__WEBPACK_IMPORTED_MODULE_22__.InspectionServiceService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵdefineComponent"]({
    type: ManualRegistrationComponent,
    selectors: [["app-manual-registration"]],
    hostBindings: function ManualRegistrationComponent_HostBindings(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("keydown", function ManualRegistrationComponent_keydown_HostBindingHandler($event) {
          return ctx.onKeydown($event);
        });
      }
    },
    decls: 73,
    vars: 23,
    consts: [["autocomplete", "off", 3, "formGroup"], [1, "section", "dashboard"], [1, "row"], [1, "col-lg-12"], [1, "col-12"], [1, "cards"], [1, "card-body", "p-0"], ["id", "accordionExample1", 1, "accordion", "section-accordian"], [1, "accordion-item"], ["id", "headingOne", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search2", 1, "accordion-button"], ["id", "act-search2", "class", "accordion-collapse collapse show", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 4, "ngIf"], [1, "card"], ["id", "accordionExample2", 1, "accordion", "section", "accordian"], ["id", "headingTwo", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search3", 1, "accordion-button"], ["id", "act-search3", "aria-labelledby", "headingTwo", "data-bs-parent", "#accordionExample2", 1, "accordion-collapse", "collapse", "show"], [1, "accordion-body"], [1, "row", "form-fields"], [1, "col-md-6", "col-lg-3"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9+-]/g, '');", "formControlName", "phone", 1, "form-control"], ["class", "error-message", 4, "ngIf"], ["type", "text", "formControlName", "pid", 1, "form-control"], ["type", "text", "formControlName", "email", 1, "form-control"], ["class", "row", 4, "ngIf"], [1, "col-12", "end-btns"], ["id", "mbId", 4, "ngIf"], ["type", "button", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "submit", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 3, "disabled", "click", 4, "ngIf"], ["type", "button", "class", "btn btn-orange", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 3, "disabled", "click", 4, "ngIf"], ["data-bs-backdrop", "static", "id", "PaymentPop", "tabindex", "-1", "aria-labelledby", "exampleModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], ["class", "modal-dialog modal-dialog-centered", 4, "ngIf"], [3, "isPaymentStarted", "email", "isSuccess", "isPayCanceled", "isNotReachable", "requestRefId", "currentDateFormat", "currentTimeFormat", "totalAmountTh", "paymentName", "onCancelEvent", "onCancelFailedEvent", "onDownloadPaymentEvent"], ["data-bs-backdrop", "static", "id", "PrintReceipt", "tabindex", "-1", "aria-labelledby", "errorLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [1, "modal-dialog", "modal-dialog-centered"], [1, "modal-content"], [1, "modal-header"], ["id", "errorLabel", 1, "modal-title"], ["src", "./assets/img/check-circle.svg"], ["type", "button", "data-bs-dismiss", "modal", "aria-label", "Close", 1, "btn-close", 3, "click"], [1, "modal-body"], [1, "pt-lab"], ["data-bs-backdrop", "static", "id", "fileUploadModal", "tabindex", "-1", "aria-labelledby", "fileUploadModalLabel", "aria-hidden", "true", 1, "modal", "fade", "locPop"], [3, "fileUploaded"], ["id", "act-search2", "aria-labelledby", "headingOne", "data-bs-parent", "#accordionExample1", 1, "accordion-collapse", "collapse", "show"], ["for", "myInput"], ["type", "number", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "id", "myInput", "name", "plateNo", "formControlName", "inputPlateNo", 1, "form-control"], ["formControlName", "inputPlateType", 1, "form-control"], [3, "value", 4, "ngFor", "ngForOf"], ["class", "form-control", "formControlName", "selectedVehicleCategory", 3, "ngModelChange", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "vcategory", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedOwnerType", 3, "ngModelChange", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "pidValue", 3, "readonly", 4, "ngIf"], ["type", "text", "class", "form-control", "readonly", "", 3, "value", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputPid", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9-]/g, '');", 3, "input", 4, "ngIf"], ["type", "text", "class", "form-control", 3, "value", "readonly", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "inputOwnerName", "oninput", "this.value = this.value.replace(/[^A-Za-z ]/g, '');", 4, "ngIf"], [4, "ngIf"], ["type", "date", "class", "form-control", "formControlName", "expDate", 3, "value", 4, "ngIf"], ["class", "col-md-6 col-lg-3", 4, "ngIf"], [1, "accordion-body", "border-top"], ["type", "text", "class", "form-control", "formControlName", "inputVinNo", 3, "value", "readonly", 4, "ngIf"], [1, "input-container"], ["type", "text", "class", "form-control", "formControlName", "inputVinNo", 3, "input", 4, "ngIf"], ["class", "text-border", 4, "ngIf"], ["class", "form-control custom-dp", "formControlName", "selectedManufacturer", "notFoundText", "Manufacturer not found", 3, "minTermLength", "closeOnSelect", "clearSearchOnAdd", "clear", "change", 4, "ngIf"], ["class", "form-control custom-dp", "formControlName", "selectedModel", "notFoundText", "Model not found", 3, "minTermLength", "closeOnSelect", "clearSearchOnAdd", "clear", 4, "ngIf"], ["class", "form-control", "formControlName", "inputManfYear", 4, "ngIf"], ["type", "number", "class", "form-control", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "inputCylinders", 4, "ngIf"], ["appThousandSeparator", "", "type", "text", "class", "form-control", 3, "value", "readonly", 4, "ngIf"], ["appThousandSeparator", "", "type", "text", "class", "form-control", "formControlName", "inputWeight", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", 3, "readonly", 4, "ngIf"], ["appThousandSeparator", "", "type", "text", "class", "form-control", "formControlName", "inputPayloadweight", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedColor", 4, "ngIf"], ["type", "text", "class", "form-control", "formControlName", "colorValue", 3, "readonly", 4, "ngIf"], ["class", "form-control", "formControlName", "selectedSubColor", 4, "ngIf"], ["type", "number", "class", "form-control", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "inputNbSeats", 4, "ngIf"], [1, "col-lg-6", "sr-vc"], ["class", "reinspection", 4, "ngIf"], ["class", "woqod", 4, "ngIf"], ["class", "staff-rate", 4, "ngIf"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#fileUploadModal", 1, "btn", "btn-vci"], [1, "bi", "bi-paperclip"], ["id", "fn", 4, "ngIf"], [1, "error-message"], [3, "value"], ["formControlName", "selectedVehicleCategory", 1, "form-control", 3, "ngModelChange"], ["type", "text", "formControlName", "vcategory", 1, "form-control", 3, "readonly"], ["formControlName", "selectedOwnerType", 1, "form-control", 3, "ngModelChange"], ["type", "text", "formControlName", "pidValue", 1, "form-control", 3, "readonly"], ["type", "text", "readonly", "", 1, "form-control", 3, "value"], ["type", "text", "formControlName", "inputPid", "onkeydown", "return !(event.keyCode === 46 || event.keyCode === 69)", "oninput", "this.value = this.value.replace(/[^0-9-]/g, '');", 1, "form-control", 3, "input"], ["type", "text", 1, "form-control", 3, "value", "readonly"], ["type", "text", "formControlName", "inputOwnerName", "oninput", "this.value = this.value.replace(/[^A-Za-z ]/g, '');", 1, "form-control"], ["type", "date", "formControlName", "expDate", 1, "form-control", 3, "value"], ["formControlName", "nonQatari", 1, "form-control"], ["type", "text", "formControlName", "inputVinNo", 1, "form-control", 3, "value", "readonly"], ["type", "text", "formControlName", "inputVinNo", 1, "form-control", 3, "input"], [1, "text-border"], ["formControlName", "selectedManufacturer", "notFoundText", "Manufacturer not found", 1, "form-control", "custom-dp", 3, "minTermLength", "closeOnSelect", "clearSearchOnAdd", "clear", "change"], [1, "dropdown-container"], ["value", "0"], ["class", "form-control custom-select", 3, "value", 4, "ngFor", "ngForOf"], [1, "form-control", "custom-select", 3, "value"], [1, "custom-option"], ["formControlName", "selectedModel", "notFoundText", "Model not found", 1, "form-control", "custom-dp", 3, "minTermLength", "closeOnSelect", "clearSearchOnAdd", "clear"], [1, "custom-select"], ["formControlName", "inputManfYear", 1, "form-control"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "inputCylinders", 1, "form-control"], ["appThousandSeparator", "", "type", "text", 1, "form-control", 3, "value", "readonly"], ["appThousandSeparator", "", "type", "text", "formControlName", "inputWeight", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", 1, "form-control", 3, "readonly"], ["appThousandSeparator", "", "type", "text", "formControlName", "inputPayloadweight", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", 1, "form-control", 3, "readonly"], ["formControlName", "selectedColor", 1, "form-control"], ["type", "text", "formControlName", "colorValue", 1, "form-control", 3, "readonly"], ["formControlName", "selectedSubColor", 1, "form-control"], ["type", "number", "oninput", "this.value = this.value.replace(/[^0-9]/g, '');", "formControlName", "inputNbSeats", 1, "form-control"], [1, "reinspection"], [1, "warn", "warning"], [1, "woqod"], [1, "warn", "warning-green"], [1, "staff-rate"], [1, "switch"], ["type", "checkbox", "formControlName", "isStaffRate", 3, "checked", "change"], [1, "slider", "round"], ["id", "fn"], ["id", "accordionExample3", 1, "accordion", "section-accordian"], ["id", "headingThree", 1, "accordion-header"], ["type", "button", "data-bs-toggle", "collapse", "data-bs-target", "#act-search4", 1, "accordion-button"], ["id", "act-search4", "aria-labelledby", "headingThree", "data-bs-parent", "#accordionExample3", 1, "accordion-collapse", "collapse", "show"], [4, "ngFor", "ngForOf"], ["class", "service-fees", 4, "ngIf"], [1, "outline-radio"], ["type", "radio", "name", "selectedServiceType", "formControlName", "selectedServiceType", 3, "id", "value", "change"], [3, "for"], [3, "src"], [1, "row", "no-gutters"], [1, "st-label"], ["class", "btn-radio", 4, "ngFor", "ngForOf"], [1, "btn-radio"], ["type", "radio", "name", "selectedInsSubType", "formControlName", "selectedInsSubType", 3, "id", "value", "ngModelChange"], ["class", "remove-service", 3, "click", 4, "ngIf"], [1, "remove-service", 3, "click"], ["type", "radio", "name", "selectedInsSubType", 3, "id", "value", "checked"], [1, "service-fees"], ["class", "vin-msg", 4, "ngIf"], ["type", "radio", "name", "selectedVinStamping", "formControlName", "selectedVinStamping", 3, "id", "value", "ngModelChange"], ["type", "radio", "name", "selectedVinStamping", 3, "id", "value", "checked"], [1, "vin-msg"], ["type", "radio", "name", "selectedTanker", "formControlName", "selectedTanker", 3, "id", "value", "ngModelChange"], ["type", "radio", "name", "selectedTanker", 3, "id", "value", "checked"], ["class", "st-label", 4, "ngIf"], ["class", "col-12 end-btns", 4, "ngIf"], ["id", "mbId"], ["type", "submit", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop", 1, "btn", "btn-orange", 3, "disabled", "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PrintReceipt", 1, "btn", "btn-orange", 3, "disabled", "click"], ["id", "exampleModalLabel", 1, "modal-title"], ["class", "payment-info", 4, "ngIf"], ["class", "col-md-6 col-lg-6", 4, "ngIf"], [1, "summery-details"], [1, "col-12", "table-responsive"], [1, "table"], [1, "modal-footer", "text-center"], ["type", "button", "data-bs-dismiss", "modal", 1, "btn", "btn-outline-gray", 3, "click"], ["type", "button", "data-bs-toggle", "modal", "data-bs-target", "#PaymentPop2", 1, "btn", "btn-orange", 3, "disabled", "click"], [1, "payment-info"], [1, "payment-type"], ["type", "radio", "formControlName", "selectedPayment", 3, "id", "value", "ngModelChange"], [1, "col-md-6", "col-lg-6"], [1, "d-flex", "align-items-center"], ["for", "customerSelect", 1, "mr-2"], ["id", "customerSelect", "formControlName", "selectedCust", "notFoundText", "Credit Customer Not Found", 1, "form-control", "custom-dp", 3, "clearSearchOnAdd", "minTermLength", "change"]],
    template: function ManualRegistrationComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](0, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](1, "body")(2, "form", 0)(3, "section", 1)(4, "div", 2)(5, "div", 3)(6, "div", 2)(7, "div", 4)(8, "div", 5)(9, "div", 6)(10, "div", 7)(11, "div", 8)(12, "h2", 9)(13, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](14, " Vehicle Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](15, ManualRegistrationComponent_div_15_Template, 120, 57, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](16, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](17, "div", 2)(18, "div", 4)(19, "div", 12)(20, "div", 6)(21, "div", 13)(22, "div", 8)(23, "h2", 14)(24, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](25, " Contact Details ");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](26, "div", 16)(27, "div", 17)(28, "div", 18)(29, "div", 19)(30, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](31, "Phone No *");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](32, "input", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](33, ManualRegistrationComponent_div_33_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](34, ManualRegistrationComponent_div_34_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](35, "div", 19)(36, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](37, "PID ");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](38, "input", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](39, ManualRegistrationComponent_div_39_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](40, "div", 19)(41, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](42, "Email");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](43, "input", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](44, ManualRegistrationComponent_div_44_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](45, ManualRegistrationComponent_div_45_Template, 18, 6, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](46, ManualRegistrationComponent_div_46_Template, 2, 1, "div", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](47, "div", 2)(48, "div", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](49, ManualRegistrationComponent_span_49_Template, 2, 0, "span", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](50, "button", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_Template_button_click_50_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](51, "Cancel");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](52, ManualRegistrationComponent_button_52_Template, 2, 1, "button", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](53, ManualRegistrationComponent_button_53_Template, 2, 1, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](54, ManualRegistrationComponent_button_54_Template, 2, 1, "button", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](55, "div", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtemplate"](56, ManualRegistrationComponent_div_56_Template, 37, 7, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](57, "payment-transaction-status-modal", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("onCancelEvent", function ManualRegistrationComponent_Template_payment_transaction_status_modal_onCancelEvent_57_listener() {
          return ctx.cancel();
        })("onCancelFailedEvent", function ManualRegistrationComponent_Template_payment_transaction_status_modal_onCancelFailedEvent_57_listener() {
          return ctx.cancelFailed();
        })("onDownloadPaymentEvent", function ManualRegistrationComponent_Template_payment_transaction_status_modal_onDownloadPaymentEvent_57_listener() {
          return ctx.downloadPayment();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](58, "div", 33)(59, "div", 34)(60, "div", 35)(61, "div", 36)(62, "h1", 37);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelement"](63, "img", 38);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](64, " Receipt ");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](65, "button", 39);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("click", function ManualRegistrationComponent_Template_button_click_65_listener() {
          return ctx.cancel();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](66, "div", 40)(67, "label", 41);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵtext"](68, " Printing Receipt... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementStart"](69, "div", 42)(70, "div", 34)(71, "div", 35)(72, "app-file-uploads", 43);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵlistener"]("fileUploaded", function ManualRegistrationComponent_Template_app_file_uploads_fileUploaded_72_listener($event) {
          return ctx.onFileUploaded($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵelementEnd"]()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("formGroup", ctx.manualReg);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.manualReg.get("showScreen").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](18);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.manualReg.get("phone").invalid && ctx.manualReg.get("phone").hasError("required") && ctx.manualReg.get("phone").touched);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.manualReg.get("phone").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.manualReg.get("pid").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.manualReg.get("email").hasError("email") || ctx.manualReg.get("email").hasError("pattern"));
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.manualReg.get("displayServiceType").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.isMobileStation);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.isMobileStation);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.totalInsFees != 0 && (!ctx.isMobileStation || ctx.isMobileStation && ctx.payMobile) && !ctx.isWoqodVehicle && (ctx.isActiveIns && !ctx.isPaidIns || ctx.isActiveIns && ctx.isAtiveReinspection && !ctx.isPaidIns || ctx.isActiveVin && !ctx.isPaidVin || ctx.isActiveTanker && !ctx.isPaidTanker || !ctx.isActiveIns && ctx.selectedMainService.length > 0 || !ctx.isActiveVin && ctx.selectedMainService.length > 0 || !ctx.isActiveTanker && ctx.selectedMainService.length > 0 || !ctx.isActiveIns && !ctx.isActiveVin && !ctx.isActiveTanker) && (ctx.manualReg.get("isStaffRate").value && !ctx.subInsId || ctx.totalInsFees > 0 || !ctx.manualReg.get("isStaffRate").value) && !(ctx.manualReg.get("isReinspection").value && ctx.subInsId && !ctx.selectedMainService.includes(2) && !ctx.selectedMainService.includes(3)));
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", ctx.isMobileStation && !ctx.payMobile || ctx.isWoqodVehicle || ctx.manualReg.get("isStaffRate").value && ctx.subInsId && ctx.totalInsFees == 0 || ctx.isActiveIns && ctx.isAtiveReinspection && ctx.isPaidIns && ctx.totalInsFees == 0 || ctx.manualReg.get("isReinspection").value && ctx.subInsId && !ctx.selectedMainService.includes(2) && !ctx.selectedMainService.includes(3) && ctx.totalInsFees == 0 && ctx.totalInsFees == 0 && !ctx.isActiveIns);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx.isWoqodVehicle && (ctx.isActiveIns && !ctx.isAtiveReinspection && ctx.isPaidIns && ctx.totalInsFees == 0 || ctx.isActiveIns && !ctx.isAtiveReinspection && ctx.isPaidIns && ctx.totalInsFees == 0) && (!ctx.isActiveVin || ctx.isActiveVin && ctx.isPaidVin && ctx.totalInsFees == 0) && (!ctx.isActiveTanker || ctx.isActiveTanker && ctx.isPaidTanker && ctx.totalInsFees == 0));
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("ngIf", !ctx.printReceiptDirectly);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_26__["ɵɵproperty"]("isPaymentStarted", ctx.isPaymentStarted)("email", ctx.manualReg.get("email").value)("isSuccess", ctx.isSuccess)("isPayCanceled", ctx.isPayCanceled)("isNotReachable", ctx.isNotReachable)("requestRefId", ctx.requestRefId)("currentDateFormat", ctx.currentDateFormat)("currentTimeFormat", ctx.currentTimeFormat)("totalAmountTh", ctx.totalAmountTh)("paymentName", ctx.paymentName);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_29__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_29__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_27__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_27__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_27__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_27__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.RadioControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_27__.FormControlName, _shared_file_uploads_file_uploads_component__WEBPACK_IMPORTED_MODULE_23__.FileUploadsComponent, _shared_thousand_separator_directive__WEBPACK_IMPORTED_MODULE_24__.ThousandSeparatorDirective, _shared_payments_popups_payment_transaction_status_modal_payment_transaction_status_modal_component__WEBPACK_IMPORTED_MODULE_25__.PaymentTransactionStatusModalComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_40__.NgSelectComponent, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_40__.NgOptionComponent],
    styles: [".row[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  margin-left: 0px;\r\n  flex-grow: 1;\r\n}\r\n\r\n.section[_ngcontent-%COMP%] {\r\n  flex-grow: 1;\r\n}\r\n\r\n.error-message[_ngcontent-%COMP%] {\r\n  color: red;\r\n  font-style: italic;\r\n}\r\n\r\n.btn-orange[_ngcontent-%COMP%]:disabled {\r\n  background-color: #ef9c3d;\r\n  color: #ffff;\r\n}\r\n\r\ninput[type=\"number\"][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=\"number\"][_ngcontent-%COMP%]::-webkit-outer-spin-button {\r\n  appearance: none;\r\n  margin: 0;\r\n}\r\n\r\n.mr-2[_ngcontent-%COMP%] {\r\n  white-space: nowrap;\r\n  padding: 10px;\r\n}\r\n\r\n#exampleModalLabelfailed[_ngcontent-%COMP%] {\r\n  color: red;\r\n}\r\n\r\n#failedTxt[_ngcontent-%COMP%] {\r\n  text-align: center;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%], .warn[_ngcontent-%COMP%]::before, .warn[_ngcontent-%COMP%]::after {\r\n  position: relative;\r\n  padding: 0;\r\n  margin: 0;\r\n}\r\n\r\n.warn[_ngcontent-%COMP%] {\r\n  font-size: 20px;\r\n  color: transparent;\r\n}\r\n\r\n.warn.warning[_ngcontent-%COMP%] {\r\n  display: inline-block;\r\n\r\n  top: 0.225em;\r\n\r\n  width: 1.15em;\r\n  height: 1.15em;\r\n\r\n  overflow: hidden;\r\n  border: none;\r\n  background-color: transparent;\r\n  border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning[_ngcontent-%COMP%]::before {\r\n  content: \"\";\r\n  display: block;\r\n  top: -0.08em;\r\n  left: 0.0em;\r\n  position: absolute;\r\n  border: transparent 0.6em solid;\r\n  border-bottom-color: rgb(249, 41, 41);\r\n  border-bottom-width: 1em;\r\n  border-top-width: 0;\r\n  box-shadow: #943131 0 1px 1px;\r\n}\r\n\r\n.warn.warning[_ngcontent-%COMP%]::after {\r\n  display: block;\r\n  position: absolute;\r\n  top: 0.3em;\r\n  left: 0;\r\n  width: 100%;\r\n  padding: 0 1px;\r\n  text-align: center;\r\n  font-family: \"Garamond\";\r\n  content: \"!\";\r\n  font-size: 0.65em;\r\n  font-weight: bold;\r\n  color: white;\r\n}\r\n\r\n.reinspection[_ngcontent-%COMP%] {\r\n  background-color: white;\r\n  box-shadow: #943131 0 0.5px 0.5px;\r\n  font-size: small;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%] {\r\n  display: inline-block;\r\n\r\n  top: 0.225em;\r\n\r\n  width: 1.15em;\r\n  height: 1.15em;\r\n\r\n  overflow: hidden;\r\n  border: none;\r\n  background-color: transparent;\r\n  border-radius: 0.625em;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::before {\r\n  content: \"\";\r\n  display: block;\r\n  top: -0.08em;\r\n  left: 0.0em;\r\n  position: absolute;\r\n  border: transparent 0.6em solid;\r\n  border-bottom-color: #448b23;\r\n  border-bottom-width: 1em;\r\n  border-top-width: 0;\r\n  box-shadow: #448b23 0 1px 1px;\r\n}\r\n\r\n.warn.warning-green[_ngcontent-%COMP%]::after {\r\n  display: block;\r\n  position: absolute;\r\n  top: 0.3em;\r\n  left: 0;\r\n  width: 100%;\r\n  padding: 0 1px;\r\n  text-align: center;\r\n  font-family: \"Garamond\";\r\n  content: \"!\";\r\n  font-size: 0.65em;\r\n  font-weight: bold;\r\n  color: white;\r\n}\r\n\r\n.woqod[_ngcontent-%COMP%] {\r\n  background-color: white;\r\n  box-shadow: #448b23 0 0.5px 0.5px;\r\n}\r\n\r\n.remove-service[_ngcontent-%COMP%] {\r\n  position: absolute;\r\n  right: 0;\r\n  top: 0;\r\n  cursor: pointer;\r\n  font-weight: bold;\r\n  color: white;\r\n  font-size: 20px;\r\n  text-align: center;\r\n  width: 100%;\r\n  height: 100%;\r\n  display: inline-block;\r\n}\r\n\r\n.btn-radio[_ngcontent-%COMP%] {\r\n  display: inline-block;\r\n  vertical-align: middle;\r\n  position: relative;\r\n}\r\n\r\n#fn[_ngcontent-%COMP%] {\r\n  font-size: 13px;\r\n  font-style: italic;\r\n}\r\n\r\n.service-fees[_ngcontent-%COMP%] {\r\n  float: right;\r\n  margin-top: 20px;\r\n}\r\n\r\n.custom-select[_ngcontent-%COMP%] {\r\n  background-color: #448b23;\r\n  border: 1px solid rgb(54, 52, 52);\r\n}\r\n\r\n[_nghost-%COMP%]     ng-select.ng-select.custom-dp .ng-dropdown-panel .ng-dropdown-panel-items {\r\n  border: 0.2px solid rgb(54, 52, 52);\r\n  background-color: white;\r\n  padding-left: 15px;\r\n}\r\n\r\n.custom-option[_ngcontent-%COMP%] {\r\n  color: #333;\r\n  cursor: pointer;\r\n  background-color: white;\r\n  padding-top: 5px;\r\n}\r\n\r\n.custom-option[_ngcontent-%COMP%]:hover {\r\n  background-color: rgb(195, 203, 210);\r\n}\r\n\r\n#mbId[_ngcontent-%COMP%] {\r\n  color: #448b23;\r\n  font-style: italic;\r\n}\r\n\r\n.input-container[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  align-items: center;\r\n}\r\n\r\n.input-container[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\r\n  margin-right: 10px;\r\n  \r\n}\r\n\r\n.text-border[_ngcontent-%COMP%] {\r\n  background-color: #ef9c3d;\r\n  border: 1px solid #ef9c3d;\r\n  color: white;\r\n  font-size: smaller;\r\n  width: -moz-fit-content;\r\n  width: fit-content;\r\n}\r\n\r\n#vin-msg[_ngcontent-%COMP%] {\r\n  font-style: italic;\r\n  color: rgb(54, 52, 52)\r\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvbW9kdWxlcy9yZWdpc3RyYXRpb24vY29tcG9uZW50cy9tYW51YWwtcmVnaXN0cmF0aW9uL21hbnVhbC1yZWdpc3RyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsWUFBWTtBQUNkOztBQUVBO0VBQ0UsWUFBWTtBQUNkOztBQUVBO0VBQ0UsVUFBVTtFQUNWLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixZQUFZO0FBQ2Q7O0FBRUE7O0VBR0UsZ0JBQWdCO0VBQ2hCLFNBQVM7QUFDWDs7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQixhQUFhO0FBQ2Y7O0FBRUE7RUFDRSxVQUFVO0FBQ1o7O0FBRUE7RUFDRSxrQkFBa0I7QUFDcEI7O0FBRUE7OztFQUdFLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1YsU0FBUztBQUNYOztBQUVBO0VBQ0UsZUFBZTtFQUNmLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLHFCQUFxQjs7RUFFckIsWUFBWTs7RUFFWixhQUFhO0VBQ2IsY0FBYzs7RUFFZCxnQkFBZ0I7RUFDaEIsWUFBWTtFQUNaLDZCQUE2QjtFQUM3QixzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsY0FBYztFQUNkLFlBQVk7RUFDWixXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLCtCQUErQjtFQUMvQixxQ0FBcUM7RUFDckMsd0JBQXdCO0VBQ3hCLG1CQUFtQjtFQUNuQiw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLFVBQVU7RUFDVixPQUFPO0VBQ1AsV0FBVztFQUNYLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsdUJBQXVCO0VBQ3ZCLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsaUJBQWlCO0VBQ2pCLFlBQVk7QUFDZDs7QUFFQTtFQUNFLHVCQUF1QjtFQUN2QixpQ0FBaUM7RUFDakMsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UscUJBQXFCOztFQUVyQixZQUFZOztFQUVaLGFBQWE7RUFDYixjQUFjOztFQUVkLGdCQUFnQjtFQUNoQixZQUFZO0VBQ1osNkJBQTZCO0VBQzdCLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxjQUFjO0VBQ2QsWUFBWTtFQUNaLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsK0JBQStCO0VBQy9CLDRCQUE0QjtFQUM1Qix3QkFBd0I7RUFDeEIsbUJBQW1CO0VBQ25CLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsVUFBVTtFQUNWLE9BQU87RUFDUCxXQUFXO0VBQ1gsY0FBYztFQUNkLGtCQUFrQjtFQUNsQix1QkFBdUI7RUFDdkIsWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsWUFBWTtBQUNkOztBQUVBO0VBQ0UsdUJBQXVCO0VBQ3ZCLGlDQUFpQztBQUNuQzs7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1IsTUFBTTtFQUNOLGVBQWU7RUFDZixpQkFBaUI7RUFDakIsWUFBWTtFQUNaLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFlBQVk7RUFDWixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsc0JBQXNCO0VBQ3RCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxZQUFZO0VBQ1osZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLGlDQUFpQztBQUNuQzs7QUFFQTtFQUNFLG1DQUFtQztFQUNuQyx1QkFBdUI7RUFDdkIsa0JBQWtCO0FBQ3BCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGVBQWU7RUFDZix1QkFBdUI7RUFDdkIsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0Usb0NBQW9DO0FBQ3RDOztBQUVBO0VBQ0UsY0FBYztFQUNkLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsMERBQTBEO0FBQzVEOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLHlCQUF5QjtFQUN6QixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLHVCQUFrQjtFQUFsQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxrQkFBa0I7RUFDbEI7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5yb3cge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgZmxleC1ncm93OiAxO1xyXG59XHJcblxyXG4uc2VjdGlvbiB7XHJcbiAgZmxleC1ncm93OiAxO1xyXG59XHJcblxyXG4uZXJyb3ItbWVzc2FnZSB7XHJcbiAgY29sb3I6IHJlZDtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbn1cclxuXHJcbi5idG4tb3JhbmdlOmRpc2FibGVkIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWY5YzNkO1xyXG4gIGNvbG9yOiAjZmZmZjtcclxufVxyXG5cclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcclxuaW5wdXRbdHlwZT1cIm51bWJlclwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XHJcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xyXG4gIGFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4ubXItMiB7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcblxyXG4jZXhhbXBsZU1vZGFsTGFiZWxmYWlsZWQge1xyXG4gIGNvbG9yOiByZWQ7XHJcbn1cclxuXHJcbiNmYWlsZWRUeHQge1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLndhcm4sXHJcbi53YXJuOjpiZWZvcmUsXHJcbi53YXJuOjphZnRlciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4ud2FybiB7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZyB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cclxuICB0b3A6IDAuMjI1ZW07XHJcblxyXG4gIHdpZHRoOiAxLjE1ZW07XHJcbiAgaGVpZ2h0OiAxLjE1ZW07XHJcblxyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNjI1ZW07XHJcbn1cclxuXHJcbi53YXJuLndhcm5pbmc6OmJlZm9yZSB7XHJcbiAgY29udGVudDogXCJcIjtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB0b3A6IC0wLjA4ZW07XHJcbiAgbGVmdDogMC4wZW07XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvcmRlcjogdHJhbnNwYXJlbnQgMC42ZW0gc29saWQ7XHJcbiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogcmdiKDI0OSwgNDEsIDQxKTtcclxuICBib3JkZXItYm90dG9tLXdpZHRoOiAxZW07XHJcbiAgYm9yZGVyLXRvcC13aWR0aDogMDtcclxuICBib3gtc2hhZG93OiAjOTQzMTMxIDAgMXB4IDFweDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZzo6YWZ0ZXIge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDAuM2VtO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMCAxcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtZmFtaWx5OiBcIkdhcmFtb25kXCI7XHJcbiAgY29udGVudDogXCIhXCI7XHJcbiAgZm9udC1zaXplOiAwLjY1ZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ucmVpbnNwZWN0aW9uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBib3gtc2hhZG93OiAjOTQzMTMxIDAgMC41cHggMC41cHg7XHJcbiAgZm9udC1zaXplOiBzbWFsbDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbiB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cclxuICB0b3A6IDAuMjI1ZW07XHJcblxyXG4gIHdpZHRoOiAxLjE1ZW07XHJcbiAgaGVpZ2h0OiAxLjE1ZW07XHJcblxyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlci1yYWRpdXM6IDAuNjI1ZW07XHJcbn1cclxuXHJcbi53YXJuLndhcm5pbmctZ3JlZW46OmJlZm9yZSB7XHJcbiAgY29udGVudDogXCJcIjtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICB0b3A6IC0wLjA4ZW07XHJcbiAgbGVmdDogMC4wZW07XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJvcmRlcjogdHJhbnNwYXJlbnQgMC42ZW0gc29saWQ7XHJcbiAgYm9yZGVyLWJvdHRvbS1jb2xvcjogIzQ0OGIyMztcclxuICBib3JkZXItYm90dG9tLXdpZHRoOiAxZW07XHJcbiAgYm9yZGVyLXRvcC13aWR0aDogMDtcclxuICBib3gtc2hhZG93OiAjNDQ4YjIzIDAgMXB4IDFweDtcclxufVxyXG5cclxuLndhcm4ud2FybmluZy1ncmVlbjo6YWZ0ZXIge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDAuM2VtO1xyXG4gIGxlZnQ6IDA7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMCAxcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtZmFtaWx5OiBcIkdhcmFtb25kXCI7XHJcbiAgY29udGVudDogXCIhXCI7XHJcbiAgZm9udC1zaXplOiAwLjY1ZW07XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG4ud29xb2Qge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGJveC1zaGFkb3c6ICM0NDhiMjMgMCAwLjVweCAwLjVweDtcclxufVxyXG5cclxuLnJlbW92ZS1zZXJ2aWNlIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgdG9wOiAwO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4uYnRuLXJhZGlvIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbiNmbiB7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcclxufVxyXG5cclxuLnNlcnZpY2UtZmVlcyB7XHJcbiAgZmxvYXQ6IHJpZ2h0O1xyXG4gIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi5jdXN0b20tc2VsZWN0IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDQ4YjIzO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYig1NCwgNTIsIDUyKTtcclxufVxyXG5cclxuOmhvc3QgOjpuZy1kZWVwIG5nLXNlbGVjdC5uZy1zZWxlY3QuY3VzdG9tLWRwIC5uZy1kcm9wZG93bi1wYW5lbCAubmctZHJvcGRvd24tcGFuZWwtaXRlbXMge1xyXG4gIGJvcmRlcjogMC4ycHggc29saWQgcmdiKDU0LCA1MiwgNTIpO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIHBhZGRpbmctbGVmdDogMTVweDtcclxufVxyXG5cclxuLmN1c3RvbS1vcHRpb24ge1xyXG4gIGNvbG9yOiAjMzMzO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBwYWRkaW5nLXRvcDogNXB4O1xyXG59XHJcblxyXG4uY3VzdG9tLW9wdGlvbjpob3ZlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE5NSwgMjAzLCAyMTApO1xyXG59XHJcblxyXG4jbWJJZCB7XHJcbiAgY29sb3I6ICM0NDhiMjM7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59XHJcblxyXG4uaW5wdXQtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pbnB1dC1jb250YWluZXIgLmZvcm0tY29udHJvbCB7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIC8qIEFkanVzdCBhcyBuZWVkZWQgZm9yIHNwYWNpbmcgYmV0d2VlbiBpbnB1dCBhbmQgYm9yZGVyICovXHJcbn1cclxuXHJcbi50ZXh0LWJvcmRlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2VmOWMzZDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZWY5YzNkO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBmb250LXNpemU6IHNtYWxsZXI7XHJcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG59XHJcblxyXG4jdmluLW1zZyB7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGNvbG9yOiByZ2IoNTQsIDUyLCA1MilcclxufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
  });
}

/***/ }),

/***/ 3024:
/*!********************************************************************!*\
  !*** ./src/app/modules/registration/registraion-base.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistraionBaseComponent": () => (/* binding */ RegistraionBaseComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 60124);


class RegistraionBaseComponent {
  static #_ = this.ɵfac = function RegistraionBaseComponent_Factory(t) {
    return new (t || RegistraionBaseComponent)();
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
    type: RegistraionBaseComponent,
    selectors: [["app-registraion-base"]],
    decls: 1,
    vars: 0,
    template: function RegistraionBaseComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
      }
    },
    dependencies: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet],
    encapsulation: 2
  });
}

/***/ }),

/***/ 47792:
/*!*************************************************************!*\
  !*** ./src/app/modules/registration/registration.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistrationModule": () => (/* binding */ RegistrationModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _registraion_base_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registraion-base.component */ 3024);
/* harmony import */ var _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/landing-page/landing-page.component */ 49103);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../shared/shared.module */ 72271);
/* harmony import */ var _components_manual_registration_manual_registration_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/manual-registration/manual-registration.component */ 82325);
/* harmony import */ var _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-select/ng-select */ 73054);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);











const routes = [{
  path: '',
  redirectTo: 'landing',
  pathMatch: 'full'
}, {
  path: '',
  component: _registraion_base_component__WEBPACK_IMPORTED_MODULE_0__.RegistraionBaseComponent,
  children: [{
    path: 'landing',
    component: _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_1__.LandingPageComponent
  }, {
    path: 'landing/manual-registration',
    component: _components_manual_registration_manual_registration_component__WEBPACK_IMPORTED_MODULE_3__.ManualRegistrationComponent
  }]
}];
class RegistrationModule {
  static #_ = this.ɵfac = function RegistrationModule_Factory(t) {
    return new (t || RegistrationModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: RegistrationModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule.forChild(routes), _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_8__.NgSelectModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_9__.DialogModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](RegistrationModule, {
    declarations: [_registraion_base_component__WEBPACK_IMPORTED_MODULE_0__.RegistraionBaseComponent, _components_landing_page_landing_page_component__WEBPACK_IMPORTED_MODULE_1__.LandingPageComponent, _components_manual_registration_manual_registration_component__WEBPACK_IMPORTED_MODULE_3__.ManualRegistrationComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_7__.RouterModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule, _ng_select_ng_select__WEBPACK_IMPORTED_MODULE_8__.NgSelectModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_9__.DialogModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=792.539e4125a1330fe5.js.map