"use strict";
(self["webpackChunkFAHES"] = self["webpackChunkFAHES"] || []).push([[291],{

/***/ 9849:
/*!*****************************************************************!*\
  !*** ./src/app/core/resolvers/reports/reports-list.resolver.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsListResolver": () => (/* binding */ ReportsListResolver)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 3158);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 591);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_reports_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../services/reports.service */ 4298);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);




class ReportsListResolver {
  constructor(_service, _router) {
    this._service = _service;
    this._router = _router;
  }
  resolve(route, state) {
    return this._service.GetMOIUserReports().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.catchError)(_ => {
      // this._router.navigate(['/error'], {});
      return rxjs__WEBPACK_IMPORTED_MODULE_2__.EMPTY;
    }));
  }
  static #_ = this.ɵfac = function ReportsListResolver_Factory(t) {
    return new (t || ReportsListResolver)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_services_reports_service__WEBPACK_IMPORTED_MODULE_0__.ReportsService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: ReportsListResolver,
    factory: ReportsListResolver.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 4298:
/*!**************************************************!*\
  !*** ./src/app/core/services/reports.service.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsService": () => (/* binding */ ReportsService)
/* harmony export */ });
/* harmony import */ var _utilities_apis__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utilities/apis */ 1603);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _fahes_api_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fahes.api.service */ 5159);




class ReportsService {
  constructor(_baseService) {
    this._baseService = _baseService;
  }
  GetMOIUserReports() {
    // TODO to remove static userId
    const url = `${_utilities_apis__WEBPACK_IMPORTED_MODULE_0__.ApiUrls.Reports.GetMOIUserReports}?${this._baseService.toQueryString({
      userId: 4
    })}`;
    return this._baseService.post(url, null).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(x => x[0].reportFiles));
  }
  static #_ = this.ɵfac = function ReportsService_Factory(t) {
    return new (t || ReportsService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_fahes_api_service__WEBPACK_IMPORTED_MODULE_1__.FahesApiService));
  };
  static #_2 = this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
    token: ReportsService,
    factory: ReportsService.ɵfac,
    providedIn: 'root'
  });
}

/***/ }),

/***/ 7977:
/*!***********************************************************************************************!*\
  !*** ./src/app/features/reports/inspection-reports-form/inspection-reports-form.component.ts ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InspectionReportsFormComponent": () => (/* binding */ InspectionReportsFormComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var src_app_core_services_language_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/language.service */ 7524);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);







const _c0 = ["iframe"];
function InspectionReportsFormComponent_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "iframe", 5, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("src", ctx_r0.safeReportUrl, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeResourceUrl"]);
  }
}
class InspectionReportsFormComponent {
  constructor(_router, _route, sanitizer, _lang) {
    this._router = _router;
    this._route = _route;
    this.sanitizer = sanitizer;
    this._lang = _lang;
    this.isEn = true;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription();
  }
  ngOnInit() {
    this.getReportLink();
    this.getLang();
    const r = localStorage.getItem('report');
    if (r) this.report = JSON.parse(r);
  }
  getLang() {
    const sub = this._lang.currentDir.subscribe(res => {
      this.isEn = res == 'ltr';
    });
    this.subscription.add(sub);
  }
  getReportLink() {
    this._route.queryParams.subscribe(x => {
      if (!x.link) this.back();
      console.log(x);
      this.reportLink = x.link;
      this.safeReportUrl = this.sanitizer.bypassSecurityTrustResourceUrl(x.link + `?rs:Embed=True&rc:toolbar=false}`);
    });
  }
  back() {
    this._router.navigate(['..'], {
      relativeTo: this._route
    });
  }
  ngAfterViewInit() {
    const iframeWindow = this.iframeRef.nativeElement.contentWindow;
    const elementToHide = iframeWindow.document.querySelector('.main.navbar-fixed-top');
    if (elementToHide) {
      elementToHide.style.display = 'none';
    }
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
    localStorage.removeItem('report');
  }
  static #_ = this.ɵfac = function InspectionReportsFormComponent_Factory(t) {
    return new (t || InspectionReportsFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.DomSanitizer), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_core_services_language_service__WEBPACK_IMPORTED_MODULE_0__.LanguageService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
    type: InspectionReportsFormComponent,
    selectors: [["app-inspection-reports-form"]],
    viewQuery: function InspectionReportsFormComponent_Query(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 5);
      }
      if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.iframeRef = _t.first);
      }
    },
    decls: 8,
    vars: 5,
    consts: [[1, "white-block", "position-relative"], [1, "static-actions", "mb-4"], [1, "back-btn", "pointer", 3, "click"], ["class", "report-frame vh-100 overflow-scroll", 4, "ngIf"], [1, "report-frame", "vh-100", "overflow-scroll"], ["frameborder", "0", "allowfullscreen", "", 3, "src"], ["iframe", ""]],
    template: function InspectionReportsFormComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 1)(4, "a", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function InspectionReportsFormComponent_Template_a_click_4_listener() {
          return ctx.back();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "translate");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, InspectionReportsFormComponent_div_7_Template, 3, 1, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.isEn ? ctx.report == null ? null : ctx.report.NameEn : ctx.report == null ? null : ctx.report.NameAr);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" \u2190 ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](6, 3, "Back"), "");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.reportLink);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
    styles: [".report-frame[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n}\n\niframe[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvZmVhdHVyZXMvcmVwb3J0cy9pbnNwZWN0aW9uLXJlcG9ydHMtZm9ybS9pbnNwZWN0aW9uLXJlcG9ydHMtZm9ybS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxZQUFBO0VBQ0EsV0FBQTtBQUVGIiwic291cmNlc0NvbnRlbnQiOlsiLnJlcG9ydC1mcmFtZXtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuaWZyYW1lIHtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgLy8gcG9zaXRpb246IGFic29sdXRlO1xyXG5cclxufVxyXG5cclxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 5750:
/*!*************************************************************************!*\
  !*** ./src/app/features/reports/reports-list/reports-list.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsListComponent": () => (/* binding */ ReportsListComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var src_app_core_services_language_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/core/services/language.service */ 7524);
/* harmony import */ var src_app_core_services_reports_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/core/services/reports.service */ 4298);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);






function ReportsListComponent_a_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "a", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ReportsListComponent_a_1_Template_a_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r3);
      const item_r1 = restoredCtx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r2.openReport(item_r1.reportPath, item_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r0.isEn ? item_r1.entityEdesc : item_r1.entityAdesc);
  }
}
class ReportsListComponent {
  constructor(_route, _lang, _router, _service) {
    this._route = _route;
    this._lang = _lang;
    this._router = _router;
    this._service = _service;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_3__.Subscription();
    this.isEn = true;
  }
  ngOnInit() {
    this.getLang();
    this.getResolved();
  }
  getLang() {
    const sub = this._lang.currentDir.subscribe(res => {
      this.isEn = res == 'ltr';
    });
    this.subscription.add(sub);
  }
  getResolved() {
    const sub = this._route.data.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(el => el['data'])).subscribe(res => {
      if (res) {
        this.items = res;
      }
    });
    this.subscription.add(sub);
  }
  openReport(link, report) {
    localStorage.setItem('report', JSON.stringify({
      NameEn: report.entityEdesc,
      NameAr: report.entityAdesc
    }));
    this._router.navigate([`moi-reports`], {
      relativeTo: this._route,
      queryParams: {
        link
      }
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  static #_ = this.ɵfac = function ReportsListComponent_Factory(t) {
    return new (t || ReportsListComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_language_service__WEBPACK_IMPORTED_MODULE_0__.LanguageService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_core_services_reports_service__WEBPACK_IMPORTED_MODULE_1__.ReportsService));
  };
  static #_2 = this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
    type: ReportsListComponent,
    selectors: [["app-reports-list"]],
    decls: 2,
    vars: 1,
    consts: [[1, "repor-links"], ["class", "pointer p-3", 3, "click", 4, "ngFor", "ngForOf"], [1, "pointer", "p-3", 3, "click"]],
    template: function ReportsListComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ReportsListComponent_a_1_Template, 2, 1, "a", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.items);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf],
    styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"]
  });
}

/***/ }),

/***/ 9482:
/*!************************************************************!*\
  !*** ./src/app/features/reports/reports-routing.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsRoutingModule": () => (/* binding */ ReportsRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _reports_list_reports_list_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports-list/reports-list.component */ 5750);
/* harmony import */ var _inspection_reports_form_inspection_reports_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./inspection-reports-form/inspection-reports-form.component */ 7977);
/* harmony import */ var src_app_core_resolvers_reports_reports_list_resolver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/core/resolvers/reports/reports-list.resolver */ 9849);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);






const routes = [{
  path: '',
  component: _reports_list_reports_list_component__WEBPACK_IMPORTED_MODULE_0__.ReportsListComponent,
  data: {
    title: "Reports"
  },
  resolve: {
    data: src_app_core_resolvers_reports_reports_list_resolver__WEBPACK_IMPORTED_MODULE_2__.ReportsListResolver
  }
}, {
  path: 'moi-reports',
  component: _inspection_reports_form_inspection_reports_form_component__WEBPACK_IMPORTED_MODULE_1__.InspectionReportsFormComponent,
  data: {
    title: "Reports"
  }
}];
class ReportsRoutingModule {
  static #_ = this.ɵfac = function ReportsRoutingModule_Factory(t) {
    return new (t || ReportsRoutingModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: ReportsRoutingModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ReportsRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
  });
})();

/***/ }),

/***/ 6291:
/*!****************************************************!*\
  !*** ./src/app/features/reports/reports.module.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportsModule": () => (/* binding */ ReportsModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _reports_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reports-routing.module */ 9482);
/* harmony import */ var _reports_list_reports_list_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reports-list/reports-list.component */ 5750);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 8699);
/* harmony import */ var _inspection_reports_form_inspection_reports_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./inspection-reports-form/inspection-reports-form.component */ 7977);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var src_app_shared_inputs_input_text_input_text_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/inputs/input-text/input-text.component */ 3661);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primeng/calendar */ 2547);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primeng/dropdown */ 8992);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);










class ReportsModule {
  static #_ = this.ɵfac = function ReportsModule_Factory(t) {
    return new (t || ReportsModule)();
  };
  static #_2 = this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({
    type: ReportsModule
  });
  static #_3 = this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _reports_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReportsRoutingModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, src_app_shared_inputs_input_text_input_text_component__WEBPACK_IMPORTED_MODULE_3__.InputTextComponent, primeng_calendar__WEBPACK_IMPORTED_MODULE_8__.CalendarModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_9__.DropdownModule]
  });
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](ReportsModule, {
    declarations: [_reports_list_reports_list_component__WEBPACK_IMPORTED_MODULE_1__.ReportsListComponent, _inspection_reports_form_inspection_reports_form_component__WEBPACK_IMPORTED_MODULE_2__.InspectionReportsFormComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _reports_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReportsRoutingModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslateModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule, src_app_shared_inputs_input_text_input_text_component__WEBPACK_IMPORTED_MODULE_3__.InputTextComponent, primeng_calendar__WEBPACK_IMPORTED_MODULE_8__.CalendarModule, primeng_dropdown__WEBPACK_IMPORTED_MODULE_9__.DropdownModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=291.d457509b5923ef6b.js.map